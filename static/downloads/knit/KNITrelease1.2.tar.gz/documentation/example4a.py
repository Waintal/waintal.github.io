# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


""" Example 4a: """
print "system with spin and 3D geometry + normalization for many samples"

import copy
import sys
sys.path.append('../')
from libpy import *
from numpy import *
from libpy.spin import *


t=spin(1.)
V=spin(0.)
E=-0.5

""" We parametrize the system with the parameter MYSIZE """
MYSIZE=2 

""" We built the system."""
A=knit.rectangle_S([MYSIZE*7,2*MYSIZE,3*MYSIZE],[0,0,0],t,V)
B=knit.rectangle_S([3*MYSIZE,10*MYSIZE, 3*MYSIZE],[2*MYSIZE,0,0],t,V)
C=knit.rectangle_S([MYSIZE*7,2*MYSIZE,3*MYSIZE],[0,8*MYSIZE,0],t,V)

A.coller(B)
A.coller(C)

""" We built the leads."""
interface_contact1=knit.rectangle_S([MYSIZE*7,1,3*MYSIZE],[0,0,0],t,V)
interface_contact2=knit.rectangle_S([MYSIZE*7,1,3*MYSIZE],[0,10*MYSIZE-1,0],t,V)

lead1=knit.unreservoirN_S(interface_contact1,t)
lead2=knit.unreservoirN_S(interface_contact2,t)

""" We create the full system with the electrodes"""
mySystem3D=knit.systemtotal_S(A,lead1)
mySystem3D.addlead(lead2)

""" We plot the system to make sure it looks as it should."""
import os
fName=sys.argv[0]
#print ".. printing system.."
#system.visu3D(mySystem3D,fName+".system", 0.1)
#writing .eps and .pdf files with names "argv[0]".systeme

""" Introduction of impurity """
yMax = 10*MYSIZE # the total height of our system
""" Bottom part of the system : Py, with a disorder on V and t given by W1, W2, Wso, eta, ksi;
Top part : Cu, with a disorder on V, given by W1 and hi """
W=0.45
W1= 1.3
W2= 4.2
Wso = 0.0
"""hi = -0.5 .. 0.5; 
Re(ksi) = -0.5 .. 0.5; Im(ksi) = -0.5 .. 0.5;
Re(eta) = -0.5 .. 0.5; Im(eta) = -0.5 .. 0.5;
"""

def putDisorder(sample, rs):
   import random
   random.seed(rs)
   for i in range(sample.fsize()):
	y = sample.coord(i,1) # y-coordinate of the site
        if (0<= y < yMax/2):	  # bottom part - Py
		hi = random.random()-0.5
		Vi_new = spin();
		Vi_new.set(0,0, hi*W1)
		Vi_new.set(0,1, 0)
		Vi_new.set(1,0, 0)
		Vi_new.set(1,1, hi*W2)
		sample.put_Hdiag(i,Vi_new)
		ksiRe = random.random()-0.5
		ksiIm = random.random()-0.5
		etaRe = random.random()-0.5
		etaIm = random.random()-0.5
		for z in range(sample.fzmax()):
			ti_new = spin()
			ti_new.set(0,0, Wso*(ksiRe+ksiIm*1.J))
			ti_new.set(0,1,(-1)*(Wso*etaRe-etaIm*1.J))
			ti_new.set(1,0, Wso*(ksiRe+ksiIm*1.J))
			ti_new.set(1,1,Wso*(ksiRe-ksiIm*1.J))
			ti_fin = spin(1.)+ti_new
			sample.put_Hopp(i,z,ti_fin)
		#print "Py: ", y, mySystem3D.get_Hdiag(i)(0,0).real, mySystem3D.get_Hopp(i,0)(0,0).real
	else:			 # bottom part - Cu
		hi = random.random()-0.5
		sample.put_Hdiag(i,spin(W*hi))
		#print "Cu: ", y, mySystem3D.get_Hdiag(i)(0,0).real, mySystem3D.get_Hopp(i,0)(0,0).real
	#return sample

sampleset = [] #list of samples
results = []   #list of results
ssize = 20  #sample set size

""" Calculation of spin accumulation """
MYDATA=[]

def getSpinAccum1(li):
	zmax = mySystem3D.fzmax()	
	accum = zeros((yMax,2),complex)
	res = zeros(yMax, complex)  

	for k in range(ssize):
		putDisorder(mySystem3D, 646+k)
		print "Sample ", k, "out of", ssize, "is ready.."

		results = obs.knitANDsew_S(mySystem3D,E)
		print "solver for sample ", k, "is done.."

		for i in range(mySystem3D.fsize()):
			y = mySystem3D.coord(i,1) # y-coordinate of the site
			Gii=results.getG_lesser(i,zmax,li)(0,0)-results.getG_lesser(i,zmax,li)(1,1)
			accum[y,0]+=Gii
			accum[y,1]+=1
		for j in range(yMax): 
			res[j]= res[j] + accum[j,0]/accum[j,1] 
			#print "y=", j, "; cross-section:",accum[j,1].real, "; delta_mu=", res[j].imag
			#MYDATA.append([j,res[j].imag])
		print "accumulator for sample ", k, "is done.." 
	return res




def normalization(aSet):
	for ii in range(yMax):
   	     aSet[ii] = aSet[ii]/ssize
	     MYDATA.append([ii,aSet[ii].imag])
	   #  print "y=", ii, "normalized accum:", aSet[ii]
	print "normalization finished.."
		

######## MAIN ########################################
lead=1
print "Accumulation: lead = ", lead
rrr = getSpinAccum1(lead)
normalization(rrr)

print "We plot the datas using PyX"
from pyx import *

g =graph.graphxy(width=10,x=graph.axis.linear(title="$Y$"),y=graph.axis.linear(title="$(\mu\uparrow - \mu\downarrow)$"))
g.plot(graph.data.list(MYDATA,x=1,y=2),[graph.style.line([style.linewidth.Thick])])
g.writePDFfile(fName+".accum5_20samples")


