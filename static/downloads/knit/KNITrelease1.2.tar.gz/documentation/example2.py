# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


""" Example 2: """
print " conductance of a 4 shape system with impurity"

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E and number of sites MYSIZE)"

t=knit.scalarM(1.)
V=knit.scalarM(0.)
E=-0.5

""" We parametrize the system with the parameter MYSIZE """
MYSIZE=2 

print "3. We built the system."
MyA=knit.rectangle([MYSIZE*8,4*MYSIZE],[0,3*MYSIZE],t,V)
MyB=knit.rectangle([3*MYSIZE,7*MYSIZE],[5*MYSIZE,0],t,V)
MyC=knit.rectangle([2*MYSIZE,6*MYSIZE],[0,3*MYSIZE],t,V)

MyA.coller(MyB)
MyA.coller(MyC)

print "4. We built the leads."
interface_contact1=knit.rectangle([1,MYSIZE*6],[0,MYSIZE*3],t,V)
interface_contact2=knit.rectangle([MYSIZE*3,1],[5*MYSIZE,0],t,V)
interface_contact3=knit.rectangle([1,MYSIZE*4],[8*MYSIZE -1,MYSIZE*3],t,V)

lead1=knit.unreservoirN(interface_contact1,t)
lead2=knit.unreservoirN(interface_contact2,t)
lead3=knit.unreservoirN(interface_contact3,t)

print "5. We create the full system with the electrodes"
MyABCwithLeads=knit.systemtotal(MyA,lead1)
"""contact1 is added to FINITE system"""
MyABCwithLeads.addlead(lead2)
MyABCwithLeads.addlead(lead3)

#Makes a hole at position (posX,posY) of the size w x h
def makeHole(posX,posY, w, h):
	for x in range(w):
		for y in range(h):
			MyABCwithLeads.move_site([MyABCwithLeads.indice([posX+x,7*MYSIZE +y-1]),MyABCwithLeads.indice([posX+x-1,7*MYSIZE +y])],t,V,[4*MYSIZE+x,7*MYSIZE+y],MyABCwithLeads.indice([x+posX,y+posY]))

print "5a. We move sites from the center to the side to make a hole"
makeHole(4*MYSIZE, 5*MYSIZE-1, 2*MYSIZE, MYSIZE)

print "6. We plot the system to make sure it looks as it should."
import os
s=sys.argv[0]
system.visu2D(MyABCwithLeads,s+".system")


#writing .eps and .pdf files with names "argv[0]".systeme
os.system("gv "+s+".systeme.eps & ")
#running of applications which show pictures.

print "7. We define a function to introduce an impurity in the system"
def myDisorder(W):
   import random
   random.seed(666)
   for ix in range(2*MYSIZE):
       for iy in range(2*MYSIZE):
           i=MyABCwithLeads.indice([ix+3*MYSIZE,iy+3*MYSIZE])
	   MyABCwithLeads.put_Hdiag(i,knit.scalarM(W*(random.random()-0.5)))

print "8. We calculate the conductance as a function of impurity strength W."
MYDATA=[]
for i in range(10):
     W=(float(i)/10)*2.
     myDisorder(W)
     G_MATRIX=obs.conductance_matrix(MyABCwithLeads,E)
     MYDATA.append([W,G_MATRIX[2,1],G_MATRIX[0,1], G_MATRIX[0,2]]) # conductance from the lead 2 to the lead 3 (bottom to right) and from 2 to 1 (bottom to left) 
     print W,G_MATRIX[2,1],G_MATRIX[0,1],G_MATRIX[0,2]


print "9. We plot the datas using PyX"
from pyx import *

g =graph.graphxy(width=10,x=graph.axis.linear(title="$W$"),y=graph.axis.linear(title="$G$"))
g.plot(graph.data.list(MYDATA,x=1,y=2),[graph.style.line([style.linewidth.Thick])])
g.plot(graph.data.list(MYDATA,x=1,y=3),[graph.style.line([style.linewidth.Thick,style.linestyle.dashed])])
g.plot(graph.data.list(MYDATA,x=1,y=4),[graph.style.line([style.linewidth.Thin,style.linestyle.dashed])])

g.writeEPSfile(s+".conductance")
g.writePDFfile(s+".conductance")
os.system("gv "+s+".conductance.eps & ")

