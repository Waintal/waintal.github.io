# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################



print "A SIMPLE CALCULATION: conductance of a 7 shape system."

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E )"

t=knit.scalarM(1.)
V=knit.scalarM(0.)
E=-0.5
""" Here we specify intercite coupling and oncite energies. Here they are scalar but could be matrices
for super conductors and  for spin systems """
print "3. We built the system."
MyA=knit.rectangle([8,4], [0,3],t,V)
MyB=knit.rectangle([3,7],[5,0],t,V)
"""Here we stik system by adding new pieces to the main part"""

MyA.coller(MyB)

print "4. We built the leads."
interface_contact1=knit.rectangle([1,4],[0,3],t,V)
interface_contact2=knit.rectangle([3,1],[5,0],t,V)

lead1=knit.unreservoirN(interface_contact1,t)
lead2=knit.unreservoirN(interface_contact2,t)

print "5. We create the full system with the electrodes"
MySystemwithLeads=knit.systemtotal(MyA,lead1)
"""lead1 is added to FINITE system"""
MySystemwithLeads.addlead(lead2)
"""lead2 is added to INFINITE system """

print "6. We plot the system to make sure it looks as it should."
import os
s=sys.argv[0]
"""
argv = array of arguments of python input for example  for command python xy.py 10 argv={xy.py,10} and
argv[0]=xy.py
"""
system.visu2D(MyA,s+".MyA")
system.visu2D(MySystemwithLeads,s+".systeme")

print "6a. We shift the system on the vector [2, 3] and plot the shifted system to make sure it looks as it should."

MySystemwithLeads.shift_system([2, 3])
system.visu2D(MySystemwithLeads,s+".systeme_shifted")

#writing .eps and .pdf files with names "argv[0]".systeme
os.system("gv "+s+".systeme.eps & ")
#running of applications which show pictures.

print "7. We calculate the conductance as a function of energy E."
for i in range(10):
    E=(float(i)/10)*2.-1.99
    G_MATRIX=obs.conductance_matrix(MySystemwithLeads,E) #here is hard core calculation!!!!!
     
    print E,G_MATRIX[1,0]
"""
everything what TAB-ed is inside the cycsystem.visu2D(MyABCwithLeads,s+".systeme")le
"""
