#!/usr/bin/python
import sys
import os

TEXTE=[]
TEXTE.append("#############################################################")
TEXTE.append(" KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #")
TEXTE.append(" DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #")
TEXTE.append(" SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #")
TEXTE.append("#############################################################")


name=sys.argv[1]
ends=name.split(".")[1]
com="ARGH"
if ends == "py": com="#"
if ends == "C": com="//"
if ends == "h": com="//"
if ends == "cxx": com="//"
if com =="ARGH":
    print com
    exit()

f=open(name)
lines=f.readlines()
f.close()

f=open(name,"w")
for a in TEXTE:print >>f,com,a
print >>f,"\n"
for a in lines:print >>f,a,
f.close()

