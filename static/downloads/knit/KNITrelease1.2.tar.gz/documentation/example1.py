# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


""" Example 1: """
print "A SIMPLE CALCULATION: conductance of a 4 shape system."

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E and number of sites MYSIZE)"

"""
it would be good to have somewhere description of all main classes and variables:
scalarM
rectangle
coller
etc.

"""

t=knit.scalarM(1.)
V=knit.scalarM(0.)
E=-0.5

""" We parametrize the system with the parameter MYSIZE """
MYSIZE=1 #system size
""" MYSIZE = 2 -> is equivalent to x2 zooming in"""

print "3. We built the system."
MyA=knit.rectangle([MYSIZE*8,4*MYSIZE],[0,3*MYSIZE],t,V)
MyB=knit.rectangle([3*MYSIZE,7*MYSIZE],[5*MYSIZE,0],t,V)
MyC=knit.rectangle([2*MYSIZE,6*MYSIZE],[0,3*MYSIZE],t,V)


print "We plot the system to make sure it looks as it should."
import os
s=sys.argv[0]

system.visu2D(MyA,s+".MyA1")

print "3a. We glue B on A "
MyA.coller(MyB)

print "3b. We glue C on AB "
MyA.coller(MyC)
system.visu2D(MyA,s+".MyA1")

print "3c. We add one site."
MyA.add_site([4,38],t,V,[4*MYSIZE,2*MYSIZE])

#print "We plot the system to make sure it looks as it should."
#system.visu2D(MyA,s+".MyA2")

print "3d. We move one site."
MyA.move_site([27],t,V,[3*MYSIZE,7*MYSIZE],13)

#print "We plot the system to make sure it looks as it should."
#system.visu2D(MyA,s+".MyA3")

print "4. We built the leads."
interface_contact1=knit.rectangle([1,MYSIZE*6],[0,MYSIZE*3],t,V)
interface_contact2=knit.rectangle([MYSIZE*3,1],[5*MYSIZE,0],t,V)

lead1=knit.unreservoirN(interface_contact1,t)
lead2=knit.unreservoirN(interface_contact2,t)

print "5. We create the full system with the electrodes"
MyABCwithLeads=knit.systemtotal(MyA,lead1)
"""contact1 is added to FINITE system"""
MyABCwithLeads.addlead(lead2)

print "6. We plot the system to make sure it looks as it should."
system.visu2D(MyABCwithLeads,s+".system")


#writing .eps and .pdf files with names "argv[0]".systeme
os.system("gv "+s+".systeme.eps & ")
#running of applications which show pictures.

print "7. We calculate the conductance as a function of energy E."
for i in range(10):
    E=(float(i)/10)*2.-1.99
    G_MATRIX=obs.conductance_matrix(MyABCwithLeads,E) #here is hard core calculation!!!!!
     
    print E,G_MATRIX[1,0]
"""
everything what TAB-ed is inside the cycsystem.visu2D(MyABCwithLeads,s+".systeme")le
"""
