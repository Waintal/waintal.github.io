# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


""" Example 5: """
print "system with spin and 3D geometry and spin rotation"

import sys
sys.path.append('../')
from libpy import *
from numpy import *
from libpy.spin import *


t=spin(1.)
V=spin(0.)
E=-0.5

""" We parametrize the system with the parameter MYSIZE """
MYSIZE=2 

""" We built the system."""
A=knit.rectangle_S([MYSIZE*7,2*MYSIZE,3*MYSIZE],[0,0,0],t,V)
B=knit.rectangle_S([3*MYSIZE,10*MYSIZE, 3*MYSIZE],[2*MYSIZE,0,0],t,V)
C=knit.rectangle_S([MYSIZE*7,2*MYSIZE,3*MYSIZE],[0,8*MYSIZE,0],t,V)

A.coller(B)
A.coller(C)

""" We built the leads."""
interface_contact1=knit.rectangle_S([MYSIZE*7,1,3*MYSIZE],[0,0,0],t,V)
interface_contact2=knit.rectangle_S([MYSIZE*7,1,3*MYSIZE],[0,10*MYSIZE-1,0],t,V)

lead1=knit.unreservoirN_S(interface_contact1,t)
lead2=knit.unreservoirN_S(interface_contact2,t)


""" We create the full system with the electrodes"""
mySystem3D=knit.systemtotal_S(A,lead1)
mySystem3D.addlead(lead2)

import os
fileN=sys.argv[0]

""" Introduction of impurity """
yMax = 10*MYSIZE # the total height of our system
""" Bottom part Py1, upper part Py2 of the system : Py, with a disorder on V and t given by W1, W2, Wso, eta, ksi;
Middle part : Cu, with a disorder on V, given by W1 and hi """

wCu = 2*MYSIZE #width of the Cu part
wPy1= (yMax-wCu)/2
wPy2= yMax-wPy1-wCu

W=0.45
W1= 1.3
W2= 4.2
Wso = 0.0
"""hi = -0.5 .. 0.5; 
Re(ksi) = -0.5 .. 0.5; Im(ksi) = -0.5 .. 0.5;
Re(eta) = -0.5 .. 0.5; Im(eta) = -0.5 .. 0.5;
"""

def putDisorder():
   import random
   random.seed(666)
   for i in range(mySystem3D.fsize()):
	y = mySystem3D.coord(i,1) # y-coordinate of the site
        if (y >= wPy1 and y < wPy1+wCu):	  #  Cu
		hi = random.random()-0.5
		mySystem3D.put_Hdiag(i,spin(W*hi))
		#print "Cu: ", y, mySystem3D.get_Hdiag(i)(0,0).real, mySystem3D.get_Hopp(i,0)(0,0).real
	else:					  # Py
		hi = random.random()-0.5
		Vi = mySystem3D.get_Hdiag(i)
		Vi_new = spin();
		Vi_new.set(0,0, hi*W1)
		Vi_new.set(0,1, 0)
		Vi_new.set(1,0, 0)
		Vi_new.set(1,1, hi*W2)
		mySystem3D.put_Hdiag(i,Vi_new)
		ksiRe = random.random()-0.5
		ksiIm = random.random()-0.5
		etaRe = random.random()-0.5
		etaIm = random.random()-0.5
		for z in range(mySystem3D.fzmax()):
			ti = mySystem3D.get_Hopp(i,z)
			ti_new = spin()
			ti_new.set(0,0, Wso*(ksiRe+ksiIm*1.J))
			ti_new.set(0,1,(-1)*(Wso*etaRe-etaIm*1.J))
			ti_new.set(1,0, Wso*(ksiRe+ksiIm*1.J))
			ti_new.set(1,1,Wso*(ksiRe-ksiIm*1.J))
			ti_fin = spin(1.)+ti_new
			mySystem3D.put_Hopp(i,z,ti_fin)
		#print "Py: ", y, mySystem3D.get_Hdiag(i)(0,0).real, mySystem3D.get_Hopp(i,0)(0,0).real
	

putDisorder()

#print " We plot the 2D potential to make sure it looks correct."
#def potential(i):
#     return mySystem3D.get_Hdiag(i)(0,0).real



"""1. Calculation of  conductance matrix - no rotation"""
#s=obs.conductance_matrix_S(mySystem3D,E)
#print "Conductance matrix (no rotation):", s[1,0]


def RotatePy1(sample, angle):
   for i in range(mySystem3D.fsize()):
	y = sample.coord(i,1) # y-coordinate of the site
        if (y >= 0 and y < wPy1):	  #  Bottom part of Py
           old_Hd = sample.get_Hdiag(i)
           new_Hd =rotate(old_Hd,[0.,1.,0.],angle)
	   sample.put_Hdiag(i,new_Hd)

def RotatePy2(sample, angle):
   for i in range(sample.fsize()):
	y = sample.coord(i,1) # y-coordinate of the site
        if (y >= wPy1+wCu and y < yMax):	  #  Upper part of Py
           old_Hd = sample.get_Hdiag(i)
           new_Hd =rotate(old_Hd,[0.,1.,0.],angle)
	   sample.put_Hdiag(i,new_Hd)

def RotatePyS(sample, angle):
   for i in range(sample.fsize()):
	y = sample.coord(i,1) # y-coordinate of the site
        if (y >= 0 and y < wPy1) or (y >= wPy1+wCu and y < yMax):	  #   Py
           old_Hd = sample.get_Hdiag(i)
           new_Hd =rotate(old_Hd,[0.,1.,0.],angle)
           sample.put_Hdiag(i,new_Hd)
	

def RotatePy(sample, angle1, angle2):
   for i in range(sample.fsize()):
	y = sample.coord(i,1) # y-coordinate of the site
        if (y >= 0 and y < wPy1):	  #  Bottom part of Py
           old_Hd1 = sample.get_Hdiag(i)
           new_Hd1 =rotate(old_Hd1,[0.,1.,0.],angle1)
           sample.put_Hdiag(i,new_Hd1)
	elif  (y >= wPy1+wCu and y < yMax):	  #  Upper part of Py
           old_Hd2 = sample.get_Hdiag(i)
           new_Hd2 =rotate(old_Hd2,[0.,1.,0.],angle2)
           sample.put_Hdiag(i,new_Hd2)

"""2. Calculation of  conductance matrix with synchronous rotation"""

def syRot(angle):
   RotatePyS(mySystem3D,angle)
   s=obs.conductance_matrix_S(mySystem3D,E)
   print "Conductance matrix (synchronous rotation on", an1*180./pi, ":", s[1,0]

#syRot(an1)

"""3. Calculation of  conductance matrix with rotation of the bottom magnet"""
mm=10
sample = mySystem3D
""" We turn the bottom magnet mm times on the pi/mm angle to obtain the complete rotation oon the angle pi;
we make mm intermediate measurements and plot them """
MYDATA=[]
phi = 0
d_phi=(float(1.)/mm)*pi #delta_phi

print "Conductance matrix (rotation of the bottom magnet)"
s=obs.conductance_matrix_S(sample,E)
MYDATA.append([phi, phi*180./pi,s[1,0]])
print "phi=", phi*180./pi, s[1,0]

for i in range(mm):
    phi+=d_phi
    RotatePy1(sample, d_phi)
    s=obs.conductance_matrix_S(sample,E)
    MYDATA.append([phi, phi*180./pi,s[1,0]])
    print "phi=", phi*180./pi, s[1,0]

print "Plot the graph.."
from pyx import *

g =graph.graphxy(width=10,x=graph.axis.linear(title="$\phi$"),y=graph.axis.linear(title="$g h/e^2$"))
g.plot(graph.data.list(MYDATA,x=1,y=3),[graph.style.line([style.linewidth.Thick])])
g.writePDFfile(fileN+".cond")






