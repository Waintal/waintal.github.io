
**************************************************************************************************************

This is a short help to compile knit on MacOS

**************************************************************************************************************

I) Install Xcode from the system DVD
	Check that libblas.dylib and liplapack.dylib are installed in /usr/lib
	you can install libmkl_lapack.dylib from commertial C++ compiler for Mac from intel cite.
II) Using macports install
	1) python: sudo port install python
	2) Blitz: sudo port install blitz
	3) swig: sudo port install swig 

III) install Numeric (an old Python package, numpy will not work)
IV) install PyX
**************************************************************************************************************
Changes in knit package:

1) file:  interface/knit_Python_Data.C
in the header add new line:

typedef unsigned int uint;

2) file: interface/knit_system.h
static int const not_lead=-1;
TO
static char const not_lead=-1;

**************************************************************************************************************
The most important thing is to write correct paths for
Python.h
Numeric/arrayobject.h
blitz/array.h

modifying knit_Makefile:
#------------------
# DIRECTIVES FOR MACBOOK at CEA
ifeq ($(strip $(HOST)),drecam0063.saclay.cea.fr)
CC= g++
PYTHDR=/Library/Frameworks/Python.framework/Versions/2.5/include/python2.5 # Numeric package must be installed here. Python.h is here; Numeric/arrayobject.h is here
BLZHDR=/opt/local/var/macports/software/blitz/0.9_0/opt/local/include      # blitz/array.h  is here
BLZLIB=/opt/local/var/macports/software/blitz/0.9_0/opt/local/lib          # libblitz.dylib is here.

# Use -lgfortran instead of obsolete -lg2c
LFLAGS = -L$(HOME)  --export-dynamic  -framework Accelerate -llapack -lblas  -lgfortran -lpython2.5   -L$(BLZLIB) -lblitz -dynamiclib -flat_namespace    
endif
#--------------------

**************************************************************************************************************
COMPILE

make python

**************************************************************************************************************
run test:

cd examplespy/
python benchmark_bar.py

IT WORKS!

but it is 3 times slower than on linux even with mkl libraries :( 