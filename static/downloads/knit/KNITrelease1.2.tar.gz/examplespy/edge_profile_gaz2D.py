# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


#!/usr/bin/python

## calculate EDGE channel profile for gaz 2D

import sys
import os

sys.path.append('../')
sys.path.append('pyx/')
sys.path.append('libpy/')
from libpy import *
from cmath import *


V=knit.scalarM(1.)
Hd=knit.scalarM(4.*V(0,0))
M=int(sys.argv[1])
N=10
# sample of n_s(without spin)=0.5*10**10 cm**(-2); calL=1 micrometre; mu= 1O**6 cm**2/Vs
# calN=4*pi*n_s*calL^2
# calG=E/W^2=h/e/24*mu*n_s
# E=calN/M**2
# phi=E/2./channels

# number of Landau channels
channels=2
A1=100.
phi=A1/M**2
E=2*channels*phi

## density in m**-2
def real_dens(B=14):
    e=1.6e-19
    h=6.63e-34
    return abs(e/h*B*channels)
## lattice step in meters
def step(B=14):
    e=1.6e-19
    hbar=1.055e-34
    length=sqrt(A1*hbar/e/B)
    return abs(length/M)

## desorder corresponding to mobility mu and magnetic field B
def myW(B=14,mu=1.e2):
    return abs(1./M*sqrt(3.*A1/B/mu))


def f_range(xmin,xmax,steps=100):
   return [(xmin+float(xmax-xmin)*x/steps) for x in range(steps+1)]

def change_edge(W):
    for i in range(ring.fsize()):
        x,y=ring.coord(i,0),ring.coord(i,1)
        ## # change on site energy
        ## Hdiag_initial=ring.get_Hdiag(i)
        ## h2put= Hdiag_initial(0,0)*(1.+W/(x+1.)**2)
        ## ring.put_Hdiag(i,knit.scalarM(h2put))
        # change hopping
        for z in range(ring.fzmax()):
            if  ring.voisin(i,z) == -1 : continue
            V=ring.get_Hopp(i,z)(0,0)*(1.-W/(x**2+1.))
            ring.put_Hopp(i,z,knit.scalarM(V))
 
print "# E=",E, " W=", myW()," n_s=",real_dens()," b=",step()

# validity TEST
if E>1. or phi>0.5:
    print "WARNING: network influence detected => increase resolution M"
    sys.exit()

# system construction
a=knit.rectangle([M,N],[0,0],V,Hd)

# WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
contacts=[]
contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V,0.),"DOWN"])
contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,N-1],V,Hd),V,0.),"UP"])

ring=knit.systemtotal(a,contacts[0][0])
for i in range(len(contacts)-1):
    ring.addlead(contacts[i+1][0])

## s=sys.argv[0].split(".")[0]
## system.visu2D(ring,s+".systeme")
## os.system("acroread "+s+".systeme.pdf & ")
## sys.exit()

#gas2D.set_white_disorder(ring,myW(),Hd,666666)
change_edge(0.5)
# sewing
gas2D.add_magnetic_flux(ring,contacts,phi)
resultats=obs.knitANDsew(ring,E)

# EDGE CURRENT AND DENSITY PROFILE
M_init=M*(N/2)
for i in range(M_init,M_init+M):
   lead=0
   x,y=ring.coord(i,0),ring.coord(i,1)
   z=3
   vi= ring.voisin(i,z)
   if vi == -1 : continue
   zmax=ring.fzmax()
   dens=resultats.getG_lesser(i,zmax,lead)(0,0).imag/pi/2.
   if ring.coord(vi,0) == x and ring.coord(vi,1) == y+1 :
       Vji=ring.get_Hopp(i,z)(0,0).conjugate()
       Gij=resultats.getG_lesser(i,z,lead)(0,0)
       curr=(2.*Vji*Gij).real
       # distance in Angstroem
       dist=(i%M)*step()*1.e10
       print dist, curr/(step()*1.e10), dens

sys.exit()


