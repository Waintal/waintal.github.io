# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

sys.path.append('../')
from libpy import *
from numpy import *
from cmath import  *
from pyx import  *


t=knit.scalarM(1.)
Hd=knit.scalarM(0.)
E=-2.5
dx=2
dy=2

# Double system of coordinate in graphene:
# x,y  : usual coordinates
# n,m,AorB : coordinate on the Bravais Lattice
# R = n a_1 + m a_2, AorB indicate on which sub lattice we are

# From n,m,AorB to x,y
def XY(n,m,AorB,dx,dy):
   x=3*dx*n/2+dx*AorB
   y=dy*n+2*dy*m
   return x,y

# From x,y to n,m, AorB
def nmAorB(x,y,dx,dy):
   tmp=(2*x)/dx
   n=tmp/3
   AorB=(tmp%3)/2
   m=(y-dy*n)/(2*dy)
   return n,m,AorB

def Neighbours(n,m,AorB,voisin):
   s= -2*AorB+1
   z=voisin-1
   return n-z*z*s,m+s*z*(1+z)/2,1-AorB

def add_one_site(n,m,AorB,t,Hd,x,y,dx,dy,monsys):
       X,Y=XY(n,m,AorB,dx,dy)
       if monsys.indice([X+x,Y+y]) != -1: return
       v=[]
       for i in range(3):
          nv,mv,AorBv=Neighbours(n,m,AorB,i)
          xv,yv=XY(nv,mv,AorBv,dx,dy)
          xv=xv+x
          yv=yv+y
          where=monsys.indice([xv,yv])
          if where != -1 : v.append(where)
       monsys.add_site(v,t,Hd,[X+x,Y+y])

def add_hexagon(n,m,t,Hd,x,y,dx,dy,monsys):
       add_one_site(n-1,m+1,1,t,Hd,x,y,dx,dy,monsys)
       add_one_site(n,m,0,t,Hd,x,y,dx,dy,monsys)
       add_one_site(n,m+1,0,t,Hd,x,y,dx,dy,monsys)
       add_one_site(n,m,1,t,Hd,x,y,dx,dy,monsys)
       add_one_site(n,m+1,1,t,Hd,x,y,dx,dy,monsys)
       add_one_site(n+1,m,0,t,Hd,x,y,dx,dy,monsys)

    
def Zigzag(n_max,m_max,x,y,dx,dy,t,Hd):
   monsys=knit.rectangle([1,1],[x-dx/2,y+dy],t,Hd)
   for m in range(2,m_max):add_one_site(-1,m,1,t,Hd,x,y,dx,dy,monsys)
   for n in range(n_max):
      for m in range(m_max):
         add_one_site(n,m,0,t,Hd,x,y,dx,dy,monsys)
         add_one_site(n,m,1,t,Hd,x,y,dx,dy,monsys)
   for m in range(0,m_max-1): add_one_site(n_max,m,0,t,Hd,x,y,dx,dy,monsys)
   return monsys

def ZigzagLeadLeftRight(n,m_min,m_max,x,y,dx,dy,t,Hd,RL):
   #RL = O : Left lead , RL=1 : Right lead
   X,Y=XY(n,m_min,RL,dx,dy)
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for m in range(m_min+1,m_max):add_one_site(n,m,RL,t,Hd,x,y,dx,dy,monsys)
   for m in range(m_min,m_max):add_one_site(n,m,1-RL,t,Hd,x,y,dx,dy,monsys)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=m_max-m_min
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+RL,i+L+1-RL,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.scalarM(1.e-5))
   return a

def ZigzagLeadUpDown(n_min,n_max,m,x,y,dx,dy,t,Hd,RL):
   #RL = O : Up lead , RL=1 : Down lead
   X,Y=XY(n_min,m,RL,dx,dy)
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for n in range(n_min+1,n_max):add_one_site(n,m,RL,t,Hd,x,y,dx,dy,monsys)
   for n in range(n_min,n_max):add_one_site(n+2*RL-1,m+1-2*RL,1-RL,t,Hd,x,y,dx,dy,monsys)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=n_max-n_min
   for i in range(L):
      a.put_leadHopp(i+L,i,t)
   for i in range(L-1):
      a.put_leadHopp(i+L+1-RL,i+RL,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i,i+L,knit.scalarM(1.e-5))
   return a

def put_magnetic_field(monsys,dx,dy,phi):
   for i in range(monsys.fsize()):
        x=monsys.coord(i,0)
        y=monsys.coord(i,1)
        n,m,AorB=nmAorB(x,y,dx,dy)
        if AorB == 0 :
           xxx=0
           x,y=XY(n,m,1,dx,dy)
           for z in range(monsys.fzmax()):
              mon_voisin=monsys.voisin(i,z)
              if mon_voisin != -1:
                 xp=monsys.coord(mon_voisin,0)
                 yp=monsys.coord(mon_voisin,1)
                 if x == xp and y == yp :
                    monsys.put_Hopp(i,z,knit.scalarM(exp(1j*phi*m))) 
                    xxx=xxx+1
           if xxx>1 : print "Y'a comme un probleme"

      
def put_magnetic_field_lead(monlead,what,phi):
   L=monlead.fsize()/2
   xx=monlead.coord(0,0)
   yy=monlead.coord(0,1)
   nn,mm,AorB=nmAorB(xx,yy,dx,dy)
   def APPLY(phi):
      for i in range(monlead.fsize()/2):
          xxx=0
          for z in range(monlead.fzmax()):
              mon_voisin=monlead.voisin(i,z)
              if mon_voisin != -1:
                   monlead.put_Hopp(i,z,knit.scalarM(exp(+1j*phi*i)) )
                   xxx=xxx+1
          if xxx!=1 : print "there should be just one neighbor in lead interface"   
   if what == "UP":
      APPLY(-phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.scalarM(exp(+1j*phi*mm)) )
   elif what == "DOWN":
      APPLY(phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.scalarM(exp(-1j*phi*mm)) )
   elif what == "LEFT":APPLY(phi)
   elif what == "RIGHT":APPLY(-phi)
   else: raise ValueError,"neither of UP DOWN LEFT RIGHT index were used for leads"


   
def put_magnetic_field_fullsystem(monsys,mycontacts,dx,dy,phi):
   put_magnetic_field(monsys,dx,dy,phi)
   for ci in mycontacts:
      put_magnetic_field_lead(ci[0],ci[1],phi)

###################################
# SYSTEM CONSTRUCTION             #
###################################
   
N_HEX=20
TOTO=Zigzag(5*N_HEX,N_HEX+1,0,0,dx,dy,t,Hd)
add_one_site(-1,0,1,t,Hd,0,0,dx,dy,TOTO)
add_one_site(5*N_HEX,N_HEX,0,t,Hd,0,0,dx,dy,TOTO)
## for m in range(N_HEX):
##    for n in range(N_HEX):
##       add_hexagon(n+N_HEX,-m-1,t,Hd,0,0,dx,dy,TOTO)
## add_one_site(N_HEX-1,-N_HEX,1,t,Hd,0,0,dx,dy,TOTO)     
## for m in range(N_HEX):
##    for n in range(N_HEX):
##       add_hexagon(n+N_HEX,N_HEX+m,t,Hd,0,0,dx,dy,TOTO)
## add_one_site(2*N_HEX,2*N_HEX,0,t,Hd,0,0,dx,dy,TOTO)  

for m in range(N_HEX):
   for n in range(N_HEX):
      add_hexagon(n+3*N_HEX,-m-1,t,Hd,0,0,dx,dy,TOTO)
add_one_site(3*N_HEX-1,-N_HEX,1,t,Hd,0,0,dx,dy,TOTO)        
## for m in range(N_HEX):
##    for n in range(N_HEX):
##       add_hexagon(n+3*N_HEX,N_HEX+m,t,Hd,0,0,dx,dy,TOTO)
## add_one_site(4*N_HEX,2*N_HEX,0,t,Hd,0,0,dx,dy,TOTO)  

mycontacts=[]

lead0=ZigzagLeadLeftRight(-1,0,N_HEX+1,0,0,dx,dy,t,Hd,0)
monsys=knit.systemtotal(TOTO,lead0)
mycontacts.append([lead0,"LEFT"])

lead1=ZigzagLeadLeftRight(5*N_HEX,0,N_HEX+1,0,0,dx,dy,t,Hd,1)
monsys.addlead(lead1)
mycontacts.append([lead1,"RIGHT"])

## lead2=ZigzagLeadUpDown(N_HEX-1,2*N_HEX,-N_HEX,0,0,dx,dy,t,Hd,1)
## monsys.addlead(lead2)
## mycontacts.append([lead2,"DOWN"])

## lead3=ZigzagLeadUpDown(N_HEX,2*N_HEX+1,2*N_HEX,0,0,dx,dy,t,Hd,0)
## monsys.addlead(lead3)
## mycontacts.append([lead3,"UP"])

lead4=ZigzagLeadUpDown(3*N_HEX-1,4*N_HEX,-N_HEX,0,0,dx,dy,t,Hd,1)
monsys.addlead(lead4)
mycontacts.append([lead4,"DOWN"])

## lead5=ZigzagLeadUpDown(3*N_HEX,4*N_HEX+1,2*N_HEX,0,0,dx,dy,t,Hd,0)
## monsys.addlead(lead5)
## mycontacts.append([lead5,"UP"])


s=sys.argv[0]
#system.visu2D(monsys,s+".systeme",ray=1)

def set_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
       V=knit.scalarM( W*(random.random()-0.5) )
       that_system.put_Hdiag( i, V )
W=0.5
set_white_disorder(monsys,W,666)   

N=51
data=[]
E=0.25
phi=0.2
put_magnetic_field_fullsystem(monsys,mycontacts,dx,dy,phi)

###################################
# MODE 1: TRANSPORT CALCULATION   #
###################################


for boucle_i in range(N):
   E=-0.91+1.8*(float(boucle_i)/N)
 #  phi=-1.+2.2*(float(boucle_i)/N)
   put_magnetic_field_fullsystem(monsys,mycontacts,dx,dy,phi) 
   s=obs.conductance_matrix(monsys,E)
   g=mat(zeros((2,2),float))
   g[0,0]=s[0,1]
   g[1,0]=s[2,1]
   g[0,1]=s[0,2]
   g[1,1]=s[2,2]
   cur=mat(zeros((2,1),float))
   cur[0,0]=1.
   voltage=g.I*cur
   f=open(sys.argv[0]+".dat",'a')
   print >>f,E,s[2,0],s[0,2],s[0,1],s[1,0],voltage[0,0],voltage[1,0]
   f.close()
   print E,s[2,0],s[0,2],s[0,1],s[1,0],voltage[0,0],voltage[1,0]



###################################
# MODE 2: CURRENT 2D COLOR PLOT   #
###################################

## resultats=obs.knitANDsew(monsys,E)


## def courant(i):
##     tmp=0.
##     for z in range(monsys.fzmax()):
##        vi= monsys.voisin(i,z)
##        if vi != -1  and monsys.sys2res(i)<0 and monsys.sys2res(vi)<0:
##           Gij=0.
##           # for lead in [1,4] :
##           for lead in [0] :
##              Gij+=resultats.getG_lesser(i,z,lead)(0,0)
##           Vji=monsys.get_Hopp(i,z)(0,0).conjugate()
##           tmp=tmp+((Vji*Gij).real)**2
##     return  abs(sqrt(tmp))


 
## s=sys.argv[0]+".courant"
## obs.colorplot2D(monsys,s,courant,tt=2)

## gm=obs.conductance_matrix(monsys,E)
## print gm

