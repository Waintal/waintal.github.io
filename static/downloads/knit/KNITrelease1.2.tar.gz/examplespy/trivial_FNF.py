# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################




import sys
import os
import time

sys.path.append('../')
from libpy import *
from libpy.spin import *


t=spin(1.)
Hd=spin(0.)
M=10
E=-0.1



mysys=knit.rectangle_S([M,5*M] ,[0,0],t,Hd)
contact1=knit.unreservoirN_S(knit.rectangle_S([M,1],[0,0],t,Hd),t)
contact2=knit.unreservoirN_S(knit.rectangle_S([M,1],[0,5*M-1],t,Hd),t)
systotal=knit.systemtotal_S(mysys,contact1)
systotal.addlead(contact2)

def add_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        tmp=that_system.get_Hdiag(i)
        that_system.put_Hdiag(i,spin(tmp)+spin(W*(random.random()-0.5))*sz)


def MagnetA(Hd):
   for ix in range(M):
       for iy in range(M):
           i=systotal.indice([ix,iy+M])
           systotal.put_Hdiag(i,Hd)

def MagnetB(Hd):
   for ix in range(M):
       for iy in range(M):
           i=systotal.indice([ix,iy+3*M])
           systotal.put_Hdiag(i,Hd)

add_white_disorder(systotal,0.3,666)
MagnetA(sz)
MagnetB(sz)

maxmax=10
for i in range(maxmax):
    angle=(float(i)/maxmax-0.5)*2*pi
    tmp=rotate(sz,[0.,1.,0.],angle)
    MagnetB(tmp)
    MagnetA(tmp)
    s=obs.conductance_matrix_S(systotal,E)
    print angle*180./pi,s[1,0]
