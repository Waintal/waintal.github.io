# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

from libpy import *
from Numeric import *

V=knit.scalarM(2.+3j)
E=knit.scalarM(1.)
phi=0.

a=knit.rectangle([5,10],[5,0],V,E)
a.coller(knit.rectangle([15,5],[0,5],V,E))
a.coller(knit.rectangle([5,11],[0,5],V,E))
a.coller(knit.rectangle([5,11],[10,5],V,E))
a.coller(knit.rectangle([15,5],[0,15],V,E))
a.coller(knit.rectangle([5,6],[5,19],V,E))

contact1=knit.unreservoirN(knit.rectangle([5,1],[5,0],V,E),V,phi)
contact2=knit.unreservoirN(knit.rectangle([5,1],[5,24],V,E),V,phi)

ring=knit.systemtotal(a,contact1)
ring.addlead(contact2)

s=sys.argv[0]
system.visu2D(ring,s)
os.system("gv "+s+".eps & ")
