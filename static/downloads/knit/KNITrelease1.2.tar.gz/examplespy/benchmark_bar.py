# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


# We have used this module to validate formular T=24*E/W**2
# T diffusive transmission of the bulk, E -energy, W disorder, both mesured in units of hopping

import sys
import os
import time

sys.path.append('../')
from libpy import *
from cmath import  *


V=knit.scalarM(1.)
Hd=knit.scalarM(4.*V(0,0))
M=100
N=100
E=0.4
in_time=time.time()
a=knit.rectangle([M,N],[0,0],V,Hd)
contact1=knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V)
contact2=knit.unreservoirN(knit.rectangle([M,1],[0,N-1],V,Hd),V)
rect=knit.systemtotal(a,contact1)
rect.addlead(contact2)
gas2D.add_white_disorder(rect,0.1,666)
mid_time=time.time()
s=obs.conductance_matrix(rect,E)
out_time=time.time()
hehe=" SYSTEME OF SIZE "+str(M)+" x "+str(N)
hoho=" CONSTRUCTION = "+str(mid_time-in_time)
haha=" CONDUCTANCE CALCULATION = "+str(out_time-in_time)
print hehe
print hoho
print haha
s=raw_input("Comment for the history file? \n (type <enter> not to add the data)")
if s != "":
    fichier=sys.argv[0].split(".")[0]+".history"
    f=open(fichier,'a')
    print >>f,"**************************************************************************"
    print >>f,s
    print >>f,hehe
    print >>f,hoho
    print >>f,haha
    print >>f,"**************************************************************************"
