# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

sys.path.append('../')
from libpy import *
from Numeric import *
from cmath import  *

from LinearAlgebra import *

V=knit.scalarM(1.)
Hd=knit.scalarM(0.)
E=-4+1
phi=0.
Lx=50
Ly=6

a=knit.rectangle([Lx,Ly],[0,0],V,Hd)

contacts=[]

# WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
contacts.append([knit.unreservoirN(knit.rectangle([Lx,1],[0,0],V,Hd),V,phi),"DOWN"])
contacts.append([knit.unreservoirN(knit.rectangle([Lx,1],[0,Ly-1],V,Hd),V,phi),"UP"])


ring=knit.systemtotal(a,contacts[0][0])
for i in range(len(contacts)-1):
    ring.addlead(contacts[i+1][0])

gas2D.add_white_disorder(ring,0.0,666)

#s=sys.argv[0]
#system.visu2D(ring,s+".systeme")
#os.system("gv "+s+".systeme.eps & ")

VVV=50
QPC_left=[Lx*(Ly/2)+i for i in range(2*Lx/5)]
QPC_right=[Lx*(Ly/2)+3*Lx/5+i for i in range(2*Lx/5)]
for i in QPC_left:ring.put_Hdiag(i,knit.scalarM(VVV))
for i in QPC_right:ring.put_Hdiag(i,knit.scalarM(VVV))

N=101
for E_i in range(N):
   E=-3.98+0.5*(float(E_i)/N)
   s=obs.conductance_matrix(ring,E)
   print E,s[0,1]


def potentiel(i):
    return ring.get_Hdiag(i)(0,0).real
s=sys.argv[0]+".courant"
print obs.colorplot2D(ring,s,potentiel)
os.system("gv "+s+".eps & ")

