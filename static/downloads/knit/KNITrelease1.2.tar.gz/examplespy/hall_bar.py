# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

sys.path.append('../')
from libpy import *
from Numeric import *
from cmath import  *

from LinearAlgebra import *

V=knit.scalarM(1.)
Hd=knit.scalarM(0.)
E=-4+1
phi=.5
Lx=10
Ly=10

a=knit.rectangle([Lx,3*Ly+2*Lx],[Lx,0],V,Hd)
a.coller(knit.rectangle([3*Lx,Lx],[0,Ly],V,Hd))
a.coller(knit.rectangle([3*Lx,Lx],[0,2*Ly+Lx],V,Hd))

contacts=[]

# WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
contacts.append([knit.unreservoirN(knit.rectangle([Lx,1],[Lx,0],V,Hd),V,phi),"DOWN"])
contacts.append([knit.unreservoirN(knit.rectangle([Lx,1],[Lx,3*Ly+2*Lx-1],V,Hd),V,phi),"UP"])
contacts.append([knit.unreservoirN(knit.rectangle([1,Lx],[0,Ly],V,Hd),V,phi),"LEFT"])
contacts.append([knit.unreservoirN(knit.rectangle([1,Lx],[3*Lx-1,Ly],V,Hd),V,phi),"RIGHT"])
contacts.append([knit.unreservoirN(knit.rectangle([1,Lx],[0,2*Ly+Lx],V,Hd),V,phi),"LEFT"])
contacts.append([knit.unreservoirN(knit.rectangle([1,Lx],[3*Lx-1,2*Ly+Lx],V,Hd),V,phi),"RIGHT"])


ring=knit.systemtotal(a,contacts[0][0])
for i in range(len(contacts)-1):
    ring.addlead(contacts[i+1][0])

#gas2D.add_white_disorder(ring,0.3,666)


def Tdisorder(W):
   import random
   random.seed(666)
   for i in range(Lx*Ly*9):
       ring.put_Hdiag(i,knit.scalarM(W*(random.random()-0.3)))

## s=sys.argv[0]
## system.visu2D(ring,s+".systeme")
## os.system("gv "+s+".systeme.eps & ")

s=sys.argv[0]
##system.visu2D(ring,s+".systeme")
##os.system("gv "+s+".systeme.eps & ")

def potential(i):
     return ring.get_Hdiag(i)(0,0).real
 
gas2D.add_magnetic_flux(ring,contacts,phi)
#ring.put_Hdiag(0,knit.scalarM(-0.5))

Tdisorder(0.1)

obs.colorplot2D(ring,s+".pot",potential)
#os.system("gv "+s+".pot.eps & ")

def currentdensity(i,lead=1):
    tmp=0.
    for z in range(ring.fzmax()):
       vi= ring.voisin(i,z)
       if vi!= -1:# and MyTwithLeads.sys2res(i)<0 and MyTwithLeads.sys2res(vi)<0:
           Gij=resultats.getG_lesser(i,z,lead)(0,0)
           Vji=ring.get_Hopp(i,z)(0,0).conjugate()
#           tmp=tmp+((Vji*Gij).real)**2
           tmp=tmp+((Vji*Gij).real)**2
#    return sqrt(tmp)
    return sqrt(tmp).real
N=101
resultats=obs.knitANDsew(ring,E)


"""
for phi_i in range(N):
   phi=0.5*(float(phi_i)/N)
   gas2D.add_magnetic_flux(ring,contacts,phi)
   s=obs.conductance_matrix(ring,E)
   gg=linear_least_squares(s,array((1.,-1.,0.,0.,0.,0.)))[0]
   print phi,gg[3]-gg[2],gg[5]-gg[4],gg[4]-gg[2],gg[5]-gg[3]
   from math import *
"""

#print obs.colorplot2D(ring,s+".cur",currentdensity)
obs.colorplot2D(ring,s+".cur",currentdensity)
os.system("gv "+s+".cur.eps & ")

