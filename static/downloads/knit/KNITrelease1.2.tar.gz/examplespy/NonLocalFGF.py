# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################




import sys
import os
import time

from libpy import *

from libpy.graphene3D_superconductor import *
from libpy.spin import *
######################################################################
# PARAMETERS                                                         #
######################################################################

hopp_G=(1.+0.J)*id
diag_G=(0.+0.J)*id


N_HEX_X=16
N_HEX_Y=4

hopp_z1=(4.+0.J)*id
hopp_t1=(0.1+0.J)*id+(0.03+0.J)*sz
N_FERRO1=2
X_FERRO1=2

hopp_z2=(4.+0.J)*id
hopp_t2=(0.1+0.J)*id+(0.03+0.J)*sz
N_FERRO2=2
X_FERRO2=12
######################################################################
# GRAPHENE BAR                                                       #
######################################################################


TOTO=ZigzagLR((N_HEX_X,N_HEX_Y),(0,0,0),hopp_G,diag_G)
add_one_site(-1,0,1,hopp_G,diag_G,TOTO)
add_one_site(N_HEX_X,N_HEX_Y,0,hopp_G,diag_G,TOTO)

mycontacts=[]
LEAD_LEFT=ZigzagLeadLR(-1,0,N_HEX_Y,(0,0,0),hopp_G,diag_G,"LEFT")
copylead0=ZigzagLeadLR(-1,0,N_HEX_Y,(0,0,0),hopp_G,diag_G,"LEFT")
copylead0.coller(TOTO)
monsys=knit.systemtotal_S(copylead0,LEAD_LEFT)
mycontacts.append([LEAD_LEFT,"LEFT"])

LEAD_RIGHT=ZigzagLeadLR(N_HEX_X,0,N_HEX_Y,(0,0,0),hopp_G,diag_G,"RIGHT")
monsys.addlead(LEAD_RIGHT)
mycontacts.append([LEAD_RIGHT,"RIGHT"])

######################################################################
# ADD THE TWO FERRO CONTACTS                                         #
######################################################################

x,y=XY(X_FERRO1,0,0)

FERRO1=ZigzagLR((N_FERRO1,N_HEX_Y),(x,y,1),hopp_G,diag_G)
LEAD_FERRO1=knit.unreservoirN_S(FERRO1,hopp_z1)
monsys.addlead(LEAD_FERRO1)

for i in range(FERRO1.fsize()):
    target1=[FERRO1.coord(i,j) for j in range(3)]
    ind1=monsys.indice(target1)
    target2=target1[:2]+[0]
    ind2=monsys.indice(target2)
    monsys.add_Hopp(ind1,ind2,hopp_t1)

x,y=XY(X_FERRO2,0,0)

FERRO2=ZigzagLR((N_FERRO2,N_HEX_Y),(x,y,1),hopp_G,diag_G)
LEAD_FERRO2=knit.unreservoirN_S(FERRO2,hopp_z2)
monsys.addlead(LEAD_FERRO2)

for i in range(FERRO2.fsize()):
    target1=[FERRO2.coord(i,j) for j in range(3)]
    ind1=monsys.indice(target1)
    target2=target1[:2]+[0]
    ind2=monsys.indice(target2)
    monsys.add_Hopp(ind1,ind2,hopp_t2)


######################################################################
# TRANSPORT CALCULATIONS                                             #
######################################################################

SEED=666
def set_ZeemanField_AndDisorder(HH,W):
    import random
    random.seed(SEED)
    for i in range(monsys.fsize()):
        dis=(W*(random.random()-0.5)+0J)*id
        if monsys.coord(i,2)==0: monsys.put_Hdiag(i,HH+dis)



s=sys.argv[0]
system.visu3D(monsys,s+".systeme",nonumber=1)
#os.system("gv "+s+".systeme.eps & ")



N_DATA=50
E=0.5
W=0.3
for boucle_i in range(N_DATA):
    HH=0.0+0.5*(float(boucle_i)/N_DATA)+0J
    set_ZeemanField_AndDisorder(HH*sx,W)
    s=obs.conductance_matrix_S(monsys,E)
    gg=linear_least_squares(s,array((1.,0.,0.,-1.)))[0]
    print HH.real,gg[2]-gg[1]



