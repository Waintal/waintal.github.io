# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


# We have used this module to validate formular T=24*E/W**2
# T diffusive transmission of the bulk, E -energy, W disorder, both mesured in units of hopping

import sys
import os
import time

sys.path.append('../')
from libpy import *
from Numeric import *
from cmath import  *
from pyx import  *
from LinearAlgebra import *

in_time=time.time()

V=knit.scalarM(1.)
Hd=knit.scalarM(4.*V(0,0))
M=100
E=0.4
print "V=",V(0,0)," Hd=",Hd(0,0)," E=",E

## s=sys.argv[0].split(".")[0]
## system.visu2D(rect,s+".systeme")
## os.system("acroread "+s+".systeme.pdf & ")
## sys.exit()


for W in map(lambda x:x/1000.,range(1,2)):
    f=open("transm"+str(W)+".dat",'w')
    # Transmission as function of N
    for N in range(3,5,1):
        # system construction
        a=knit.rectangle([M,N],[0,0],V,Hd)
    
        # WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
        contacts=[]
        contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V,0.),"DOWN"])
        contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,N-1],V,Hd),V,0.),"UP"])
        
        rect=knit.systemtotal(a,contacts[0][0])
        for i in range(len(contacts)-1):
            rect.addlead(contacts[i+1][0])

        ss=0.
        for i in range(3):
            gas2D.set_white_disorder(rect,W,Hd,6*i**2)
            s=obs.conductance_matrix(rect,E)
            ss+=s[1,0]
        ss=ss/3.
        f.write(str(N)+"\t"+str(ss)+"\n")
        print "N=",N," tr=",ss,"\n"
sys.exit()
## ##############################################


# Transmission calculations of rect
for ii in range(1,2):

    # system construction
    a=knit.rectangle([M,M],[0,0],V,Hd)
    
    # WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
    contacts=[]
    contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V,0.),"DOWN"])
    contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,M-1],V,Hd),V,0.),"UP"])

    rect=knit.systemtotal(a,contacts[0][0])
    for i in range(len(contacts)-1):
        rect.addlead(contacts[i+1][0])

    w_max=0.1
    w_min=0.01
    N=20 # number of steps
    step=(w_max-w_min)/N
    ww=w_min
    while ww<w_max:
        f=open("transm"+str(M)+"gw"+str(E)+".dat",'a')
        ss=0.
        num=30 # average number
        for i in range(num):
            gas2D.set_white_disorder(rect,ww,Hd,6*i)
            s=obs.conductance_matrix(rect,E)
            ss+=s[1,0]
        ss=ss/num
        f.write(str(ww)+"\t"+str(ss)+"\n")
        f.close()
        print "desorder=",ww," tr=",ss,"\n"
        ww+=step
##############################################

out_time=time.time()
print "execution time=",int(out_time-in_time)," sec \n sample M=",M
f=open("exec_time.dat",'w')
f.write("execution time="+str(int(out_time-in_time))+" sec \n sample M="+str(M))


