# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


# We have used this module to validate formular T=24*E/W**2
# T diffusive transmission of the bulk, E -energy, W disorder, both mesured in units of hopping

import sys
import os
import time

sys.path.append('../')
from libpy import *
from Numeric import *
from math import  *
from pyx import  *
from LinearAlgebra import *
import numpy

# BEWARE THE FUNCTION gas2D.add_white_disorder(rect,W,seed)
# PUT A DISORDER WHICH IS [-Hdiag W/2,+Hdiag W/2]


def shot_noise_matrix(systotal,E):
    resultats=obs.knitonly(systotal,E)
    s=systotal.fNres()
    conduct=zeros((s,s),Float)
    shotnoise=zeros((s,s),Float)
    Sigma=[obs.SelfEnergy(i,0,0,resultats,systotal) for i in range(s)]
    Gam=[]
    for S in Sigma: Gam.append(S-numpy.transpose(numpy.conjugate(S)))
    G=[[obs.Green(i,j,0,0,resultats,systotal) for j in range(s)] 
       for i in range(s)]
    for i in range(s):
        for j in range(s):
            TT=numpy.dot(Gam[i],G[i][j])
            TT=numpy.dot(TT,Gam[j])
            TT=-numpy.dot(TT,numpy.transpose(numpy.conjugate(G[i][j])) )
            conduct[i,j]=numpy.trace(TT).real
            TT=numpy.dot(TT,TT)
            shotnoise[i,j]=conduct[i,j]-numpy.trace(TT).real
    return conduct,shotnoise
   

def COND_NOISE(M,N,W,E,seed):
    in_time=time.time()
    V=knit.scalarM(1.)
    Hd=knit.scalarM(4.*V(0,0))
    a=knit.rectangle([M,N],[0,0],V,Hd)
    contact1=knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V)
    contact2=knit.unreservoirN(knit.rectangle([M,1],[0,N-1],V,Hd),V)
    rect=knit.systemtotal(a,contact1)
    rect.addlead(contact2)
    gas2D.add_white_disorder(rect,W,seed)
    gg,ss=shot_noise_matrix(rect,E)
    out_time=time.time()
    return gg[0,1],ss[0,1],out_time-in_time

def COND_NOISE_AV(M,N,W,E,N_sample):
    g=[]
    noise=[]
    for seed in range(N_sample):
        gg,ss,toto=COND_NOISE(M,N,W,E,seed)
        g.append(gg)
        noise.append(ss)
    g_av=reduce(lambda x,y:x+y,g)/N_sample
    g2_av=reduce(lambda x,y:x+y,map(lambda x:x*x,g))/N_sample
    var_g=abs(g2_av-g_av**2)
    noise_av=reduce(lambda x,y:x+y,noise)/N_sample
    noise2_av=reduce(lambda x,y:x+y,map(lambda x:x*x,noise))/N_sample
    var_n=abs(noise2_av-noise_av**2)
    return g_av,sqrt(var_g/N_sample),noise_av,sqrt(var_n/N_sample)

E=0.5
M=24
N_sample=1
N_R=500
dR=0.02


def W_g(R_square): return sqrt(24.*E*R_square)/4 #due to add_disorder()...

fichier="fano2D_E"+str(E)+"M"+str(M)+".dat"
fich=open(fichier,'a')
print  >>fich,"# M = ",M," E = ",E
print  >>fich,"# R_square - cond - error - noise - erreur - fano"
fich.close()

R_square=0.
W=W_g(R_square)
for i in range(N_R):
    g,err_g,nn,err_nn=COND_NOISE_AV(M,M,W,E,N_sample)
    fich=open(fichier,'a')
    print  >>fich,R_square,g,err_g,nn,err_nn,nn/g
    fich.close()
    R_square+=dR
    W=W_g(R_square)
   

