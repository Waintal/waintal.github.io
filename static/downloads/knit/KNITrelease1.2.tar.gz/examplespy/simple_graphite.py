# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os
import time

from libpy import *

from libpy.graphene3D_superconductor import *
from libpy.spin import *


######################################################################
# GRAPHITE                                        #
######################################################################
hopp_G=(1.+0.J)*id
diag_G=(0.+0.J)*id
hopp_z=(4.+0.J)*id

N_HEX_X=2
N_HEX_Y=2
N_SHEETS=10

TOTO=ZigzagLR((N_HEX_X,N_HEX_Y),(0,0,0),hopp_G,diag_G)
sheet_size = TOTO.fsize()
for i in range(N_SHEETS-1):
  TOTO.coller(ZigzagLR((N_HEX_X,N_HEX_Y),(0,0,(i+1)),hopp_G,diag_G))
  for j in range(sheet_size):
      TOTO.add_Hopp(j+sheet_size*i,j+sheet_size*(i+1),hopp_z)


lead0=knit.unreservoirN_S(ZigzagLR((N_HEX_X,N_HEX_Y),(0,0,0),hopp_G,diag_G)
                          ,hopp_z)

lead1=knit.unreservoirN_S(ZigzagLR((N_HEX_X,N_HEX_Y),(0,0,(N_SHEETS-1)),hopp_G,diag_G)
                          ,hopp_z)

monsys=knit.systemtotal_S(TOTO,lead0)
monsys.addlead(lead1)

#s=sys.argv[0]
#system.visu3D(monsys,s+".systeme",nonumber=1)
#os.system("gv "+s+".systeme.eps & ")


N_DATA=200
for i in range(N_DATA):
     E=(float(i)/N_DATA)*24.-12.
     G_MATRIX=obs.conductance_matrix_S(monsys,E) 
     print E,G_MATRIX[1,0]

print "SHEET SIZE = ",sheet_size
