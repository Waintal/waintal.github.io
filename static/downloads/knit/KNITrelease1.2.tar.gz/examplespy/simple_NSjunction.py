# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################




import sys
import os
import time

from libpy import *
import numpy

from libpy.spin import *

M=10
assy=6
#assy=10

t=(30.+0.J)*sz
Hd=(0.+0.J)*sz
#Delta=spin(0)
Delta=(1+0.J)*sx
#Hd=Delta

mysys=knit.rectangle_S([M,assy*M] ,[0,0],t,Hd)
contact1=knit.unreservoirN_S(knit.rectangle_S([M,1],[0,0],t,Hd),t)
contact2=knit.unreservoirN_S(knit.rectangle_S([M,1],[0,assy*M-1],t,Delta),t)
systotal=knit.systemtotal_S(mysys,contact1)
systotal.addlead(contact2)

def add_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        tmp=that_system.get_Hdiag(i)
        that_system.put_Hdiag(i,spin(tmp)+spin(W*(random.random()-0.5))*sz)

def Set_superconductivity(ss):
   for ix in range(M):
       for iy in range(assy*M/2):
           i=systotal.indice([ix,iy+assy*M/2])
           systotal.put_Hdiag(i,ss)

Set_superconductivity(Delta)
add_white_disorder(systotal,0.1,666)

## s=sys.argv[0]
## system.visu2D(systotal,s+".systeme")
## os.system("gv "+s+".systeme.eps & ")

##########################################
# DENSITY OF STATES                      #
##########################################

# ONE SHOULD VERIFY THE NORMALIZATION + DEFINITION
# OF THE DENSITY (in term of ee versus eh or hh)

def LDOSofE():
    zmax=systotal.fzmax()
    N=100
    data=[]
    for boucle_i in range(N):
        E=-2.01+4.05*(float(boucle_i)/N)
        resultats=obs.knitANDsew_S(systotal,E)
        def density(i):
            tmp=resultats.getG_retarded(i,zmax)
            return (-tmp(0,0).imag-tmp(1,1).imag)/3.1415927
        def avdensity(y):
            tmp=0
            for x in range(M): tmp=tmp+density(systotal.indice([x,y]))
            return tmp/M
        print E,avdensity(M),avdensity(2*M),avdensity(4*M),avdensity(5*M),avdensity(6*M-2)
   


##########################################
# COLOR PLOT OF THE DENSITY OF STATES    #
##########################################

# ONE SHOULD VERIFY THE NORMALIZATION + DEFINITION
# OF THE DENSITY (in term of ee versus eh or hh)

def LDOSofXY(E):
    zmax=systotal.fzmax()
    resultats=obs.knitANDsew_S(systotal,E)
    def density(i):
        tmp=resultats.getG_retarded(i,zmax)
        return (-tmp(0,0).imag-tmp(1,1).imag)/3.1415927
    s=sys.argv[0]
    obs.colorplot2D(systotal,s+".ldos",density)
#    def supra(i): return systotal.get_Hdiag(i)(0,1).real
#    obs.colorplot2D(systotal,s+".ldos",supra)

##########################################
# ANDREEV CONDUCTANCE                    #
##########################################

def Set_Hdiag(W):
   import random
   random.seed(666)
   for ix in range(M):
       for iy in range(assy*M/2):
           i=systotal.indice([ix,iy+assy*M/2])
           systotal.put_Hdiag(i,Delta)     
       i=systotal.indice([ix,1])
       systotal.put_Hdiag(i,complex(W)*sz)
       i=systotal.indice([ix,2])
       systotal.put_Hdiag(i,complex(W)*sz)
    
  
def AndreevConductance(E):

    resultats=obs.knitonly_S(systotal,E)
    Gam_ee=obs.SelfEnergy(0,0,0,resultats,systotal)
    Gam_ee=Gam_ee-numpy.transpose(numpy.conjugate(Gam_ee))
    Gam_hh=obs.SelfEnergy(0,1,1,resultats,systotal)
    Gam_hh=Gam_hh-numpy.transpose(numpy.conjugate(Gam_hh))
    Ghe=obs.Green(0,0,1,0,resultats,systotal)
    Geh=obs.Green(0,0,0,1,resultats,systotal)

    tmp=numpy.dot(Geh,Gam_hh)
    Ghe=numpy.transpose(numpy.conjugate(Ghe))
    tmp=numpy.dot(tmp,Ghe)
    tmp=numpy.dot(tmp,Gam_ee)
    return 2*numpy.trace(tmp).real

def Andreev():
    N=20
    W=0
    for boucle_i in range(N):
        W=0.01+200.05*(float(boucle_i)/N)
        Set_Hdiag(W)
        print W,AndreevConductance(0.001)

##########################################
# CHOOSE HERE WHAT YOU WANT TO COMPUTE   #
##########################################


#Andreev()

LDOSofXY(0.01)

#LDOSofXY(1.)

#LDOSofE()
