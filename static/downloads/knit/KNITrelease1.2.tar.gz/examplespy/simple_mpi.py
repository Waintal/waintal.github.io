# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


# We have used this module to validate formular T=24*E/W**2
# T diffusive transmission of the bulk, E -energy, W disorder, both mesured in units of hopping

import sys
import os
import time

sys.path.append('../')

import mpi   
from libpy import *
from cmath import  *


V=knit.scalarM(1.)
Hd=knit.scalarM(4.*V(0,0))
M=100
N=100

x=float(mpi.rank)/mpi.size
E=0.5*x+0.001
in_time=time.time()
a=knit.rectangle([M,N],[0,0],V,Hd)
contact1=knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V)
contact2=knit.unreservoirN(knit.rectangle([M,1],[0,N-1],V,Hd),V)
rect=knit.systemtotal(a,contact1)
rect.addlead(contact2)
gas2D.add_white_disorder(rect,0.1,666)
mid_time=time.time()
s=obs.conductance_matrix(rect,E)
out_time=time.time()
mydata=[[ E , s[0,1] ]]
alldata=mpi.gather(mydata)
if mpi.rank==0:
    output_file_name="simple_mpi.dat"
    output_file=open(output_file_name,'w')
    for i in alldata: print >>output_file,i[0],i[1]
    hehe=" SYSTEME OF SIZE "+str(M)+" x "+str(N)
    hoho=" CONSTRUCTION TIME = "+str(mid_time-in_time)
    haha=" CONDUCTANCE CALCULATION TIME = "+str(out_time-in_time)
    print hehe
    print hoho
    print haha

