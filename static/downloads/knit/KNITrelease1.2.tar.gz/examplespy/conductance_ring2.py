# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

sys.path.append('../')
from libpy import *
from Numeric import *
from cmath import  *
from pyx import  *

V=knit.scalarM(1.)
Hd=knit.scalarM(0.)
E=-0.5
phi=0.

a=knit.rectangle([5,10],[5,0],V,Hd)
a.coller(knit.rectangle([15,5],[0,5],V,Hd))
a.coller(knit.rectangle([5,11],[0,5],V,Hd))
a.coller(knit.rectangle([5,11],[10,5],V,Hd))
a.coller(knit.rectangle([15,5],[0,15],V,Hd))
a.coller(knit.rectangle([5,6],[5,19],V,Hd))

contact1=knit.unreservoirN(knit.rectangle([5,1],[5,0],V,Hd),V,phi)
contact2=knit.unreservoirN(knit.rectangle([5,1],[5,24],V,Hd),V,-phi)

ring=knit.systemtotal(a,contact1)
ring.addlead(contact2)

def conductance(E):
    toto=knit.tricot(0,ring,E)
    toto.set_saving_level(0)
    toto.forward(2)
    toto.forward(3)
    return knit.TransProba(toto,0,1)

N=71
data=[]
sites=[135,136,137,138,139]
for phi_i in range(N):
    phi=4*(float(phi_i)/N)*3.14159
    for a in sites:
        ring.put_Hopp(a,3,knit.scalarM(exp(1j*phi)))
    gg=conductance(E).real  
    data.append([phi,gg])

 
g =graph.graphxy(width=10,x=graph.axis.linear(title="$\phi$"),y=graph.axis.linear(title="$G$"))
g.plot(graph.data.list(data,x=1,y=2),[graph.style.line([style.linewidth.Thick])])

s=sys.argv[0]
g.writeEPSfile(s)
g.writePDFfile(s)
system.visu2D(ring,s+".systeme")
os.system("gv "+s+".eps & ")

