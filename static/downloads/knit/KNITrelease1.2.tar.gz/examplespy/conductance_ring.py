# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


import sys
import os

sys.path.append('../')
from libpy import *
from Numeric import *
from cmath import  *
from pyx import  *

V=knit.scalarM(1.)
Hd=knit.scalarM(0.)
E=-0.5
phi=0.

a=knit.rectangle([5,10],[5,0],V,Hd)
a.coller(knit.rectangle([15,5],[0,5],V,Hd))
a.coller(knit.rectangle([5,11],[0,5],V,Hd))
a.coller(knit.rectangle([5,11],[10,5],V,Hd))
a.coller(knit.rectangle([15,5],[0,15],V,Hd))
a.coller(knit.rectangle([5,6],[5,19],V,Hd))

contact1=knit.unreservoirN(knit.rectangle([5,1],[5,0],V,Hd),V,phi)
contact2=knit.unreservoirN(knit.rectangle([5,1],[5,24],V,Hd),V,-phi)

ring=knit.systemtotal(a,contact1)
ring.addlead(contact2)

s=sys.argv[0]

#system.visu2D(ring,s+".systeme")
#writing .epf and .pdf files with names "argv[0]".systeme
#os.system("gv "+s+".systeme.eps & ")

def conductance(E):
    toto=knit.tricot(0,ring,E)
    toto.set_saving_level(0)
    toto.forward(2)
    toto.forward(3)
    return knit.TransProba(toto,0,1)

N=301
data=[]
for E_i in range(N):
    E=(float(E_i)/N)*2.-2.
    gg=conductance(E).real  
    data.append([E,conductance(E).real])

 
g =graph.graphxy(width=10,x=graph.axis.linear(title="$E$"),y=graph.axis.linear(title="$G$"))
g.plot(graph.data.list(data,x=1,y=2),[graph.style.line([style.linewidth.Thick])])

#s=sys.argv[0]



g.writeEPSfile(s)
g.writePDFfile(s)
#system.visu2D(ring,s+".systeme")
os.system("gv "+s+".eps & ")


def potential(i):
     return ring.get_Hdiag(i)(0,0).real


#ring.put_Hdiag(0,knit.scalarM(-0.5))

#print
#obs.colorplot2D(ring,s+".pot",potential)
#os.system("gv "+s+".pot.eps & ")

resultats=obs.knitANDsew(ring,-.8)
#print obs.conductance_matrix(ring,-1.)


from math import *
def currentdensity(i,lead=1):
    tmp=0.
    for z in range(ring.fzmax()):
       vi= ring.voisin(i,z)
       if vi!= -1:# and MyTwithLeads.sys2res(i)<0 and MyTwithLeads.sys2res(vi)<0:
           Gij=resultats.getG_lesser(i,z,lead)(0,0)
           Vji=ring.get_Hopp(i,z)(0,0).conjugate()
#           tmp=tmp+((Vji*Gij).real)**2
           tmp=tmp+((Vji*Gij).real)**2
    return sqrt(tmp)

#print system.colorplot2D(ring,s+".cur",currentdensity)
system.colorplot2D(ring,s+".cur",currentdensity)
os.system("gv "+s+".cur.eps & ")

