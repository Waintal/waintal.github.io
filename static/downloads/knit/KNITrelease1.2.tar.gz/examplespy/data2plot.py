# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


#!/usr/bin/python

# MODULE THAT MAKE PDF FROM DATA(x,x+dx,y,y+dy,value)
# use obs.saveplot2D() function to save data first
# usage
# ./data2plot.py data_file x_min x_max
# ./data2plot.py data_file
# one could plot log data, to do this uncomment 2 corresponding lines in this file

import sys
import os
import pickle

from cStringIO import StringIO
from Numeric import array
from math import *

from pyx import *

def HSL_to_RGB(h,s,l):
    ''' Converts HSL colorspace (Hue/Saturation/Value) to RGB colorspace.
        Formula from http://www.easyrgb.com/math.php?MATH=M19#text19
       
        Input:
            h (float) : Hue (0...1, but can be above or below
                              (This is a rotation around the chromatic circle))
            s (float) : Saturation (0...1)    (0=toward grey, 1=pure color)
            l (float) : Lightness (0...1)     (0=black 0.5=pure color 1=white)
       
        Ouput:
            (r,g,b) (integers 0...255) : Corresponding RGB values
       
        Examples:
            >>> print HSL_to_RGB(0.7,0.7,0.6)
            (110, 82, 224)
            >>> r,g,b = HSL_to_RGB(0.7,0.7,0.6)
            >>> print g
            82
    '''
    def Hue_2_RGB( v1, v2, vH ):
        while vH<0.0: vH += 1.0
        while vH>1.0: vH -= 1.0
        if 6*vH < 1.0 : return v1 + (v2-v1)*6.0*vH
        if 2*vH < 1.0 : return v2
        if 3*vH < 2.0 : return v1 + (v2-v1)*((2.0/3.0)-vH)*6.0
        return v1
   
    if not (0 <= s <=1): raise ValueError,"s (saturation) parameter must be between 0 and 1."
    if not (0 <= l <=1): raise ValueError,"l (lightness) parameter must be between 0 and 1."
   
    r,b,g = (l*255,)*3
    if s!=0.0:
       if l<0.5 : var_2 = l * ( 1.0 + s )
       else     : var_2 = ( l + s ) - ( s * l )
       var_1 = 2.0 * l - var_2
       r = 255 * Hue_2_RGB( var_1, var_2, h + ( 1.0 / 3.0 ) )
       g = 255 * Hue_2_RGB( var_1, var_2, h )
       b = 255 * Hue_2_RGB( var_1, var_2, h - ( 1.0 / 3.0 ) )
      
    return (int(round(r)),int(round(g)),int(round(b)))


def rgbcolortostring(c):
    return "".join([chr(int(255*c.color[name])) for name in "rgb"])

def hsbcolortostring(c):
    hsb=[c.color[name] for name in "hsb"]
    rgb=HSL_to_RGB(hsb[0],hsb[1],hsb[2]/2.)
    return "".join([chr(name) for name in rgb])

filename=sys.argv[1]
f=open(filename)
data = pickle.load(f)
filename=filename.split(".")[0]

## LOG data plot with minimum offset
#min_offset=1e-4
#for d in data: d[4]=log(d[4]+min_offset)

if len(sys.argv)<4: minV,maxV=-1,-1
else: minV,maxV=float(sys.argv[2]),float(sys.argv[3])

aveV= " not calculated "
if minV == -1 and maxV == -1 :aveV=sum(map(lambda x:x[4],data))/len(data)
if minV==-1: minV=min(map(lambda x:x[4],data))
if maxV==-1: maxV=max(map(lambda x:x[4],data))

xmin=min(map(lambda x:x[0],data))
xmax=max(map(lambda x:x[0],data))
ymin=min(map(lambda x:x[2],data))
ymax=max(map(lambda x:x[2],data))
xiterations = xmax - xmin+1
yiterations = ymax-ymin+1

for i in data:
    i[4]=(i[4]-minV)/(maxV-minV)
    if i[4]>1: i[4]=1.
    if i[4]<0: i[4]=0.

## rearange data by index
def xy2ind(x,y):
     return x-xmin+(ymax-y)*xiterations

dataArr = array([-1. for x in range(xiterations*yiterations)],'f')

for a in data:
    ind=xy2ind(a[0],a[2])
    dataArr[ind]=a[4]
    
# p = color.palette.RedBlue
#p = color.palette.ReverseRainbow
p = color.gradient.ReverseRainbow

# string that is used to plot data
dataBW = StringIO()
# compute dataBW
for a in dataArr:
    if a >= 0.:
        # append color(RGB or HSL) of the current pixel to the end of data
        # dataBW.write(rgbcolortostring(colHSL_to_RGB(p.getcolor(a))))
        dataBW.write(hsbcolortostring(p.getcolor(a)))
    else:
        dataBW.write("\377\377\377")

# generate image from dataBW
julia = bitmap.image(xiterations, yiterations, "RGB", dataBW.getvalue())
juliabitmap = bitmap.bitmap(0, 0, julia, height=10)

c = canvas.canvas()
c.insert(juliabitmap)
c.writeEPSfile(filename)
c.writePDFfile(filename)

os.system("xpdf "+filename+".pdf & ")

print "min=",minV,"max=",maxV,"average=",aveV

sys.exit()

## #################################
## aveV=sum(map(lambda x:x[4],data))/len(data)
## x_size=max(map(lambda x:x[0],data)) - min(map(lambda x:x[0],data))
## y_size=max(map(lambda x:x[2],data)) - min(map(lambda x:x[2],data))
## g = graph.graphxy(width=x_size,height=y_size,
##                   x=graph.axis.linear(),
## 		  y=graph.axis.linear())
## g.plot(graph.data.list(data,xmin=1, xmax=2, ymin=3, ymax=4,color=5),
##        [graph.style.rect(color.palette.ReverseRainbow)])
## g.writeEPSfile(filename)
## g.writePDFfile(filename)
## print "average=",aveV
## sys.exit()
