# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


#!/usr/bin/python

# MODULE THAT MAKE PDF FROM DATA(x,x+dx,y,y+dy,value)

import sys
import os
import pickle

from cStringIO import StringIO
from Numeric import array
from pyx import bitmap,canvas,color

def flo_to_RGB(h):
    def Hue_2_RGB( vH ):
        while vH<0.0: vH += 1.0
        while vH>1.0: vH -= 1.0
        if 6*vH < 1.0 : return 6.0*vH
        if 2*vH < 1.0 : return 1.
        if 3*vH < 2.0 : return ((2.0/3.0)-vH)*6.0
        return 0.
    r = 255 * Hue_2_RGB( h + 1./3)
    g = 255 * Hue_2_RGB( h )
    b = 255 * Hue_2_RGB( h - 1./3)
    return (int(round(r)),int(round(g)),int(round(b)))
def rgbcolortostring(c):
    return "".join([chr(int(255*c.color[name])) for name in "rgb"])
def hsbcolortostring(c):
    rgb=flo_to_RGB(c.color['h'])
    return "".join([chr(name) for name in rgb])


fichier=sys.argv[1]
print fichier
f=open(fichier)
data = pickle.load(f)
fichier=fichier.split(".")[0]
f.close()

if len(sys.argv)<4: minV,maxV=-1,-1
else: minV,maxV=float(sys.argv[2]),float(sys.argv[3])

if minV==-1: minV=min(map(lambda x:x[2],data))
if maxV==-1: maxV=max(map(lambda x:x[2],data))
aveV=sum(map(lambda x:x[2],data))/len(data)
for i in data:
    i[2]=(i[2]-minV)/(maxV-minV)
    if i[2]>1: i[2]=1.
    if i[2]<0: i[2]=0.
xmin=min(map(lambda x:x[0],data))
xmax=max(map(lambda x:x[0],data))
ymin=min(map(lambda x:x[1],data))
ymax=max(map(lambda x:x[1],data))
xiterations = xmax-xmin+1
yiterations = ymax-ymin+1
## rearange data by index
def xy2ind(x,y):
    return x-xmin+(ymax-y)*xiterations

dataArr = array([-1. for x in range(xiterations*yiterations)],'f')
for a in data:
    ind=xy2ind(a[0],a[1])
    dataArr[ind]=a[2]
    if a[0]<xmax and a[1]<ymax:
        ind1=xy2ind(a[0],a[1]+1)
        ind2=xy2ind(a[0]+1,a[1])
        ind3=xy2ind(a[0]+1,a[1]+1)
        dataArr[ind1]=a[2]
        dataArr[ind2]=a[2]
        dataArr[ind3]=a[2]

for ind in range(1,len(dataArr)-1):
  if dataArr[ind]==-1. and dataArr[ind+1]==-1 and dataArr[ind-1]>-0.5 and dataArr[ind+2]>-0.5: 
    dataArr[ind]=dataArr[ind-1]
    dataArr[ind+1]=dataArr[ind+2]    

p = color.gradient.ReverseRainbow

# string that is used to plot data
dataBW = StringIO()
# compute dataBW
for a in dataArr:
    if a >= 0.:
        # append color(RGB) of the current pixel to the end of data
        dataBW.write(hsbcolortostring(p.getcolor(a)))
    else:
        dataBW.write("\377\377\377")

# generate image from dataBW
julia = bitmap.image(xiterations, yiterations, "RGB", dataBW.getvalue())
juliabitmap = bitmap.bitmap(0, 0, julia, height=10)
c = canvas.canvas()
c.insert(juliabitmap)

c.writeEPSfile(fichier)
c.writePDFfile(fichier)
os.system("xpdf "+fichier+".pdf & ")
print "min=",minV,"max=",maxV,"average=",aveV

