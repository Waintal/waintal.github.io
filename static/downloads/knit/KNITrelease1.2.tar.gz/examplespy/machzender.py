# #############################################################
#  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
#  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
#  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
# #############################################################


#!/usr/bin/python

import sys
import os
import time

sys.path.append('../')
sys.path.append('pyx/')
sys.path.append('libpy/')
from libpy import *
from cmath import *

in_time=time.time()

V=knit.scalarM(1.)
Hd=knit.scalarM(4.*V(0,0))
M=50
# sample of n_s(without spin)=0.5*10**10; calL=1 micrometre; mu= 1O**6 sm**-2
#calN=4*pi*n_s*calL^2
calN=628.
# calG=E/W^2=h/e/24*mu*n_s
calG=0.78
# number of Landau channels
channels=1
E=calN/M**2
phi=E/2./channels
def myW(calGG=calG,calNN=calN):
    return (0.25*sqrt(calNN/calGG)/M).real
W=myW()
#rc=sqrt(2/phi)=2*M/sqrt(calN)
print "V=",V(0,0)," Hd=",Hd(0,0)," E=",E, " phi=",phi,"W=",W
# validity TEST
if E>1. or phi>0.5:
    print "WARNING: network influence detected => increase resolution M"
    #sys.exit()
# QPC data
# QPC potential in B is given by h*(1-th^2(x/xi_x))(1+r*th^2(y/xi_y))
# h is the zero point offset given in terms of Hd
# h(1+r) = maximal hight of the potential
# xi_x xi_y are characteristic x and y scales
# QPC hight for 1/2 transmission
# appriximate formular for QPC hight (rB=100.,M>20)
def QPC_hight(correction=1.):
   # calN=628.
   # correction=0.9674 # for calN*=2
   # correction=0.9405 # for calN*=3
    return (-0.50883+0.23458*log(calN).real)*(1./10.7+E/164.258)*correction
sitesQPC_A=[2*M*M+i for i in range(M/2*M)]
centerQPC_A=[(M-1)/2.,2*M+(M/2-1)/2.]
sitesQPC_B=[]
for j in range(M/2):
    for i in range(M):
        sitesQPC_B.append(4*M*M+(M+1)*i+j)
centerQPC_B=[M+(M/2-1)/2.,3*M+(M-1)/2.]

def QPC_profile(x,y,h,r,xi_x,xi_y):
    return 1.+h*(1.-tanh(x/xi_x)**2)*(1.+r*tanh(y/xi_y)**2)

# system construction
a=knit.rectangle([M,4*M],[0,0],V,Hd)
a.coller(knit.rectangle([M+2,M],[M-1,3*M],V,Hd))
a.coller(knit.rectangle([M+2,M],[M-1,M],V,Hd))
a.coller(knit.rectangle([M,4*M],[2*M,M],V,Hd))

# WARNING: PUT THE LEADS IN APPEARING ORDER ALONG THE LACE
contacts=[]
contacts.append([knit.unreservoirN(knit.rectangle([M,1],[0,0],V,Hd),V,0.),"DOWN"])
contacts.append([knit.unreservoirN(knit.rectangle([1,M/2],[M-1,3*M-M/2],V,Hd),V,0.),"RIGHT"])
contacts.append([knit.unreservoirN(knit.rectangle([M/2,1],[M,M],V,Hd),V,0.),"DOWN"])
contacts.append([knit.unreservoirN(knit.rectangle([M,1],[2*M,5*M-1],V,Hd),V,0.),"UP"])

ring=knit.systemtotal(a,contacts[0][0])
for i in range(len(contacts)-1):
    ring.addlead(contacts[i+1][0])

## s=sys.argv[0].split(".")[0]
## system.visu2D(ring,s+".systeme")
## os.system("acroread "+s+".systeme.pdf & ")
## sys.exit()

def add_ab_flux(phi):
    ABpoints=[8*M*M +i for i in range(M)]
    for i in ABpoints:
        a=ring.get_Hopp(i,gas2D.haut(i,ring))(0,0)
        ring.put_Hopp(i,gas2D.haut(i,ring),knit.scalarM(a*exp(-1j*phi)) )

def visibiliteTF(visN=8):
    from FFT import fft
    #visN = number of iterations for visibility calculations
    if visN<4: print "visibilityTF should be calculated using at least 4 points"
    visi_arr=[]
    for i in range(visN):
        s=obs.conductance_matrix(ring,E)
        add_ab_flux(2*pi/visN)
        visi_arr.append(s[3,0])    
    TFvisi=abs(fft(visi_arr))
    avV=TFvisi[0]
    TFvisi=TFvisi/TFvisi[0]*2.
    return avV,TFvisi[1],TFvisi[2],TFvisi[3]

def visibilite(visN=10):
    #visN = number of iterations for visibility calculations
    if visN<=2: print "visibility should be calculated using at least 2 points"
    visi_arr=[]
    for i in range(visN):
        s=obs.conductance_matrix(ring,E)
        add_ab_flux(2*pi/visN)
        visi_arr.append(s[3,0])
    maxV=max(visi_arr)
    minV=min(visi_arr)
    return (maxV-minV)/(maxV+minV)

# first QPC potential
def V_QPC_A(x,y,h):
    rA=100.
    xiA_x=M/2.
    xiA_y=M/12.
    return QPC_profile(y,x,h*E,rA,xiA_y,xiA_x)
# second QPC potential
def V_QPC_B(x,y,h):
    rB=100.
    xiB_x=M/12.
    xiB_y=M/2.
    return QPC_profile(x,y,h*E,rB,xiB_x,xiB_y)

def setQPC_A(h=QPC_hight()):
    for i in sitesQPC_A:
        x=ring.coord(i,0)-centerQPC_A[0]
        y=ring.coord(i,1)-centerQPC_A[1]
        # VVA=V_QPC_A(x,y,h)*ring.get_Hdiag(i)(0,0)
        VVA=V_QPC_A(x,y,h)*4.
        ring.put_Hdiag(i,knit.scalarM(VVA))

def setQPC_B(h=QPC_hight()):
    for i in sitesQPC_B:
        x=ring.coord(i,0)-centerQPC_B[0]
        y=ring.coord(i,1)-centerQPC_B[1]
        # VVB=V_QPC_B(x,y,h)*ring.get_Hdiag(i)(0,0)
        VVB=V_QPC_B(x,y,h)*4.
        ring.put_Hdiag(i,knit.scalarM(VVB))
    
## # TRANSMISSION ON ENERGY
## gas2D.add_magnetic_flux(ring,contacts,phi)
## h_max=QPC_hight()*1.001
## h_min=QPC_hight()*0.999
## N=3 # number of steps
## step=(h_max-h_min)/N
## hh=h_min
## while hh<=h_max:
##     # Add QPC A or B
##     setQPC_A(hh)
##     #setQPC_B(hh)
##     s=obs.conductance_matrix(ring,E)
##     f=open("transm"+str(M)+".dat",'a')
##     f.write(str(hh)+"\t"+str(s[3,0])+"\t"+str(s[1,0])+"\n")
##     f.close()
##     print "h=",hh," tr=",s[3,0],"\t"+str(s[1,0])+"\n"
##     hh+=step

## # VISIBILITY average
## gas2D.add_magnetic_flux(ring,contacts,phi)
## gmin=0.2
## gmax=calG
## Nit=50
## for g in [x*(gmax-gmin)/Nit+gmin for x in range(Nit)]:
##     WW=myW(g)
##     summa=0.
##     summa2=0.
##     avNmin=10   #minumum number of iterations
##     avNcur=1
##     err_cur=1.
##     while err_cur>0.02 or avNcur<avNmin:
##         gas2D.set_white_disorder(ring,WW,Hd,int(666666*err_cur))
##         setQPC_A()
##         setQPC_B()
##         vvv=visibilite(4)
##         summa+=vvv
##         summa2+=vvv**2        
##         err_cur=sqrt(summa2/avNcur-(summa/avNcur)**2).real/sqrt(avNcur).real
##         avNcur+=1
##         if avNcur*M**4>10**7: print "TIME PER POINT IS TOO LONG"
##     visi_av=summa/avNcur
##     visi_err=sqrt(summa2/avNcur-visi_av**2).real/sqrt(avNcur).real
##     f=open("VisiMU1_"+str(M)+".dat",'a')
##     f.write(str(1./g)+"\t"+str(visi_av)+"\t"+str(visi_err)+"\n")
##     f.close()
##     print "visibility=",visi_av," for W**2/E=",1./g," iter number=",avNcur

## # VISIBILITY single sample
## gas2D.add_magnetic_flux(ring,contacts,phi)
## gmin=0.12
## gmax=0.4
## Nit=300
## for g in [x*(gmax-gmin)/Nit+gmin for x in range(Nit)]:
##     WW=myW(g)
##     gas2D.set_white_disorder(ring,WW,Hd,666)
##     setQPC_A()
##     setQPC_B()
##     f=open("Visi1_no_aver"+str(M)+".dat",'a')
##     #vvv=visibilite(4)
##     #f.write(str(1./g)+"\t"+str(vvv)+"\n")
##     vvv=visibiliteTF()
##     f.write(str(1./g)+"\t"+str(vvv[0])+"\t"+str(vvv[1])+"\t"+str(vvv[2])+"\t"+str(vvv[3])+"\n")
##     f.close()
##     print "visibility=",vvv," for W**2/E=",16*WW**2/E

## # Check of conductance matrix
## gas2D.add_magnetic_flux(ring,contacts,phi)
## setQPC_A()
## ##setQPC_B()
## s=obs.conductance_matrix(ring,E)
## print s

## # POTENTIAL FORM
## setQPC_A()
## setQPC_B()
## def V_potent(i):
##     return ring.get_Hdiag(i)(0,0).real
## print obs.colorplot2D(ring,"sysPlot",V_potent)
## os.system("xpdf sysPlot.pdf & ")


## # AB OSCILATIONS
## gas2D.add_magnetic_flux(ring,contacts,phi)
## gas2D.set_white_disorder(ring,myW(1./0.43),Hd,666666)
## # Add QPCs
## setQPC_A()
## setQPC_B()

## flmin=4*pi
## flmax=8*pi
## flux=flmin
## while flux<=flmax:
##     dflux=2*pi/80.
##     s=obs.conductance_matrix(ring,E)
##     add_ab_flux(dflux)
##     f=open("ABoscil"+str(M)+".dat",'a')
##     f.write(str(flux)+"\t"+str(s[3,0])+"\n")
##     f.close()
##     print flux,s[3,0]
##     flux+=dflux

# sewing using saving level
save_level=8*M
gas2D.add_magnetic_flux(ring,contacts,0.1)
resultats=obs.knitANDsew(ring,E,save_level)

out_time=time.time()
print "execution time=",int(out_time-in_time)," sec \n sample M=",M
f=open("exec_time.dat",'w')
f.write("execution time="+str(int(out_time-in_time))+" sec \n sample M="+str(M))

## # Density Plot
## def densite(i): return -resultats.getG_retarded(i,4)(0,0).imag/pi
## s=sys.argv[0].split(".")[0]+".densite"
## obs.colorplot2D(ring,s,densite)
## os.system("xpdf "+s+".pdf & ")

# Current plot
def courant(i):
    lead=0
    tmp=0.
    for z in range(ring.fzmax()):
        vi= ring.voisin(i,z)
       if ring.voisin(i,z) != -1 and ring.sys2res(i)<0 and ring.sys2res(vi)<0:
           Gij=resultats.getG_lesser(i,z,lead)(0,0)
           Vji=ring.get_Hopp(i,z)(0,0).conjugate()
           tmp=tmp+((Vji*Gij).real)**2
    return sqrt(tmp).real
s=sys.argv[0].split(".")[0]+".courant"

print obs.RGBplot2D(ring,s,courant)
os.system("xpdf "+s+".pdf & ")

sys.exit()


