#include "knit_knit.h"
#include "knit_Python_Data.h"

/** This mode permits to obtain LDOS map of the rectangular sample  connected to two leads **/
// this file should be placed in tmp folder and executed with make LDOS command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(){
  //typedef vectorM<2> testM;
  typedef scalarM testM;

  // construction of the systemerectangle
  clock_t t_in=clock();

  // system
  int M=150;// channel number
  int N=75;// sample size

  double En=-1.5; // working energy
  double epsilon=0.00001; // complex part of energy
  double flux=0.2;
  // with or without Direct Inversion
  const bool with_DI=false;
  const bool is_Bfield=false;
  if (!is_Bfield) flux=0.;
  bool is_QPC=false;
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=M/2,N/2; 
  int QPCchannel=5;


  // Hdiag should not be zero as QPC will multiply this value by some factor
  testM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  for (int i=0;i<testM::dim();++i) {
    V_sample(i,i)=-1.;
    V_LL(i,i)=-1.;
    V_RL(i,i)=-1.;
    Hdiag(i,i)=1.;
    Hdiag_LL(i,i)=1.;
    Hdiag_RL(i,i)=1.;
  }
  // END of Input ***************************************************

  // Print on screen what we are doing
  cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
  cout<<"2 Leads Rectangular system"<<endl;
  if (is_QPC) cout<<"with QPC"<<endl;
  else cout<<"no QPC"<<endl;
  if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
  else cout<<"no B field"<<endl;
  cout<<"\nDensity calculations"<<endl;

  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<testM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<testM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<testM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<testM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);

  cout.precision(15);cout<<scientific;  
  // Density calculations *************************
  const COMPLEX cEn=COMPLEX(En,epsilon);

  // with or without Direct Inversion
  if (with_DI) { // density by direct inversion
    cout<<"Direct Inversion calculations"<<endl;
    direct<testM> dir(sys_lead ); 
    if (with_DI)  dir.calculate4E(cEn);
    for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_denDI=-dir.G(i,i)(0,0).imag()/PI;
    };
  }
  else{ // density by knit technique
    cout<<"Knit calculations"<<endl;
    knit<testM> work(0,sys_lead, cEn); 
    work.forward(ToEnd);
    sew<testM> S(work);
    S.sew2end();
    const GF_type GnotK( S.getGnotK() );
    for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_den=-GnotK(i,0,sys_lead.fzmax(),0).imag()/PI;
    };
  };


  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Density calculations done for "<<cEn<<" energy"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
