#!/usr/bin/python
#density plot of data given in the form of three columns
# x  y  value

# this program load two coloumn file and find distribution of length between peaks

from commands import *
from math import *
from pyx import *
import sys
import os

#conversion elements to the list of float
def s2floats(a):
   return map(float,a.split())

if len(sys.argv) == 1:
  print " USAGE: plot3D.py fichier extension "
  print " ou:    plot3D.py fichier extension zmin zmax"
  sys.exit()

print " LECTURE DONNEES... "

donnees= open(sys.argv[1])
donnees= map(s2floats,donnees.readlines())

#eliminate bad data point and choose range
new_data=[]
for i in donnees:
   if i[1]>1e-15 and i[0]<0.9 and i[0]>0.2 :
      new_data.append(i)

#list of maximal values {Emax,E}      
max_data=[]
for i in range(len(new_data)):
   if i<4 or i>len(new_data)-4 : continue
   voisins=[new_data[i+1][1], 2.*new_data[i+2][1], 3.*new_data[i+3][1], new_data[i-1][1], 2.*new_data[i-2][1], 3.*new_data[i-3][1]] 
   if new_data[i][1] >= max(voisins): max_data.append([new_data[i][0],new_data[i][1]])

#list of length between two peaks  diff_data={delta E}; diff_dataE={delta E, int(E)}
R=1e4 #round value used to calculate distribution
diff_data=[]
diff_dataE=[]
for i in range(len(max_data)):
   if i==0 or i==len(max_data)-1: continue
   diff_dataE.append([max_data[i][0],max_data[i+1][0]-max_data[i][0]])
   diff_data.append(int(R*(max_data[i+1][0]-max_data[i][0])))

#distribution of delta E
distrib=[]
maxD=max(diff_data)
minD=min(diff_data)
meanD=sum(diff_data)/len(diff_data)/R
print meanD
for i in range(maxD+1):
   number=diff_data.count(i)
   #if number != 0 :
   distrib.append([i/R,number])

#write output
f=open("test.dat",'w')
for i in diff_dataE:
#for i in distrib:
   f.write(str(i[0]))
   f.write('\t')
   f.write(str(i[1]))
   f.write('\n')
sys.exit()



maxV=max(map(lambda x:x[2],donnees))
sumV=sum(map(lambda x:x[2],donnees))



