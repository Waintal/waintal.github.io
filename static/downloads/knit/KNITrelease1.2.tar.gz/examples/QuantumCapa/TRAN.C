#include "knit_physics.h"
#include "knit_Python_Data.h"

/** This mode permits to obtain LDOS dependance on energie of the rectangular sample connected to one lead via QPC **/
// this file should be placed in tmp folder and executed with make TRAN command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  if (argc == 1) {cout<<"\nUSAGE:\n ./test.out TRAN.input\n";return 1;};

  PythonData::Python_Data input(argv[1]);

  // general options
  const string outfileS=input.S("outfile"); 
  const char* outfile=outfileS.c_str(); // both of this lines are needed if not outfile is modified during execution

  int ep=input.I("ep"); // number of energy points
  double flux=input.D("flux");
  const bool is_Bfield=input.I("is_Bfield");
  if (!is_Bfield) flux=0.;
  bool is_QPC=input.I("is_QPC");
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); 
  int QPCchannel=input.I("QPCchannel");

  // system
  int M=input.I("M");// channel number
  int N=input.I("N");// sample size
  // Hdiag should not be zero as QPC will multiply this value by some factor
  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  V_sample(0,0)=input.D("V_sample");
  V_LL(0,0)=input.D("V_LL");
  V_RL(0,0)=input.D("V_RL");
  Hdiag(0,0)=input.D("Hdiag");
  Hdiag_LL(0,0)=input.D("Hdiag_LL");
  Hdiag_RL(0,0)=input.D("Hdiag_LL");
  // END of Input ***************************************************

  // Print on screen what we are doing
  cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
  cout<<"2 Leads Rectangular system"<<endl;
  if (is_QPC) cout<<"with QPC"<<endl;
  else cout<<"no QPC"<<endl;
  if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
  else cout<<"no B field"<<endl;
  cout<<"\nTrasmission calculations"<<endl;

  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,8);
    sys.changeH(QPCpotential); // change profile for the system
  };

  //Adding desorder
    Array<int,1> TMP(shape(2));
    Rand Randpotential(TMP,0.01);
    rand();
//     for (int i=0;i<100;++i)
//       sys.changeH(Randpotential); // change profile for the system


  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);
  
  // Trasmission calculations *******************************

  ofstream toTrans(outfile);
  cout<<"Write data to file="<<outfile<<endl;
  double bande_min=max(Hdiag_LL(0,0).real()-4.*abs(V_LL(0,0)),Hdiag_RL(0,0).real()-4.*abs(V_RL(0,0)) );
  double bande_max=min(Hdiag_LL(0,0).real()+4.*abs(V_LL(0,0)),Hdiag_RL(0,0).real()+4.*abs(V_RL(0,0)) );
  cout<<"bande_min="<<bande_min<<endl;
  cout<<"bande_max="<<bande_max<<endl;
  bande_min=0.01;bande_max=3.5; //TTTT
  cout.precision(15);cout<<scientific;
  toTrans.precision(15);

  cout<<"Knit calculations"<<endl;
  for (double EE=bande_min; EE<bande_max; EE+=(bande_max-bande_min)/ep){
    knit<scalarM> work(0,sys_lead, EE); 
    work.set_saving_level(0);
    work.forward(ToZero); work.forward(ToEnd);
    COMPLEX coef=coef_T(work,0,1);
    toTrans<<EE<<"\t"<<coef.real()<<endl;
  };

  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Transmission calculations done for "<<ep<<" energy points"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
