// NOT executable .C file
// rectangular system  connected to two leads
// one could optionnaly add QPC in the middle
// needed variables:
//  Array<int,1> LxLyLz(2),OxOyOz(2);
//  int M, N; 
//  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
//  double flux;
// output is 
//  system_infini<scalarM> sys_lead;

// main system
Array<int,1> LxLyLz(2),OxOyOz(2);
LxLyLz=M,N;
OxOyOz=0,0;
systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

// Adding QPC potential
if (is_QPC) {
  QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
  sys.changeH(QPCpotential); // change profile for the system
};

// adding magnetic field
if (is_Bfield)  sys.applyB(flux);

// first lead
LxLyLz=M,1;
OxOyOz=0,0;
s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

// second lead
LxLyLz=M,1;
OxOyOz=0,N-1;
s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
sys_lead.addlead(lead2);
  
