#!/usr/bin/python

# simple 2D plot

from commands import *
from math import *
from pyx import *
import sys
import os

if len(sys.argv) == 1:
  print " USAGE: 2Dplot.py filename"
  sys.exit()

filename=sys.argv[1];
if len(sys.argv)==4:
   ymin=float(sys.argv[2])
   ymax=float(sys.argv[3])
   print "ymin=",ymin
   print "ymax=",ymax
   g = graph.graphxy(width=15,x=graph.axis.lin(min=0,max=500),y=graph.axis.lin(min=ymin,max=ymax))
else:   
   g = graph.graphxy(width=15,y=graph.axis.lin())
g.plot(graph.data.file(filename, x="$1*$2", y="log($3)/log(10)"))
g.writeEPSfile(filename)
g.writePDFfile(filename)
os.system("gv "+filename+".eps&")

