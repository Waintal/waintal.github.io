#include "knit_knit.h"
#include "blitz_addon.h"
#include "knit_Python_Data.h"

//** This module permits to obtain LDOS of the rectangular sample connected to the two leads
// direct inversion and knit methode are both used simultaniosly and average error is calculated
// combined with python script precision.py one could get errors as function of sample size

// this file should be placed in tmp folder and executed with make test_LDOS command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  if (argc == 1) {cout<<"\nUSAGE:\n ./test.out LDOS_error.input\n";return 1;};

  PythonData::Python_Data input(argv[1]);

  // general options
  double En=input.D("En"); // working energy
  const double epsilon=input.D("epsilon"); // complex part of energy
  double flux=input.D("flux");
  const bool is_PythonScript=input.I("is_PythonScript");
  const bool is_Bfield=input.I("is_Bfield");
  if (!is_Bfield) flux=0.;
  bool is_QPC=input.I("is_QPC");
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); 
  int QPCchannel=input.I("QPCchannel");

  // system
  int M=input.I("M");// channel number
  int N=input.I("N");// sample size
  // for Python scripts
  if (is_PythonScript){
    if (argc!=4)  {cout<<"In Python script mode M and N variables should be passed as argv[2] and argv[3] arguments"<<endl;return 1;}
    M=atoi(argv[2]); N=atoi(argv[3]); // overwrite default arguments
  };
  // Hdiag should not be zero as QPC will multiply this value by some factor
  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  V_sample(0,0)=input.D("V_sample");
  V_LL(0,0)=input.D("V_LL");
  V_RL(0,0)=input.D("V_RL");
  Hdiag(0,0)=input.D("Hdiag");
  Hdiag_LL(0,0)=input.D("Hdiag_LL");
  Hdiag_RL(0,0)=input.D("Hdiag_LL");
  // END of Input ***************************************************
  if (argc > 2 && !is_PythonScript) {cout<<"\nUSAGE:\n Set is_PythonScript=1 in input file to use 3 input parameters\n ./test.out LDOS_error.input M N\n";return 1;};


  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);


  // Print on screen what we are doing
  if (!is_PythonScript){ // only for non python mode
    cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
    cout<<"2 Leads Rectangular system"<<endl;
    if (is_QPC) cout<<"with QPC"<<endl;
    else cout<<"no QPC"<<endl;
    if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
    else cout<<"no B field"<<endl;
    cout<<"\nDensity calculations"<<endl;
  };

  cout.precision(15);cout<<scientific;  
  // Density calculations *************************
  const COMPLEX cEn=COMPLEX(En,epsilon);

  //knit technique
  knit<scalarM> work(0,sys_lead, cEn); 
  work.forward(ToEnd);
  sew<scalarM> S(work);
  S.sew2end();
  const GF_type GnotK( S.getGnotK() );

  // direct inversion
  direct<scalarM> dir(sys_lead ); 
  dir.calculate4E(cEn);

  //calculate errors
  double max_err=0.,mean_err=0.;
  for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_den=-GnotK(i,0,sys_lead.fzmax(),0).imag()/PI;
      const double val_denDI=-dir.G(i,i)(0,0).imag()/PI;
      const double val_diff=val_denDI-val_den;
      max_err=max(max_err,abs(val_diff));
      mean_err+=abs(val_diff/(val_denDI+val_den));
  };
  mean_err/=sys_lead.fsize();
  //output for python scrips
  ofstream toTmp4Py("./tmp/Tmp4Py.dat");
  toTmp4Py<<M<<'\t'<<N<<'\t'<<mean_err<<'\t'<<max_err<<endl;
  //print results onscreen
  if (!is_PythonScript){ // only for non python mode
    cout<<M<<'\t'<<N<<endl<<"Mean error="<<mean_err<<endl<<"Max error="<<max_err<<endl;
  };

  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Density Error calculations done for "<<cEn<<" energy"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
