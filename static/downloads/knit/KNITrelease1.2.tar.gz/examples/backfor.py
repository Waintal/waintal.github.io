#!/usr/bin/python

# Forward Backward test of error compared to DI
# dependance of sum of relative error on site index for given system is calculated: err(Middle_Point) 
# this script compile make test_BwFw and executes ./error.out file.input Middle_Point for different Middle_point 

from commands import *
from math import *
from pyx import *
import sys
import os
import time

def s2floats(a):
   return map(float,a.split())

if len(sys.argv) == 1:
  print " USAGE: give range for Middle_Point \n ./backfor.py minMP maxMP"
  sys.exit()

#input middle point range
minMP=int(sys.argv[1])
maxMP=int(sys.argv[2])
time.sleep(0.5)

filename="../tmp/forback.dat"
if os.path.exists("../tmp/BwFw_error.C") == 0 :
   print "Copy BwFw_error.C to tmp folder first"
   sys.exit()
if os.path.exists("../examples/BwFw_error.input") == 0 :
   print "No input file found"
   sys.exit()
   
os.system("cd ..;make test_BwFw")
os.system("rm -f "+filename)
os.system("touch "+filename )

print " EXECUSION OF TEST.OUT... "
for sys_ind in range(minMP,maxMP):
   os.system("cd ..;./error.out ./examples/BwFw_error.input "+str(sys_ind))
   while (os.path.exists("../tmp/Tmp4Py.dat") == 0): pass
   time.sleep(0.05)
   os.system("cat ../tmp/Tmp4Py.dat >> "+filename)
   os.system("rm ../tmp/Tmp4Py.dat")

g = graph.graphxy(width=18)
#g.plot(graph.data.file(filename, x=1, y=2))
#g.writeEPSfile(filename)
#os.system("gv "+filename+".eps")
print "\nData is written to "+filename
#sys.exit()
