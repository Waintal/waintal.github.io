#!/usr/bin/python

# use data in the form of four columns
# M      N       abs_err      rel_err
# for different M and N to plot multipple curves of errors depending on N (M is fixed) or M (N is fixed)

from commands import *
from math import *
from pyx import *
import sys
import os


# for absolute error plotting set abs_or_relative=2
# for relative error plotting set abs_or_relative=3
abs_or_relative=3 
# False => err(N) for different M ; True => err(M) for different N
NM=True

MN=not NM
if NM :
   GraphIndex="N"
   X_axe="M"
else :
   GraphIndex="M"
   X_axe="N"

#conversion elements to the list of float
#those started with # are set to "not data" string
def s2floats(a):
   if a.split()[0] == "#": return "not_data"
   return map(float,a.split())

# coordinates scaling function
def f_coordz(a):
   return log(a+1.e-17)/log(10)
if len(sys.argv) == 1:
  print " USAGE: plotScaling.py datafile"
  print " ou:    plotScaling.py datafile zmin zmax"
  sys.exit()

print " LECTURE DONNEES... "

donnees=open(sys.argv[1])
donnees= map(s2floats,donnees.readlines())

while donnees[0] == "not_data":
   donnees.remove("not_data")
   if len(donnees) ==0:
      print "\nNO INPUT DATA\n"
      sys.exit()

maxV=max(map(lambda x:f_coordz(x[2]),donnees))
minV=min(map(lambda x:f_coordz(x[2]),donnees))

print " max = ",maxV
print " min = ",minV

if len(sys.argv) == 4:
   minV=float(sys.argv[2])
   maxV=float(sys.argv[3])
   print "max",maxV

gdata_list=[]

print "MULTIPLE 2D PLOTS"

maxNM=max(map(lambda x:x[NM],donnees))

for iter in range(2,int(maxNM+1)):
   a=[]
#   print " TRAITEMENT DONNEES... "
   for i in donnees:
      if i[0]*i[1]<5 : continue #for small size do nothing
      if i[NM]==iter : a.append([ i[MN], f_coordz(i[abs_or_relative]) ])

#for i in a:
#  i[1]=(i[1]-minV)/(maxV-minV)
#  if i[1]>1: i[1]=1
#  if i[1]<0: i[1]=0

#   print " ... FIN TRAITEMENT DONNEES"

   y_size=max(map(lambda x:x[1],a)) - min(map(lambda x:x[1],a))+1
   x_size=max(map(lambda x:x[0],a)) - min(map(lambda x:x[0],a))+1
   
   aspect=y_size/x_size
   ww=25
   gdata_list.append(graph.data.list(a,x=1, y=2, title=r" "+GraphIndex+"="+str(iter)))

print " DEBUT PYX... "
g = graph.graphxy(width=ww,
                  key=graph.key.key(pos="br", dist=0.1),
                  x=graph.axis.linear(title=X_axe),
                  y=graph.axis.linear(title="log (error per site) "))
g.plot( gdata_list,
        [graph.style.line([color.palette.Rainbow])])

# color.palette.WhiteRed Rainbow
g.writeEPSfile(sys.argv[1]+X_axe)
g.writePDFfile(sys.argv[1]+X_axe)
print " ...FIN PYX "

os.system("gv "+sys.argv[1]+X_axe+".eps & ")
#os.system("acroread "+sys.argv[1]+".pdf & ")
