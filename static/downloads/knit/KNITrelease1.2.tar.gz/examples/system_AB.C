// NOT executable .C file
// system of AB geometry (loop with a hole)
// one could optionnaly add two QPC in the arms
// needed variables:
//  Array<int,1> LxLyLz(2),OxOyOz(2);
//  int M, N; 
//  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
//  double flux;
// output is 
//  system_infini<scalarM> sys_lead;

  // main system
  LxLyLz=M,N;
  OxOyOz=M-1,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);
  OxOyOz=0,2*N/3;
  systemerectangle<scalarM> sys2(LxLyLz,OxOyOz,V_sample,Hdiag);
  sys.coller(sys2);
  OxOyOz=2*M-2,2*N/3;
  systemerectangle<scalarM> sys3(LxLyLz,OxOyOz,V_sample,Hdiag);
  sys.coller(sys3);
  OxOyOz=M-1,N+N/3;
  systemerectangle<scalarM> sys4(LxLyLz,OxOyOz,V_sample,Hdiag);
  sys.coller(sys4);

  // Adding QPC potential
  if (is_QPC) {
    Array<int,1> QPC_in_coord(2); // coordinates for QPC
    QPC_in_coord=3*M/2,N/2; // in the middle of the sample
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),M/10,4);
    sys.changeH(QPCpotential); // change profile for the system

    QPC_in_coord=3*M/2,N+N/3+N/2; // in the middle of the sample
    QPC QPC2potential(QPC_in_coord, 6.*abs(V_sample(0,0)),M/10,4);
    sys.changeH(QPC2potential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=M-1,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=M-1,2*N+N/3-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);
