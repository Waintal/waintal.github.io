#include "knit_physics.h"
#include "knit_Python_Data.h"

/** This mode permits to obtain transmission dependance on energie of the rectangular sample  connected to two leads **/
// this file should be placed in tmp folder and executed with make TRAN command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  if (argc == 1) {cout<<"\nUSAGE:\n ./test.out TRAN_2LeadsRect.input\n";return 1;};

  PythonData::Python_Data input(argv[1]);

  // general options
  const string outfileS=input.S("outfile"); 
  const char* outfile=outfileS.c_str(); // both of this lines are needed if not outfile is modified during execution

  int ep=input.I("ep"); // number of energy points
  double flux=input.D("flux");
  // with or without Direct Inversion
  const bool with_DI=input.I("with_DI");
  const bool is_Bfield=input.I("is_Bfield");
  if (!is_Bfield) flux=0.;
  bool is_QPC=input.I("is_QPC");
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); 
  int QPCchannel=input.I("QPCchannel");

  // system
  int M=input.I("M");// channel number
  int N=input.I("N");// sample size
  // Hdiag should not be zero as QPC will multiply this value by some factor
  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  V_sample(0,0)=input.D("V_sample");
  V_LL(0,0)=input.D("V_LL");
  V_RL(0,0)=input.D("V_RL");
  Hdiag(0,0)=input.D("Hdiag");
  Hdiag_LL(0,0)=input.D("Hdiag_LL");
  Hdiag_RL(0,0)=input.D("Hdiag_LL");
  // END of Input ***************************************************

  // Print on screen what we are doing
  cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
  cout<<"2 Leads Rectangular system"<<endl;
  if (is_QPC) cout<<"with QPC"<<endl;
  else cout<<"no QPC"<<endl;
  if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
  else cout<<"no B field"<<endl;
  cout<<"\nTrasmission calculations"<<endl;

  //****** System construction*******

 //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

// supplementary part Left
LxLyLz=N/5,N/5;
OxOyOz=M-1,N/6;
systemerectangle<scalarM> sysPartL(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartL);

// supplementary part Right
LxLyLz=N/5,N/5;
OxOyOz=M-1,N-N/5-N/6;
systemerectangle<scalarM> sysPartR(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartR);


// supplementary part LeftDown
LxLyLz=N/5,N/5;
OxOyOz=-N/5+1,N/6;
systemerectangle<scalarM> sysPartLD(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartLD);

// supplementary part RightDown
LxLyLz=N/5,N/5;
OxOyOz=-N/5+1,N-N/5-N/6;
systemerectangle<scalarM> sysPartRD(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartRD);


  //Adding desorder
  Array<int,1> TMP(shape(2));
  Rand Randpotential(TMP,0.003);
  rand();
  for (int i=0;i<1000;++i)
    sys.changeH(Randpotential); // change profile for the system


  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);


// lead for supplementary part left
LxLyLz=1,N/5;
OxOyOz=M-2+N/5,N/6;
s_systemrectangle lead_interfaceL(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
 if (is_Bfield)  lead_interfaceL.applyB(flux);
N_reservoir<scalarM> leadL(lead_interfaceL,V_LL,flux); // create lead from its interface
sys_lead.addlead(leadL);

// lead for supplementary part right
LxLyLz=1,N/5;
OxOyOz=M-2+N/5,N-N/5-N/6;
s_systemrectangle lead_interfaceR(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
if (is_Bfield)  lead_interfaceR.applyB(flux);
N_reservoir<scalarM> leadR(lead_interfaceR,V_RL,flux); // create lead from its interface
sys_lead.addlead(leadR);


// lead for supplementary part LeftDown
LxLyLz=1,N/5;
OxOyOz=-N/5+1,N/6;
s_systemrectangle lead_interfaceLD(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
 if (is_Bfield)  lead_interfaceLD.applyB(flux);
N_reservoir<scalarM> leadLD(lead_interfaceLD,V_LL,-flux); // create lead from its interface
sys_lead.addlead(leadLD);

// lead for supplementary part RightDown
LxLyLz=1,N/5;
OxOyOz=-N/5+1,N-N/5-N/6;
s_systemrectangle lead_interfaceRD(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
if (is_Bfield)  lead_interfaceRD.applyB(flux);
N_reservoir<scalarM> leadRD(lead_interfaceRD,V_RL,-flux); // create lead from its interface
sys_lead.addlead(leadRD);

  
  // Trasmission calculations *******************************

  ofstream toTrans(outfile);
  cout<<"Write data to file="<<outfile<<endl;
  double bande_min=max(Hdiag_LL(0,0).real()-4.*abs(V_LL(0,0)),Hdiag_RL(0,0).real()-4.*abs(V_RL(0,0)) );
  double bande_max=min(Hdiag_LL(0,0).real()+4.*abs(V_LL(0,0)),Hdiag_RL(0,0).real()+4.*abs(V_RL(0,0)) );
  cout<<"bande_min="<<bande_min<<endl;
  cout<<"bande_max="<<bande_max<<endl;
  cout.precision(15);cout<<scientific;


  // Direct Inversion calculations if with_DI=true
  if (with_DI){
    cout<<"Direct Inversion calculations"<<endl;
    if (sys_lead.fsize()>10000) cout<<"\nAttention! size of DI matrix is too big\n";
    direct<scalarM> dir(sys_lead); 
    for (double EE=bande_min; EE<bande_max; EE+=(bande_max-bande_min)/ep){
      dir.calculate4E(EE);
      COMPLEX coefDI=coef_T(dir,0,1);
      toTrans<<EE<<"\t"<<coefDI.real()<<endl;
    };
  }
  else{ //if with_DI=false =>  knit calculations
    cout<<"Knit calculations"<<endl;
    //    for (double EE=bande_min; EE<(bande_min+bande_max)/2; EE+=(bande_max-bande_min)/ep/2){
    for (double EE=-1.935; EE<-1.905; EE+=0.03/ep){
      knit<scalarM> work(0,sys_lead, EE); 
      work.set_saving_level(0);
      work.forward(ToZero); work.forward(ToEnd);
      const int lead_number=6;
      Array<COMPLEX,2> T_Matrix;
      T_Matrix.resize(lead_number,lead_number);
      for (int li=0;li<lead_number;li++) for (int lj=0;lj<lead_number;lj++)
	T_Matrix(lj,li)=coef_T(work,li,lj);
      Array<COMPLEX,2> G_Matrix;
      G_Matrix.resize(lead_number-1,lead_number-1);
      G_Matrix=0.;
      for (int li=0;li<lead_number-1;li++) for (int lj=0;lj<lead_number-1;lj++)
	if (li!=lj) G_Matrix(li,lj)=-T_Matrix(li,lj);
      for (int li=0;li<lead_number-1;li++)  for (int lj=0;lj<lead_number;lj++)
	if (li!=lj) G_Matrix(li,li)+=T_Matrix(li,lj);
      Inverse(G_Matrix);
      Array<COMPLEX,1> I_vec,V_vec;
      I_vec.resize(lead_number-1);
      V_vec.resize(lead_number-1);
      I_vec=1.,-1.,0.,0.,0.;
      V_vec=matmul(G_Matrix,I_vec);
      cout.precision(15);cout<<scientific;
      if (sum(abs(T_Matrix))>1e-6)
	toTrans<<EE<<"     \t"<<
	  (V_vec(2)-V_vec(3)).real()<<"      \t"<<(V_vec(4)-V_vec(2)).real()<<"   \t"<<V_vec(4).real()<<"   \t"<<-V_vec(3).real()<<endl;
    };
  };
  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Transmission calculations done for "<<ep<<" energy points"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
