#!/usr/bin/python
#density plot of data given in the form of three columns
# x  y  value


from commands import *
from math import *
from pyx import *
import sys
import os

#conversion elements to the list of float
#those started with # are set to "not data" string
def s2floats(a):
   if a.split()[0] == "#": return "not_data"
   return map(float,a.split())

# function to apply to different coordinates
def f_coordx(a):
   return a
def f_coordy(a):
   return a
def f_coordz(a):
   return a

if len(sys.argv) == 1:
  print " USAGE: plot3D.py fichier extension "
  print " ou:    plot3D.py fichier extension zmin zmax"
  sys.exit()

print " LECTURE DONNEES... "

donnees= open(sys.argv[1])
donnees= map(s2floats,donnees.readlines())

# delete not_data lines
while donnees[0] == "not_data":
   donnees.remove("not_data")
   if len(donnees) ==0:
      print "\nNO INPUT DATA\n"
      sys.exit()

maxV=max(map(lambda x:f_coordz(x[2]),donnees))
minV=min(map(lambda x:f_coordz(x[2]),donnees))
sumV=sum(map(lambda x:x[2],donnees))

for el in donnees:
   el[0]=int(el[0])
   el[1]=int(el[1])

print " max = ",maxV
print " min = ",minV
print " sum = ",sumV
print " size =", len(donnees)

a=[]
print " TRAITEMENT DONNEES... "
for i in donnees:
   a.append([f_coordx(i[1]),f_coordx(i[1]+1),f_coordy(i[0]),f_coordy(i[0]+1),f_coordz(i[2])])

if len(sys.argv) == 4:
  minV=float(sys.argv[2])
  maxV=float(sys.argv[3])
  print "max",maxV

for i in a:
  i[4]=(i[4]-minV)/(maxV-minV)
  if i[4]>1: i[4]=1
  if i[4]<0: i[4]=0



print " ... FIN TRAITEMENT DONNEES"

print " DEBUT PYX... "

x_size=max(map(lambda x:f_coordy(x[1]),donnees)) - min(map(lambda x:f_coordy(x[1]),donnees))
y_size=max(map(lambda x:f_coordx(x[0]),donnees)) - min(map(lambda x:f_coordx(x[0]),donnees))

print " x_size = ",x_size
print " y_size = ",y_size

#aspect=y_size/x_size
#ww=min(x_size,20)
g = graph.graphxy(width=x_size,height=y_size,
                  x=graph.axis.linear(),
		  y=graph.axis.linear())
g.plot(graph.data.list(a,xmin=1, xmax=2, ymin=3, ymax=4,color=5),
       [graph.style.rect(color.palette.ReverseRainbow)])
# color.palette.WhiteRed Rainbow Grey BlueRed
#g.writeEPSfile(sys.argv[1])
g.writePDFfile(sys.argv[1])
print " ...FIN PYX "

#os.system("scp "+sys.argv[1]+".pdf scylla:. ")
#os.system("gv "+sys.argv[1]+".eps & ")
os.system("acroread "+sys.argv[1]+".pdf & ")
