#include "knit_knit.h"
#include "knit_Python_Data.h"

//** This module permits to obtain GF errors dependance during backward for the rectangular sample connected to the two leads
// direct inversion and knit methode are both used simultaniosly and average error is calculated
// combined with python script backfor.py one could get errors as function of Middle_Point

// this file should be placed in tmp folder and executed with make test_FwBw command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  if (argc == 1) {cout<<"\nUSAGE:\n ./test.out LDOS_error.input\n";return 1;};

  PythonData::Python_Data input(argv[1]);

  // general options
  // middle point is a point where we will compare ours GFs calculated on forward and backward
  int Middle_Point = input.I("Middle_Point");
  double En=input.D("En"); // working energy
  const double epsilon=input.D("epsilon"); // complex part of energy
  double flux=input.D("flux");
  const bool is_PythonScript=input.I("is_PythonScript");
  const bool is_Bfield=input.I("is_Bfield");
  if (!is_Bfield) flux=0.;
  bool is_QPC=input.I("is_QPC");
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); 
  int QPCchannel=input.I("QPCchannel");

  // system
  int M=input.I("M");// channel number
  int N=input.I("N");// sample size
  // for Python scripts
  if (is_PythonScript){
    cout<<"xxxxxxxxxxxxxx"<<endl;
    if (argc!=3)  {cout<<"In Python script mode Middle_Point variable should be passed via argv[2] arguments: \nSet is_PythonScript=0"<<endl;return 1;}
    Middle_Point = atoi(argv[2]); // overwrite default argument
  };

  // Hdiag should not be zero as QPC will multiply this value by some factor
  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  V_sample(0,0)=input.D("V_sample");
  V_LL(0,0)=input.D("V_LL");
  V_RL(0,0)=input.D("V_RL");
  Hdiag(0,0)=input.D("Hdiag");
  Hdiag_LL(0,0)=input.D("Hdiag_LL");
  Hdiag_RL(0,0)=input.D("Hdiag_LL");
  // END of Input ***************************************************
  if (argc > 2 && !is_PythonScript) {cout<<"\nUSAGE:\n Set is_PythonScript=1 in input file to use 3 input parameters\n ./test.out LDOS_error.input M N\n";return 1;};
  if (Middle_Point<M || Middle_Point>M*N-M) {cout<<"Authorised range "<<M<<" => "<<M*N-M<<endl;ERROR("Middle Point should not belongs to any lead");}

  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);


  // Print on screen what we are doing
  if (!is_PythonScript){ // only for non python mode
    cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
    cout<<"2 Leads Rectangular system"<<endl;
    if (is_QPC) cout<<"with QPC"<<endl;
    else cout<<"no QPC"<<endl;
    if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
    else cout<<"no B field"<<endl;
    cout<<"\nDensity calculations"<<endl;
  };

  cout.precision(15);cout<<scientific;  

  const COMPLEX cEn=COMPLEX(En,epsilon);
  // FORWARD BACKWARD ERRORS FOR RECTANGULAR SYSTEM
  // cout<<"********* testing forward backward errors for rectangular system ********\n";

  knit<scalarM> work(0,sys_lead, cEn); 
  work.set_saving_level(5*M);
  
  // work forward till middle point
  while ( Middle_Point  != work.fpos().ffin())
    work.forward(la_fin);  
  // save GF for middle point
  GF_type Gsave=work.G().copy();

  // go to the end
  work.forward(ToEnd);
  // come back to the middle
  while (Middle_Point != work.fpos().ffin())
    work.backward(la_fin);  

  // Transmission matrix error testing
  //DIRECT INVERSION CALCULATIONS
  //cout<<"DIRECT INVERSION CALCULATIONS"<<endl;
  direct<scalarM> dir(sys_lead,0,work.fpos().ffin());
  dir.calculate4E(cEn);
  GF_type GF_DI((work.G()).shape());
  for (int i=0;i<work.fpos().ftaille();++i){
    const int si=work.fpos().g2s(i); // sys index of i
    for (int j=0;j<work.fpos().ftaille();++j){
      const int sj=work.fpos().g2s(j); // sys index of j
      GF_DI(i,ALL,j,ALL)=dir.G(si,sj);
      };
  };

  
  // err DI
  Array<double,4> TMP(abs((work.G()-GF_DI)/(work.G()+GF_DI)));
  Array<double,2> ErrDI( TMP.data(), shape(TMP.extent(0),TMP.extent(2)) );
  const double val_diffDI=sum(ErrDI)/work.G().size();

  //err backward forward
  Array<double,4> TMP1(abs((work.G()-Gsave)/(work.G()+Gsave)));
  Array<double,2> ErrBF( TMP1.data(), shape(TMP1.extent(0),TMP1.extent(2)) );
  const double val_diffBF=sum(ErrBF)/work.G().size();

  //err forward forward
  Array<double,4> TMP2(abs((GF_DI-Gsave)/(work.G()+GF_DI)));
  Array<double,2> ErrFor( TMP2.data(), shape(TMP2.extent(0),TMP2.extent(2)) );
  const double val_diffFW=sum(ErrFor)/work.G().size();


  //output for python
  ofstream toTmp4Py("./tmp/Tmp4Py.dat");
  toTmp4Py<<Middle_Point<<'\t'<<val_diffBF<<'\t'<<val_diffDI<<'\t'<<val_diffFW<<endl;
  cout<<"Middle_Point="<<Middle_Point<<endl<<"errorBF="<<val_diffBF<<'\t'<<"errorB="<<val_diffDI<<'\t'<<"errorF="<<val_diffFW<<endl;
  //   cout<<"min err GF "<<minIndex(ErrFor)<<"="<<min(ErrFor)<<endl;
  //   cout<<"max err GF "<<maxIndex(ErrFor)<<"="<<max(ErrFor)<<endl;
  //   cout<<"max err GF elem="<<GF_DI(maxIndex(TMP2))<<endl;
  //  for (int i=0;i<ErrFor.extent(0);++i)  for (int j=0;j<ErrFor.extent(1);++j) cout<<ErrFor(i,j)<<endl;

  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Density Error calculations done for "<<cEn<<" energy"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
