#include "knit_knit.h"
#include "knit_Python_Data.h"

/** This mode permits to obtain LDOS map of the rectangular sample  connected to two leads **/
// this file should be placed in tmp folder and executed with make LDOS command


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  //typedef vectorM<2> testM;
  typedef scalarM testM;

  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  if (argc == 1) {cout<<"\nUSAGE:\n ./test.out LDOS_2LeadsRect.input\n";return 1;};

  PythonData::Python_Data input(argv[1]);

  // general options
  const string outfileS=input.S("outfile"); 
  const char* outfile=outfileS.c_str(); // both of this lines are needed if not outfile is modified during execution

  double En=input.D("En"); // working energy
  double epsilon=input.D("epsilon"); // complex part of energy
  double flux=input.D("flux");
  // with or without Direct Inversion
  const bool with_DI=input.I("with_DI");
  const bool is_Bfield=input.I("is_Bfield");
  if (!is_Bfield) flux=0.;
  bool is_QPC=input.I("is_QPC");
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); 
  int QPCchannel=input.I("QPCchannel");

  // system
  int M=input.I("M");// channel number
  int N=input.I("N");// sample size
  // Hdiag should not be zero as QPC will multiply this value by some factor
  testM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  for (int i=0;i<testM::dim();++i) {
    V_sample(i,i)=input.D("V_sample");
    V_LL(i,i)=input.D("V_LL");
    V_RL(i,i)=input.D("V_RL");
    Hdiag(i,i)=input.D("Hdiag");
    Hdiag_LL(i,i)=input.D("Hdiag_LL");
    Hdiag_RL(i,i)=input.D("Hdiag_LL");
  }
  // END of Input ***************************************************

  // Print on screen what we are doing
  cout<<"SYSTEM"<<endl<<"MxN="<<M<<"x"<<N<<endl;
  cout<<"2 Leads Rectangular system"<<endl;
  if (is_QPC) cout<<"with QPC"<<endl;
  else cout<<"no QPC"<<endl;
  if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
  else cout<<"no B field"<<endl;
  cout<<"\nDensity calculations"<<endl;

  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<testM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);

  // Adding QPC potential
  if (is_QPC) {
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),QPCchannel,4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<testM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<testM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<testM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  sys_lead.addlead(lead2);

  cout.precision(15);cout<<scientific;  
  // Density calculations *************************
  const COMPLEX cEn=COMPLEX(En,epsilon);

  // file title that is put in first two lines
  stringstream fileTitle;
  fileTitle<<"# M="<<M<<"  N="<<N<<"   Energy="<<cEn<<"  is_QPC ="<<is_QPC<<"  V_sample="<<V_sample(0,0)<<"  V_LL="<<V_LL(0,0)<<"  V_RL="<<V_RL(0,0)<<"  Hdiag="<<Hdiag(0,0)<<"  Hdiag_LL="<<Hdiag_LL(0,0)<<"  Hdiag_RL="<<Hdiag_RL(0,0);
  if (is_Bfield) fileTitle<<"  flux="<<flux;
  fileTitle<<"\n# x_coor  y_coord  density"<<endl;
  ofstream toDensity(outfile);
  cout<<"Write data to file="<<outfile<<endl;
  toDensity<<fileTitle.str();

  // with or without Direct Inversion
  if (with_DI) { // density by direct inversion
    cout<<"Direct Inversion calculations"<<endl;
    direct<testM> dir(sys_lead ); 
    if (with_DI)  dir.calculate4E(cEn);
    for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_denDI=-dir.G(i,i)(0,0).imag()/PI;
      toDensity<<x_pos<<"\t"<<y_pos<<"\t"<<val_denDI<<endl;
    };
  }
  else{ // density by knit technique
    cout<<"Knit calculations"<<endl;
    knit<testM> work(0,sys_lead, cEn); 
    work.forward(ToEnd);
    sew<testM> S(work);
    S.sew2end();
    const GF_type GnotK( S.getGnotK() );
    for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_den=-GnotK(i,0,sys_lead.fzmax(),0).imag()/PI;
      toDensity<<x_pos<<"\t"<<y_pos<<"\t"<<val_den<<endl;
    };
  };


  // output time of calculations
  clock_t t_out=clock();
  ofstream toTime("./tmp/execTime.dat");
  toTime<<"Density calculations done for "<<cEn<<" energy"<<endl;
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
  return 0;
};

#endif
