#!/usr/bin/python

# we get data for maximal absolut error depending on system size
# data is given in the following format
# M  N  err_mean err_max
# one could then plot this data using plotScaling.py

from commands import *
from math import *
from pyx import *
import sys
import os
import time

def s2floats(a):
   return map(float,a.split())

if len(sys.argv) == 1:
  print " USAGE: precision.py max_x_size max_y_size"
  sys.exit()

M_range=int(sys.argv[1])
N_range=int(sys.argv[2])

filename="../tmp/prec.dat"
if os.path.exists("../tmp/LDOS_error.C") == 0 :
   print "Copy LDOS_error.C to tmp folder first"
   sys.exit()
if os.path.exists("../examples/LDOS_error.input") == 0 :
   print "No input file found"
   sys.exit()

os.system("cd ..;make test_LDOS")
f=open(filename,'w')
f.write("# M  N err_abs err_rel")
f.close()
print " EXECUSION OF TEST.OUT... "
for N in range(2,N_range+1):
   for M in range(1,M_range+1):
      #run error.out inputfile M N
      os.system("cd ..;./error.out examples/LDOS_error.input "+str(M)+" "+str(N))
      # wait while calculates
      while (os.path.exists("../tmp/Tmp4Py.dat") == 0): pass
      # wait all data to be written to file
      time.sleep(0.05)
      
      os.system("cat ../tmp/Tmp4Py.dat >> "+filename)
      os.system("rm ../tmp/Tmp4Py.dat")
      #donnees.append( map(s2floats,open("./DATA/Tmp4Py.dat").readlines())[0])

print "\nData are written to file"+filename
