// NOT executable .C file
// system for four contacts mesurements (rectangle with two suppementary contacts on the top)
// one could optionnaly add QPC in the middle
// needed variables:
//  Array<int,1> LxLyLz(2),OxOyOz(2);
//  int M, N; 
//  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
//  double flux;
// output is 
//  system_infini<scalarM> sys_lead;

// main system
LxLyLz=M,N;
OxOyOz=0,0;
systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);
// supplementary part Left
LxLyLz=N/5,N/5;
OxOyOz=M-1,N/6;
systemerectangle<scalarM> sysPartL(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartL);

// supplementary part Right
LxLyLz=N/5,N/5;
OxOyOz=M-1,N-N/5-N/6;
systemerectangle<scalarM> sysPartR(LxLyLz,OxOyOz,V_sample,Hdiag);
sys.coller(sysPartR);

// Adding QPC potential
if (is_QPC) {
  Array<int,1> QPC_in_coord(2); // coordinates for QPC
  QPC_in_coord=M/2,N/2; // in the middle of the sample
  QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),M/10,4);
  sys.changeH(QPCpotential); // change profile for the system
};

// adding magnetic field
if (is_Bfield)  sys.applyB(flux);

// first lead
LxLyLz=M,1;
OxOyOz=0,0;
s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

// second lead
LxLyLz=M,1;
OxOyOz=0,N-1;
s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
sys_lead.addlead(lead2);

// lead for supplementary part left
LxLyLz=1,N/5;
OxOyOz=M-2+N/5,N/6;
s_systemrectangle lead_interfaceL(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
N_reservoir<scalarM> leadL(lead_interfaceL,V_LL); // create lead from its interface
sys_lead.addlead(leadL);

// lead for supplementary part right
LxLyLz=1,N/5;
OxOyOz=M-2+N/5,N-N/5-N/6;
s_systemrectangle lead_interfaceR(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
N_reservoir<scalarM> leadR(lead_interfaceR,V_RL); // create lead from its interface
sys_lead.addlead(leadR);
