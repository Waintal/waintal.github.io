#include "swig_general.h"
#include <stdio.h>
#include <iostream>
#include <sstream>

namespace PY {
  //using namespace PY;
int PyView::profondeur=0;
PyObject* main_namespace=NULL,*main_module =NULL;
bool a_python_is_running = false; // to avoid multiple instancesof an embedded interpreter

/**************************************************

Pyref class

**************************************************/

pyref::pyref(PyObject * obj,bool increase_ref)
{
  me = obj;
  if (!me) FATAL("C++ internal error : Trying to construct a pyref with a NULL ref !!");
  if (increase_ref) Py_INCREF(me);
}

pyref::~pyref(){ 
if ( me)  Py_DECREF(me);
}

pyref::pyref(const pyref & x,bool deep_copy): me(x.me)
{
  if (!deep_copy)
    {
      if ( me ) Py_INCREF(me);
    }
  else
    {
      PyObject *pymodule = PyImport_ImportModule("copy"); // new ref
      if (!pymodule) FATAL("Module copy not found");
      PyObject *fnt =  PyObject_GetAttrString(pymodule,"deepcopy"); //new ref
      if (!fnt) FATAL("Function : deepcopy  not found in Module copy ");
      PyObject * args = Py_BuildValue("(O)",x.me);
      me = PyObject_CallObject(fnt, args);
      Py_DECREF(pymodule); Py_DECREF(fnt); Py_DECREF(args);
      if (me==NULL) {clean_error();FATAL("pyref : deepcopy error");}
    }
}

pyref & pyref::operator = (const pyref & x)
{
  PyObject* tmp=me;
  me = x.me;
  if (me) Py_INCREF(me); 
  if (tmp) Py_DECREF(tmp);
  return *this;
}
  
pyref::operator PyObject* () const
{ if (!me) FATAL("C++ internal error : Trying to use a NULL ref !!");
  return me;
}


PyObject * pyref::new_pyo() const
{ if (!me) FATAL("C++ internal error : Trying to use a NULL ref !!");
  //  FLAG("pyo inc"<<me->ob_refcnt);
  Py_INCREF(me); 
  //FLAG("pyo inc done"<<me->ob_refcnt);
  return me;
}
/*
PyObject * pyref::bor_pyo() const
{ if (!me) FATAL("C++ internal error : Trying to use a NULL ref !!");
  return me;
}
*/

/***********************************************************/
 
pyref callPythonFunction(PyObject* args,string name,string module,string err_mess)
{
  PyView V();
  PyObject *pymodule = PyView().pyo(module,"",Optional);
  if (pymodule) Py_INCREF(pymodule); else pymodule = PyImport_ImportModule((char*) module.c_str()); // new ref
  if (!pymodule) FATAL("Module "<<module<<" not found");
  PyObject *fnt =  PyObject_GetAttrString(pymodule,(char*)name.c_str()); //new ref
  if (!fnt) FATAL("Function :"<<name<<"  not found in Module "<<module);

  // if we pass jsut an argument, not in tuple, I put it in a tuple...
  if (PyTuple_Check(args)) Py_INCREF(args);
  else { args = Py_BuildValue("(O)",args);}

  PyObject* res = PyObject_CallObject(fnt,args);
  
  Py_DECREF(pymodule); Py_DECREF(fnt);Py_DECREF(args);
  if (res==NULL) {pyref::clean_error();FATAL(err_mess);}
  return pyref(res);
}

/***********************************************************/
 
pyref callPythonMethod(PyObject* object,string method,PyObject* args,string err_mess)
{
  PyObject *meth = PyObject_GetAttrString(object,(char*)method.c_str()); 
  //PyObjectPyView(object).pyo(method,"",Strict);
  if (!meth)  FATAL("Method "<<method<<" not found");
  if (!PyMethod_Check(meth)) FATAL(method<<" is not a method");
  Py_INCREF(meth);
  PyObject *fnt = PyMethod_Function(meth);
  if (!fnt) FATAL("Method "<<method<<" can not be a function");
  
  // if we pass jsut an argument, not in tuple, I put it in a tuple...
  if (!args) args = Py_BuildValue("()");
  else 
    {
      if (PyTuple_Check(args)) Py_INCREF(args);
      else { args = Py_BuildValue("(O)",args);}
    }

  PyObject* fullargs = PyTuple_New(PyTuple_Size(args)+1);
  Py_INCREF(object);
  PyTuple_SetItem(fullargs,0,object);
  for (int i =0; i<PyTuple_Size(args); i++) PyTuple_SetItem(fullargs,i+1,PySequence_GetItem(args,i));

  PyObject* res = PyObject_CallObject(fnt,fullargs);
  
  Py_DECREF(meth); Py_DECREF(fnt);Py_DECREF(args);Py_DECREF(fullargs);
  if (res==NULL) {pyref::clean_error();FATAL(err_mess);}
  return pyref(res);
}

/***********************************************************

 
               CONSTRUCTORS


***********************************************************/

PyView::PyView(int argc, char *argv[],string preamble_add_on)
{
  test_mode=false;
  bool ok=false;string fich;
#ifdef USE_MPI
  if IS_MASTER_NODE {
#endif
    if (argc>=2) {
      if ((string(argv[1])=="-test")&&(argc>=3))  {ok=true; fich=argv[2];test_mode=true;}
      else {ok=true; fich=argv[1];}
    } 

#ifdef USE_MPI
  }
  myMPI_bcast(ok);myMPI_bcast(fich);
#endif 
  if (!ok) FATAL("Usage : program input_file  OR program -test input_file");
  for_construct(fich,preamble_add_on);
}

/***********************************************************/

PyView::PyView(string python_script,string preamble_add_on)
{ test_mode=false; for_construct(python_script,preamble_add_on);}


/***********************************************************/

void PyView::for_construct(string python_script,string preamble_add_on)
{
  is_original=true;
  if (a_python_is_running) FATAL("FATAL : There is already a PyView class using the interpreter. Use other constructors");
  a_python_is_running = true;
  
  Py_Initialize();
  main_module    = PyImport_ImportModule("__main__");//PyImport_AddModule("__main__");
  main_namespace = PyModule_GetDict(main_module);
  Py_INCREF(main_namespace);
  DICO = main_namespace;
  CLASSDICO = main_namespace;  CLASS=NULL;
  Py_INCREF(DICO); Py_INCREF(CLASSDICO);

  import_array();
  // PyImport_ImportModule("Numeric");

  // First the preamble 
  char *preamble = "import sys,os     \n\
from math import *  \n\
#from lisa import *  \n\
___local_for_include_DONT_CHANGE = locals() \n\
def include(f) :                              \n\
    global ___local_for_include_DONT_CHANGE      \n\
    execfile(f,globals(),___local_for_include_DONT_CHANGE)   \n\
class StdoutCatcher:  \n\
     def __init__(self):\n\
        self.data = ''                \n\
     def write(self, stuff):            \n\
        self.data = self.data + stuff    \n\
#sys.stdout = StdoutCatcher()              \n\
#sys.stderr = StdoutCatcher()              \n\
#_old_local = locals().copy()              \n\
sys.path = ['./'] + sys.path \n\
";
  PyRun_SimpleString(preamble);      

  exec(preamble_add_on);
  execfile(python_script);

  /*
  PyRun_SimpleString("sys.stdout.data,sys.stderr.data='',''");
  PyView SYS("sys");

  if (!PyRun_SimpleString((char *)preamble_add_on.c_str()))
    {PyErr_Print();FATAL("Error in the preamble of the script: \n"<<preamble_add_on<<endl
			 <<PyView("stdout",&SYS).S("data")<<endl
			 <<PyView("stderr",&SYS).S("data")<<endl);}
  
  PyRun_SimpleString("sys.stdout.data,sys.stderr.data='',''");
  
  if (!PyRun_SimpleString((char *)python_script.c_str()))
    {PyErr_Print();FATAL("Error in the script"<<endl
			 <<PyView("stdout",&SYS).S("data")<<endl
			 <<PyView("stderr",&SYS).S("data")<<endl);}
  */


}


/***********************************************************/

PyView::~PyView() 
{   
  if (CLASS !=NULL) Py_DECREF(CLASS);
  if (CLASSDICO !=NULL) Py_DECREF(CLASSDICO);
  if (DICO!=NULL) Py_DECREF(DICO);

  if (is_original) 
    {
      Py_Finalize();
      a_python_is_running =false;
      main_module=NULL;main_namespace=NULL;
    }
}

/***********************************************************/

PyView::PyView(PyObject * Obj)
{ for_construct2(Obj);}


/***********************************************************/


PyView::PyView(const PyView & p,string s)
{
  if (s=="")
    {
      is_original=false;test_mode = false;
      DICO = p.DICO; if (DICO) Py_INCREF(DICO);
      CLASSDICO = p.CLASSDICO;if (CLASSDICO) Py_INCREF(CLASSDICO);
      CLASS = p.CLASS; if (CLASS) Py_INCREF(CLASS);
    } 
  else
    { 
      string err = "Construction PyView: " + s + "not found";
      PyObject* Obj = p.pyo(s.c_str(),err.c_str(),Strict);
      if (Obj==NULL) FATAL(err);
      // Py_INCREF(Obj);// pyo returns a BORROWED ref !
      for_construct2(Obj);
    }
}

void PyView::for_construct2(PyObject * Obj)
{
  import_array();
  is_original=false;test_mode = false;
  if (main_namespace==NULL)
  {
    main_module    = PyImport_ImportModule("__main__");//PyImport_AddModule("__main__");
    main_namespace = PyModule_GetDict(main_module);
    Py_INCREF(main_namespace);
  }

  if (Obj==NULL) // a view of the main of the interpreter
    {
      PyErr_Clear();
      DICO = main_namespace; CLASSDICO=main_namespace;Py_INCREF(CLASSDICO);Py_INCREF(DICO);CLASS=NULL; return;
    }
  DICO = PyObject_GetAttrString(Obj,"__dict__");
  if (DICO==NULL)
    {
      if  (PyDict_Check(Obj))  
	{ PyErr_Clear();
	  DICO = Obj; CLASSDICO=main_namespace;Py_INCREF(CLASSDICO);Py_INCREF(DICO);CLASS=NULL; return;}
      FATAL("Construction PyView : Obj has no __dict__ and is not a dict itself.");
    }
  // now it is a module or a class.  Both have a __class_.__dict__
  CLASS =  PyObject_GetAttrString(Obj,"__class__");
  if (CLASS ==NULL)
      FATAL("Construction PyView : Obj is not a class ");
   
  if (PyObject_HasAttrString(CLASS,"__dict__"))
    {
      CLASSDICO = PyObject_GetAttrString(CLASS,"__dict__");
      //      if (CLASSDICO==NULL) {CLASSDICO=main_namespace; Py_INCREF(CLASSDICO);}
    }
  else 
    {CLASSDICO=main_namespace; Py_INCREF(CLASSDICO); // some new-style class don't  necessarely have a dict....
    }
  //CLASSDICO=main_namespace; // PB ???
  // cout<<"For cons 2 fini"<<endl;
}

/***********************************************************

 
               PYO


***********************************************************/


void PyView::Fail(const char *nom, const char * error, const char * mess) const
{
   stringstream fs;
  fs << "The element "<< full_name(nom)<< " "<<error << endl;
  fs << "\nDescription : "<<mess<<endl;

  FATAL(fs.str());
}

/***********************************************************/

// RETURNS A BORROWED REFERENCE !!

PyObject * PyView::pyo(string nom, string mess, Policy pol) const
{
  PyObject* pElem = PyDict_GetItemString(DICO, nom.c_str());
  if (pElem==NULL) pElem = PyDict_GetItemString(CLASSDICO, nom.c_str());
  if (pElem==NULL) {
    if (pol==Strict) {Fail(nom.c_str(),"does not exist",mess.c_str());}
  }
  return(pElem);
}
/***********************************************************/

// STEALS THE REFERENCE !!

void PyView::put_pyo(string nom,PyObject * x)
{
  PyDict_SetItemString(DICO,(char*)nom.c_str(),x);Py_DECREF(x);
}

/***********************************************************

 
               EXEC


***********************************************************/



string PyView::exec(string s)
{
  // no argument : use the buffer.
  if (s=="") s=execbuf.str();
  execbuf.str(""); // clean the buffer in any case
  // If namepace, adapt the string : replace the @ by the namesapce
  s += "\n";
  //cout<<"executing "<<s<<endl;
  PyErr_Clear();

  string res ="";
  /*if (a_python_is_running) // the interpreter has been launched from C++
    {
      PyRun_SimpleString("sys.stdout.data,sys.stderr.data='',''");

      PyObject *sys_module    = PyImport_ImportModule("sys");
      PyView SYS(sys_module);
      if (!PyRun_String((char *)s.c_str(),Py_file_input,CLASSDICO,DICO))
	{PyErr_Print();FATAL("PyView::exec error : \n"<<s<<endl<<
			     PyView(SYS,"stdout").S("data")<<endl<<
			     PyView(SYS,"stderr").S("data")<<endl);}
      res =PyView(SYS,"stdout").S("data");
      Py_DECREF(sys_module);
    }
  else 
  */
    {
      if (!PyRun_String((char *)s.c_str(),Py_file_input,CLASSDICO,DICO))
	{PyErr_Print();FATAL("Error occurred");}
    }
  return(res);

}

string PyView::execfile(string s)
{
  FILE *fp = fopen(s.c_str(),"r");
  if (!fp) FATAL("File "<< s<<" not found ");
  PyErr_Clear();

  string res ="";

  /*  if (a_python_is_running) // the interpreter has been launched from C++
    {
      PyRun_SimpleString("sys.stdout.data,sys.stderr.data='',''");

      PyObject *sys_module    = PyImport_ImportModule("sys");
      PyView SYS(sys_module);
      if (!PyRun_File(fp,(char *)s.c_str(),Py_file_input,CLASSDICO,DICO))
	{PyErr_Print();FATAL("PyView::exec error : \n"<<s<<endl<<
			     PyView(SYS,"stdout").S("data")<<endl<<
			     PyView(SYS,"stderr").S("data")<<endl);}
      res =PyView(SYS,"stdout").S("data");
      Py_DECREF(sys_module);
    }
  else 
  */
 {
      //FLAG("Interpreter not embedded");
      PyRun_File(fp,(char *)s.c_str(),Py_file_input,CLASSDICO,DICO);
    }
  return(res);
}


/***********************************************************/

bool PyView::exists(string s)//const char * nom)
{
  PyObject* pElem = pyo(s.c_str(),"",Optional);
  return (pElem!=NULL);
}

/***********************************************************/

void PyView::require(string s, string mess)
{
  if (!exists(s)) Fail(s.c_str(),"does not exist", mess.c_str());
}


/***********************************************************/

string PyView::all()
{ 
  //if (CLASS==NULL) { cout <<" all not implemented for subview of pythondata"<<endl;}
  return ( exec(" \n\
print '# List of all defined variables' \n\
_l = locals().keys() \n\
_l.sort() \n\
for _x in _l : \n\
  if not(_x in _old_local) and (_x[0]!='_') and (locals()[_x]!=None) and (type(_x)!=type(sys)) :\n\
    print _x,'=',locals()[_x]\n\
print '#'\n\
"));
}
/***********************************************************/

void PyView::test_point() 
{   
#ifdef USE_MPI
  if (IS_MASTER_NODE) 
#endif
 
    // Do a list of the optional not found.

    /*
cout<<exec(" \n							\
print '########################################################' \n\
print '###   ANALYSIS OF DATA : FINAL REPORT               ####' \n\
print '########################################################' \n\
print '' \n\
print 'The following data have NOT been requested (at least directly !)' \n\
print '' \n\
_req=__requis__.keys()\n\
_l = locals().keys() \n\
_l.sort() \n\
for _x in _l : \n\
  if not(_x in _old_local) and (_x[0]!='_') and (locals()[_x]!=None) and (type(locals()[_x])!=type(sys)) and not(_x in _req) :\n\
    print _x,'=',locals()[_x]\n\
print '########################################################' \n\n\
print '' \n\
print 'The following OPTIONAL data have NOT been found : default has been used !' \n\
print '' \n\
_req=__pastrouve__.keys()\n\
for _x in _req : \n\
  if not(_x in _old_local) and (_x[0]!='_')  :\n\
    print '    ',_x,':',__pastrouve__[_x]\n\
    print '    ' \n\
print '########################################################' \n\n\
print '########################################################' \n\n\
")<<endl;

    */
  
  if (test_mode) {Py_Finalize();cout<<"TEST MODE : TEST SUCCESSFULL"<<endl;exit(0);}
}

/***********************************************************/
/*
int PyView::sequence_size(const char *nom, const char * mess, Policy pol)
{
  PyObject* pElem = pyo(nom,mess,pol);
  if ( (pElem!=NULL) && ( PyList_Check(pElem)  ||  PyTuple_Check(pElem)))
    return(PySequence_Length(pElem));
  else
    return(-1);
}
*/
/***********************************************************/

string PyView::tempo()
{
  stringstream fs;
  fs<<"_python_data_tmp_"<<profondeur;
  profondeur++;
  return(fs.str());
}

void PyView::cleartempo()
{
  profondeur--;
}

/***********************************************************/

/*void PyView::dump(string var,string file)
{
  exec("import pickle\npickle.dump("+var+",open('"+file+"','w'))");
}
*/

void check_list_elements_are_unique(PyObject * l,string error_message)
{
  pyref ok(callPythonFunction(l,"check_list_elements_are_unique","myUtils","Can't find check_list_elements_..."));
  if (!Py_to_C<bool>(ok)) FATAL(error_message);
}
 
template<>
void PyView::get<string,1>(string nom,Array<string,1> & arr, string mess, Policy pol)
{
  PyObject* pElem = pyo(nom,mess,pol);
    if ((pElem==NULL) && (pol==Optional)) {arr <= Array<string,1>(fortranArray);return;}
    try {list_to_blitz(pElem,arr);}
    catch (string err) {FATAL(err<<endl<<mess);}
}
 

}
