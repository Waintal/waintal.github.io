%module knit

%{

#include "kernel/knit_system.h"
#include "kernel/knit_micromatrices.h"
#include "kernel/knit_knit.h"
#include "kernel/knit_physics.h"


COMPLEX TransProba(const knit<scalarM>& kn,int leadA,int leadB) {return  coef_T<scalarM>(kn,leadA,leadB);};

COMPLEX TransProba_S(const knit<spinM>& kn,int leadA,int leadB) {return  coef_T<spinM>(kn,leadA,leadB);};

%}

namespace blitz{};
typedef std::complex<double> COMPLEX;
%include "swig_general.i"
%include "std_complex.i"
//swig_specialize_complex(COMPLEX);

%rename(my_print) print;
%include "kernel/knit_system.h"
%include "kernel/knit_micromatrices.h"
%include "kernel/knit_knit.h"
%include "kernel/knit_physics.h"

//****************** SCALAR **************************************

%template(unsysteme) systeme<scalarM>;
%template(rectangle) systemerectangle<scalarM>;
%template(unreservoir) reservoir<scalarM>;
%template(unreservoirN) N_reservoir<scalarM>;
%template(systemtotal) systeme_infini<scalarM>;

COMPLEX TransProba(const knit<scalarM>& kn,int leadA,int leadB);

%template(couture) sew<scalarM>;
%template(tricot) knit<scalarM>;

//****************** SPIN *****************************************

%template(spinM) vectorM<2>;
%template(unsysteme_S) systeme<spinM>;
%template(rectangle_S) systemerectangle<spinM>;
%template(unreservoir_S) reservoir<spinM>;
%template(unreservoirN_S) N_reservoir<spinM>;
%template(systemtotal_S) systeme_infini<spinM>;

COMPLEX TransProba_S(const knit<spinM>& kn,int leadA,int leadB);

%template(couture_S) sew<spinM>;
%template(tricot_S) knit<spinM>;
