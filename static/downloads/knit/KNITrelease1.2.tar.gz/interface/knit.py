# This file was created automatically by SWIG 1.3.29.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.

import _knit
import new
new_instancemethod = new.instancemethod
def _swig_setattr_nondynamic(self,class_type,name,value,static=1):
    if (name == "thisown"): return self.this.own(value)
    if (name == "this"):
        if type(value).__name__ == 'PySwigObject':
            self.__dict__[name] = value
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    if (not static) or hasattr(self,name):
        self.__dict__[name] = value
    else:
        raise AttributeError("You cannot add attributes to %s" % self)

def _swig_setattr(self,class_type,name,value):
    return _swig_setattr_nondynamic(self,class_type,name,value,0)

def _swig_getattr(self,class_type,name):
    if (name == "thisown"): return self.this.own()
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

def _swig_repr(self):
    try: strthis = "proxy of " + self.this.__repr__()
    except: strthis = ""
    return "<%s.%s; %s >" % (self.__class__.__module__, self.__class__.__name__, strthis,)

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0
del types


class permutation(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, permutation, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, permutation, name)
    __repr__ = _swig_repr
    def __call__(*args): return _knit.permutation___call__(*args)
    def __init__(self, *args): 
        this = _knit.new_permutation(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _knit.delete_permutation
    __del__ = lambda self : None;
permutation_swigregister = _knit.permutation_swigregister
permutation_swigregister(permutation)

class cmp_Array(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, cmp_Array, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, cmp_Array, name)
    __repr__ = _swig_repr
    def __call__(*args): return _knit.cmp_Array___call__(*args)
    def __init__(self, *args): 
        this = _knit.new_cmp_Array(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _knit.delete_cmp_Array
    __del__ = lambda self : None;
cmp_Array_swigregister = _knit.cmp_Array_swigregister
cmp_Array_swigregister(cmp_Array)

class A_reservoir(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, A_reservoir, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, A_reservoir, name)
    __repr__ = _swig_repr
    __swig_destroy__ = _knit.delete_A_reservoir
    __del__ = lambda self : None;
    def __init__(self, *args): 
        this = _knit.new_A_reservoir(*args)
        try: self.this.append(this)
        except: self.this = this
    def my_print(*args): return _knit.A_reservoir_my_print(*args)
    def green(*args): return _knit.A_reservoir_green(*args)
    def selfE(*args): return _knit.A_reservoir_selfE(*args)
    def G_SE(*args): return _knit.A_reservoir_G_SE(*args)
A_reservoir_swigregister = _knit.A_reservoir_swigregister
A_reservoir_swigregister(A_reservoir)

class scalarM(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, scalarM, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, scalarM, name)
    __repr__ = _swig_repr
    __swig_destroy__ = _knit.delete_scalarM
    __del__ = lambda self : None;
    def __init__(self, *args): 
        this = _knit.new_scalarM(*args)
        try: self.this.append(this)
        except: self.this = this
    def __neg__(*args): return _knit.scalarM___neg__(*args)
    def __iadd__(*args): return _knit.scalarM___iadd__(*args)
    def __isub__(*args): return _knit.scalarM___isub__(*args)
    def __imul__(*args): return _knit.scalarM___imul__(*args)
    def __call__(*args): return _knit.scalarM___call__(*args)
    def hconjugate(*args): return _knit.scalarM_hconjugate(*args)
    def inverse(*args): return _knit.scalarM_inverse(*args)
    def micro2arr(*args): return _knit.scalarM_micro2arr(*args)
    def __eq__(*args): return _knit.scalarM___eq__(*args)
    __swig_getmethods__["dim"] = lambda x: _knit.scalarM_dim
    if _newclass:dim = staticmethod(_knit.scalarM_dim)
scalarM_swigregister = _knit.scalarM_swigregister
scalarM_swigregister(scalarM)
scalarM_dim = _knit.scalarM_dim

class unsysteme(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, unsysteme, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, unsysteme, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_unsysteme(*args)
        try: self.this.append(this)
        except: self.this = this
    def coord(*args): return _knit.unsysteme_coord(*args)
    def vcoord(*args): return _knit.unsysteme_vcoord(*args)
    def indice(*args): return _knit.unsysteme_indice(*args)
    def voisin(*args): return _knit.unsysteme_voisin(*args)
    def vvoisin(*args): return _knit.unsysteme_vvoisin(*args)
    def Mvoisin(*args): return _knit.unsysteme_Mvoisin(*args)
    def vMvoisin(*args): return _knit.unsysteme_vMvoisin(*args)
    def Msite(*args): return _knit.unsysteme_Msite(*args)
    def fdim(*args): return _knit.unsysteme_fdim(*args)
    def fsize(*args): return _knit.unsysteme_fsize(*args)
    def fzmax(*args): return _knit.unsysteme_fzmax(*args)
    def z_voisin(*args): return _knit.unsysteme_z_voisin(*args)
    def permutme(*args): return _knit.unsysteme_permutme(*args)
    def sys_print(*args): return _knit.unsysteme_sys_print(*args)
    def coller(*args): return _knit.unsysteme_coller(*args)
    def deplacer(*args): return _knit.unsysteme_deplacer(*args)
    def reset(*args): return _knit.unsysteme_reset(*args)
    def addsite(*args): return _knit.unsysteme_addsite(*args)
    def movesite(*args): return _knit.unsysteme_movesite(*args)
    def translate_system(*args): return _knit.unsysteme_translate_system(*args)
    def delete_site(*args): return _knit.unsysteme_delete_site(*args)
    def add_site(*args): return _knit.unsysteme_add_site(*args)
    def move_site(*args): return _knit.unsysteme_move_site(*args)
    def put_Hdiag(*args): return _knit.unsysteme_put_Hdiag(*args)
    def get_Hdiag(*args): return _knit.unsysteme_get_Hdiag(*args)
    def put_Hopp(*args): return _knit.unsysteme_put_Hopp(*args)
    def add_Hopp(*args): return _knit.unsysteme_add_Hopp(*args)
    def get_Hopp(*args): return _knit.unsysteme_get_Hopp(*args)
    def comparer(*args): return _knit.unsysteme_comparer(*args)
    def xyz2ind_mapTEST(*args): return _knit.unsysteme_xyz2ind_mapTEST(*args)
    outsample = _knit.unsysteme_outsample
    __swig_getmethods__["minus_z"] = lambda x: _knit.unsysteme_minus_z
    if _newclass:minus_z = staticmethod(_knit.unsysteme_minus_z)
    __swig_destroy__ = _knit.delete_unsysteme
    __del__ = lambda self : None;
unsysteme_swigregister = _knit.unsysteme_swigregister
unsysteme_swigregister(unsysteme)
unsysteme_minus_z = _knit.unsysteme_minus_z

class rectangle(unsysteme):
    __swig_setmethods__ = {}
    for _s in [unsysteme]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, rectangle, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, rectangle, name)
    __repr__ = _swig_repr
    def fHhopp(*args): return _knit.rectangle_fHhopp(*args)
    def fHdiag(*args): return _knit.rectangle_fHdiag(*args)
    def real_dim(*args): return _knit.rectangle_real_dim(*args)
    def __init__(self, *args): 
        this = _knit.new_rectangle(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _knit.delete_rectangle
    __del__ = lambda self : None;
rectangle_swigregister = _knit.rectangle_swigregister
rectangle_swigregister(rectangle)

class unreservoir(unsysteme):
    __swig_setmethods__ = {}
    for _s in [unsysteme]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, unreservoir, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, unreservoir, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    __swig_destroy__ = _knit.delete_unreservoir
    __del__ = lambda self : None;
    def green(*args): return _knit.unreservoir_green(*args)
    def selfE(*args): return _knit.unreservoir_selfE(*args)
    def G_SE(*args): return _knit.unreservoir_G_SE(*args)
unreservoir_swigregister = _knit.unreservoir_swigregister
unreservoir_swigregister(unreservoir)

class unreservoirN(unreservoir):
    __swig_setmethods__ = {}
    for _s in [unreservoir]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, unreservoirN, name, value)
    __swig_getmethods__ = {}
    for _s in [unreservoir]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, unreservoirN, name)
    __repr__ = _swig_repr
    def Nchannels(*args): return _knit.unreservoirN_Nchannels(*args)
    __swig_destroy__ = _knit.delete_unreservoirN
    __del__ = lambda self : None;
    def __init__(self, *args): 
        this = _knit.new_unreservoirN(*args)
        try: self.this.append(this)
        except: self.this = this
    def getHdiag(*args): return _knit.unreservoirN_getHdiag(*args)
    def get_leadHopp(*args): return _knit.unreservoirN_get_leadHopp(*args)
    def put_leadHopp(*args): return _knit.unreservoirN_put_leadHopp(*args)
    def green(*args): return _knit.unreservoirN_green(*args)
    def selfE(*args): return _knit.unreservoirN_selfE(*args)
    def G_SE(*args): return _knit.unreservoirN_G_SE(*args)
unreservoirN_swigregister = _knit.unreservoirN_swigregister
unreservoirN_swigregister(unreservoirN)

class systemtotal(unsysteme):
    __swig_setmethods__ = {}
    for _s in [unsysteme]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, systemtotal, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, systemtotal, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_systemtotal(*args)
        try: self.this.append(this)
        except: self.this = this
    def addlead(*args): return _knit.systemtotal_addlead(*args)
    def fNres(*args): return _knit.systemtotal_fNres(*args)
    def p_lead(*args): return _knit.systemtotal_p_lead(*args)
    def res2sys(*args): return _knit.systemtotal_res2sys(*args)
    def sys2res(*args): return _knit.systemtotal_sys2res(*args)
    def sys2res_ind(*args): return _knit.systemtotal_sys2res_ind(*args)
    def lead_voisin(*args): return _knit.systemtotal_lead_voisin(*args)
    def lead_size(*args): return _knit.systemtotal_lead_size(*args)
    def max_lead_size(*args): return _knit.systemtotal_max_lead_size(*args)
    not_lead = _knit.systemtotal_not_lead
    def comparer(*args): return _knit.systemtotal_comparer(*args)
    def res2sysTEST(*args): return _knit.systemtotal_res2sysTEST(*args)
    __swig_destroy__ = _knit.delete_systemtotal
    __del__ = lambda self : None;
systemtotal_swigregister = _knit.systemtotal_swigregister
systemtotal_swigregister(systemtotal)

TransProba = _knit.TransProba
class couture(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, couture, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, couture, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_couture(*args)
        try: self.this.append(this)
        except: self.this = this
    def backward(*args): return _knit.couture_backward(*args)
    def sew2end(*args): return _knit.couture_sew2end(*args)
    def getG_LL(*args): return _knit.couture_getG_LL(*args)
    def getSE(*args): return _knit.couture_getSE(*args)
    def getGnotK(*args): return _knit.couture_getGnotK(*args)
    def getGless(*args): return _knit.couture_getGless(*args)
    def getG_lesser(*args): return _knit.couture_getG_lesser(*args)
    def getG_retarded(*args): return _knit.couture_getG_retarded(*args)
    __swig_destroy__ = _knit.delete_couture
    __del__ = lambda self : None;
couture_swigregister = _knit.couture_swigregister
couture_swigregister(couture)

class tricot(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, tricot, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, tricot, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_tricot(*args)
        try: self.this.append(this)
        except: self.this = this
    def __eq__(*args): return _knit.tricot___eq__(*args)
    def forward(*args): return _knit.tricot_forward(*args)
    def backward(*args): return _knit.tricot_backward(*args)
    def G_LL(*args): return _knit.tricot_G_LL(*args)
    def SE(*args): return _knit.tricot_SE(*args)
    def G(*args): return _knit.tricot_G(*args)
    def Energy(*args): return _knit.tricot_Energy(*args)
    def p_system(*args): return _knit.tricot_p_system(*args)
    def fpos(*args): return _knit.tricot_fpos(*args)
    def set_saving_level(*args): return _knit.tricot_set_saving_level(*args)
    def get_saving_level(*args): return _knit.tricot_get_saving_level(*args)
    def getG_LL(*args): return _knit.tricot_getG_LL(*args)
    def getSE(*args): return _knit.tricot_getSE(*args)
    __swig_destroy__ = _knit.delete_tricot
    __del__ = lambda self : None;
tricot_swigregister = _knit.tricot_swigregister
tricot_swigregister(tricot)

class spinM(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, spinM, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, spinM, name)
    __repr__ = _swig_repr
    def __neg__(*args): return _knit.spinM___neg__(*args)
    def __iadd__(*args): return _knit.spinM___iadd__(*args)
    def __isub__(*args): return _knit.spinM___isub__(*args)
    def __imul__(*args): return _knit.spinM___imul__(*args)
    def __call__(*args): return _knit.spinM___call__(*args)
    def set(*args): return _knit.spinM_set(*args)
    def __init__(self, *args): 
        this = _knit.new_spinM(*args)
        try: self.this.append(this)
        except: self.this = this
    def hconjugate(*args): return _knit.spinM_hconjugate(*args)
    def inverse(*args): return _knit.spinM_inverse(*args)
    def micro2arr(*args): return _knit.spinM_micro2arr(*args)
    def __eq__(*args): return _knit.spinM___eq__(*args)
    __swig_getmethods__["dim"] = lambda x: _knit.spinM_dim
    if _newclass:dim = staticmethod(_knit.spinM_dim)
    __swig_destroy__ = _knit.delete_spinM
    __del__ = lambda self : None;
spinM_swigregister = _knit.spinM_swigregister
spinM_swigregister(spinM)
spinM_dim = _knit.spinM_dim

class unsysteme_S(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, unsysteme_S, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, unsysteme_S, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_unsysteme_S(*args)
        try: self.this.append(this)
        except: self.this = this
    def coord(*args): return _knit.unsysteme_S_coord(*args)
    def vcoord(*args): return _knit.unsysteme_S_vcoord(*args)
    def indice(*args): return _knit.unsysteme_S_indice(*args)
    def voisin(*args): return _knit.unsysteme_S_voisin(*args)
    def vvoisin(*args): return _knit.unsysteme_S_vvoisin(*args)
    def Mvoisin(*args): return _knit.unsysteme_S_Mvoisin(*args)
    def vMvoisin(*args): return _knit.unsysteme_S_vMvoisin(*args)
    def Msite(*args): return _knit.unsysteme_S_Msite(*args)
    def fdim(*args): return _knit.unsysteme_S_fdim(*args)
    def fsize(*args): return _knit.unsysteme_S_fsize(*args)
    def fzmax(*args): return _knit.unsysteme_S_fzmax(*args)
    def z_voisin(*args): return _knit.unsysteme_S_z_voisin(*args)
    def permutme(*args): return _knit.unsysteme_S_permutme(*args)
    def sys_print(*args): return _knit.unsysteme_S_sys_print(*args)
    def coller(*args): return _knit.unsysteme_S_coller(*args)
    def deplacer(*args): return _knit.unsysteme_S_deplacer(*args)
    def reset(*args): return _knit.unsysteme_S_reset(*args)
    def addsite(*args): return _knit.unsysteme_S_addsite(*args)
    def movesite(*args): return _knit.unsysteme_S_movesite(*args)
    def translate_system(*args): return _knit.unsysteme_S_translate_system(*args)
    def delete_site(*args): return _knit.unsysteme_S_delete_site(*args)
    def add_site(*args): return _knit.unsysteme_S_add_site(*args)
    def move_site(*args): return _knit.unsysteme_S_move_site(*args)
    def put_Hdiag(*args): return _knit.unsysteme_S_put_Hdiag(*args)
    def get_Hdiag(*args): return _knit.unsysteme_S_get_Hdiag(*args)
    def put_Hopp(*args): return _knit.unsysteme_S_put_Hopp(*args)
    def add_Hopp(*args): return _knit.unsysteme_S_add_Hopp(*args)
    def get_Hopp(*args): return _knit.unsysteme_S_get_Hopp(*args)
    def comparer(*args): return _knit.unsysteme_S_comparer(*args)
    def xyz2ind_mapTEST(*args): return _knit.unsysteme_S_xyz2ind_mapTEST(*args)
    outsample = _knit.unsysteme_S_outsample
    __swig_getmethods__["minus_z"] = lambda x: _knit.unsysteme_S_minus_z
    if _newclass:minus_z = staticmethod(_knit.unsysteme_S_minus_z)
    __swig_destroy__ = _knit.delete_unsysteme_S
    __del__ = lambda self : None;
unsysteme_S_swigregister = _knit.unsysteme_S_swigregister
unsysteme_S_swigregister(unsysteme_S)
unsysteme_S_minus_z = _knit.unsysteme_S_minus_z

class rectangle_S(unsysteme_S):
    __swig_setmethods__ = {}
    for _s in [unsysteme_S]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, rectangle_S, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme_S]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, rectangle_S, name)
    __repr__ = _swig_repr
    def fHhopp(*args): return _knit.rectangle_S_fHhopp(*args)
    def fHdiag(*args): return _knit.rectangle_S_fHdiag(*args)
    def real_dim(*args): return _knit.rectangle_S_real_dim(*args)
    def __init__(self, *args): 
        this = _knit.new_rectangle_S(*args)
        try: self.this.append(this)
        except: self.this = this
    __swig_destroy__ = _knit.delete_rectangle_S
    __del__ = lambda self : None;
rectangle_S_swigregister = _knit.rectangle_S_swigregister
rectangle_S_swigregister(rectangle_S)

class unreservoir_S(unsysteme_S):
    __swig_setmethods__ = {}
    for _s in [unsysteme_S]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, unreservoir_S, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme_S]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, unreservoir_S, name)
    def __init__(self): raise AttributeError, "No constructor defined"
    __repr__ = _swig_repr
    __swig_destroy__ = _knit.delete_unreservoir_S
    __del__ = lambda self : None;
    def green(*args): return _knit.unreservoir_S_green(*args)
    def selfE(*args): return _knit.unreservoir_S_selfE(*args)
    def G_SE(*args): return _knit.unreservoir_S_G_SE(*args)
unreservoir_S_swigregister = _knit.unreservoir_S_swigregister
unreservoir_S_swigregister(unreservoir_S)

class unreservoirN_S(unreservoir_S):
    __swig_setmethods__ = {}
    for _s in [unreservoir_S]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, unreservoirN_S, name, value)
    __swig_getmethods__ = {}
    for _s in [unreservoir_S]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, unreservoirN_S, name)
    __repr__ = _swig_repr
    def Nchannels(*args): return _knit.unreservoirN_S_Nchannels(*args)
    __swig_destroy__ = _knit.delete_unreservoirN_S
    __del__ = lambda self : None;
    def __init__(self, *args): 
        this = _knit.new_unreservoirN_S(*args)
        try: self.this.append(this)
        except: self.this = this
    def getHdiag(*args): return _knit.unreservoirN_S_getHdiag(*args)
    def get_leadHopp(*args): return _knit.unreservoirN_S_get_leadHopp(*args)
    def put_leadHopp(*args): return _knit.unreservoirN_S_put_leadHopp(*args)
    def green(*args): return _knit.unreservoirN_S_green(*args)
    def selfE(*args): return _knit.unreservoirN_S_selfE(*args)
    def G_SE(*args): return _knit.unreservoirN_S_G_SE(*args)
unreservoirN_S_swigregister = _knit.unreservoirN_S_swigregister
unreservoirN_S_swigregister(unreservoirN_S)

class systemtotal_S(unsysteme_S):
    __swig_setmethods__ = {}
    for _s in [unsysteme_S]: __swig_setmethods__.update(_s.__swig_setmethods__)
    __setattr__ = lambda self, name, value: _swig_setattr(self, systemtotal_S, name, value)
    __swig_getmethods__ = {}
    for _s in [unsysteme_S]: __swig_getmethods__.update(_s.__swig_getmethods__)
    __getattr__ = lambda self, name: _swig_getattr(self, systemtotal_S, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_systemtotal_S(*args)
        try: self.this.append(this)
        except: self.this = this
    def addlead(*args): return _knit.systemtotal_S_addlead(*args)
    def fNres(*args): return _knit.systemtotal_S_fNres(*args)
    def p_lead(*args): return _knit.systemtotal_S_p_lead(*args)
    def res2sys(*args): return _knit.systemtotal_S_res2sys(*args)
    def sys2res(*args): return _knit.systemtotal_S_sys2res(*args)
    def sys2res_ind(*args): return _knit.systemtotal_S_sys2res_ind(*args)
    def lead_voisin(*args): return _knit.systemtotal_S_lead_voisin(*args)
    def lead_size(*args): return _knit.systemtotal_S_lead_size(*args)
    def max_lead_size(*args): return _knit.systemtotal_S_max_lead_size(*args)
    not_lead = _knit.systemtotal_S_not_lead
    def comparer(*args): return _knit.systemtotal_S_comparer(*args)
    def res2sysTEST(*args): return _knit.systemtotal_S_res2sysTEST(*args)
    __swig_destroy__ = _knit.delete_systemtotal_S
    __del__ = lambda self : None;
systemtotal_S_swigregister = _knit.systemtotal_S_swigregister
systemtotal_S_swigregister(systemtotal_S)

TransProba_S = _knit.TransProba_S
class couture_S(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, couture_S, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, couture_S, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_couture_S(*args)
        try: self.this.append(this)
        except: self.this = this
    def backward(*args): return _knit.couture_S_backward(*args)
    def sew2end(*args): return _knit.couture_S_sew2end(*args)
    def getG_LL(*args): return _knit.couture_S_getG_LL(*args)
    def getSE(*args): return _knit.couture_S_getSE(*args)
    def getGnotK(*args): return _knit.couture_S_getGnotK(*args)
    def getGless(*args): return _knit.couture_S_getGless(*args)
    def getG_lesser(*args): return _knit.couture_S_getG_lesser(*args)
    def getG_retarded(*args): return _knit.couture_S_getG_retarded(*args)
    __swig_destroy__ = _knit.delete_couture_S
    __del__ = lambda self : None;
couture_S_swigregister = _knit.couture_S_swigregister
couture_S_swigregister(couture_S)

class tricot_S(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, tricot_S, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, tricot_S, name)
    __repr__ = _swig_repr
    def __init__(self, *args): 
        this = _knit.new_tricot_S(*args)
        try: self.this.append(this)
        except: self.this = this
    def __eq__(*args): return _knit.tricot_S___eq__(*args)
    def forward(*args): return _knit.tricot_S_forward(*args)
    def backward(*args): return _knit.tricot_S_backward(*args)
    def G_LL(*args): return _knit.tricot_S_G_LL(*args)
    def SE(*args): return _knit.tricot_S_SE(*args)
    def G(*args): return _knit.tricot_S_G(*args)
    def Energy(*args): return _knit.tricot_S_Energy(*args)
    def p_system(*args): return _knit.tricot_S_p_system(*args)
    def fpos(*args): return _knit.tricot_S_fpos(*args)
    def set_saving_level(*args): return _knit.tricot_S_set_saving_level(*args)
    def get_saving_level(*args): return _knit.tricot_S_get_saving_level(*args)
    def getG_LL(*args): return _knit.tricot_S_getG_LL(*args)
    def getSE(*args): return _knit.tricot_S_getSE(*args)
    __swig_destroy__ = _knit.delete_tricot_S
    __del__ = lambda self : None;
tricot_S_swigregister = _knit.tricot_S_swigregister
tricot_S_swigregister(tricot_S)



