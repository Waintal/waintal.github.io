%module swig_general
%{
#include "Numeric/arrayobject.h"

#include "swig_general.h"
#include "blitz_addon.h"
//template<class T, int n>
//inline Array<T,n> & operator <= (Array<T,n> & L, const Array<T,n> & R)
//{L.resize(R.shape()); L =R;return (L);}
// uncomment the above if blitz_addon.h is not there.
using namespace std;

template<class T,int n>
class MyArray : public Array<T,n>
{	
public:	
  MyArray():Array<T,n>(){}
  MyArray(const Array<T,n>& x):Array<T,n>(x.copy()){}
  inline MyArray & operator = (const Array<T,n> & x)
  {this->resize(x.shape()); Array<T,n>::operator =(x);return(*this);}
  inline MyArray & operator = (const MyArray & x){return(operator=(Array<T,n>(x)));}
};

template <class T>
T* gal_convert_swig_to_C(PyObject* obj,swig_type_info* THE_TYPE,string mess)
{ void *argp1 = 0 ; int res1 = SWIG_ConvertPtr(obj, &argp1, THE_TYPE,  0  | 0);
string s= string("Internal ERROR CONVERT : ")  + mess;
  if (res1<0) throw s.c_str();
  return( reinterpret_cast<T * >(argp1));
}
	
%}

typedef complex<double> COMPLEX;

%feature("compactdefaultargs");


/*  -------------------------------

  	strings

    ------------------------------- */

//%include "std_string.i"

// Typemap for a C++ string
%typemap(out) string {
  $result = PyString_FromString($1.c_str());
}
%typemap(in) string {
    if (PyString_Check($input)) {
         $1 = std::string(PyString_AsString($input));
     } else {
         PyErr_SetString(PyExc_ValueError,"String expected");
	 return NULL;
     }
}
// Copy the typecheck code for "char *".  
//%typemap(typecheck) std::string = char *;
%typemap(typecheck,precedence=SWIG_TYPECHECK_STRING) string {
   $1 = PyString_Check($input) ? 1 : 0;
}
%apply string {std::string};

#define WRAPPER


%define OUTArray 
MyArray
%enddef
%define DOC(x)
%feature("docstring",x) ;
%enddef




/*  -------------------------------

    	 1d array : interfaced to list

    -------------------------------
*/

%define ARRAY1(typeC,PyConv,PyCH,PyAS,nametype)
%typemap(out)   MyArray<typeC,1>
{	
 int n = $1.size(); $result = PyList_New(n);
 for (int i = 0,pos = $1.lbound(0); i < n; i++,pos++) 
    	 PyList_SetItem($result,i,PyConv($1(pos))); // steals reference :cf http://docs.python.org/api/refcountDetails.html
}

%typemap(out) Array<typeC,1> *  
{
 int n = $1->size(); $result = PyList_New(n);
 for (int i = 0,pos = $1->lbound(0); i < n; i++,pos++) 
    	 PyList_SetItem($result,i,PyConv((*$1)(pos))); // steals reference :cf http://docs.python.org/api/refcountDetails.html
}

// careful : use list and not sequence ! see http://docs.python.org/api/refcountDetails.html
%typemap(in) Array<typeC,1> 
{
  if (!PyList_Check($input)) {PyErr_SetString(PyExc_ValueError,"Expected a List");return NULL;}
  int n= PyList_Size($input);
  $1.resize(n);$1.reindexSelf(0);
  for (int i = 0; i < n; i++) {
    PyObject *o = PyList_GetItem($input,i);
    if (PyCH(o)) 
      $1(i) = PyAS;
    else {
	string err =string("List elements must be ") + nametype;
	 PyErr_SetString(PyExc_ValueError,err.c_str());  return NULL;}
   }
}

%typemap(in) Array<typeC,1> *
{
    if ($input==Py_None) $1=NULL; 
else{
    if (!PyList_Check($input)) {PyErr_SetString(PyExc_ValueError,"Expected a List");return NULL;}
    int n= PyList_Size($input);
    $1= new Array<typeC,1>(n);
    for (int i = 0; i < n; i++) {
    PyObject *o = PyList_GetItem($input,i);
    if (PyCH(o)) 
      (*$1)(i) = PyAS;
    else {
	string err =string("List elements must be ") + nametype;
        PyErr_SetString(PyExc_ValueError,err.c_str());  return NULL;}
  }
 }
}


%typemap(freearg) Array<typeC,1> * { if ($1) delete $1;}

%typemap(typecheck,precedence=SWIG_TYPECHECK_POINTER)  Array<typeC,1> 
{ $1 = (PyList_Check($input) || ($input==Py_None));}

%typemap(typecheck)  Array<typeC,1> * =  Array<typeC,1>;
%apply Array<typeC,1>* {const Array<typeC,1> &, Array<typeC,1> &,Array<typeC,1> const &};
%enddef

ARRAY1(int,PyInt_FromLong,PyInt_Check,PyInt_AsLong(o),"integers");
ARRAY1(double,PyFloat_FromDouble,PyFloat_Check,PyFloat_AsDouble(o),"floats");
//ARRAY1(complex<double>,PyComplex_Check,complex<double>(PyComplex_RealAsDouble(o),PyComplex_ImagAsDouble(o)),"complexes");
//ARRAY1(string,PyString_Check,string(PyString_AsString(o)),"strings");










/*  -------------------------------

  Array of DIM >1
  Interfaced to Numeric.

    -------------------------------
*/

%define MYARRAY(typeC,typePy,DIM)
%typemap(out) MyArray<typeC,DIM>
{$result = PY::Blitz_as_NumPy($1);}

%typemap(out) MyArray<typeC,DIM> *
{$result = PY::Blitz_as_NumPy(*$1);}

%typemap(in) Array<typeC,DIM>
{$1 <= PY::Blitz_View_of_Numpy<typeC,DIM>($input);}

%typemap(in) Array<typeC,DIM> *
{$1 = new Array<typeC,DIM>(PY::Blitz_View_of_Numpy<typeC,DIM>($input));}

%typemap(typecheck,precedence=SWIG_TYPECHECK_POINTER) Array<typeC,DIM> *  
{$1 = PY::NumPy_has_structure<typeC >($input,DIM);}

%typemap(typecheck) Array<typeC,DIM>  = Array<typeC,DIM> *;

%typemap(freearg) Array<typeC,DIM> * { delete $1;}
%apply Array<typeC,DIM>* {const Array<typeC,DIM> &,Array<typeC,DIM> &,Array<typeC,DIM> const &,const Array<typeC,DIM> *};

%enddef

MYARRAY(int,PyArray_LONG,2)
MYARRAY(int,PyArray_LONG,3)
MYARRAY(int,PyArray_LONG,4)
MYARRAY(double,PyArray_DOUBLE,2)
MYARRAY(double,PyArray_DOUBLE,3)
MYARRAY(double,PyArray_DOUBLE,4)
MYARRAY(complex<double>,PyArray_CDOUBLE,2)
MYARRAY(complex<double>,PyArray_CDOUBLE,3)
MYARRAY(complex<double>,PyArray_CDOUBLE,4)

