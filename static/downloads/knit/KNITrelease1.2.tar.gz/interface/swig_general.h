#ifndef READ_PYTHON
#define READ_PYTHON

#include "Python.h"
#include "Numeric/arrayobject.h"
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <complex>
#include <iostream>
using namespace std;
#include <blitz/array.h>
using namespace blitz;



#ifndef FATAL
#define FATAL(s) {cout<<"FATAL : "<<s<<endl; exit(1);}
#endif

#ifndef COMPLEX
#define COMPLEX complex<double>
#endif


namespace PY {
  
  /** ----------------------------------------------------------------------------------------------------
      
  Conversion functions Python <-> C++, Numpy to Blitz etc...

  ----------------------------------------------------------------------------------------------------- */

  /**
     Types
  */
  template <class T> struct myPyArrayType {};
  template <> struct myPyArrayType<int> {  static const int arraytype =PyArray_LONG; static const char arraytype_num='l';};
  template <> struct myPyArrayType<double> {  static const int arraytype = PyArray_DOUBLE; static const char arraytype_num='d';};
  template <> struct myPyArrayType<complex<double> > { static const int arraytype = PyArray_CDOUBLE; static const char arraytype_num='D';};
  /**
     Types
  */
  template <class T> inline  T TheDefaults() {return 0;};
  template <> inline string TheDefaults<string>() {return "";}

  /**
     C to Python for usual types
     Returns a new reference.
  */
  template<class T> inline PyObject * C_to_Py(T x){ FATAL("C_to_Py : unknown conversion");}
  template<> inline PyObject * C_to_Py(PyObject* p){Py_INCREF(p);return p;}
  template<> inline PyObject * C_to_Py(string s){return PyString_FromString(s.c_str());}
  template<> inline PyObject * C_to_Py(int x){return PyInt_FromLong(x);}
  template<> inline PyObject * C_to_Py(bool x){return PyBool_FromLong(x);}
  template<> inline PyObject * C_to_Py(double x){return PyFloat_FromDouble(x);}
  template<> inline PyObject * C_to_Py(complex<double> x){return PyComplex_FromDoubles(real(x),imag(x));}

  template<class T>
  PyObject * C_to_Py(const vector<T> & v)
  {   int n = v.size(); PyObject * result = PyList_New(n);
    for (int i = 0; i < n; i++) 
      PyList_SetItem(result,i,C_to_Py(v[i])); // steals reference :cf http://docs.python.org/api/refcountDetails.html
    return result;
  }

  /**
     Python to C for usual types
     Does nothing to the reference of the object
  */
  template<class T> inline T Py_to_C(PyObject *x,string mess="") { FATAL("Py_to_C : unknown conversion : "<<mess);}

  template<> inline PyObject * Py_to_C<PyObject *>(PyObject *x,string mess){ return x;}

  template<> inline bool Py_to_C<bool>(PyObject *x,string mess){ 
    if (!PyBool_Check(x)) FATAL("Type Error in PY->C conversion : not a bool. "<<mess); 
    assert( (x==Py_True) || (x==Py_False));
    return (x==Py_True);}

  template<> inline string Py_to_C<string>(PyObject *x,string mess){ 
    if (!PyString_Check(x)) FATAL("Type Error in PY->C conversion : not a string."<<mess); 
    return string(PyString_AsString(x));}

  template<> inline int Py_to_C<int>(PyObject *x,string mess){ 
    if (!PyInt_Check(x)) FATAL("Type Error in PY->C conversion : not an integer."<<mess); 
    return PyInt_AsLong(x);}

  template<> inline double Py_to_C<double>(PyObject *x,string mess){ 
    if (PyFloat_Check(x)) return( PyFloat_AsDouble(x));
    if (PyInt_Check(x))  return(double(PyInt_AsLong(x)));
    FATAL("Type Error in PY->C conversion : not a float."<<mess); }

  template<> inline complex<double> Py_to_C<complex<double> >(PyObject *x,string mess){ 
    if (PyComplex_Check(x)) return complex<double>(PyComplex_RealAsDouble(x),PyComplex_ImagAsDouble(x));
    if (PyFloat_Check(x)) return( complex<double>(PyFloat_AsDouble(x)));
    if (PyInt_Check(x))  return(complex<double>(PyInt_AsLong(x)));
    FATAL("Type Error in PY->C conversion : not a complex or a double or a int."<<mess); }
  
  /**
     Check if the numpy and A have the same structure
  */
  template<class T>
  bool NumPy_has_structure (PyObject *obj, int dim)
  {
    import_array();	
    if (!PyArray_Check(obj)) return false;
    PyArrayObject *arr_obj = (PyArrayObject *)obj;
    return (arr_obj->nd==dim) && (arr_obj->descr->type_num == myPyArrayType<T>::arraytype);
  }

  /**
     Check if the numpy and A have the same structure
  */
  template<class T,int N>
  bool NumPy_has_structure (PyObject *obj,const TinyVector<int,N> & shape)
  {
    import_array();	
    if (!PyArray_Check(obj)) return false;
    PyArrayObject *arr_obj = (PyArrayObject *)obj;
    bool res = (arr_obj->nd==N) && (arr_obj->descr->type_num == myPyArrayType<T>::arraytype);
    for (int i=0;i<N;i++) res = res && (shape(i)== arr_obj->dimensions[i]);
    return res;
  }

  /**
     Check if the numpy and A have the same structure
  */
  template<class T,int N>
  inline bool NumPy_Blitz_conform(PyObject *obj,const Array<T,N> & A){return (NumPy_has_structure<T>(obj,A.shape()));}

  /** 
      Returns a view of the Numpy array obj in a Blitz Array.
      No copy.
      Does not increase the references to the obj. For quick,local use only
  */
  template<class T,int N> 
  Array<T,N> Blitz_View_of_Numpy(PyObject *obj, string mess="")
  {
    import_array();
    if (!PyArray_Check(obj)) FATAL("Blitz_View_of_Numpy : First arg is not a Numeric array "<<mess);
    PyArrayObject *arr_obj = (PyArrayObject *)obj;
    if (arr_obj->descr->type_num != myPyArrayType<T>::arraytype) 
      FATAL("Blitz_View_of_Numpy : The Numeric array does not contain the correct type of number"<<mess);
    if (arr_obj->nd!=N) FATAL("Blitz_View_of_Numpy : dimensions do not match"<<mess);
    int T_size = sizeof(T);
    TinyVector<int,N>  shape(0),strides(0);
    int *arr_dimensions = arr_obj-> dimensions, *arr_strides = arr_obj-> strides;
    for (int i=0;i<N;++i) {
      shape[i]   = arr_dimensions[i];
      strides[i] = arr_strides[i]/T_size;
    }
    return Array<T,N> ((T*) arr_obj->data,shape,strides,neverDeleteData);
  }
  
  /**
     Copy the numpy in the array target.
     If noresize is set and the array do not conform :  Error
     otherwise the target is resized if necessary.
  */
  template<class T,int N> 
  void NumPy_to_Blitz(PyObject *obj,Array<T,N> & target, string mess="",bool noresize=false) 
  {
    if (noresize && (!NumPy_Blitz_conform(obj,target))) FATAL("NumPy_to_Blitz : Numpy and Array do not conform");
    target <= Blitz_View_of_Numpy<T,N>(obj,mess);
  }
  
  /** 
      Returns a Numpy Array which is a COPY of the blitz array // TO DO see the SAME data as the blitz array (no copy)
      Returns a NEW REFERENCE
  */
  template<class T,int N> 
  PyObject * Blitz_as_NumPy(const Array<T,N> & A)
  {
    import_array(); // ?
    int dim[N]; for (int i=0;i<N;i++) dim[i] = A.extent(i);
    PyObject *res = PyArray_FromDims (N, dim, myPyArrayType<T>::arraytype);
    PyArrayObject * arr = ( PyArrayObject *)res;
    Array<T,N> tmp((T*)(arr->data),A.shape(),neverDeleteData); tmp = A;
    return res;
  }


  /**
     Transform a Python list into an array of T, if possible.
     Does not affect the ref counting of l
  */
  template<class T>
  void list_to_blitz(PyObject * l,Array<T,1> & target,bool noresize=false)
  {
    if (!PyList_Check(l)) FATAL("list_to_blitz : python object is not a list");int n= PyList_Size(l);
    if (noresize && (target.extent(0)!=n)) {FATAL("list_to_blitz : size of the array and pyobject do not match");}
    else target.resize(n);
    for (int i = 0,j=target.lbound(0); i < n; i++,j++) 
      target(j) = Py_to_C<T>(PyList_GetItem(l,i)); //borrowed ref
  }

  void check_list_elements_are_unique(PyObject* l,string error_message);

  /** ----------------------------------------------------------------------------------------------------

  C++ class wrapping some python reference

  ----------------------------------------------------------------------------------------------------- */
  /**
     Contains an OWNED python ref.
   */
  class pyref 
  {
  public : 
    /** increase_ref : */
    pyref(PyObject *,bool increase_ref=false);
    pyref():me(NULL){}
    ~pyref();
    pyref(const pyref &,bool deep_copy=false);
    operator PyObject* () const; // returns a new REF
    PyObject * new_pyo() const;
    pyref & operator = (const pyref & x);
    bool is_nul() const {return (me==NULL);}
    static void clean_error(){if (PyErr_Occurred()) {PyErr_Print();PyErr_Clear();} }
  protected: 
    PyObject *me;
  };

  /**
     Return a new ref to the result of module.name(args)
  */
  pyref callPythonFunction(PyObject* args,string name,string module,string err_mess);
  
  /**
     Return a new ref to the result of object.method(args)
  */
  pyref callPythonMethod(PyObject* object,string method,PyObject* args,string err_mess);

  /** 
      A storage for a python function : x-> f(x) for x in R,C or N and any value
  */
  template<class arg_type,class val_type>
  class PythonFunction : public pyref {
  public : 
    PythonFunction(PyObject * Fnt,string myname=""):pyref(Fnt,true),name(myname){ 
      if (me && (!PyCallable_Check(me))) FATAL("Function "<<name<<" is not callable !");
    }
    PythonFunction(const PythonFunction &f):pyref(f),name(f.name){}
    PythonFunction & operator = (const PythonFunction & x){ pyref::operator=(x); name = x.name;}
    val_type operator()(arg_type x) const { if (is_nul()) FATAL("EValuating a null function !"); PyObject* tmp = C_to_Py(x);
      PyObject * p = PyObject_CallObject(me,tmp);clean_error();
      val_type res =Py_to_C<val_type>(p);Py_DECREF(p);Py_DECREF(tmp);return res;}
  protected:
    string name;
  };
  
  /**
     Numerical type promotion (int->float->complex) for a numpy array to type T
  */
  template<class T>
  pyref NumPy_Promote(PyObject *arr,string mess)
  { char c[2];c[0] = myPyArrayType<T>::arraytype_num;c[1]=0;
    pyref args(Py_BuildValue("(O,N)",arr,PyString_FromString(c)));
    return callPythonFunction(args,"asarray","Num","can't promote the numerical type\n"+mess);}

  /** ----------------------------------------------------------------------------------------------------

  PyView class 

  ----------------------------------------------------------------------------------------------------- */

  /** Policy for PyView. 
      Strict = The object must be present or the program stops
      Optional = It is optional. If not present a standard default is returned.
  */
  enum Policy {Strict,Optional};
  
  /** A simple class to embed the python interpreter for the purpose of inputs (and outputs!).
      
  Usage : 
  
  - The input file is digested by the class at construction. 
  One can then pick up the values from the file,
  or change their value, print the defined data (output) as a python input file...
  Outputs can then be inputs of another program......

  - The input file is a python file, so one can use any python command.
  - "from math import *" is automatically done.
  - a new command include has been added : include("file1") e.g.
  - Warning : Don't use variables starting with _, except for local calculations. (some are used for internal work)
  - The boolean are new (python>2.3) so use integers for portability... (method I can load a boolean as an integepr).
  -  There can be only one instance of the class at a time.
  otherwise the python interpreter has trouble (double initialisation)
  But in general, one has only one input file (if many, use
  the include command I added to python....)

  - Blitz Arrays : 
  - a list A[j][i] will be transformed into an Blitz Array A(i,j)
  beware that Python list and Array are in C mode
  EXPLAIN BETTTER
      
  -  A correct usage of the class : 
  PyView *DATA = new PyView(file_name,preamble);
  all constructors of various classes that require data
  DATA->test_point : check which data has been required and stop if -test given in argv
  at this point one is sure that all necessary data are present and the calculation
  will be done until the end.
  One can then delete DATA or keep it for later use.

  - when a PyView is open, Ctrl-C does not work. Use kill or killall.

  -  MPI : in MPI, all nodes opens and read the file. 
  (Note that the master has to bcast the name of the file independently).
  Compile with -DUSE_MPI
  To be improved ?
	   
  - To do : one can also dynamically load the lib (to clear the interpreter from the memory after delete DATA),
  but I am not sure of the portability of this : some machines don't like shared libraries....

  */
  class PyView
  {
  public:

    /** 
	Constructor.
	python_script is the name of the file to be interpreted
	Python is loaded in memory, it loads the file and interprets it completely (with an exception if error).
	preamble_add_on is a piece of python code to be executed before the script (e.g. a modification 
	of sys.path, an inclusion of a file common to the project : cf lisa code).
      
	THERE CAN BE ONLY ONE INSTANCE BUILT WITH THIS CONSTRUCTOR AT A TIME.
	(the interpreter can only be open once).
    */
    PyView (string python_script, string preamble_add_on);

    /** 
	Same but the input file is taken from argv
	prg input or prg -test input.
	THERE CAN BE ONLY ONE INSTANCE BUILT WITH THIS CONSTRUCTOR AT A TIME.
	(the interpreter can only be open once).
    */
    PyView(int argc, char *argv[],string preamble_add_on="");

    /** 
	Construct restricted view on the interpreter. 
        If Obj is an instance of a python class, all get, put, exec will be executed in the instance
	local __dict__ and in the global _dict_ of the class.
	e.g. 
        Obj is a instance a of class A, get("x") will grab a.x, exec("f(2)") will execute "a.f(2)" etc...
	
	If Obj is NULL, open a view on the top level of the interpreter (no restriction).

	The interpreter MUST be open, i.e. a PyView has to be constructed somewhere
	from the first 2 constructors if the interpreter is embedded OR the class is an extension of Python.
	
	NB : this constructor does not steal the reference.
    */
    PyView(PyObject *Obj=NULL);
    
    /**
       Copy constructor.
       If s is provided however, it opens a PyView restricted on the element s of p
    */
    PyView(const PyView & p,string s="");
   
    /** Clear the python interpreter from memory */
    ~PyView();
  
    /** Report the data analysis. 
	In test mode, (-test is given) it stops the code */
    void test_point();
  
    /**
       Buffer for exec
    */
    stringstream execbuf;

    /** Execute a python command in the interpreter; Returns the output. 
	if no command is given (s==""), the content of execbuf is executed 
    */
    string exec(string s="");
  
    /** 
	Same as exec, but from a file
    */
    string execfile(string s);

    /** Check if the element nom exist in the interpreter. */
    bool exists(string s);//const char * nom);
    
    /** Check if the element nom exist in the interpreter. */
    //inline bool exists(string s){return(exists(s.c_str()));}
  
    /** Requires that the element nom exists in the interpreter.
	IF not, Fatal error.
	Useful for constructor to require the presence of some elements
    */
    void require(string s,string mess);
  
    /** Returns in a string all defined quantities except _ones (the one starting with a _)
	sorted and written as in a python file (read for input therefore).
    */
    string all();

    /**
       Specialisation of () for arrays : no defaut
       - e.g. DATA(Array<double,1>(fortranArray),"AA")
       returns an array <double,1>, storage fortran, containing AA.
       NB : the policy is strict.
    */
    template <class T,int n>
    inline Array<T,n> operator()(const Array<T,n> & type,string nom, string mess="")
    {Array<T,n> r(type);get(nom,r,mess,Strict);return(r);}
  
    /**
       - Returns an element of the DATA of the type of the element "type"
       e.g. DATA(double(),"a","blabla") is the same as DATA.D("a","blabla").
    */
    template <class T>
    inline T operator()(const T & type,string nom, string mess="", Policy pol=Strict, T defaut=0)
    {T r(type);get(nom,r,mess,pol,defaut);return(r);}


  /* ------------------------------------------------------------------------
     GET
       ---------------------------------------------------------------------- */

   
    
    /**
       Returns a VIEW on a Numpy array in the form of blitz array.
       Data are NOT copied.
       Valid up to 6 dimensions, for double, complex<double>, int. 
       (if more, just instanciate in the cpp file at the end or use export if your compiler has it !
       If Pol is not strict, it returns an empty array
       
       Ordering : 
       - The ordering is preserved : A[1,2] in python is A(1,2) in C++  (!)
       - In memory the ordering is C-style.
    */
    template<class T,int N> 
    Array<T,N> View_NumPy(string nom, string mess="", Policy pol=Strict)
    {  
      PyObject* pElem = pyo(nom,mess,pol);
      if ((pElem==NULL) && (pol==Optional)) return(Array<T,N>(fortranArray));
      return Blitz_View_of_Numpy<T,N>(pElem);
    }

    /**
       - Makes a copy
       - If it is a list, the array IS TRANSPOSED.
    */
    template<class T,int N> 
    void get(string nom,Array<T,N> & arr, string mess="", Policy pol=Strict);

    

    template<class T> 
    void get(string nom, T & s, string mess="", Policy pol=Strict,T defaut=TheDefaults<T>())
    {
      PyObject* pElem = pyo(nom,mess,pol);// borrowed
      s= (pElem==NULL ? defaut : Py_to_C<T> (pElem,mess)); }

    // for backward compatibility : pick int, double etc...
    /** Picks an integer (same as get(nom,i...))  */
    int I(string nom, string mess="", Policy pol=Strict,int defaut=0){int i; get(nom,i,mess,pol,defaut); return i;}
  
    /** Picks a double  */
    double D( string nom, string mess="", Policy pol=Strict,double defaut=0){double i; get(nom,i,mess,pol,defaut); return i;}
  
    /** Picks a COMPLEX (double)  */
    COMPLEX C( string nom, string mess="", Policy pol=Strict,COMPLEX defaut=0) {COMPLEX i; get(nom,i,mess,pol,defaut); return i;}
  
    /** Picks a string */
    string S( string nom, string mess="", Policy pol=Strict,string defaut="") {string i; get(nom,i,mess,pol,defaut); return i;}
  
    /** Picks a boolean  */
    bool B( string nom, string mess="", Policy pol=Strict,bool defaut=false)  {bool i; get(nom,i,mess,pol,defaut); return i;}

     /**
       Executes "command" in the interpreter and grad the result in var.
    */
    template<class T> 
    inline void get_exec(string command, T & var, string mess="", Policy pol=Strict)
    {string tmp=tempo();exec(tmp+"="+ command);get(tmp,var,mess,pol);cleartempo();exec("del "+tmp);}

    /** 
	Pick up a dictionnary
	dict[ keys] = vals
	keys and vals store the keys and values  : the LAST index is the dictionnay index.
    */
    template<class key_type,int key_dim, class val_type, int val_dim>
    void get( string nom, Array<key_type,key_dim> & keys, 
	      Array<val_type,val_dim> & vals,string mess="")
    {
      require(nom,mess);stringstream fs;
      fs<<"__pythondata_get_dico1="<<full_name(nom)<<".keys()"<<endl<<"__pythondata_get_dico2="<<full_name(nom)<<".values()"<<endl;
      exec(fs.str());
      get("__pythondata_get_dico1",keys,mess);get("__pythondata_get_dico2",vals,mess);
      exec("del __pythondata_get_dico1,__pythondata_get_dico2");
    } 

 /* ------------------------------------------------------------------------
     PUT 
       ---------------------------------------------------------------------- */

    template<class T,int n>
    void put(string nom, const Array<T,n> & x) {put_pyo( Blitz_as_NumPy(x));}

    template<class T>
    void put(string nom, const T & x) {put_pyo( C_to_Py(x));}
    
    /** 
	Return the requested object.
	NB : returns a BORROWED reference 
    */
    PyObject * pyo(string nom, string mess, Policy pol) const ;

  protected:
    // STEALS the ref.
    void put_pyo(string nom,PyObject * x);

    void Fail(const char *nom, const char * error, const char * mess) const ;
    void for_construct(string python_script,string preamble_add_on);
    void for_construct2(PyObject * Obj);
    PyObject * DICO,* CLASSDICO, *CLASS;
    bool test_mode,is_original;
    //map<string,string,less<string > > requested,optional_not_found;

    static int profondeur;
    string tempo();
    void cleartempo();

    inline string full_name(string nom) const { return(nom);}

  };


  template<class T,int N> 
  void PyView::get(string nom,Array<T,N> & arr, string mess, Policy pol)
  {
    PyObject* pElem = pyo(nom,mess,pol);
    if ((pElem==NULL) && (pol==Optional)) {arr <= Array<T,N>(fortranArray);return;}
    pyref aa;
    if (PySequence_Check(pElem)) // ask the python to make a numarray from the list and to transpose it
      aa = NumPy_Promote<T>(callPythonFunction(callPythonFunction(pElem,"array","Num","Can not make an array out of the list"),
					       "transpose","Num","can't transpose"),mess);
    else
      aa= NumPy_Promote<T>(pElem,mess);
    arr <= Blitz_View_of_Numpy<T,N>(aa,mess);
  }
  
  template<>
  void PyView::get<string,1>(string nom,Array<string,1> & arr, string mess, Policy pol);
 
/**
     For a class C to access the DATA under the namespace Name_Space
     just derive from it.
  */
  class PyView_User
  {
  public:
    PyView_User(PyObject *p):PYDATA(p){}
    PyView_User(const PyView_User & b):PYDATA(b.PYDATA){}
    PyView_User(const PyView & b):PYDATA(b){}
    PyView PYDATA;
  };


  /**
     A class deriving from PyView_User will have a PYDATA connected to the PyObject if passed 
     at construction or to a new private python dictionnary if no PyObject is provided

     NOT GOOD . if I want both ?

  class PyView_User
  {
  public:
    PyView_User():Personnal_Dico(PyDict_New()),PYDATA((PyObject*)Personnal_Dico){}
    PyView_User(PyObject *p):Personnal_Dico(NULL),PYDATA(p){}
    PyView_User(const PyView_User & b):Personnal_Dico(b.Personnal_Dico),PYDATA(b.PYDATA){}
    PyView_User(const PyView & b):Personnal_Dico(NULL),PYDATA(b){}
  protected:
    pyref Personnal_Dico;
  public:
    PyView PYDATA;
  };
  */


  // for backward compatibility
  typedef PyView Python_Data;
  typedef PyView_User Python_Data_User;

} 

#endif

 
