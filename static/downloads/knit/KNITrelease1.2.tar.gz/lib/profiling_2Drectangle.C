
#include "knit_knit.h"
#include "knit_physics.h"

// SIMPLE CALCULATION OF A 2D RIBBON USED FOR PROFILING THE CODE

int main(){

  typedef scalarM testM;
  int M=200;// TRANSVERSE SIZE
  int N=200;//  LENGTH
  double En=-1.532; // working energy
  double flux=0.;
  testM hopp,Hdiag;

  for (int i=0;i<testM::dim();++i) {hopp(i,i)=+1.;Hdiag(i,i)=0.;}
  
  cout<<endl<<"-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*"<<endl;
  cout<<"CALCULATIONS OF THE CONDUCTANCE FOR A RECTANGULAR SYSTEM"<<endl;
  cout<<"WITH TWO TERMINALS"<<endl;
  cout<<"SIZE = "<<M<<"X"<<N<<endl;
 

  //****** System construction*******
  // main system
  Array<int,1> LxLyLz(2),OxOyOz(2);
  LxLyLz=M,N;
  OxOyOz=0,0;
  systemerectangle<testM> sys(LxLyLz,OxOyOz,hopp,Hdiag);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,hopp,Hdiag); // lead's interface
  N_reservoir<testM> lead(lead_interface,hopp,flux); // create lead from its interface
  systeme_infini<testM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,hopp,Hdiag); // lead's interface
  N_reservoir<testM> lead2(lead_interface2,hopp,flux); // create lead from its interface
  sys_lead.addlead(lead2);

  //****** Calculation *******
  cout<<"Begining Knit calculations..."<<endl;
  clock_t t_in=clock();
  knit<scalarM> work(0,sys_lead, En); 
  work.set_saving_level(0);
  work.forward(ToZero); 
  work.forward(ToEnd);
  COMPLEX coef=coef_T(work,0,1);
  clock_t t_out=clock();
  cout<<"...Completed"<<endl;
  cout<<"ENERGY = "<<En<<"\t CONDUCTANCE = "<<coef.real()<<endl;
  cout<<"COMPUTATION (KNIT) TIME = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" SECONDS"<<endl;
  cout<<endl<<"-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*"<<endl;
  return 0;
};


