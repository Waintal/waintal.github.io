#ifndef _BLITZ_ADDON_
#define _BLITZ_ADDON_

#include<iostream>
#include<complex>

#include <blitz/array.h>
#include <assert.h>
using namespace blitz;
#include "../kernel/knit_general.h"

//This function is needed for choice between gnu and intel C++ compilers
#define F77(x) x##_

/**
 * \defgroup blitzop Extensions of Blitz
 @{
*/

///

#define ZERO  1.e-6

// maximal dimension for switching from BLITZ to BLAS in matrix multiplication
#define MAX_MATMUL 4

typedef complex<double> COMPLEX; // complex= pair of double


extern "C"{
  //real
  void F77(sgetrf)(const int& M,const int& N,float* A,const int& LDA,int* IPIV,int& INFO);  
  void F77(sgetri)(const int& N,float* A,const int& LDA ,const int* IPIV,float* WORK,const int& LWORK,int& INFO);
  //double
  void F77(dgetrf)(const int &, const int &,double[], const int & ,int [],int &);
  void F77(dgetri)(const int & , double [], const int & ,const int [],double [],const int & ,int & );
  //complex
  void F77(zgetrf)(const int &, const int &,complex<double>[], const int & ,int [],int &);
  void F77(zgetri)(const int & , complex<double> [], const int & , const int [],complex<double> [], const int & ,int & );

  void F77(sgemm) (const char *, const char *,  //TRANSA, TRANSB  
		       const int & , // M
		       const int & , // N
		       const int & , // K
		       const float &, //ALPHA, 
		       const float[], //  A, (M,K) matrix 
		       const int &, // LDA 
		       const float[], // B,  (K,N) matrix  
		       const int &, // LDB,
		       const float &, // BETA, 
		       float[], // C,  (M,N) matrix
		       const int & //  LDC
		       );
  void F77(dgemm) (const char *, const char *, const int & , const int & ,const int & , const double &, const double[], const int &,  
		       const double[],const int &, const double &, double[], const int & );
  void F77(zgemm) (const char *, const char *, const int & , const int & ,const int & , const COMPLEX &, const COMPLEX[], const int &,  
		       const COMPLEX[],const int &, const COMPLEX &, COMPLEX[], const int & );
  void F77(zgeev) (const char * JOBVL, const char * JOBVR, const int & N, COMPLEX A[], const int & LDA,COMPLEX W[],COMPLEX VL[],const int & LDVL,                   COMPLEX  VR[],const int & LDVR,COMPLEX  WORK[],const int & LWORK,double* RWORK,int& info);
  void F77(zggev) (const char * JOBVL, const char * JOBVR, const int & N, COMPLEX A[], const int & LDA,COMPLEX B[], const int & LDB,COMPLEX ALPHA[],COMPLEX BETA[],COMPLEX VL[],const int & LDVL,COMPLEX  VR[],const int & LDVR,COMPLEX  WORK[],const int & LWORK,double* RWORK,int& info);


};

#ifdef _TESTING_
void ERROR(char* message);
#endif
//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// Array Addon  /////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////


// ******************** extra functions on Arrays of general information *************** // 
/// Is it fortran ordered ?
template <class T, int n>
bool is_fortran_ordering(const Array<T,n> & A) 
{bool r=true; for (int i=0; i<n;i++) r = (r && (A.ordering(i)==i));return(r);}

/// Is it C ordered ?
template <class T, int n>
bool is_C_ordering(const Array<T,n> & A) 
{bool r=true; for (int i=0; i<n;i++) r = (r && (A.ordering(i)==n-i-1));return(r);}

/// Is all ranks are in ascending order ?
template <class T, int n>
bool isAllRanksStoredAscending(const Array<T,n> & A)
{bool r=true; for (int i=0; i<n;++i) r = (r && A.isRankStoredAscending(i));return r;}

// Is C style, check RankAscending, dimensions Order, and Base==0
template <class T, int n>
bool is_C_style(const Array<T,n> & A){
  bool r=true; 
  r = r && is_C_ordering(A) && isAllRanksStoredAscending(A);
  for (int i=0;i<n;++i) r =  r && (A.base(i) == 0); // check if indexes start at 0.
  return r;
}

//G_{i\alpha,j\beta}
// LD leading dimension of an array presented in the tensor form
// MD minor dimension of an array presented in the tensor form
// Total_Dimension=Leading_Dimension*Minor_Dimension
// For C-ordered Array it gives
// rank | LD                 | MD
// 1    | 1                  | ext(0)
// 2    | ext(1)             | ext(0)
// 3    | ext(2)             | ext(0)*ext(1)
// 4    | ext(2)*ext(3)      | ext(0)*ext(1)
// 5    | ext(3)*ext(4)      | ext(0)*ext(1)*ext(2)
// etc
// For Fortran-ordered Arrays LD and MD have inversed meaning
//MD
template<class T, int n>
int MD(const Array<T,n>& A, const bool& C_flag=true){
if (C_flag) {
  int dim=A.extent(0);
  for (int i=1;i<(n+1)/2;++i) dim*=A.extent(i);
  return dim;}
 else return LD(A);
}
//LD
template<class T, int n>
int LD(const Array<T,n>& A, const bool& C_flag=true){
  if (C_flag) {
    int dim=1;
    for (int i=(n+1)/2;i<n;++i) dim*=A.extent(i);
    return dim;}
  else return MD(A);
};

// print tensor in matrix form: round values before printing
template<class T,int n>
void MFprint(const Array<T,n>& A, const bool& C_flag=true){
  const int M=MD(A,C_flag), N=LD(A,C_flag);
  const int nd=3; // number of digits in precision
  cout.precision(nd);
  //cout.setf(ios::floatfield,ios::scientific); // scientific output
  cout<<"Mat("<<M<<", "<<N<<")\n";
  typename Array<T,n>::const_iterator CI=A.begin();
  // calculate maximal width of output array element
  int max_width=1;
  for (; CI!=A.end(); ++CI) {
    stringstream fs; 
    fs.precision(nd);
    fs<<(*CI);
    max_width=max( int(fs.str().length()), max_width);
  };
  // print tensor in the matrix form
  CI=A.begin();
  for (int i=0; i<M;++i) { 
    for (int j=0;j<N;++j,++CI){ 
      cout.width(max_width);
      cout<<left<<(*CI)<<" ";
    };
    cout<<endl;
  };
  return;
};


// round Array elements with -esp- precision to zero
template<class T,int n>
Array<T,n> round(const Array<T,n>& A ,const double eps = 0.000001){
  Array<T,n> output(A.shape());
  typename Array<T,n>::const_iterator CI_A=A.begin();
  typename Array<T,n>::iterator CI_res=output.begin();
  for (;CI_A!=A.end();++CI_A,++CI_res)
    *CI_res= round_el(*CI_A,eps);
  return output;    
}

// round for scalars
template<class T>
inline T round_el(const T& elem,const double& eps){  T res= abs(elem)>eps?elem:T(0.); };

// specialization for complex
template<>
inline COMPLEX round_el(const COMPLEX& elem,const double& eps)
{ COMPLEX res;
 res.real() = abs(elem.real())>eps?elem.real():0.;
 res.imag() = abs(elem.imag())>eps?elem.imag():0.; 
 return res;
};



// *********************************** SUBARRAY ************************************//
// partially contiguous subArray of an array, used to pass data to LAPACK and BLITZ 
// the size is MxN
// data access is given via pointer -p_base- and leading dimension of the main Array -L-
template<class T,int n>  
class subArray{
public:
  subArray(){};
  subArray(Array<T,n> & A): p_base(A.data()), N(LD(A)), M(MD(A)), L(N) {p_base_const=p_base;test(A);};
  subArray(const Array<T,n> & A): p_base_const(A.data()), N(LD(A)), M(MD(A)), L(N) {test(A);};
  subArray(Array<T,n> & A, int dimMD, int dimLD=-1)  : 
           p_base(A.data()), M(dimMD), N((dimLD==-1)?dimMD:dimLD), L(LD(A)){p_base_const=p_base;test(A);};
  subArray(const Array<T,n> & A, int dimMD, int dimLD=-1)  : 
    p_base_const(A.data()), M(dimMD), N((dimLD==-1)?dimMD:dimLD), L(LD(A)){test(A);};
  subArray(Array<T,n> & A, const TinyVector<int,n>& base, int dimMD, int dimLD=-1): 
           p_base(&A(base)), M(dimMD),N((dimLD==-1)?dimMD:dimLD), L(LD(A))   {p_base_const=p_base;test(A,base);};
  subArray(const Array<T,n> & A, const TinyVector<int,n>& base, int dimMD, int dimLD=-1): 
           p_base_const(&A(base)), M(dimMD),N((dimLD==-1)?dimMD:dimLD), L(LD(A))   {test(A,base);};
  operator T* (){return p_base;}; //conversion of subarray to pointer to first element
  operator const T* () const {return p_base_const;};
  int subLD(bool op=true) const {return (op?N:M);};
  int subMD(bool op=true) const {return (op?M:N);};
  int mainLD() const {return L;};
  void print(){
    cout<<"SubArray = Mat("<<M<<", "<<N<<")\n";
    for (int i=0; i<M;++i) { for (int j=0;j<N;++j) {cout.precision(2); cout<<*(p_base+i*L+j)<<"\t";} cout<<endl;};
  };
#ifdef _DEBUG_
  subArray(Array<T,n> & A, T* p_data, int dimMD, int dimLD): p_base(p_data), M(dimMD), N(dimLD), L(LD(A)){test(A);};
  Array<T,2> s2a() const {
    Array<T,2> res(M,N);
    for (int i=0; i<M;++i) for (int j=0;j<N;++j) res(i,j)=(*(p_base+i*L+j));
    return res;
  };
#endif
private:
  T* p_base; //pointer to to first element of subArray
  const T* p_base_const; //const pointer to to the same first element of subArray
  int N;     // leading dimension of subarray
  int M;     // minor dimension of subarray
  int L;     // main array leading dimension
  void test(const Array<T,n>& A2test, const TinyVector<int,n>& vbase=0) const{
#ifdef _DEBUG_
    if (LD(A2test)==0) return; // if empty do nothing
    if (! A2test.isStorageContiguous())
      ERROR("SubArray: storage is not contiguous\n");
    // works only if matrix are in C ordering
    if (! is_C_style(A2test) ) 
      ERROR("subArray is defined only for C style Arrays\n");
    const int posLD=dot(A2test.stride(),vbase)%LD(A2test);
    const int posMD=dot(A2test.stride(),vbase)/LD(A2test);
    if (posLD+N>LD(A2test) || posMD+M>MD(A2test)) 
       ERROR("subArray: subMatrix is out of range\n");
#endif
    return;
  };
};


//************************BLAS LAPACK defined operations ************************************* //

// Inversion 
template<class T,int n>  
bool Inverse(Array<T,n>& A)
{
#ifdef _DEBUG_ 
  if (LD(A) != MD(A))  ERROR("Inverse Array: not square matrix \n"); 
  if (! A.isStorageContiguous())
     ERROR("Inverse Array: storage is not contiguous\n");
  // works only if matrix are in C ordering
  if (! is_C_style(A) ) 
     ERROR("Inverse Array works only for C style Arrays\n");
#endif
  const int LDA = LD(A); int N=LDA;
  int *ipiv = new int[N*N]; T *work = new T[N]; int info;
  F77(zgetrf) (N,N,A.data(),LDA,ipiv,info);
  if (info) return (false);
  F77(zgetri) (N,A.data(),LDA,ipiv,work,N,info);
  delete[] work; delete[] ipiv;
  return (info==0);
}


// tensor-matrix inversion using LAPACK
// (N,N) subarray of the matrix A (LDA,*) is inverted
template<class T,int n>  
bool Inverse(subArray<T,n> A)
{
#ifdef _DEBUG_ 
  if (n%2 != 0)  ERROR("Inverse subArray: not pair dimentions \n"); 
  if (A.subMD()!= A.subLD())  ERROR("Inverse subArray: not square Matrix \n"); 
#endif
  // values of leading dimension LD
  int LDA = A.mainLD(); 
  // size of array part to be inverted 
  int N=A.subLD();
  int *ipiv = new int[N*N]; T *work = new T[N];
  int info;
  F77(zgetrf) (N,N,A,LDA,ipiv,info);
  if (info) return (false);
  F77(zgetri) (N,A,LDA,ipiv,work,N,info);
  delete[] work; delete[] ipiv;
  return (info==0);
}


// Diagonalization of a general non hermitian matrix using ZGEEV 
// IN ITS PRESENT STATE, COMPUTE THE LEFT EIGENVECTORS
template<class T,int n,int m>
bool Diagonalization_General(Array<T,n>& AAA, Array<T,m>& W,  Array<T,n>& RIGHT_VECT)
{
#ifdef _DEBUG_ 
  if (LD(AAA) != MD(AAA))  ERROR("Diag Array: not square matrix \n"); 
  if (! AAA.isStorageContiguous())
     ERROR("Diag Array: storage is not contiguous\n");
  // works only if matrix are in C ordering
  if (! is_C_style(AAA) ) 
     ERROR("Diag Array works only for C style Arrays\n");
#endif
  const int LDA = LD(AAA); int N=LDA;
  T *VR = new T[N]; 
  int LWORK=2*N*N;
  T *WORK = new T[LWORK]; 
  double *RWORK=new double[2*N];
  int info;
  int LDVL=N;
  int LDVR=1;
  const char* JOBVL="V";
  const char* JOBVR="N";
  F77(zgeev) (JOBVL,JOBVR,N,AAA.data(),LDA,W.data(),RIGHT_VECT.data(),LDVL,VR,LDVR,WORK,LWORK,RWORK,info);
  delete[] WORK; delete[] VR; delete[] RWORK;
  // THE EIGENVECTORS ARE IN LINE and COMPLEX CONJUGATED: conjugate(RIGHT_VECT(i,:)) IS THE EIGENVECTOR.
  return (info==0);
}


// general eigenvalue problem for non hermitian matrix using ZGGEV
//   A x = lambda B x 
// IN ITS PRESENT STATE, COMPUTE THE LEFT EIGENVECTORS
template<class T,int n,int m>
bool Diagonalization_VeryGeneral(Array<T,n>& AAA,Array<T,n>& BBB, Array<T,m>& ALPHA,Array<T,m>& BETA,Array<T,n>& RIGHT_VECT)
{
  // ON EXIT THE EIGENVALUES ARE ALPHA/BETA
#ifdef _DEBUG_ 
  if (LD(AAA) != MD(AAA))  ERROR("Diag Array: A not square matrix \n"); 
  if (! AAA.isStorageContiguous())
     ERROR("Diag Array: storage of A is not contiguous\n");
  // works only if matrix are in C ordering
  if (! is_C_style(AAA) ) 
     ERROR("Diag Array (A) works only for C style Arrays\n");
 if (LD(BBB) != MD(BBB))  ERROR("Diag Array: B not square matrix \n"); 
  if (! BBB.isStorageContiguous())
     ERROR("Diag Array: storage for B is not contiguous\n");
  // works only if matrix are in C ordering
  if (! is_C_style(BBB) ) 
     ERROR("Diag Array (B) works only for C style Arrays\n");
#endif
  const int LDA = LD(AAA); int N=LDA;
  const int LDB = LD(BBB); 
  T *VR = new T[1]; 
  int LWORK=2*N*N;
  T *WORK = new T[LWORK]; 
  double *RWORK=new double[8*N];
  int info;
  int LDVL=N;
  int LDVR=1;
  const char* JOBVL="V";
  const char* JOBVR="N";
  F77(zggev) (JOBVL,JOBVR,N,AAA.data(),LDA,BBB.data(),LDB,ALPHA.data(),BETA.data(),RIGHT_VECT.data(),LDVL,VR,LDVR,WORK,LWORK,RWORK,info);
  delete[] WORK; delete[] VR; delete[] RWORK;
  // THE EIGENVECTORS ARE IN LINE and COMPLEX CONJUGATED: conjugate(RIGHT_VECT(i,:)) IS THE EIGENVECTOR.
  return (info==0);
}


//tensor-matrix multiplication using BLAS
// C := alpha*op( A )*op( B ) + beta*C
// works only for contiguous Arrays
template<class T, int n1, int n2, int n3>
void matmul_blas(const Array<T,n1> & A, const Array<T,n2> & B, Array<T,n3> & C, const T& alpha=T(1), const T& beta=T(0), const char& TransA='n', const char& TransB='n')
{//!!!do not confuse C(input matrix) and C(programming language). C-ordering is language related notation, nothing to do with C(input matrix)
  const int N=MD(C), M=LD(C), K=LD(A,(TransA=='n'||TransA=='N')); // K=LD(op(A))
#ifdef _DEBUG_
  if (n1%2 != 0 || n2%2 !=0 || n3%2 != 0)  ERROR("matmul_blas: works only for pair dimentions \n");
  const bool opA=(TransA=='n'||TransA=='N'), opB=(TransB=='n'||TransB=='N'); // if opA==true then there is no options for A
  // LD(A,opA) returns leading dimension of op(A) array
  // works only if all matrix are in "C/C++" ordering
  if (!( is_C_style(A) && is_C_style(B) && is_C_style(C) )) {
    cout<<"MD(A) x LD(A)="<<MD(A,opA)<<" x "<<LD(A,opA)<<endl
	<<"MD(B) x LD(B)="<<MD(B,opB)<<" x "<<LD(B,opB)<<endl
	<<"MD(C) x LD(C)="<<MD(C)<<" x "<<LD(C)<<endl;
    ERROR("b_gemm works only for C style Arrays\n");};
  if (MD(A,opA) != MD(C) || LD(B,opB) != LD(C))  {
    cout<<"MD(A) x LD(A)="<<MD(A,opA)<<" x "<<LD(A,opA)<<endl
	<<"MD(B) x LD(B)="<<MD(B,opB)<<" x "<<LD(B,opB)<<endl
	<<"MD(C) x LD(C)="<<MD(C)<<" x "<<LD(C)<<endl;
    ERROR("in matmul_blas: multiplied matrix sizes do not correspond to the result");
  };
  if (LD(A,opA) != MD(B,opB))  ERROR("in matmul_blas: multiplied matrix sizes do not correct");
#endif
  if (M*N*K==0) {
    if (M*N>4) cout<<"\nWARNING in matmul_blas LOST OF PERFORMANCE:\n multiplied matrix of zero size, final result is too big\n";
    if ( beta == T(0) ) C=T(0); else C*=beta; 
    return;
  }; // for zero size matrix return beta*C
  int LDA = LD(A), LDB = LD(B), LDC = LD(C); // initialize values of leading dimensions (LDs)
  // A and B position are inversed since we are using C/C++-ordered arrays
  F77(zgemm)(&TransB,&TransA,M,N,K, alpha, B.data(), LDB, A.data(), LDA, beta, C.data(), LDC);
  return;
}


//tensor-submatrix multiplication using BLAS
// C := alpha*op( A )*op( B ) + beta*C
// most general interface that use subArrays
template<class T, int n1, int n2, int n3>
void matmul_blas(const subArray<T,n1> A, const subArray<T,n2> B, subArray<T,n3> C, const T& alpha=T(1), const T& beta=T(0), const char& TransA='n',const char& TransB='n')
{//!!!do not confuse C(input matrix) and C(programming language). C-ordering is language related notation, nothing to do with C(input matrix) 
  const int N=A.subMD((TransB=='n'||TransB=='N')), M=B.subLD((TransB=='n'||TransB=='N')), K=A.subLD((TransA=='n'||TransA=='N'));
#ifdef _DEBUG_
  if (n1%2 != 0 || n2%2 !=0 || n3%2 != 0)  ERROR("matmul subArray works only for pair dimentions \n");
  TinyVector<char,6> ops;ops='n','N','t','T','c','C';
  bool rA=false, rB=false;
  for (int i=0;i<=6;++i) rA = rA || (TransA == ops(i) );
  for (int i=0;i<=6;++i) rB = rB || (TransB == ops(i) );
  if ((!rA) && (!rB))  ERROR("in matmul_blas: matrix operation option is not correst (! 'n', 't', 'c')");
  if (N != C.subMD() || M != C.subLD())   {
    C.print();cout<<"N="<<N<<"  M="<<M<<" K="<<K<<endl;
    ERROR("in matmul_blas: multiplied submatrix sizes do not correspond to the result");};
  if (K != B.subMD((TransB=='n'||TransB=='N')))  ERROR("in matmul_blas: multiplied submatrix sizes do not correct");
#endif
  if (M*N*K==0) {
    if (M*N>4) cout<<"\nWARNING in matmul_blas LOST OF PERFORMANCE:\n multiplied submatrix of zero size, final result is too big\n";
    T* p_base=C;
    for (int i=0; i<C.subMD();++i) for (int j=0;j<C.subLD();++j) *(p_base+i*C.mainLD()+j) *= beta;
    return;
  }; // for zero size matrix return beta*C
  const int LDA = A.mainLD(), LDB = B.mainLD(), LDC = C.mainLD(); // initialize values of leading dimensions (LDs)
  // A and B position are inversed since we are using C/C++-ordered arrays
  F77(zgemm)(&TransB,&TransA,M,N,K, alpha, B, LDB, A, LDA, beta, C, LDC);
  return;
}


// //tensor-matrix multiplication using BLAS
// // C := alpha*op( A )*op( B ) + beta*C  SPECIAL CASE ASSUME ALPHA=1 AND BETA=0
// template<class T, int n1, int n2, int n3>
// void matmul_blas(const Array<T,n1> & A, const Array<T,n2> & B, Array<T,n3> & C)
// {
//   const char& bb='n';
//   matmul_blas(A,B,C,T(1.0),T(0.),bb,bb);
//   return;
// }

// three tensor multiplications res=op(A)*op(B)*op(C)
// order of multiplication is choosen for maximal speed performance
template<class T,int n>
void matmul3_blas(const Array<T,n>& A, const Array<T,n>& B, const Array<T,n>& C, Array<T,n>& res, const char& TransA='n', const char& TransB='n', const char& TransC='n'){
  // choose order of multiplication
  // if opA==true then there is no options for A
  const bool opA=(TransA=='n'||TransA=='N'), opB=(TransB=='n'||TransB=='N'),opC=((TransC=='n')||TransC=='N');
  if (MD(A,opA) >= LD(C,opC)){// if multiplication "price" of A*B > price of B*C then B is multiplied by C first
    Array<T,2> BC(MD(B,opB),LD(C,opC)); // temporary Array B*C
    matmul_blas(B,C,BC,T(1.0),T(0.),TransB,TransC);
    matmul_blas(A,BC,res,T(1.0),T(0.),TransA,'n');
  }
  else{// if price AB<price BC then A is multiplied by B first
    Array<T,2> AB(MD(A,opA),LD(B,opB));  // temporary Array A*B
    matmul_blas(A,B,AB,T(1.0),T(0.),TransA,TransB);
    matmul_blas(AB,C,res,T(1.0),T(0.),'n',TransC);
  };
  return;
};


//tensor-matrix multiplication using BLAS
// C := alpha*op( A )*op( B ) + beta*C  SPECIAL CASE ASSUME one of the Arrays is given as a subArrays
template<class T, int n1, int n2, int n3> 
void matmul_blas(const Array<T,n1> & A, const Array<T,n2> & B, subArray<T,n3> & C, T alpha=1., T beta=0., const char& TransA='n', const char& TransB='n') 
{ matmul_blas(subArray<T,n1>(A), subArray<T,n2>(B), C, alpha, beta, TransA, TransB); return;} 
template<class T, int n1, int n2, int n3>
void matmul_blas(const subArray<T,n1> & A, const Array<T,n2> & B, Array<T,n3> & C, T alpha=1., T beta=0., const char& TransA='n', const char& TransB='n')
{ matmul_blas(A, subArray<T,n2>(B), subArray<T,n3>(C), alpha, beta, TransA, TransB); return;} 
template<class T, int n1, int n2, int n3> 
void matmul_blas(const Array<T,n1> & A, const subArray<T,n2> & B, Array<T,n3> & C, T alpha=1., T beta=0., const char& TransA='n', const char& TransB='n') 
{ matmul_blas(subArray<T,n1>(A), B, subArray<T,n3>(C), alpha, beta, TransA, TransB); return;}


//************************BLITZ defined operations ******************************************* //


//-----------------------------------------------------------------------------------------------
// is_equal(A,B,eps) compare two arrays element by element with precision epsilon
template<class T, int n>
		    bool is_equal(const Array<T,n> & A, const Array<T,n> & B, double eps=1.e-6)
{ 
  TinyVector<int,n> diff_shape = A.shape(); diff_shape-=B.shape();
  bool egale =  (all(diff_shape)==0) &&(  all(abs(A-B)<=abs(A+B)*eps) );return egale;
}


//-----------------------------------------------------------------------------------------------
// Identity

template<class T,class T2>
void set_Scalar( Array<T,2> & M, T2 x)
{
  assert(M.extent(secondDim) == M.extent(firstDim));
  M=0; for (int i=M.lbound(firstDim);i<=M.ubound(firstDim);i++)  M(i,i) = x;
}


//-----------------------------------------------------------------------------------------------
// A<=B
template<class T, int n>
inline Array<T,n> & operator <= (Array<T,n> & L, const Array<T,n> & R)
{L.resize(R.shape()); L =R;return (L);}


//-----------------------------------------------------------------------------------------------
// Return a scalar matrix
template<class T>
Array<T,2> scalar_matrix(int n, T val) {Array<T,2> res(n,n);res = T(0);
  for (int i =0;i<n;i++) res(i,i) = val; return(res);}

// Return a scalar tensor
template<class T>
Array<T,4> scalar_matrix(int dim,int subdim, T val) { Array<T,4> res(dim,subdim,dim,subdim);res = T(0);
  for (int j=0;j<subdim;++j) for (int i =0;i<dim;i++) res(i,j,i,j) = val; return(res);}

// Return a diagonal matrix
template<class T>
Array<T,2> diagonal_matrix(const Array<T,1> & diag){ int n=diag.extent(0); Array<T,2> res(n,n);res =0;
  for (int i =0;i<n;i++) res(i,i) = diag(i); return(res);}

//-----------------------------------------------------------------------------------------------

/*
    Matrix multiplication 
*/

template<class T1,class T2, class T3>
inline void _for_matmul( const Array<T1,2> & M, const Array<T2,2> & B, Array<T3,2> & r)
{
  assert(M.extent(secondDim) == B.extent(firstDim));
  r=0;
  for (int i=M.lbound(firstDim),ir=r.lbound(firstDim);i<=M.ubound(firstDim);i++,ir++)
    for (int k=B.lbound(secondDim),kr=r.lbound(secondDim);k<=B.ubound(secondDim);k++,kr++)
      for (int j1=M.lbound(secondDim),j2=B.lbound(firstDim);j1<=M.ubound(secondDim);j1++,j2++) r(ir,kr)+= M(i,j1)*B(j2,k);
  return;
}

//r:=r+M*B
template<class T1,class T2, class T3>
inline void plus_matmul( const Array<T1,2> & M, const Array<T2,2> & B, Array<T3,2> & r)
{
  assert(M.extent(secondDim) == B.extent(firstDim));
  for (int i=M.lbound(firstDim),ir=r.lbound(firstDim);i<=M.ubound(firstDim);i++,ir++)
    for (int k=B.lbound(secondDim),kr=r.lbound(secondDim);k<=B.ubound(secondDim);k++,kr++)
      for (int j1=M.lbound(secondDim),j2=B.lbound(firstDim);j1<=M.ubound(secondDim);j1++,j2++) r(ir,kr)+= M(i,j1)*B(j2,k);
  return;
}


template<class T1,class T2, class T3>
inline void _for_matmul_v (const Array<T1,2> & M, const Array<T2,1> & V, Array<T3,1> & r)
{
  assert(M.extent(secondDim) == V.extent(firstDim));
  r=0;
  for (int i=M.lbound(firstDim),kr=r.lbound(firstDim);i<=M.ubound(firstDim);i++,kr++)
    for (int j1=M.lbound(secondDim),j2=V.lbound(firstDim);j1<=M.ubound(secondDim);j1++,j2++) r(kr)+= M(i,j1)*V(j2);
  return;
}


template<class T>
inline Array<T,2> matmul(const Array<T,2> & M, const Array<T,2> & B) 
{
  Array<T,2> r(M.extent(firstDim),B.extent(secondDim));
  if (M.extent(secondDim)>MAX_MATMUL) matmul_blas(M,B,r); else _for_matmul(M,B,r);
  return(r);
}

// A*B*C
template<class T>
inline Array<T,2> matmul(const Array<T,2> & A, const Array<T,2> & B,  const Array<T,2> & C) 
{
  Array<T,2> AB(A.extent(firstDim),B.extent(secondDim));
  if (A.extent(secondDim)>MAX_MATMUL) matmul_blas(A,B,AB); else  _for_matmul(A,B,AB);
  Array<T,2> r(A.extent(firstDim),C.extent(secondDim));
  if (C.extent(firstDim)>MAX_MATMUL) matmul_blas(AB,C,r); else  _for_matmul(AB,C,r);
  return(r);
}

// - operation * for tensor-form Matrix
template<class T>
Array<T,4> matmul(const Array<T,4>& A, const Array<T,4>& B)
{
#ifdef _DEBUG_
  assert(LD(A) == MD(B));
#endif
  const int rank=4;
  firstIndex i; secondIndex j; thirdIndex k; fourthIndex l; fifthIndex m; sixthIndex n;
  TinyVector<int,rank> dim;
  for (int ii=0;ii<rank;++ii) dim(ii)=(ii<(rank+1)/2)?A.extent(ii):B.extent(ii);
  Array<T,rank> result(dim);
  if (LD(A)>MAX_MATMUL) matmul_blas(A,B,result); else result=sum(sum(A(i,j,m,n)*B(m,n,k,l),n),m);
  return result;
}

/// Y=M*X
template<class T>
inline Array<T,1> matmul(const Array<T,2> & M,const  Array<T,1> & X)
{ Array<T,1> r (M.extent(firstDim));
  _for_matmul_v(M,X,r);return(r);}



//-----------------------------------------------------------------------------------------------



#ifdef _TESTING_

int myRand(int ii){return ((rand()+ii)%10);};
BZ_DECLARE_FUNCTION(myRand);

template<class T, int n>
void print(Array<T,n> c,char t_or_m){
  if (t_or_m == 'm' || t_or_m =='a') subArray<T,n>(c).print();
  if (t_or_m == 't' || t_or_m =='a') {cout.precision(2);cout<<c<<endl;}
  if (t_or_m != 't' && t_or_m !='a' && t_or_m != 'm') cout<<c.extent()<<endl;
};

template<class T, int n>
int halfMD(const Array<T,n>& A){ return (A.extent(0)/2*MD(A)/A.extent(0));};

template<class T, int n>
int halfLD(const Array<T,n>& A){ return (A.extent(n/2)/2*LD(A)/A.extent(n/2));};

//one should redefine dgetrf and dgetri for other type i.e. dgetrf for double
// diag(Tnum,int) should be changed

#endif //_TESTING_
// g++ -D_DEBUG_ -D_TESTING_ -O2 -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz blitz_addon.C

//-----------------------------------------------------------------------------------------------


/*@}*/


#endif  //_BLITZ_ADDON_
