#include "blitz_addon.h"

#ifdef _TESTING_
void ERROR(char* message){cout<<"*** SORTIE GENEREE PAR ROUTINE ERROR ***"<<endl<<message<<endl; exit(1);};

//one should redefine dgetrf and dgetri for other type i.e. dgetrf for double
// diag(Tnum,int) should be changed

// g++ -D_DEBUG_ -D_TESTING_ -O2 -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz blitz_addon.C

////////////////////////////////////////////////////////////////////////////////
///////////////////////           main           ///////////////////////////////
////////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv){
#define _MULTIPLICATION_TEST_
#define _SUB_MULTIPLICATION_TEST_
#define _INVERSION_TEST_
#define _SUB_INVERSION_TEST_
#define TT COMPLEX
  if (argc==1) {
    cout<<"Please, input maximal submatrix size, for example\n"<<
      "./a.out 2 t\n 't' means that matrix are printed in tensor form\n"<<
      "other options are 'm' - matrix form; 'a' - both forms\n";
    return 0;};
  int sizeM=atoi(argv[1]);
#if defined _SUB_TEST_ || defined _SUB_MULTIPLICATION_TEST_ || defined _SUB_INVERSION_TEST_
  sizeM*=2;//double size for subArray testings
#endif
  char t_or_m=' ';
  // 't' - just tensor form
  // 'm' - just matrix form
  // 'a' - all forms
  if (argc==3)  t_or_m=*argv[2];
  const int n=4;
  cout<<"rank="<<n<<endl;
  cout<<"size="<<sizeM<<endl;
  srand(sizeM);
  TinyVector<int,n> dim,base; // variables used in Array and subArray creation
  for (int ii=0;ii<n;++ii) dim(ii)=sizeM+(rand()%3);  
  Array<TT,n> a(dim); //random size Matrix
  for (int ii=0;ii<n;++ii) dim(ii)=(ii<(n+1)/2)?a.extent(ii+n/2):sizeM+rand()%3;
  Array<TT,n> b(dim); // matrix with LD equal to MD of -a-
  for (int ii=0;ii<n;++ii) dim(ii)=(ii<(n+1)/2)?a.extent(ii):b.extent(ii);  
  Array<TT,n> c(dim); // matrix of size of the tensor product a*b 
  for (int ii=0;ii<n/2;++ii) {dim(ii)=sizeM+(rand()%3); dim(n/2+ii)=dim(ii);};
  Array<TT,n> sq(dim); //random size square Matrix
  // Initialization with Random
  {  firstIndex i; secondIndex j;thirdIndex k;fourthIndex l;
  if (n==4) {a=myRand(i*j*k*l); b=myRand(i*j*k*l); sq=myRand(i*j*k*l);};
  if (n==2) {a=myRand(i*j); b=myRand(i*j); sq=myRand(i*j);};
  };
  /*
  a=1000*i+100*j+10*k+l;
  b=-1000*i+100*j-10*k+l;
  */
#ifdef _MULTIPLICATION_TEST_
  cout<<"*************** multiplication function TEST *************** \n";
  cout<<"a = \n"; print(a,t_or_m);
  cout<<"b = \n"; print(b,t_or_m);
  cout<<"c = \n"; print(c,t_or_m);
  cout<<"c=a*b  BLITZ \n";
  c=matmul(a,b); // multiply with BLITZ
  print(c,t_or_m);
  c=10; // reset result matrix
  matmul_blas(a,b,c); //multiply with BLASS
  cout<<"c=a*b+0.*c Blas"<<endl;
  print(c,t_or_m);
  //compare both Blitz and Blas and give error if result are not close enough
  cout<<"BLAS versus BLITZ  Multiplication of Array test=>\n"<<
    ((all(abs(matmul(a,b)-c)<0.001))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision int test function)!!!")<<endl;
#endif
#ifdef _SUB_MULTIPLICATION_TEST_
  cout<<"*************** multiplication subArray TEST *************** \n";
  base=0;
  //creation of subArray of "halfsize" and random base
  base(0)=rand()%(a.extent(0)/2); base(n/2)=rand()%(a.extent(n/2)/2);
  subArray<TT,n> suba(a,base,halfMD(a),halfLD(a));
  base(0)=rand()%(b.extent(0)/2); base(n/2)=rand()%(b.extent(n/2)/2);
  subArray<TT,n> subb(b,base,halfMD(b),halfLD(b));
  base(0)=rand()%(c.extent(0)/2); base(n/2)=rand()%(c.extent(n/2)/2);
  subArray<TT,n> subc(c,base,halfMD(c),halfLD(c));
  //copy of this subArrays in Arrays
  Array<TT,2> halfa=suba.s2a(),halfb=subb.s2a(),halfc=subc.s2a();
  if (t_or_m == 'm' || t_or_m == 't' ){
    cout<<"suba = \n"; suba.print();cout<<halfa<<endl;
    cout<<"subb = \n"; subb.print();cout<<halfb<<endl;
    cout<<"subc = \n"; subc.print();
  };
  cout<<"subc=suba*subb  BLITZ \n";
  halfc=matmul(halfa,halfb); //Multiply Arrays copy by Blitz
  if (t_or_m == 'm' || t_or_m == 't' ) print(halfc,t_or_m);
  matmul_blas(suba,subb,subc); // Multiply subArray by Blas
  cout<<"subc=suba*subb+csub Blas"<<endl;
  if (t_or_m == 'm' || t_or_m == 't' ) subc.print();
  //compare both Blitz and Blas and give error if result are not close enough
  cout<<"BLAS versus BLITZ  Multiplication of subArray test=>\n"<<
    ((all(abs(halfc-subc.s2a())<0.001))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision int test function)!!!")<<endl;
#endif
    
#ifdef _INVERSION_TEST_
  // ******************************* Inverse  TEST *************** //
  cout<<"*************** Inverse  TEST *************** \n";
  Array<TT,n> sq_copy(sq.copy());
  Array<TT,n> ident; // matrix that should be identity if test succeeds
  ident.resize(sq.shape());
  cout<<"sq =\n";
  print(sq,t_or_m);
  // Inverse using Lapack
  if (!Inverse(sq)) cout<<"\nInversion failed LAPACK\n"<<endl;
  //  if (max(sq)>1./ZERO || min(sq)<-1./ZERO) cout<<"\nWARNING: possibly trying to inverse Matrix with zero determinant\n\n";
  if (max(abs(sq))>1./ZERO ) cout<<"\nWARNING: possibly trying to inverse Matrix with zero determinant\n\n";
  cout<<"sq^-1 =\n";
  print(sq,t_or_m);
  ident=matmul(sq,sq_copy);
  cout<<"sq*sq^-1 =\n";
  print(ident,t_or_m);
  // identity check is performed sq*id =?= sq
  cout<<"BLAS Inversion of Array test=>\n"<<
    ((all(abs(matmul(sq,ident)-sq)<ZERO))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision int test function)!!!")<<endl;
#endif
#ifdef _SUB_INVERSION_TEST_
  // ******************************* Inverse subArray TEST *************** //
  cout<<"*************** Inverse subArray TEST *************** \n";
  base=0;
  base(0)=rand()%(sq.extent(0)/2); base(n/2)=rand()%(sq.extent(n/2)/2);
  subArray<TT,n> subsq(sq,base,halfMD(sq),halfLD(sq));
  Array<TT,n> sq_subcopy(sq.copy());
  cout<<"sq =\n";
  print(sq,t_or_m);
  // Inverse using Lapack
  if (!Inverse(subsq)) cout<<"\nInversion failed LAPACK\n"<<endl;
  //if (max(sq)>1./ZERO || min(sq)<-1./ZERO) cout<<"\nWARNING: possibly trying to inverse Matrix with zero determinant\n\n";
  if (max(abs(sq))>1./ZERO ) cout<<"\nWARNING: possibly trying to inverse Matrix with zero determinant\n\n";
  cout<<"subsq^-1 =\n";
  print(sq,t_or_m);
  // Inverse using Lapack second time
  if (!Inverse(subsq)) cout<<"\nInversion failed LAPACK\n"<<endl;
  //error test based on equality sq^(-1)^-1 =?= sq
  cout<<"BLAS Inversion of subArray test=>\n"<<
    ((all(abs(sq_subcopy-sq)<ZERO))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision int test function)!!!")<<endl;
#endif
#ifdef _SUB_TEST_  
  cout<<"********************subArray constructors tests ***********\n";  
  subArray<TT,n> sub(a);
  subArray<TT,n> subSize(a,8);
  subArray<TT,n> subBase(a,base,2,5);
  Inverse(subArray<TT,n>(a,base,2));
#endif
  return 1;
};

#endif //_TESTING_


//-----------------------------------------------------------------------------------------------


/*@}*/
