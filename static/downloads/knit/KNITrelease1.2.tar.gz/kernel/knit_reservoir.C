// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include "blitz_addon.h"
#include "knit_reservoir.h"
#include "knit_acos.h"

int semi_infini(const GF_type& Hhopp, const GF_type& Hdiag, COMPLEX E, GF_type& GFsurf){
  //return semi_infini_new(Hhopp,Hdiag,E,GFsurf);
  return semi_infini_newbis(Hhopp,Hdiag,E,GFsurf);
  //return semi_infini_old(Hhopp,Hdiag,E,GFsurf);
};


// 10th October 2008: A new version of semi_infini(...) which should work when V
// is not inversible can be find below. This one is depreciated.
int semi_infini_old(const GF_type& V,const GF_type& Ho,COMPLEX E,GF_type& resultat){
  
  int Nch=0;
  const int TAILLE=V.extent(0)*V.extent(1); // tensor size
  firstIndex ii;
  secondIndex jj;
  thirdIndex kk;
  fourthIndex ll;
  fifthIndex mm;
  sixthIndex nn;
 
  // ETAPE 1: CALCULATION OF THE INVERSE OF V: Vm
  GF_type Vm=V.copy();
  Inverse(Vm);
  
  // ETAPE 2: CALCULATION OF THE EFFECTIVE MATRIX OO
  ///           [ Vm (E-Ho)   -Vm Vd   ]
  ///      HH = [                      ]
  ///           [   1           0      ]
  /// WHERE Vd (V dagger) IS THE HERMITIAN CONJUGATE OF V
  TinyVector<int,6> dd; // dd is shape vector of six indexes HH Array
  dd(0)=dd(3)=2; // extra index (phi, theta) of 2x2 matrix structure given above
  dd(1)=dd(4)=V.extent(0); // site index
  dd(2)=dd(5)=V.extent(1); // inner degree of freedom
  Array<COMPLEX,6> HH(dd);
  // HH(0,0) = Vm*E - Vm*Ho
  GF_type TMP(E*Vm);
  matmul_blas(Vm,Ho,TMP,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  HH(0,ALL,ALL,0,ALL,ALL)=TMP;
  // HH(0,1) = -Vm*Vd
  matmul_blas(Vm,V,TMP,COMPLEX(-1.0),COMPLEX(0.0),'n','c');/////'n'  'c'
  HH(0,ALL,ALL,1,ALL,ALL)=TMP;
  // HH(1,0) = 1
  HH(1,ALL,ALL,0,ALL,ALL)= scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  // HH(1,1) = 0
  HH(1,ALL,ALL,1,ALL,ALL)= 0.;
  
  // ETAPE 3: DIAGONALIZATION OF THE EFFECTIVE MATRIX HH
  Array<COMPLEX,3> VAL_PROPRES(dd(0),dd(1),dd(2));
  Array<COMPLEX,6> VECTEURS_PROPRES(dd);
  Diagonalization_General(HH,VAL_PROPRES,VECTEURS_PROPRES);

  // ETAPE 4: CLASSIFICATION OF THE EIGENVECTORS INTO LEFT AND RIGHT GOERS
  // ATTENTION!!! for real energy procedure is not efficient because of phiVphi calculation
  Array<TinyVector<int,3>,1>  L_movers(TAILLE),R_movers(TAILLE); // store vector indexes of left and right movers
  int L_taille(0),R_taille(0); // number of left and right movers
 
  for(int i1=0;i1<dd(0);++i1)for(int i2=0;i2<dd(1);++i2)for(int i3=0;i3<dd(2);++i3){
    const double eps=1.e-6; // precision of classiffication
    COMPLEX xi=VAL_PROPRES(i1,i2,i3);
    TinyVector<int,3> i; i=i1,i2,i3;
    if ( abs(xi)>(1.+eps) )      {R_movers(R_taille)=i;++R_taille;}
    else if ( abs(xi)<(1.-eps) ) {L_movers(L_taille)=i;++L_taille;}
    else { // for abs(xi)=1 we calculate the velocity sign
      // CAREFUL THE EIGENVECTORS HAVE NOT BEEN NORMALIZED
      Nch++;
      const Array<COMPLEX,2> vp_i=VECTEURS_PROPRES(i1,i2,i3,0,ALL,ALL); // conjugate of phi part of eigen vector
      const COMPLEX phiVphi=sum( vp_i(ii,jj)*V(ii,jj,kk,ll)*conj(vp_i(kk,ll)) );
      const COMPLEX vitesse=COMPLEX(0.,1.)*( phiVphi*xi - conj(phiVphi)/xi );
      if( real(vitesse)>0) 
	{L_movers(L_taille)=i;++L_taille;} 
      else if( real(vitesse)<0)
	{R_movers(R_taille)=i;++R_taille;}
    }
  }
 
  // ETAPE 5: INITIALIZATION OF THE LEFT GOERS BASIS:
  Array<COMPLEX,3>  tmp_vec(V.extent(0),V.extent(1),TAILLE);
  Array<COMPLEX,1>  tmp_val(TAILLE);
#ifdef _DEBUG_
  if(L_taille != TAILLE )  ERROR("semi infinite leads: not full basis L_taille != TAILLE");
  if(R_taille != TAILLE )  ERROR("semi infinite leads: not full basis R_taille != TAILLE");
#endif
  tmp_vec=0;
  for(int i=0;i<TAILLE;++i) {
    const TinyVector<int,3> idx=L_movers(i); // vector index of a left mover
    tmp_val(i)=VAL_PROPRES(idx);
    tmp_vec(ALL,ALL,i)=conj(VECTEURS_PROPRES(idx(0),idx(1),idx(2),0,ALL,ALL));
  };
  GF_type PHI(tmp_vec.data(),V.shape(),neverDeleteData); // PHI(:,:,k,l) is the eigen vector for tensor index (k,l)
  Array<COMPLEX,2> PHI_vp(tmp_val.data(),TinyVector<int,2>(V.extent(0),V.extent(1)),neverDeleteData);
  
  //ETAPE 6: DUAL BASIS multiplied by xi:
  GF_type PHI_bar_H(PHI.copy());
  Inverse(PHI_bar_H); // conj(PHI_bar_H(i,j,:,:)) is the dual vector for PHI(:,:,i,j)
  GF_type xiPHI_bar_H(PHI_bar_H);
  xiPHI_bar_H = PHI_vp(ii,jj)*PHI_bar_H(ii,jj,kk,ll);

  //ETAPE 7: CONSTRUCTION OF THE MATRIX Fl (for left goers) defined as 
  // Fl(i,j) = xi(a) PHI(i,a) PHI_bar^H(a,j)
  GF_type Fl(V.shape());
  matmul_blas(PHI,xiPHI_bar_H,Fl);
  //  Fl=sum(sum(PHI_vp(mm,nn)*PHI(ii,jj,mm,nn)*PHI_bar_H(mm,nn,kk,ll),nn),mm);
   
  //ETAPE 8: THE SURFACE GREEN FUNCTION" defined as
  //G=Fl*V^(-H)
  matmul_blas(Fl,Vm,resultat,COMPLEX(1.),COMPLEX(0.),'n','c');
#ifdef _DEBUG_
  if (sum(abs(imag(resultat))) < 1e-16 ) cout<<"\nWARNING GF of the lead is purely real\n";
#endif
  return Nch/2;
};



// 10th October 2008: new version of semi_infini(...) which should work when V
// is not inversible: we look for eigenvalues of the problem A x = lambda B x with
///           [ (E-Ho)   -Vd   ]          [ V      0 ]
///      A  = [                ]  and B=  [          ]
///           [   1       0    ]          [ 0      1 ]
int semi_infini_new(const GF_type& V,const GF_type& Ho,COMPLEX E,GF_type& resultat){
  
  int Nch=0;
  const int TAILLE=V.extent(0)*V.extent(1); // tensor size
  firstIndex ii;
  secondIndex jj;
  thirdIndex kk;
  fourthIndex ll;
  fifthIndex mm;
  sixthIndex nn;
 
  // ETAPE 1: CALCULATION OF THE EFFECTIVE MATRIX BB
  TinyVector<int,6> dd; // dd is shape vector of six indexes HH Array
  dd(0)=dd(3)=2; // extra index (phi, theta) of 2x2 matrix structure given above
  dd(1)=dd(4)=V.extent(0); // site index
  dd(2)=dd(5)=V.extent(1); // inner degree of freedom

  Array<COMPLEX,6> BB(dd);
  // BB(1,0) = 0
  BB(1,ALL,ALL,0,ALL,ALL)= 0.;
  // BB(0,1) = 0
  BB(0,ALL,ALL,1,ALL,ALL)= 0.;
  // BB(1,1) = 1.
  BB(1,ALL,ALL,1,ALL,ALL)= scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  // BB(0,0) = V
  BB(0,ALL,ALL,0,ALL,ALL)= V.copy();

  // ETAPE 2: CALCULATION OF THE EFFECTIVE MATRIX 
  ///           [ (E-Ho)   - Vd   ]
  ///      HH = [                      ]
  ///           [   1           0      ]
  /// WHERE Vd (V dagger) IS THE HERMITIAN CONJUGATE OF V
 
  Array<COMPLEX,6> HH(dd);
  // HH(0,0) = Vm*E - Vm*Ho
  GF_type Vm=scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  GF_type TMP(E*Vm);
  matmul_blas(Vm,Ho,TMP,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  HH(0,ALL,ALL,0,ALL,ALL)=TMP;
  // HH(0,1) = -Vm*Vd
  matmul_blas(Vm,V,TMP,COMPLEX(-1.0),COMPLEX(0.0),'n','c');/////'n'  'c'
  HH(0,ALL,ALL,1,ALL,ALL)=TMP;
  // HH(1,0) = 1
  HH(1,ALL,ALL,0,ALL,ALL)= scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  // HH(1,1) = 0
  HH(1,ALL,ALL,1,ALL,ALL)= 0.;
  
  // ETAPE 3: DIAGONALIZATION OF THE EFFECTIVE MATRIX HH x = lambda BB x
  Array<COMPLEX,3> VAL_PROPRES(dd(0),dd(1),dd(2));
  Array<COMPLEX,3> ALPHA(dd(0),dd(1),dd(2)),BETA(dd(0),dd(1),dd(2));
  Array<COMPLEX,6> VECTEURS_PROPRES(dd);
  Diagonalization_VeryGeneral(HH,BB,ALPHA,BETA,VECTEURS_PROPRES);
  for(int i1=0;i1<dd(0);++i1)for(int i2=0;i2<dd(1);++i2)for(int i3=0;i3<dd(2);++i3){
    VAL_PROPRES(i1,i2,i3)=ALPHA(i1,i2,i3)/BETA(i1,i2,i3);
  }

  // ETAPE 4: CLASSIFICATION OF THE EIGENVECTORS INTO LEFT AND RIGHT GOERS
  // ATTENTION!!! for real energy procedure is not efficient because of phiVphi calculation
  Array<TinyVector<int,3>,1>  L_movers(TAILLE),R_movers(TAILLE); // store vector indexes of left and right movers
  int L_taille(0),R_taille(0); // number of left and right movers
 
  for(int i1=0;i1<dd(0);++i1)for(int i2=0;i2<dd(1);++i2)for(int i3=0;i3<dd(2);++i3){
    const double eps=1.e-6; // precision of classiffication
    COMPLEX xi=VAL_PROPRES(i1,i2,i3);
    TinyVector<int,3> i; i=i1,i2,i3;
    if ( abs(xi)>(1.+eps) )      {R_movers(R_taille)=i;++R_taille;}
    else if ( abs(xi)<(1.-eps) ) {L_movers(L_taille)=i;++L_taille;}
    else { // for abs(xi)=1 we calculate the velocity sign
      // CAREFUL THE EIGENVECTORS HAVE NOT BEEN NORMALIZED
      Nch++;
      const Array<COMPLEX,2> vp_i=VECTEURS_PROPRES(i1,i2,i3,0,ALL,ALL); // conjugate of phi part of eigen vector
      const COMPLEX phiVphi=sum( vp_i(ii,jj)*V(ii,jj,kk,ll)*conj(vp_i(kk,ll)) );
      const COMPLEX vitesse=COMPLEX(0.,1.)*( phiVphi*xi - conj(phiVphi)/xi );
      if( real(vitesse)>0) 
	{L_movers(L_taille)=i;++L_taille;} 
      else if( real(vitesse)<0)
	{R_movers(R_taille)=i;++R_taille;}
    }
  }
 
  // ETAPE 5: INITIALIZATION OF THE LEFT GOERS BASIS:
  Array<COMPLEX,3>  tmp_vec(V.extent(0),V.extent(1),TAILLE);
  Array<COMPLEX,1>  tmp_val(TAILLE);
#ifdef _DEBUG_
  if(L_taille != TAILLE )  ERROR("semi infinite leads: not full basis L_taille != TAILLE");
  if(R_taille != TAILLE )  ERROR("semi infinite leads: not full basis R_taille != TAILLE");
#endif
  tmp_vec=0;
  for(int i=0;i<TAILLE;++i) {
    const TinyVector<int,3> idx=L_movers(i); // vector index of a left mover
    tmp_val(i)=VAL_PROPRES(idx);
    tmp_vec(ALL,ALL,i)=conj(VECTEURS_PROPRES(idx(0),idx(1),idx(2),0,ALL,ALL));
  };
  GF_type PHI(tmp_vec.data(),V.shape(),neverDeleteData); // PHI(:,:,k,l) is the eigen vector for tensor index (k,l)
  Array<COMPLEX,2> PHI_vp(tmp_val.data(),TinyVector<int,2>(V.extent(0),V.extent(1)),neverDeleteData);
  
  //ETAPE 6: DUAL BASIS multiplied by xi:
  GF_type PHI_bar_H(PHI.copy());
  Inverse(PHI_bar_H); // conj(PHI_bar_H(i,j,:,:)) is the dual vector for PHI(:,:,i,j)
  GF_type xiPHI_bar_H(PHI_bar_H);
  xiPHI_bar_H = PHI_vp(ii,jj)*PHI_bar_H(ii,jj,kk,ll);

  //ETAPE 7: CONSTRUCTION OF THE MATRIX Fl (for left goers) defined as 
  // Fl(i,j) = xi(a) PHI(i,a) PHI_bar^H(a,j)
  GF_type Fl(V.shape());
  matmul_blas(PHI,xiPHI_bar_H,Fl);
  //  Fl=sum(sum(PHI_vp(mm,nn)*PHI(ii,jj,mm,nn)*PHI_bar_H(mm,nn,kk,ll),nn),mm);
   

  // ETAPE 5bis: INITIALIZATION OF THE "R I G H T" GOERS BASIS:
  Array<COMPLEX,3>  tmp_vec_R(V.extent(0),V.extent(1),TAILLE);
  Array<COMPLEX,1>  tmp_val_R(TAILLE);
#ifdef _DEBUG_
  if(L_taille != TAILLE )  ERROR("semi infinite leads: not full basis L_taille != TAILLE");
  if(R_taille != TAILLE )  ERROR("semi infinite leads: not full basis R_taille != TAILLE");
#endif
  tmp_vec_R=0;
  for(int i=0;i<TAILLE;++i) {
    const TinyVector<int,3> idx=R_movers(i); // vector index of a left mover
    tmp_val_R(i)=VAL_PROPRES(idx);
    tmp_vec_R(ALL,ALL,i)=conj(VECTEURS_PROPRES(idx(0),idx(1),idx(2),0,ALL,ALL));
  };
  GF_type PHI_R(tmp_vec_R.data(),V.shape(),neverDeleteData); // PHI(:,:,k,l) is the eigen vector for tensor index (k,l)
  Array<COMPLEX,2> PHI_vp_R(tmp_val_R.data(),TinyVector<int,2>(V.extent(0),V.extent(1)),neverDeleteData);
  
  //ETAPE 6bis: DUAL BASIS multiplied by xi FOR "R I G H T" GOERS:
  GF_type PHI_bar_H_R(PHI_R.copy());
  Inverse(PHI_bar_H_R); // conj(PHI_bar_H(i,j,:,:)) is the dual vector for PHI(:,:,i,j)
  GF_type xiPHI_bar_H_R(PHI_bar_H_R);
  xiPHI_bar_H_R = PHI_vp_R(ii,jj)*PHI_bar_H_R(ii,jj,kk,ll);

  //ETAPE 7bis: CONSTRUCTION OF THE MATRIX Fr (for right goers) defined as 
  // Fr(i,j) = xi(a) PHI_R(i,a) PHI_bar^H_R(a,j)
  GF_type Fr(V.shape());
  matmul_blas(PHI_R,xiPHI_bar_H_R,Fr);
  

  //ETAPE 8: THE SURFACE GREEN FUNCTION" defined as
  //Ginf=1/[E-Ho-V Fl- V^H Fr^-1]
  // and G = [1 - Fl Fr^-1] G inf
  GF_type oneone=scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  GF_type TMP2(E*oneone);
  matmul_blas(oneone,Ho,TMP2,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  matmul_blas(V,Fl,TMP2,COMPLEX(-1.0),COMPLEX(1.0),'n','n'); 
  Inverse(Fr);
  matmul_blas(V,Fr,TMP2,COMPLEX(-1.0),COMPLEX(1.0),'c','n');
  Inverse(TMP2);
  matmul_blas(Fl,Fr,oneone,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  
  matmul_blas(oneone,TMP2,resultat,COMPLEX(1.0),COMPLEX(0.0),'n','n');

  //matmul_blas(oneone,TMP2,resultat,COMPLEX(1.),COMPLEX(0.),'n','n');
#ifdef _DEBUG_
  if (sum(abs(imag(resultat))) < 1e-16 ) cout<<"\nWARNING GF of the lead is purely real\n";
#endif
  //cout<<Nch<<"\t"<<Nch/2<<endl;
  return Nch/2;
};


int iteration(
		 const GF_type& Ho,
		 COMPLEX E,
		 GF_type& s_LL,
		 GF_type& s_LR,
		 GF_type& s_RL,
		 GF_type& s_RR,
		 GF_type& T_LR,
		 GF_type& T_RL,
		 GF_type& X){

  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)
      for(int i3=0;i3<Ho.extent(0);++i3)
	for(int i4=0;i4<Ho.extent(1);++i4) X(i1,i2,i3,i4)=-Ho(i1,i2,i3,i4)-s_LL(i1,i2,i3,i4)-s_RR(i1,i2,i3,i4);
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2) X(i1,i2,i1,i2)+=E;

  Inverse(X);
  matmul_blas(X,s_LR,T_LR,COMPLEX(1.0),COMPLEX(0.0),'n','n');
  matmul_blas(X,s_RL,T_RL,COMPLEX(1.0),COMPLEX(0.0),'n','n');
  matmul_blas(s_LR,T_RL,s_LL,COMPLEX(1.0),COMPLEX(1.0),'n','n');
  matmul_blas(s_RL,T_LR,s_RR,COMPLEX(1.0),COMPLEX(1.0),'n','n');
  matmul_blas(s_RL,T_RL,X,COMPLEX(1.0),COMPLEX(0.0),'n','n');
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)
      for(int i3=0;i3<Ho.extent(0);++i3)
	for(int i4=0;i4<Ho.extent(1);++i4) s_RL(i1,i2,i3,i4)=X(i1,i2,i3,i4);

  matmul_blas(s_LR,T_LR,X,COMPLEX(1.0),COMPLEX(0.0),'n','n');
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)
      for(int i3=0;i3<Ho.extent(0);++i3)
	for(int i4=0;i4<Ho.extent(1);++i4) s_LR(i1,i2,i3,i4)=X(i1,i2,i3,i4);
}


int get_G_from_S(
		 const GF_type& Ho,
		 COMPLEX E,
		 GF_type& s_LL,
		 GF_type& G_LL){

  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)
      for(int i3=0;i3<Ho.extent(0);++i3)
	for(int i4=0;i4<Ho.extent(1);++i4) G_LL(i1,i2,i3,i4)=-Ho(i1,i2,i3,i4)-s_LL(i1,i2,i3,i4);
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)G_LL(i1,i2,i1,i2)+=E;
  Inverse(G_LL);
  
}

int get_S_from_G(
		 const GF_type& V,
		 GF_type& s_LL,
		 GF_type& G_LL,
		 GF_type X){
  matmul_blas(G_LL,V,X,COMPLEX(1.0),COMPLEX(0.0),'n','c');
  matmul_blas(V,X,s_LL,COMPLEX(1.0),COMPLEX(0.0),'n','n');
}

 double get_error(GF_type& s_LL,GF_type& s_LR){

   double maxLL(0),maxLR(0);
   for(int i1=0;i1<s_LL.extent(0);++i1)
     for(int i2=0;i2<s_LL.extent(1);++i2)
       for(int i3=0;i3<s_LL.extent(0);++i3)
	 for(int i4=0;i4<s_LL.extent(1);++i4){
	   if (abs(s_LL(i1,i2,i3,i4))>maxLL) maxLL=abs(s_LL(i1,i2,i3,i4));
	   if (abs(s_LR(i1,i2,i3,i4))>maxLR) maxLR=abs(s_LR(i1,i2,i3,i4));
	 }
   //cout<<"MAX VALUES  = "<<maxLR<<" -/- "<<maxLL<<endl;
   return maxLR/maxLL;
  
}


int semi_infini_newbis(const GF_type& V,const GF_type& Ho,COMPLEX E,GF_type& resultat){

  int NN=100;
  double myerror;
  if (imag(E)<1.e-11) E+=COMPLEX(0,1.e-11);
  GF_type s_LL(Ho.shape());
  GF_type s_LR(Ho.shape());
  GF_type s_RL(Ho.shape());
  GF_type s_RR(Ho.shape());
  GF_type T_LR(Ho.shape());
  GF_type T_RL(Ho.shape());
  GF_type X(Ho.shape());
  
  // initialization:
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2)
      for(int i3=0;i3<Ho.extent(0);++i3)
	for(int i4=0;i4<Ho.extent(1);++i4) X(i1,i2,i3,i4)=-Ho(i1,i2,i3,i4);
  for(int i1=0;i1<Ho.extent(0);++i1)
    for(int i2=0;i2<Ho.extent(1);++i2) X(i1,i2,i1,i2)+=E;

  Inverse(X);
  
  matmul_blas(X,V,T_RL,COMPLEX(1.0),COMPLEX(0.0),'n','n');
  matmul_blas(V,T_RL,s_RR,COMPLEX(1.0),COMPLEX(0.0),'c','n');
  matmul_blas(V,T_RL,s_LR,COMPLEX(1.0),COMPLEX(0.0),'n','n');

  matmul_blas(X,V,T_RL,COMPLEX(1.0),COMPLEX(0.0),'n','c');
  matmul_blas(V,T_RL,s_RL,COMPLEX(1.0),COMPLEX(0.0),'c','n');
  matmul_blas(V,T_RL,s_LL,COMPLEX(1.0),COMPLEX(0.0),'n','n');

  GF_type G_LL(Ho.shape());

  for(int n=0;n<NN;++n) {
    iteration(Ho,E,s_LL,s_LR,s_RL,s_RR,T_LR,T_RL,X);
    myerror=get_error(s_LL,s_LR);
    if (myerror<1.e-10) break;
  }
  get_G_from_S(Ho,E,s_LL,resultat);

 
  return -NN;
}








// February 18th 2011: Yet a newer version of semi_infini(...) which should work when V
// is not inversible: we look for eigenvalues of the problem A x = lambda B x with
///           [ (E-Ho)   -Vd   ]          [ V      0 ]
///      A  = [                ]  and B=  [          ]
///           [   1       0    ]          [ 0      1 ]
///  VERY BAD !

int semi_infini_newter(const GF_type& V,const GF_type& Ho,COMPLEX E,GF_type& resultat){
  
  int Nch=0;
  const int TAILLE=V.extent(0)*V.extent(1); // tensor size
  firstIndex ii;
  secondIndex jj;
  thirdIndex kk;
  fourthIndex ll;
  fifthIndex mm;
  sixthIndex nn;
 
  cout<<"#########################################"<<endl;
  cout<<" ENTERING SEMI_INFINI_NEWBIS ROUTINE   "<<endl;
  cout<<"#########################################"<<endl;

  // ETAPE 1: CALCULATION OF THE EFFECTIVE MATRIX BB
  TinyVector<int,6> dd; // dd is shape vector of six indexes HH Array
  dd(0)=dd(3)=2; // extra index (phi, theta) of 2x2 matrix structure given above
  dd(1)=dd(4)=V.extent(0); // site index
  dd(2)=dd(5)=V.extent(1); // inner degree of freedom



  Array<COMPLEX,6> BB(dd);
  // BB(1,0) = 0
  BB(1,ALL,ALL,0,ALL,ALL)= 0.;
  // BB(0,1) = 0
  BB(0,ALL,ALL,1,ALL,ALL)= 0.;
  // BB(1,1) = 1.
  BB(1,ALL,ALL,1,ALL,ALL)= scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  // BB(0,0) = V
  BB(0,ALL,ALL,0,ALL,ALL)= V.copy();

  // ETAPE 2: CALCULATION OF THE EFFECTIVE MATRIX 
  ///           [ (E-Ho)   - Vd   ]
  ///      HH = [                      ]
  ///           [   1           0      ]
  /// WHERE Vd (V dagger) IS THE HERMITIAN CONJUGATE OF V
 
  Array<COMPLEX,6> HH(dd);
  // HH(0,0) = Vm*E - Vm*Ho
  GF_type Vm=scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  GF_type TMP(E*Vm);
  matmul_blas(Vm,Ho,TMP,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  HH(0,ALL,ALL,0,ALL,ALL)=TMP;
  // HH(0,1) = -Vm*Vd
  matmul_blas(Vm,V,TMP,COMPLEX(-1.0),COMPLEX(0.0),'n','c');/////'n'  'c'
  HH(0,ALL,ALL,1,ALL,ALL)=TMP;
  // HH(1,0) = 1
  HH(1,ALL,ALL,0,ALL,ALL)= scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  // HH(1,1) = 0
  HH(1,ALL,ALL,1,ALL,ALL)= 0.;
  

// ETAPE 3: DIAGONALIZATION OF THE EFFECTIVE MATRIX HH x = lambda BB x
  Array<COMPLEX,3> VAL_PROPRES(dd(0),dd(1),dd(2));
  Array<COMPLEX,3> ALPHA(dd(0),dd(1),dd(2)),BETA(dd(0),dd(1),dd(2));
  Array<COMPLEX,6> VECTEURS_PROPRES(dd);
  Diagonalization_VeryGeneral(HH,BB,ALPHA,BETA,VECTEURS_PROPRES);
  
  //cout<<"BEGIN EIGEN VALUES   "<<endl;
  //for(int i1=0;i1<dd(0);++i1)for(int i2=0;i2<dd(1);++i2)for(int i3=0;i3<dd(2);++i3){
  //cout<<ALPHA(i1,i2,i3)<<"     "<<BETA(i1,i2,i3)<<endl;;
  //}  
  //cout<<"END...  "<<endl;
  
  // ETAPE 4: CLASSIFICATION OF THE EIGENVECTORS INTO LEFT AND RIGHT GOERS
  // ATTENTION!!! for real energy procedure is not efficient because of phiVphi calculation
  Array<TinyVector<int,3>,1>  L_movers(TAILLE),R_movers(TAILLE); // store vector indexes of left and right movers
  int L_taille(0),R_taille(0); // number of left and right movers
 
  int Q_taille(0);
  Array<TinyVector<int,3>,1>  Q_movers(TAILLE);

  for(int i1=0;i1<dd(0);++i1)for(int i2=0;i2<dd(1);++i2)for(int i3=0;i3<dd(2);++i3){
    const double eps=1.e-6; // precision of classiffication
    COMPLEX xi;
    COMPLEX be=BETA(i1,i2,i3);
    COMPLEX al=ALPHA(i1,i2,i3);
    TinyVector<int,3> i; i=i1,i2,i3;
    if ( abs(be)<eps)  {continue;}; 
    if ( abs(al)<eps) {Q_movers(Q_taille)=i;++Q_taille;continue;}; 
    
    xi=al/be;
    VAL_PROPRES(i1,i2,i3)=xi;
    //cout<<"EIGENVALUE : "<<abs(xi)<<"      "<<xi<<endl;
    if ( abs(xi)>(1.+eps) )      {R_movers(R_taille)=i;++R_taille;}
    else if ( abs(xi)<(1.-eps) ) {L_movers(L_taille)=i;++L_taille;}
    else { // for abs(xi)=1 we calculate the velocity sign
      // CAREFUL THE EIGENVECTORS HAVE NOT BEEN NORMALIZED
      const Array<COMPLEX,2> vp_i=VECTEURS_PROPRES(i1,i2,i3,0,ALL,ALL); // conjugate of phi part of eigen vector
      const COMPLEX phiVphi=sum( vp_i(ii,jj)*V(ii,jj,kk,ll)*conj(vp_i(kk,ll)) );
      const COMPLEX vitesse=COMPLEX(0.,1.)*( phiVphi*xi - conj(phiVphi)/xi );
      if( real(vitesse)>0) 
	{L_movers(L_taille)=i;++L_taille;Nch++;} 
      else if( real(vitesse)<0)
	{R_movers(R_taille)=i;++R_taille;}
      //cout<<" V "<<vitesse<<" xi "<<xi<<" Nch "<<Nch<<endl;
    }
    

  }
 
  cout<<"L taille  "<<L_taille<<endl;
  cout<<"R taille  "<<R_taille<<endl;
 cout<<"Q taille  "<<Q_taille<<endl;

  cout<<"Taille  "<<TAILLE<<endl;


 // ETAPE 5: INITIALIZATION OF THE LEFT GOERS BASIS:
  Array<COMPLEX,3>  tmp_vec(V.extent(0),V.extent(1),TAILLE);
  Array<COMPLEX,1>  tmp_val(TAILLE);

 tmp_vec=0;
  for(int i=0;i<L_taille;++i) {
    const TinyVector<int,3> idx=L_movers(i); // vector index of a left mover
    tmp_val(i)=VAL_PROPRES(idx);
    tmp_vec(ALL,ALL,i)=conj(VECTEURS_PROPRES(idx(0),idx(1),idx(2),0,ALL,ALL));
  };
  for(int i=0;i<Q_taille;++i) {
    const TinyVector<int,3> idx=Q_movers(i); // vector index of a left mover
    tmp_val(L_taille+i)=0;
    tmp_vec(ALL,ALL,L_taille+i)=conj(VECTEURS_PROPRES(idx(0),idx(1),idx(2),1,ALL,ALL));
  };


  GF_type PHI(tmp_vec.data(),V.shape(),neverDeleteData); // PHI(:,:,k,l) is the eigen vector for tensor index (k,l)
  Array<COMPLEX,2> PHI_vp(tmp_val.data(),TinyVector<int,2>(V.extent(0),V.extent(1)),neverDeleteData);
  
  //ETAPE 6: DUAL BASIS multiplied by xi:
  GF_type PHI_bar_H(PHI.copy());
  Inverse(PHI_bar_H); // conj(PHI_bar_H(i,j,:,:)) is the dual vector for PHI(:,:,i,j)
  GF_type xiPHI_bar_H(V.shape());
   for(int i1=0;i1<V.extent(0);++i1)for(int i2=0;i2<V.extent(1);++i2)
      for(int i3=0;i3<V.extent(0);++i3)for(int i4=0;i4<V.extent(1);++i4){
	xiPHI_bar_H(i1,i2,i3,i4)=PHI_vp(i1,i2)*PHI_bar_H(i1,i2,i3,i4);
      }



  //ETAPE 7: CONSTRUCTION OF THE MATRIX Fl (for left goers) defined as 
  // Fl(i,j) = xi(a) PHI(i,a) PHI_bar^H(a,j)
  GF_type Fl(V.shape());
  matmul_blas(PHI,xiPHI_bar_H,Fl,COMPLEX(1.0),COMPLEX(0.0),'n','n');
 

  //ETAPE 8: THE SURFACE GREEN FUNCTION" defined as
 
  GF_type oneone=scalar_matrix(dd(1),dd(2),COMPLEX(1.));
  GF_type TMP2(E*oneone);
  GF_type TMP3(V.shape());
cout<<"UP THERE4"<<endl;

// TMP2= (E-Ho) 
  matmul_blas(oneone,Ho,TMP2,COMPLEX(-1.0),COMPLEX(1.0),'n','n');
  

  // TMP2 = (E-Ho)  - V Fl
  matmul_blas(V,Fl,TMP2,COMPLEX(-1.0),COMPLEX(1.0),'n','n'); 


 

  Inverse(TMP2);

 
 cout<<"UP THERE5"<<endl;
  matmul_blas(oneone,TMP2,resultat,COMPLEX(1.0),COMPLEX(0.0),'n','n');

#ifdef _DEBUG_
  if (sum(abs(imag(resultat))) < 1e-16 ) cout<<"\nWARNING GF of the lead is purely real\n";
#endif
  //cout<<Nch<<"\t"<<Nch/2<<endl;
  return Nch;
};





































void analytic_semi_infini(double hopp,COMPLEX Hdiag,COMPLEX E,int M, GF_type& resultat) {
  double const pi=3.14159265358979323;
  COMPLEX const cI=COMPLEX(0.,1.);
  resultat=0.;
  for(int i=0;i<M;i++) for(int j=0;j<M;j++)
    for(int l=1;l<=M;l++) {                            // sum over all channels
      const COMPLEX  El=2.*hopp*cos(pi*l/(M+1.));      // energy of discrete spectrum
      const COMPLEX kl=acos((E-El-Hdiag)/2./hopp);     //we could omit this difinition of kl replacing exp(cI*kl) in the next line
      resultat(i,0,j,0)+=2./(M+1.)/hopp*sin(pi*l*(i+1.)/(M+1.))*sin(pi*l*(j+1.)/(M+1.))*exp(cI*kl);
    };
#ifdef _DEBUG_
  if (sum(abs(imag(resultat))) < 1e-16 ) cout<<"\nWARNING GF of the lead is purely real\n";
#endif
  return;
};

/// TEST OF THE ROUTINE
/// COMPILATION SUR MOUSSAILLON: 
/// g++ -D_DEBUG_ -D_TESTING_ -O2 -L /usr/local/stow/Blitz_g++/lib/ -I . -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz kernel/knit_semi_infini.C
#ifdef _TESTING_

int rank=0;
int size=1;

//void ERROR(char* message){cout<<"*** SORTIE GENEREE PAR ROUTINE ERROR ***"<<endl<<message<<endl; exit(1);};

int main(){
  int taille_sys=150;
  const COMPLEX hopp=-COMPLEX(2.,0.);
  GF_type V=scalar_matrix(taille_sys,1,hopp );
  cout<<"INTER SLICE HOPPING V"<<endl;
  //MFprint(V);
  
  const COMPLEX  UN=hopp;
  const COMPLEX ZER=COMPLEX(0.);
  Array<COMPLEX,2> tmp(taille_sys,taille_sys);
  tmp=ZER;
//   tmp= ZER,UN ,ZER,
//        UN ,ZER,UN ,
//        ZER,UN ,ZER; 
//   tmp = ZER,UN ,ZER,ZER,ZER,ZER,
//         UN ,ZER,UN ,ZER,ZER,ZER,
//         ZER,UN ,ZER,UN ,ZER,ZER,
//         ZER,ZER,UN ,ZER,UN ,ZER,
//         ZER,ZER,ZER,UN ,ZER,UN,
//         ZER,ZER,ZER,ZER,UN ,ZER;
  for (int i=0; i<taille_sys-1;++i) {tmp(i,i+1)=hopp;tmp(i+1,i)=hopp;};

  GF_type Ho(tmp.data(),V.shape(),neverDeleteData);
  cout<<"INTRA SLICE HAMILTONIAN"<<endl;
  //  MFprint(Ho); 

  const COMPLEX E=COMPLEX(3.,0.1);
  cout<<"NUMERICAL SURFACE GREEN FUNCTION"<<endl;
  GF_type result_n(V.shape());
  clock_t t_in=clock();
  semi_infini(V,Ho,E,result_n);
  clock_t t_out=clock();
  float ex_time_n=float(t_out-t_in)/CLOCKS_PER_SEC; // multiplication time in seconds
  //MFprint(resultat);

  cout<<"ANALYTICAL SURFACE GREEN FUNCTION"<<endl;
  GF_type result_a(V.shape());
  t_in=clock();
  if (hopp.imag()!=0.) cout<<"Analytical GF could be calculated only for real hopping matrix element im(V)=0\n";
  analytic_semi_infini(hopp.real(),COMPLEX(0.),E,taille_sys,result_a);
  t_out=clock();

  float ex_time_a=float(t_out-t_in)/CLOCKS_PER_SEC; // multiplication time in seconds
  //MFprint(resultat);
  cout<<"Analytic versus Numeric TEST=>\n"<<
    ((all(abs(result_a-result_n)<0.00001))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision test function)!!!")<<endl;
  cout<<"Execution time numeric="<<ex_time_n<<" sec"<<endl;
  cout<<"Execution time analytic="<<ex_time_a<<" sec"<<endl;
  return 0;
}

#endif //_TESTING_SEMI_INFINI
