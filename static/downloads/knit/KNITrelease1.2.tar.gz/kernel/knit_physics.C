// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################



#include "knit_physics.h"
#include "knit_Python_Data.h"

/** This mode permits to obtain physical variables density and transmision of rectangular sample
// it's also used by python script modules DATA/Prec.py that calculates error between knit and direct inversion algorithm for density 
c++ -c -O2  knit_micromatrices.C
c++ -c -O2  knit_acos.C
g++ -c -O2  -I /usr/local/stow/Blitz_g++/include/  knit_system.C	
g++ -c -O2  -I /usr/local/stow/Blitz_g++/include/ -lblitz knit_algorithm.C
g++ -c -O2 -D_TESTING_ -D_DEBUG_ -I /usr/local/stow/Blitz_g++/include/ -lblitz knit_physics.C
g++ -o test.out -O2 -D_TESTING_ -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz knit_system.o knit_micromatrices.o knit_acos.o knit_algorithm.o knit_physics.o
 **/

#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  // construction of the systemerectangle
  clock_t t_in=clock();

  // Reading inputs *********************************************
  PythonData::Python_Data input(argv[1]);

  int M=input.I("M");// channel number
  int N=input.I("N");// sample size

  double En=input.D("En"); // working energy
  double flux=input.D("flux"); //0.287639243209;
  // with or without Direct Inversion
  bool with_DI=input.I("with_DI");
  // is this a python script 
  bool is_Pythonscript=input.I("is_Pythonscript");
  bool is_QPC=input.I("is_QPC");
  bool is_NotRectangle=input.I("is_NotRectangle");
  bool is_Bfield=input.I("is_Bfield");
  bool get_Transmission=input.I("get_Transmission");
  if (!is_Bfield) flux=0.;
  //INPUT OPTIONS
  if (argc == 1) {
    cout<<"\nUSAGE:\n ./test.out xsize ysize Energy is_Pythonscript is_QPC is_notRectangle flux\n for example \n ./test.out 10 30 0.01 \n Will execute 10x30 system for energy 0.01 and it's not a python scripting\n";
    return 1;
  };
  //for python script DI is compulsory
  if (is_Pythonscript) with_DI=true;
  //END of Input
  const COMPLEX cEn=En;//+COMPLEX(0.,0.0000000000000001); // complex Energy
  Array<int,1> LxLyLz(2),OxOyOz(2);
  // we use the same language as in GFDI
  // Hdiag should not be zero as QPC will multiply this value by some factor
  scalarM V_sample,V_LL,V_RL,Hdiag, Hdiag_LL, Hdiag_RL;
  V_sample(0,0)=input.D("V_sample");
  V_LL(0,0)=input.D("V_LL");
  V_RL(0,0)=input.D("V_RL");
  Hdiag(0,0)=input.D("Hdiag");
  Hdiag_LL(0,0)=input.D("Hdiag_LL");
  Hdiag_RL(0,0)=input.D("Hdiag_LL");

  if (!is_Pythonscript){
    cout<<"SYSTEM MxN="<<M<<"x"<<N<<endl;
    cout<<"Energy ="<<cEn<<endl;
    if (is_NotRectangle) cout<<"Not rectangular system"<<endl;
    else cout<<"Rectangular system ";
    if (is_QPC) cout<<"with QPC"<<endl;
    else cout<<", no QPC"<<endl;
    if (is_Bfield) cout<<"with Bfield, flux="<<flux<<endl;
    else cout<<", no B field"<<endl;
  };

  double V=min(abs(V_LL(0,0)),abs(V_RL(0,0)));
  // main system
  LxLyLz=M,N;
  OxOyOz=0,0;
  //cout<<"system is created using costructor from size LxLyLz, initial position OxOyOz, hopping V and onsite energy Hdiag\n";
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V_sample,Hdiag);
  // supplementary part Left
  LxLyLz=N/5,N/5;
  OxOyOz=M-1,N/6;
  systemerectangle<scalarM> sysPartL(LxLyLz,OxOyOz,V_sample,Hdiag);
  if (is_NotRectangle) sys.coller(sysPartL);

  // supplementary part Right
  LxLyLz=N/5,N/5;
  OxOyOz=M-1,N-N/5-N/6;
  systemerectangle<scalarM> sysPartR(LxLyLz,OxOyOz,V_sample,Hdiag);
  if (is_NotRectangle) sys.coller(sysPartR);


  // Adding QPC potential
  if (is_QPC) {
    Array<int,1> QPC_in_coord(2); // coordinates for QPC
    QPC_in_coord=input.I("QPC_x"),input.I("QPC_y"); // in the middle of the sample
    QPC QPCpotential(QPC_in_coord, 6.*abs(V_sample(0,0)),input.I("QPCchannel"),4);
    sys.changeH(QPCpotential); // change profile for the system
  };

  // supplementary part Bridge
  LxLyLz=N/12,N-2*(N/5+N/6)+10;
  OxOyOz=M-1+N/10,N/5+N/6-2;
  systemerectangle<scalarM> sysPartB(LxLyLz,OxOyOz,V_sample,Hdiag);
  if (is_NotRectangle) sys.coller(sysPartB);

  // adding magnetic field
  if (is_Bfield)  sys.applyB(flux);

  // first lead
  LxLyLz=M,1;
  OxOyOz=0,0;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> lead(lead_interface,V_LL,flux); // create lead from its interface
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=M,1;
  OxOyOz=0,N-1;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> lead2(lead_interface2,V_RL,-flux); // create lead from its interface
  if (get_Transmission)  sys_lead.addlead(lead2);
  // cout<<"SYSTEM+LEAD1+LEAD2 PRINTING"<<endl<<sys_lead<<endl;


//   // third lead
//  LxLyLz=1,1;
//  OxOyOz=0,(N+2)/5;
//  s_systemrectangle lead_interface3(LxLyLz,OxOyOz,V_sample,1.5*Hdiag); // lead's interface
//  N_reservoir<scalarM> lead3(lead_interface3,0.5*V_sample); // create lead from its interface
//  sys_lead.addlead(lead3);

  // lead for supplementary part left
  LxLyLz=1,N/5;
  OxOyOz=M-2+N/5,N/6;
  s_systemrectangle lead_interfaceL(LxLyLz,OxOyOz,V_LL,Hdiag_LL); // lead's interface
  N_reservoir<scalarM> leadL(lead_interfaceL,V_LL); // create lead from its interface
  if (is_NotRectangle) sys_lead.addlead(leadL);

  // lead for supplementary part right
  LxLyLz=1,N/5;
  OxOyOz=M-2+N/5,N-N/5-N/6;
  s_systemrectangle lead_interfaceR(LxLyLz,OxOyOz,V_RL,Hdiag_RL); // lead's interface
  N_reservoir<scalarM> leadR(lead_interfaceR,V_RL); // create lead from its interface
  if (is_NotRectangle) sys_lead.addlead(leadR);

  cout.precision(15);cout<<scientific;

 
  ////////////////////////////////////////////
  knit<scalarM> work(0,sys_lead, cEn); 
  work.forward(ToEnd);
  sew<scalarM> S(work);
  S.sew2end();
  // with or without Direct Inversion
  // if with DI then we calculate errors of density
  direct<scalarM> dGF(sys_lead.fsize()<5000?sys_lead : systeme_infini<scalarM>() ); 
  if (with_DI)  dGF.calculate4E(cEn);
  const GF_type GnotK( S.getGnotK() );
  double max_err=0.; // maximal error for all array element
  double mean_err=0.; // meaning error for array
  const double PI=3.14159265358;

 
  // DENSITY CALCULATIONS
  // output file
  stringstream fileName;
  fileName<<"./DATA/density";
  if (is_QPC) fileName<<"QPC";
  fileName<<M<<"x"<<N;
  if (is_NotRectangle) fileName<<"NR";
  // file title that is put in first two lines
  stringstream fileTitle;
  fileTitle<<"# M="<<M<<"  N="<<N<<"   Energy="<<cEn<<"  is_QPC ="<<is_QPC<<"  Not Rectangle="<<is_NotRectangle<<
    "  V_sample="<<V_sample(0,0)<<"  V_LL="<<V_LL(0,0)<<"  V_RL="<<V_RL(0,0)<<"  Hdiag="<<Hdiag(0,0)<<"  Hdiag_LL="<<Hdiag_LL(0,0)<<"  Hdiag_RL="<<Hdiag_RL(0,0);
  if (is_Bfield) fileTitle<<"  flux="<<flux<<endl;
  fileTitle<<"# x_coor  y_coord  density"<<endl;
  // density by knit technique
  ofstream toDensity( (fileName.str()+".dat").c_str() );
  toDensity<<fileTitle.str();
  for (int i=0;i<sys_lead.fsize();++i){
    const int x_pos=sys_lead.coord(i,0);
    const int y_pos=sys_lead.coord(i,1);
    const double val_den=-GnotK(i,0,sys_lead.fzmax(),0).imag()/PI;
    toDensity<<x_pos<<"\t"<<y_pos<<"\t"<<val_den<<endl;
  };
  // with direct inversion, calculate density by DI and errors
  if (with_DI) {
    ofstream toDensity_DI( (fileName.str()+"_DI.dat").c_str() );
    ofstream toDiff( (fileName.str()+"_DIerr.dat").c_str() );
    toDensity_DI<<fileTitle.str();
    toDiff<<fileTitle.str();
    //full density and error calculations
    max_err=0.;mean_err=0.;
    for (int i=0;i<sys_lead.fsize();++i){
      const int x_pos=sys_lead.coord(i,0);
      const int y_pos=sys_lead.coord(i,1);
      const double val_den=-GnotK(i,0,sys_lead.fzmax(),0).imag()/PI;
      const double val_denDI=-dGF.G(i,i)(0,0).imag()/PI;
      const double val_diff=val_denDI-val_den;
      toDensity_DI<<x_pos<<"\t"<<y_pos<<"\t"<<val_denDI<<endl;
      toDiff<<x_pos<<"\t"<<y_pos<<"\t"<<val_diff<<endl;
      max_err=max(max_err,abs(val_diff));
      mean_err+=abs(val_diff/(val_denDI+val_den));
    };
    mean_err/=sys_lead.fsize();
    cout<<"Mean Relative Error="<<mean_err<<endl;
    cout<<"Max Abs Error="<<max_err<<endl;
  };

#ifdef _ZHOPA_
  // just backward test
  // we start from zero advance to the middle then save GF, then knit to the end and back and compare GFs
  // repeated iterations point 
  int iteration_point=0;
  const int middle_point=sys_lead.fsize()-4*M; 
  if (argc == 6) iteration_point=middle_point+atoi(argv[5]);
  knit<scalarM> work(0,sys_lead,En);
  double max_GF_el=0.;
  double min_GF_el=1.e10;
  while (work.fpos().ffin()< middle_point) 
    {work.forward(la_fin); max_GF_el=max(max_GF_el,max(abs(work.G())));  min_GF_el=min(min_GF_el,min(abs(work.G())));} //advance to the middle
  GF_type Gsave=work.G().copy(); //save GF
  work.forward(ToEnd); 
  cout<<"Middle Point="<<middle_point<<endl;
  cout<<"(x_in, y_ind) for Middle Point="<<middle_point%M<<", "<<middle_point/M<<endl;
  const int iteration_number=M;
  cout<<"Iteration Point="<<iteration_point<<endl;
  cout<<"(x_in, y_ind) for Iteration Point="<<iteration_point%M<<", "<<iteration_point/M<<endl;
  while (work.fpos().ffin() != middle_point) { //come back to the middle
    if ( work.fpos().ffin() == iteration_point ){
      for (int i=0;i<iteration_number;++i) work.backward(la_fin);
      for (int i=0;i<iteration_number;++i) work.forward(la_fin); 
    }
    work.backward(la_fin); 
    max_GF_el=max( max_GF_el,max(abs(work.G())) ); 
    min_GF_el=min(min_GF_el,min(abs(work.G())));}
#ifdef _DEBUG_
  if (work.fpos().ffin() != iteration_point & work.fpos().fdebut() != 0) ERROR("knit_bfTest: we compare not the same positions");
#endif
  const double back_err=sum( abs( (Gsave-work.G())/(Gsave+work.G()) ) );
  // cout<<"max GF element="<<max_GF_el<<endl;//TTT
  // cout<<"min GF element="<<min_GF_el<<endl;//TTT
  cout<<"max abs error="<<back_err<<endl;//TTT
  if (! is_equal(work.G(),Gsave ) ){
    cout<<"Back&forth TEST for KNIT failed for half system backward\n";
  };

  //output for python
  toTmp4Py<<iteration_point<<'\t'<<back_err<<endl;

#endif // _ZHOPA_

  //cout<<"max_GF_size="<<max_GF_size(sys_lead)<<endl;
  clock_t t_out=clock();
  ofstream toTime("./DATA/execTime.dat");
  toTime<<"sytem size "<<M<<"x"<<N<<"="<<sys_lead.fsize()<<endl;
  //  toTime<<"energy points = "<<ep<<endl;
  toTime<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<" sec"<<endl;
#ifdef _ZHOPA_
#endif //_ZHOPA_
  return 0;
};

#endif
