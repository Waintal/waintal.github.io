// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


// file to be included to knit_knit.h

// ********************************* GLOBAL FUNCTIONS ********************************//



// forward - backward test for knit variable for given infinite system:
  // we create knit variable then make back and forth knit, then we knit forward to get the whole system and then once again back and forth from both ends, and finally we knit backward to initial position. At each step we compare that back and forth operation does not change the knit ie GFs 
  // all this is made for three different starting points: debut(O), fin(size-1), lead(last last-lead site)
template<class Tmicromatrix>
bool knit_bfTEST(const systeme_infini<Tmicromatrix>& S, COMPLEX En){
  const int sys_size=S.fsize();
  int starting_point;
  bool result=true;
  cout<<"For this starting points:\n";
  for (int i=1;i<=1;++i) {//TTTT // three different starting points
    switch (i){
    case 1:
      starting_point=0;
      break;
    case 2:
      starting_point=sys_size-1;
      break;
    case 3:
      const int li=S.fNres()-1; // last lead index
      starting_point=S.res2sys(li, S.lead_size(li)-1 ); // last site of this lead
      break;
    default:
      return false;
    }; 
    cout<<"site "<<starting_point<<endl;
    knit<Tmicromatrix> work(starting_point,S,En);
    knit<Tmicromatrix> work_start(work);
    //forward-backward from tail only if it's not the last site 
    if (starting_point < sys_size-1 ) {work.forward(la_fin);  work.backward(la_fin);}
    if ( !(work == work_start) ) {cout<<"failed here"<<endl;result=false;}
    //forward-backward from head only if it's not the first site 
    if (starting_point > 0) {work.forward(le_debut);work.backward(le_debut);}
    if ( !(work == work_start) ) {cout<<"failed here"<<endl;result=false;}
    // knit forward to get entire lace
    work.forward(ToZero); work.forward(ToEnd); 
    knit<Tmicromatrix> copy_work(work);
    //backward-forward from tail test; only this test would work as last advance operation was made ToEnd
    if ( sys_size>=3 && starting_point != sys_size-1) {work.backward(la_fin); work.forward(la_fin);}
    if ( !(copy_work == work) ) {cout<<"failed here"<<endl;result=false;}
    //knit_back to starting point
    work.backward(FromEnd);  work.backward(FromZero);
    if ( !(work_start == work) ) {cout<<"failed here"<<endl;result=false;}
  };
  // we start from zero advance to the middle then save GF, then knit to the end and back and compare GFs
  knit<Tmicromatrix> work(0,S,En);
  for (int i=0;i<S.fsize()/2; ++i ) work.forward(la_fin); //advance to the middle
  const int temp_fin=work.fpos().ffin(); // point used to come back
  GF_type Gsave=work.G().copy(); //save GF
  work.forward(ToEnd); 
  while (work.fpos().ffin() != temp_fin) work.backward(la_fin); //come back to the middle
#ifdef _DEBUG_
  if (work.fpos().ffin() != temp_fin & work.fpos().fdebut() != 0) ERROR("knit_bfTest: we compare not the same positions");
#endif
  if (! is_equal(work.G(),Gsave ) ){
    cout<<"Back&forth TEST for KNIT failed for half system backward\n";
  };
  if (result) cout<<"Back&forth TEST for KNIT is passed with sucess\n";
  else  cout<<"Back&forth TEST for KNIT failed !!!\n";
  return result;
};



// ********************TEMPLATE FUNCTIONS******************* //
// ********************************************************* //


// ************************** TEMP4KNIT member functions *************************** //

// copy constructor for temporal variable, temporal arrays are copied using reference sematic
template<class Tmicromatrix> temp4knit<Tmicromatrix>::temp4knit(const temp4knit<Tmicromatrix>& T):
  max_taille(T.max_taille),  G_NN(T.G_NN), G_Na(T.G_Na), G_aN(T.G_aN), VgV(T.VgV)
{};


// assignement operator for temporal variables
template<class Tmicromatrix> temp4knit<Tmicromatrix>& temp4knit<Tmicromatrix>::operator=(const temp4knit<Tmicromatrix>& T){
  max_taille=T.max_taille;
  //temporal variables are reinitialized in the assignement operation (improve operation speed)
  G_NN.resize(T.G_NN.shape());
  G_Na.resize(T.G_Na.shape());
  G_aN.resize(T.G_aN.shape());
  VgV.resize(T.VgV.shape());
  return *this;
};


// constructor of temporal variables for knit from given system
template<class Tmicromatrix> temp4knit<Tmicromatrix>::temp4knit(const sys_inf& sys, int init_site=0):
     max_taille(  max( max_GF_size(sys,init_site), max_GF_size(sys,sys.fsize()-1) )  ),
     G_NN(Tmicromatrix::dim(), Tmicromatrix::dim()),
     VgV(Tmicromatrix::dim(), Tmicromatrix::dim()),
     G_aN(max_taille, Tmicromatrix::dim(), 1, Tmicromatrix::dim()), 
     G_Na(1, Tmicromatrix::dim(), max_taille, Tmicromatrix::dim())
{};


// ************************* SAVED4KNIT member functions *************************** //

// copy constructor for saved variables, array are really copied, while maps of constants are passed by reference 
template<class Tmicromatrix> saved4knit<Tmicromatrix>::saved4knit(const saved4knit<Tmicromatrix>& S):
  mapG_NN(S.mapG_NN), mapG_aN(S.mapG_aN), mapG_Na(S.mapG_Na), map_g_ra(S.map_g_ra), map_g_ar(S.map_g_ar), mapGF(S.mapGF)
{GF.resize(S.GF.shape()); for (int li=GF.lbound(firstDim); li<=GF.ubound(firstDim); ++li) GF(li)<=S.GF(li);
 SE.resize(S.SE.shape()); for (int li=SE.lbound(firstDim); li<=SE.ubound(firstDim); ++li) SE(li)<=S.SE(li);
 g_rr.resize(S.g_rr.shape()); for (int li=g_rr.lbound(firstDim); li<=g_rr.ubound(firstDim); ++li) g_rr(li)<=S.g_rr(li);
 G_NN.resize(S.G_NN.shape()); for (int li=G_NN.lbound(firstDim); li<=G_NN.ubound(firstDim); ++li) G_NN(li)<=S.G_NN(li);
 GFLL.resize(S.GFLL.shape()); 
 for (int li=GFLL.lbound(firstDim); li<=GFLL.ubound(firstDim); ++li) 
   for (int lj=GFLL.lbound(secondDim); lj<=GFLL.ubound(secondDim); ++lj) GFLL(li,lj)<=S.GFLL(li,lj);
};


// assignement operator for temporal variables, that need to be saved
template<class Tmicromatrix> saved4knit<Tmicromatrix>& saved4knit<Tmicromatrix>::operator=(const saved4knit<Tmicromatrix>& S){
  saving_level=S.saving_level;
  //makes real copy of maps
  map_copy(mapG_NN, S.mapG_NN);
  map_copy(mapG_aN, S.mapG_aN);
  map_copy(mapG_Na, S.mapG_Na);
  map_copy(map_g_ra, S.map_g_ra);
  map_copy(map_g_ar, S.map_g_ar);
  GF.resize(S.GF.shape());
  SE.resize(S.SE.shape());
  g_rr.resize(S.g_rr.shape());
  G_NN.resize(S.G_NN.shape());
  for (int li=GF.lbound(firstDim); li<=GF.ubound(firstDim); ++li) GF(li)<=S.GF(li);
  for (int li=SE.lbound(firstDim); li<=SE.ubound(firstDim); ++li) SE(li)<=S.SE(li);
  GFLL.resize(S.GFLL.shape()); 
  for (int li=GFLL.lbound(firstDim); li<=GFLL.ubound(firstDim); ++li) 
    for (int lj=GFLL.lbound(secondDim); lj<=GFLL.ubound(secondDim); ++lj) GFLL(li,lj)<=S.GFLL(li,lj);
  map_copy(mapGF, S.mapGF);
  return *this;
};


// ************************KNIT member functions************************************* //


// copy constructor
// Since copy constructor for Arrays is defined as reference passing we redefine all copy constructors containing it
template<class Tmicromatrix> knit<Tmicromatrix>::knit(const knit<Tmicromatrix>& tricot):
  TMP(tricot.TMP), E(tricot.E), p_sys(tricot.p_sys), pos(tricot.pos), pos_new(tricot.pos_new), GF(tricot.GF.copy()), SAV(tricot.SAV){};


// assignement operator
template<class Tmicromatrix> knit<Tmicromatrix>& knit<Tmicromatrix>::operator=(const knit<Tmicromatrix>& tricot){
  E=tricot.E;
  p_sys=tricot.p_sys;
  pos=tricot.pos;     
  pos_new=tricot.pos_new;
  GF<=tricot.GF;
  TMP=tricot.TMP;
  SAV=tricot.SAV;
  return *this;
};


// constructor of knit from a single site with system index -indice-.
template<class Tmicromatrix> 
knit<Tmicromatrix>::knit(int indice,const sys_inf& sys, COMPLEX En=0.) : TMP(sys,indice), E(En), p_sys(&sys), pos(indice,sys), 
     GF(TMP.max_taille,MicroDim,TMP.max_taille,MicroDim), SAV(sys.fNres(),sys.fsize()) 
{
  const  int& lead_number=sys.sys2res(indice);
  GF=0.;// set the initial value of GF to zero
  // we add a whole lead if site is connected to one of them 
  if (lead_number!=sys_inf::not_lead) {
    pair<GF_type,GF_type> G_SE=sys.p_lead(lead_number)->G_SE(E);
    Range reduit = Range(0,sys.lead_size(lead_number)-1);
    GF(reduit,ALL,reduit,ALL)=G_SE.first; // initialize GF
    SAV.GF(lead_number) <= GF(reduit,ALL,reduit,ALL); // save whole GF for lead
    SAV.SE(lead_number) <= G_SE.second; // save self energy for lead
  }
  // for the single site GF is defined as scalar 1/(E-Hdiag)
  else GF(New,ALL,New,ALL)=(-sys.Msite(indice)+E).inverse().micro2arr(); 
  pos_new=pos;// at the initialization new and old position are the same
};


// bool compare operator == for knit
template<class Tmicromatrix> 
bool knit<Tmicromatrix>::operator==(const knit<Tmicromatrix>& tricot) const{ 
  if ( !(pos == tricot.pos && pos_new == tricot.pos_new)) return false;
  Range r(0,pos.ftaille()-1);
  return is_equal( GF(r,ALL,r,ALL) ,tricot.GF(r,ALL,r,ALL) );
};

template<class Tmicromatrix> void knit<Tmicromatrix>::forward(int i){
  switch(i){
  case 0:forward(le_debut);break;
  case 1:forward(la_fin);break;
  case 2:forward(ToZero);break;
  case 3:forward(ToEnd);break;
  };
};



// forward knitting: advance by one site using the end or the beginning of the lace
template<class Tmicromatrix> void knit<Tmicromatrix>::forward(const moveType& debut_fin){
#ifdef _DEBUG_ // check if we don't try to advance outside of the sample
  if (p_sys->fsize()-1==pos.ffin()&&debut_fin==la_fin) ERROR("In knit::forward() trying to add site beyond the last one");
  if (debut_fin==le_debut&&pos.fdebut()==0) ERROR("In knit::forward() trying to advance to outside of the sample");
  if ( max(GF.extent(0),GF.extent(3)) < pos.ftaille()+p_sys->fzmax()+1) ERROR("In knit::forward() size allocated for GF is not sufficient");
#endif
#ifdef _DEBUG_LONG_
  if (!(pos == pos_new)) ERROR("In knit::forward() pos != pos_new at the beginning");
#endif
  if (debut_fin == le_debut || debut_fin == la_fin){
    //At the beginning: pos==pos_new
    // the site index that is added to the lace depend on debut_fin variable
    // if debut_fin==le_debut, then we add site to the end, if debut_fin==la_fin we add site to the beginning
    int added_lead; // addedlead indicates to which lead is connected added site,
    int added_site;
    if (debut_fin==le_debut) added_site=pos.fdebut()-1;
    if (debut_fin==la_fin) added_site=pos.ffin()+1;
    pos_new.avancer(debut_fin); // advance to the new position
    added_lead=p_sys->sys2res(added_site);
    if (added_lead!=sys_inf::not_lead) collerlead(added_lead);// modify  GF adding a lead added_lead
    else collersite(added_site); // modify  GF adding a site added_site
    pos.avancer(debut_fin); // old position advance to the new one AAA this procedure could be improved by introduction of position.swap() function
    if (pos.fdebut() == 0 && p_sys->fsize()-1==pos.ffin()) { // at the last step
    // order GF between leads for full system
      for (int li=0;li<p_sys->fNres();li++) for (int lj=0;lj<p_sys->fNres();lj++) {// for every lead
 	SAV.GFLL(li,lj).resize(p_sys->lead_size(li), MicroDim, p_sys->lead_size(lj), MicroDim);
	const Range r_li=Range(pos.flead_offset(li), pos.flead_offset(li) + p_sys->lead_size(li)-1); 
	const Range r_lj=Range(pos.flead_offset(lj), pos.flead_offset(lj) + p_sys->lead_size(lj)-1); 
	SAV.GFLL(li,lj)(ALL,ALL,ALL,ALL)=GF(r_li,ALL,r_lj,ALL);
      };
      /* other possibility: element by element copy
      for (int li=0;li<p_sys->fNres();li++) for (int lj=0;lj<p_sys->fNres();lj++) {// for every lead
 	SAV.GFLL(li,lj).resize(p_sys->lead_size(li), MicroDim, p_sys->lead_size(lj), MicroDim);
 	for (int i=0;i<p_sys->lead_size(li);i++) for (int j=0;j<p_sys->lead_size(lj);j++) // for every element of lead
 	  SAV.GFLL(li,lj)(i,ALL,j,ALL)=G(p_sys->res2sys(li,i), p_sys->res2sys(lj,j));
      };
      */
    };    
  };
  // advance till the end of the lace
  if (debut_fin==ToEnd) while(pos.ffin() != p_sys->fsize()-1) forward(la_fin);
  // advance till the beginning of the lace
  if (debut_fin==ToZero) while(pos.fdebut() != 0) forward(le_debut);
  return;
};


// backward knitting: stepback by one site using the end or the beginning of the lace
// la_fin, then lace is reduced at the end by one site
// le_debut, then lace is reduced at the beginning
// FromZero, completely reduce from the zero-site(debut) of the lace
// FromEnd, completely reduce from the Tail(fin) of the lace
template<class Tmicromatrix> void knit<Tmicromatrix>::backward(const moveType& debut_fin){
#ifdef _DEBUG_LONG_ 
  if (!(pos == pos_new)) ERROR("In knit::backward() pos != pos_new at the beginning");
#endif
#ifdef _DEBUG_
  if (SAV.saving_level == 0)  ERROR("In knit::backward() could not come back if no saving was done in forward");
  if (debut_fin == ToEnd || debut_fin == ToZero)  ERROR("In knit::backward() not correct argument is used");
  if (max(GF.extent(0),GF.extent(3)) < pos.ftaille()+p_sys->fzmax()+1) ERROR("In knit::backward() size allocated for GF is not sufficient");
#endif
  //end debug
  if (debut_fin == le_debut || debut_fin == la_fin){
#ifdef _DEBUG_ // check if we don't try to advance outside of the sample
    if (pos.ffin() == pos.fdebut()) ERROR("In position_knit::backward() trying to suppress the last site");
#endif
    //At the beginning: pos==pos_new
    // the site index that is added to the lace depend on debut_fin variable
    // if debut_fin==le_debut, then we add site to the end, if debut_fin==la_fin we add site to the beginning
    int del_site=sys_inf::outsample; //site to be deleted
    if (debut_fin==le_debut) del_site=pos.fdebut();
    if (debut_fin==la_fin) del_site=pos.ffin();
    const int del_lead=p_sys->sys2res(del_site); //del_lead indicates to which lead is connected del site,
    pos_new.reculer(debut_fin); // stepback to the new position
    if (del_lead == sys_inf::not_lead) enleversite(del_site); // modify  GF deleting the site del_site
    else if (pos.fwhereAddLead(del_lead) == del_site) enleverlead(del_lead); // modify  GF deleting a lead del_lead
    pos.reculer(debut_fin); // old position stepback and become equal to the new one
  };
  // stepback till the initial position of the lace from its head(debut)
  if (debut_fin==FromZero) while(pos.fdebut() != pos.get_init_pos()) backward(le_debut);
  // stepback till the initial position of the lace from its tail(fin)
  if (debut_fin==FromEnd) while(pos.ffin() != pos.get_init_pos()) backward(la_fin); 
  return;
};


// GF element for system_index arguments
template<class Tmicromatrix>
Array<COMPLEX,2> knit<Tmicromatrix>::G(const int sys_indi, const int sys_indj) const{
  const int& GFindi=pos.s2g(sys_indi);
  const int& GFindj=pos.s2g(sys_indj);
#ifdef _DEBUG_
  if (GFindi<0 || GFindi>=pos.ftaille() || GFindj<0 || GFindj>=pos.ftaille()) ERROR("in knit::G(sys_i,sys_j) index do not belongs to interface");
#endif
  return GF(GFindi,ALL,GFindj,ALL);
}; 


// ************** private KNIT function ***************************** //


// collersite
// add a site in forward knitting: using site -added_site- and both old(pos) and new(pos_new) positions. GF is modified
// G_ab=g_ab+\sum_s G_aN/G_NN * G_NN * G_Nb/G_NN
template<class Tmicromatrix> 
void knit<Tmicromatrix>::collersite(int added_site){
  if (pos.s2g(added_site)!=position<Tmicromatrix>::outlace) return; // if the site is already inside lace, do nothing
  forward_save(added_site); //update all temporal GF parts: G_NN G_aN G_Na, and make savings necessairy for backward
  // update G_ab matrix element between interface sites -a- and -b-  G_ab=g_ab using new GFidexes
  //only element with changed GFindexes need to be updated
  reindex(pos_new,pos,GF); // reindex GF using new position
  // if added_site belong to new interface (it was not deleted) then it's GFindex_new corresponds to taille-1
  // in this case the G_ab loop is taken for a(b)\in(0,taille-2), so that we do not try to calculate G_ab for a=N or b=N 
  int last_index=pos_new.ftaille()-2; // last index in the range for -a- and -b- in G_ab;
  //  if added site was deleted from the interface
  if (pos_new.s2g(added_site)<0) last_index++;
  //G_Na_norm is needed for faster main loop calculations; AAA probably need to add it as class knit member 
  // version 
  GF_type G_Na_norm(TMP.G_Na.shape());//normalized vector G_Na
  // !!! multiplication order is very important
  for (int i=0;i<=last_index;++i) //contiguous copy of G_Na part
    G_Na_norm(New,ALL,i,ALL) = matmul(TMP.G_NN, TMP.G_Na(New,ALL,i,ALL));
  // main loop
  matmul_blas(subArray<COMPLEX,4>(TMP.G_aN), subArray<COMPLEX,4>(G_Na_norm), 
	      subArray<COMPLEX,4>(GF),COMPLEX(1.),COMPLEX(1.));// TTT verify if no transposition is needed
  for (int i=0;i<=last_index;++i) {    // update G_aN and G_Na parts of GF
    GF(i,ALL,last_index+1,ALL) = matmul(TMP.G_aN(i,ALL,New,ALL), TMP.G_NN);// write updated G_aN values    
    GF(last_index+1,ALL,i,ALL) = matmul(TMP.G_NN, TMP.G_Na(New,ALL,i,ALL));// write updated G_Na values 
  };
  GF(last_index+1,ALL,last_index+1,ALL)=TMP.G_NN; // write updated G_NN value
  //stara version
//   const int last_ind=last_index;
//   GF_type G_Na_norm(1,MicroDim,last_ind+1,MicroDim);//normalized vector G_Na
//   // !!! multiplication order is very important
//   for (int i=0;i<=last_ind;++i) {    // update G_aN and G_Na parts of GF
//     GF(i,ALL,last_ind+1,ALL) = matmul(TMP.G_aN(i,ALL,New,ALL), TMP.G_NN);// write updated G_aN values    
//     GF(last_ind+1,ALL,i,ALL) = matmul(TMP.G_NN, TMP.G_Na(New,ALL,i,ALL));// write updated G_Na values 
//     G_Na_norm(New,ALL,i,ALL) = GF(last_ind+1,ALL,i,ALL);         //contiguous copy of G_Na part
//   };
//   GF(last_ind+1,ALL,last_ind+1,ALL)=TMP.G_NN; // write updated G_NN value
//   // main loop
//   const int mr=(last_ind+1)*MicroDim;// GF size of modified region
//   matmul_blas(subArray<COMPLEX,4>(TMP.G_aN,mr,MicroDim), subArray<COMPLEX,4>(G_Na_norm), 
// 	      subArray<COMPLEX,4>(GF,mr,mr),COMPLEX(1.),COMPLEX(1.));// TTT verify if no transposition is needed
//   GF(last_ind,ALL,last_ind,ALL)=TMP.G_NN; // rewrite G_NN, oubraty line
  return;
};


// enleversite
// suppress a site in backward knitting: using sys_index -del_site- and both "small"(pos_new) and "big"(pos) position variables. GF is modified
// g_ab=G_ab-\sum_s G_aN/G_NN * G_NN * G_Nb/G_NN
template<class Tmicromatrix> 
void knit<Tmicromatrix>::enleversite(int del_site){
#ifdef _DEBUG_
  if (pos.s2g(del_site)==position<Tmicromatrix>::outlace) ERROR("In knit::enleversite() trying to suppress site that is not inside the lace");
  if (SAV.saving_level == 0) ERROR("In knit::enleversite() no backward possible for saving_level=0");
#endif
  if (SAV.saving_level >0 && del_site%SAV.saving_level == 0 && del_site != 0){ // case of full GF recovery
#ifdef _DEBUG_
    if (SAV.mapGF.find(del_site) == SAV.mapGF.end()) ERROR("in knit::enleversite() no GF value was saved, no backward possible"); 
#endif
    cout<<"recover full GF for"<<del_site<<endl; //TTTT
    GF(pos_new.range(),ALL,pos_new.range(),ALL)=SAV.mapGF.find(del_site)->second;
    SAV.mapGF.erase(del_site);
  }
  else{
    backward_save(del_site); // assign temporals and recover from saved the "new" GF elements, G_NN, G_Na, G_aN
    // update g_ab matrix element between interface sites -a- and -b-  g_ab=G_ab using smallGFidexes
    //only element with changed GFindexes need to be updated
    reindex(pos_new,pos,GF); // reindex GF using new position
    //Vg is needed for faster main loop calculations: Vg = -(G_NN)^(-1)*G_Nb
    GF_type Vg(1,MicroDim,pos_new.ftaille(),MicroDim);//"normalized" vector of G_Nb (small indexes)
    Array<COMPLEX,2> G_NNinverseMinus(-TMP.G_NN.copy()); Inverse(G_NNinverseMinus);//minus inverse of G_NN
    for (int i=0;i<pos_new.ftaille();++i)  Vg(New,ALL,i,ALL) = matmul(G_NNinverseMinus,TMP.G_Na(New,ALL,i,ALL));
    const int mr=pos_new.ftaille()*MicroDim;// GF size of modified region
    // main loop
    matmul_blas(subArray<COMPLEX,4>(TMP.G_aN,mr,MicroDim), subArray<COMPLEX,4>(Vg),// update of g_ab
	      subArray<COMPLEX,4>(GF,mr,mr),COMPLEX(1.),COMPLEX(1.));// TTT verify if no transposition is needed
    // overwrite of wronly calculated value done in the previous step
    backward_all(del_site);
  };
  return;
};


// add a lead in forward knitting: using site -added_lead- and both old(pos) and new(pos_new) positions. GF is modified
template<class Tmicromatrix> 
void knit<Tmicromatrix>::collerlead(int added_lead){
  // if the lead is already inside lace, do nothing
  if (pos.s2g(p_sys->res2sys(added_lead,0)) != position<Tmicromatrix>::outlace) return;
  Range r(0,pos.ftaille()-1); // small GF range
  if (SAV.saving_level != 0)  SAV.GF(added_lead)<=GF(r,ALL,r,ALL); // save whole GF
  // SUPLEMENTARY CALCULATIONS
  const  Array<map<int,int>,1> interface = pos.interfaceLead(added_lead); // vector of map<z,smallGF_ind> for each lead's element
  int ls=p_sys->lead_size(added_lead); // size of the added_lead
  // notations: s - interface lead-system; N - lead; a - system
  GF_type VgV_lead(ls,MicroDim,ls,MicroDim); VgV_lead=0.;      // VgV = sum_{ss'} V_Ns*g_ss'*V_s'N';     Mat(lead_size, lead_size) 
  GF_type toInverse=scalar_matrix(ls,MicroDim,COMPLEX(1.));    // toInverse = 1-G_LL*VgV;                Mat(lead_size, lead_size)
  pair<GF_type,GF_type> G_SE=(p_sys->p_lead(added_lead))->G_SE(E);// Green Function and self Energy of the lead       Mat(lead_size, lead_size)  
  GF_type g_LL=G_SE.first;                                     // g_LL= Green Function of the lead       Mat(lead_size, lead_size)  
  SAV.SE(added_lead)<=G_SE.second;                             // save self energy for the lead added_lead
  GF_type G_La(ls,MicroDim,pos_new.ftaille(),MicroDim);G_La=0.;// G_La= sum_{N's} (G_LL)_NN'*V_N's*g_sa; Mat(lead_size, GF_size) 
  GF_type Vg(ls,MicroDim,pos_new.ftaille(),MicroDim);  Vg=0.;  // Vg  = sum_{s} V_Ns*g_sa;               Mat(lead_size, GF_size) 
  GF_type G_aL(pos_new.ftaille(),MicroDim,ls,MicroDim);G_aL=0.;// G_aL= sum_{N's} g_as*V_sN'*(G_LL)_N'N; Mat(GF_size,   lead_size) 
  GF_type gV(pos_new.ftaille(),MicroDim,ls,MicroDim);  gV=0.;  // gV  = sum_s    g_as*V_sN;              Mat(GF_size,   lead_size) 
  // VgV_lead calculations; cation their is another variable VgV for backward knitting
  for (int l1=0; l1<ls;++l1) 
    for (int l2=0; l2<ls;++l2) 
      for (map<int,int>::const_iterator s1=interface(l1).begin() ;s1!=interface(l1).end();++s1) 
	for (map<int,int>::const_iterator s2=interface(l2).begin() ;s2!=interface(l2).end();++s2) 
	  VgV_lead(l1,ALL,l2,ALL) += matmul((p_sys->Mvoisin(p_sys->res2sys(added_lead,l1), s1->first)).micro2arr(), // V(l1,s1)
				       GF(s1->second,ALL,s2->second,ALL),                                      // g(s1,s2)  
				                                                       // V(l2,s2).hconjugate() = V(s2,l2)
				       (p_sys->Mvoisin(p_sys->res2sys(added_lead,l2), s2->first).hconjugate()).micro2arr());
  // toInverse calculations
  toInverse -= matmul(g_LL,VgV_lead);
  // inverse toInverse: one gets inverse(1-g_LL*V*g*V)
  Inverse(toInverse);
  // G_LL calculations; to save memory we store it first in g_LL and then make a reference, no supplementary copy operation is needed
  g_LL = matmul(toInverse,g_LL); GF_type G_LL=g_LL;
  // calculations of gV
  for (int a_new=0; a_new<pos_new.ftaille();++a_new){
    int a_old=pos.s2g(pos_new.g2s(a_new));                 // a_new => a_old correspondance is not unique
    if (a_old == position<Tmicromatrix>::outlace) continue;// outlace cases are skipped
    for (int li=0;li<ls;++li){
      for (map<int,int>::const_iterator s=interface(li).begin();s!=interface(li).end();++s) 
	gV(a_new,ALL,li,ALL) += matmul(GF(a_old,ALL,s->second,ALL),                  // g(a,s)
				                                                     // V(li,s).hconjugate() = V(s,li)
				       (p_sys->Mvoisin(p_sys->res2sys(added_lead,li),s->first).hconjugate()).micro2arr());
    };
  };
  //calculations of G_aL = gV *G_LL
  matmul_blas(gV,G_LL,G_aL);
  //calculations of Vg
  for (int a_new=0; a_new<pos_new.ftaille();++a_new){
    int a_old=pos.s2g(pos_new.g2s(a_new));                 // a_new => a_old correspondance is not unique
    if (a_old == position<Tmicromatrix>::outlace) continue;// outlace cases are skipped
    for (int li=0;li<ls;++li){
      for (map<int,int>::const_iterator s=interface(li).begin();s!=interface(li).end();++s) 
	Vg(li,ALL,a_new,ALL) += matmul( (p_sys->Mvoisin(p_sys->res2sys(added_lead,li),s->first)).micro2arr(), // V(li,s)
					GF(s->second,ALL,a_old,ALL));                                         // g(s,a)
    };
  };
  //calculations of G_La = G_LL*Vg
  matmul_blas(G_LL,Vg,G_La);
  // SUPLEMENTARY CALCULATIONS ENDED
  // UPDATE part
  // update G_ab matrix element between interface sites -a- and -b-  G_ab=g_ab using new GFidexes
  // only element with new GFindexes need to be updated
  reindex(pos_new,pos,GF); // reindex GF using new position
  // main loop
  //calculations of G_ab
  matmul_blas(subArray<COMPLEX,4>(G_aL),subArray<COMPLEX,4>(Vg),subArray<COMPLEX,4>(GF,pos_new.ftaille()*MicroDim),COMPLEX(1.),COMPLEX(1.));
#ifdef _DEBUG_LONG_
  GF_type GF_test1(pos_new.ftaille(),MicroDim,pos_new.ftaille(),MicroDim);
  GF_type GF_test2(pos_new.ftaille(),MicroDim,pos_new.ftaille(),MicroDim);
  matmul_blas(G_aL,Vg,GF_test1);
  matmul_blas(gV,G_La,GF_test2);
  if (sum(abs(GF_test1-GF_test2))>0.001 ) ERROR("in coller lead gV*G_La != G_aL*Vg");
#endif
  // ecrire un test avec gV*G_La
  //update G_aL and G_La parts of Green Function
  for (int li=0;li<ls;++li){
    int new_GF_ind=pos_new.s2g(p_sys->res2sys(added_lead,li));
    GF(Range(0,pos_new.ftaille()-1),ALL,new_GF_ind,ALL)=G_aL(ALL,ALL,li,ALL);
    GF(new_GF_ind,ALL,Range(0,pos_new.ftaille()-1),ALL)=G_La(li,ALL,ALL,ALL);
  };
  //update G_LL part of Green Function
  for (int l1=0;l1<ls;++l1){
    int new_GF_ind1=pos_new.s2g(p_sys->res2sys(added_lead,l1));
    for (int l2=0;l2<ls;++l2){
      int new_GF_ind2=pos_new.s2g(p_sys->res2sys(added_lead,l2));
      GF(new_GF_ind1,ALL,new_GF_ind2,ALL)=G_LL(l1,ALL,l2,ALL);
    };
  };
  return;
};


// detouche a lead in the backward knitting: using site -del_lead- and both small(pos) and big(pos_new) position variables. GF is modified
template<class Tmicromatrix> 
void knit<Tmicromatrix>::enleverlead(int del_lead){
  Range r=pos_new.range(); // small GF range
#ifdef _DEBUG_ // check sizes of GF and saved GF
  TinyVector<int,4> check ((GF(r,ALL,r,ALL)).shape());
  check -= (SAV.GF(del_lead)).shape();
  if ( sum(check)!=0  ) ERROR("in knit::enleverlead shape of GF and saved GF are not the same");
#endif
  //  cout<<"ENLEVER lead "<<del_lead<<endl; //TTT
  const int init_lead = p_sys->sys2res( pos.get_init_pos() ); // initial lead
  if ( del_lead != init_lead ) GF(r,ALL,r,ALL)=SAV.GF(del_lead); //do not recover init_lead
  return;
};

// set level of saving
/// level of saving 
// -1 (exacte version, save G_aN,G_Na,G_NN,G_rN,G_Nr,G_rr at each step) (default value)
//  0 (no saving, usefull only for transmission calculations or very small systems)
//  n (save full GF each -n- sites)
template<class Tmicromatrix> 
void knit<Tmicromatrix>::set_saving_level(int level){
  if (level<-1) ERROR("in knit: Saving level should be >=-1 ");
  if (pos.fdebut() != pos.ffin()) ERROR("in knit: Saving level should be set at very begining");
  SAV.saving_level=level;return;
};


// ************************* TEMPORAL knit functions *************************** //

//FORWARD FUNCTIONS

// update G_NN (diagonal GF element for added(new) site) G_NN=(E-H_NN-\sum_{ss'}V_Ns*g_ss'*V_s'N)^{-1}
template<class Tmicromatrix> void knit<Tmicromatrix>::forwardG_NN(int added_site, const map<int,int>& interface){
  Tmicromatrix self_energy; // intermediate variable =\sum_{ss'}V_Ns*g_ss'*V_s'N)^{-1}
  map<int,int>::const_iterator s1=interface.begin();
  for (;s1!=interface.end();++s1) {
      map<int,int>::const_iterator s2=interface.begin();
      for (;s2!=interface.end();++s2) 
	self_energy+=p_sys->Mvoisin(added_site,s1->first)*arr2micro<Tmicromatrix>(GF(s1->second,ALL,s2->second,ALL))*p_sys->Mvoisin(added_site,s2->first).hconjugate();
  };
  TMP.G_NN=(-p_sys->Msite(added_site)-self_energy+E).inverse().micro2arr();
  return;
}; 


// update G_Na matrix element between added interface sites(a) and added site(N) G_Na/G_NN=\sum_s V_Ns*g_sa
// WARNING!! in order to get G_Na multiplication by normalisation factor G_NN is needed
template<class Tmicromatrix> void knit<Tmicromatrix>::forwardG_Na(int added_site,const map<int,int>& interface){
  // if added_site belong to new interface (it was not deleted) then it's GFindex_new corresponds to taille-1
  // in this case the G_Na loop is taken untill for a\in(0,taille-2), so that we do not try to calculate G_Na for a=N 
  int range_a=(pos_new.s2g(added_site)>=0)?pos_new.ftaille()-2:pos_new.ftaille()-1; // range for -a- in G_Na
  for (int i_new=0; i_new<=range_a;++i_new){ // in this loop there is for sure no added_site itself 
    int i_old=pos.s2g(pos_new.g2s(i_new)); // as added_site is not present in this loop i_new=>i_old correspondace is unique
    TMP.G_Na(New,ALL,i_new,ALL)=0.;          // ititial value is set to zero in order to clear previous one
    map<int,int>::const_iterator s=interface.begin();
    for (;s!=interface.end();++s) 
      // G_Na = G_Na + Mvoisin*GF //TTT
      //      plus_matmul((p_sys->Mvoisin(added_site,s->first)).micro2arr(), GF(s->second,ALL,i_old,ALL), G_Na(New,ALL,i_new,ALL));
      TMP.G_Na(New,ALL,i_new,ALL) += matmul((p_sys->Mvoisin(added_site,s->first)).micro2arr(), GF(s->second,ALL,i_old,ALL));
  };
  return;
};


// update G_aN/G_NN matrix element between added interface sites(a) and added site(N) G_aN/G_NN=\sum_s g_as*V_sN
// WARNING!! in order to get G_Na multiplication by normalisation factor G_NN is needed
template<class Tmicromatrix> void knit<Tmicromatrix>::forwardG_aN(int added_site,const map<int,int>& interface){
  // if added_site belong to new interface (it was not deleted) then it's GFindex_new corresponds to taille-1
  // in this case the G_aN loop is taken untill for a\in(0,taille-2), so that we do not try to calculate G_aN for a=N 
  int range_a=(pos_new.s2g(added_site)>=0)?pos_new.ftaille()-2:pos_new.ftaille()-1; // range for -a- in G_aN
  for (int i_new=0; i_new<=range_a;++i_new){ // in this loop there is for sure no added_site itself 
    int i_old=pos.s2g(pos_new.g2s(i_new)); // as added_site is not present in this loop i_new=>i_old correspondace is unique
    TMP.G_aN(i_new,ALL,New,ALL)=0.;          // ititial value is set to zero in order to clear previous one
    map<int,int>::const_iterator s=interface.begin();
    for (;s!=interface.end();++s) 
      // G_Na = G_Na + Mvoisin*GF 
      // plus_matmul(GF(i_old,ALL,s->second,ALL),(p_sys->Mvoisin(added_site,s->first).hconjugate()).micro2arr(), G_aN(i_new,ALL,New,ALL));
      TMP.G_aN(i_new,ALL,New,ALL) += matmul(GF(i_old,ALL,s->second,ALL),(p_sys->Mvoisin(added_site,s->first).hconjugate()).micro2arr());
  };
  return;
};


// Forward all temporal GF elements, when a single site is added
// save parts of GF in order to make backward possible
template<class Tmicromatrix> void knit<Tmicromatrix>::forward_save(int added_site){
  const map<int,int> interface=pos.interface(added_site); // interface map of pairs <z,smallGF_ind>
  forwardG_NN(added_site,interface);
  forwardG_Na(added_site,interface);
  forwardG_aN(added_site,interface);
  // save parts of GF to make backward possible 
  // this parts would need to be recovered in backward knitting
  switch (SAV.saving_level) { // different scenarios depending on saving_level
  case -1: // no precision lost version, memory hungry one
    // SAV.G_NN(added_site)<=TMP.G_NN.copy();
    update_Gnew_map(added_site); // save G_aN, G_Na, G_NN 
    update_gRec_map(added_site); // save G_ar, G_ra , G_rr for all neighbors of added_site
    break;
  case 0: // no saving version only for forward iteration
    break;
  default://memory gain version => the more memory you gain the worth is you precision
    if (added_site%SAV.saving_level == 0 && added_site != 0){ // save full GF each saving level sites
      SAV.mapGF.insert( SAV.mapGF.end(), make_pair(added_site,GF(pos.range(),ALL,pos.range(),ALL).copy()) ); // precision saving GF
      cout<<"save full GF for"<<added_site<<endl;
    }
    if (pos_new.s2g(added_site) < 0)
      update_Gnew_map(added_site);// save G_NN, G_aN, G_Na if -N- was deleted from interface 
    //save G_ar, G_ra , G_rr for all neighbors of added_site, in case where interface size was reduced 
    if ( pos_new.ftaille() < pos.ftaille() ) update_gRec_map(added_site); 
  };
  return;
};


// ************** temporal BACKWARD functions


// backward knitting
// recover all saved part of GF used in backward knitting
// assign scalars VgV, G_NN and vectors G_aN, G_Na components of bigGF -G- to temporal variables; 
// !!! smallGF indexes are used
// VgV=\sum_{ss'}V_Ns*g_ss'*V_s'N ; update formular is VgV=E-H_NN-(G_NN)^{-1}
// G_aN=sum_s g_as*V_sN*G_NN; 
// G_Na=sum_s G_NN*V_Ns*g_sa; 
template<class Tmicromatrix> void knit<Tmicromatrix>::backward_save(int del_site){
  Range All_a(0,pos_new.ftaille()-1); // -a- index range
  switch (SAV.saving_level){// different scenarios depending on saving_level
    /////// no precision lost version, memory hungry one
  case -1:
    // recover G_aN, G_Na, G_NN 
    TMP.G_NN=SAV.mapG_NN.find(del_site)->second; 
    TMP.G_Na(Range(New,New),ALL,All_a,ALL) = SAV.mapG_Na.find(del_site)->second;
    TMP.G_aN(All_a,ALL,Range(New,New),ALL) = SAV.mapG_aN.find(del_site)->second;
    //erase recovered elements
    SAV.mapG_NN.erase(del_site);
    SAV.mapG_Na.erase(del_site);
    SAV.mapG_aN.erase(del_site);
    break;
    //////// no saving version, works only for forward iteration
  case 0: 
    ERROR("in backward::backward_save, no backward possible for saving_level=0");
    break;
    ////////memory gain version => the more memory you gain the worth is you precision
  default:
    const int N_ds=pos.s2g(del_site); // deleted site bigGF index
#ifdef _DEBUG_
    if (N_ds<0 && SAV.mapG_NN.find(del_site)==SAV.mapG_NN.end()) ERROR("in knit::backward_save no G_new value was saved, no backward possible"); 
#endif
    //G_NN
    if (N_ds<0) TMP.G_NN=SAV.mapG_NN.find(del_site)->second; // recover G_NN using saved values
    else TMP.G_NN=GF(N_ds,ALL,N_ds,ALL); // update G_NN using GF
    //VgV
    Array<COMPLEX,2> E_arr(MicroDim,MicroDim);E_arr=COMPLEX(0.,0.); // micromatrix with energie on diagonal
    for (int i=0;i<MicroDim;++i) E_arr(i,i)=E;
    Array<COMPLEX,2> G_NNinverse(TMP.G_NN.copy()); Inverse(G_NNinverse);//inverse of G_NN
    TMP.VgV=E_arr-p_sys->Msite(del_site).micro2arr()-G_NNinverse;
    //G_Na and G_aN
    if (N_ds<0) { // recover G_aN, G_Na using saved values
      TMP.G_Na(Range(New,New),ALL,All_a,ALL) = SAV.mapG_Na.find(del_site)->second;
      TMP.G_aN(All_a,ALL,Range(New,New),ALL) = SAV.mapG_aN.find(del_site)->second;
      //erase recovered elements
      SAV.mapG_NN.erase(del_site);
      SAV.mapG_Na.erase(del_site);
      SAV.mapG_aN.erase(del_site);
    }
    else for (int i_small=0; i_small<pos_new.ftaille();++i_small){// calculate G_aN and G_Na using GF 
      int i_big=pos.s2g(pos_new.g2s(i_small));
      // update all but recovered site, that is present in smallGF, but not in the bigGF
      if (i_big < 0) continue; // if the site does not belong to bigGF interface then do nothing
      TMP.G_Na(New,ALL,i_small,ALL)=GF(N_ds,ALL,i_big,ALL); //save G_Na and change index at the same time
      TMP.G_aN(i_small,ALL,New,ALL)=GF(i_big,ALL,N_ds,ALL); //save G_aN and change index at the same time
    };
  };
  return;
};


// update small GF element (g_rr) - diagonal hopping of recovered site, here -r- is recovered site index
// based on  VgV=\sum_{ss'}V_Ns*g_ss'*V_s'N ; we extract g_rr element (g_rs and g_sr being already calculated)
// del_site - system index; rec_pair - <z,r_smallGF_index>; interface <z,small_GF_index> - full interface of del_site
template<class Tmicromatrix> void knit<Tmicromatrix>::backward_g_rr(int del_site, const pair<int,int>& rec_pair,const map<int,int>& interface){
  if (rec_pair.first == sys_inf::outsample) return; // do nothing if there is no site to be recovered
  // rec_pair is pair <z,rec_site>, where z - is hopping index from "new" site to recovered site, rec_site = smallGFindex
  const int rec_site=rec_pair.second, rec_z=rec_pair.first;
  //calculation of VgV_rr
  // VgV_rr = VgV-\sum_{ss',-r}V_Ns*g_ss'*V_s'N where g_rr is not included
  Tmicromatrix VgV_rr=arr2micro<Tmicromatrix>(TMP.VgV); //initial value is set to VgV_rr = VgV
  // VgV_rr = VgV-\sum_{s} [ V_Ns*g_sr*V_rN +V_Nr*g_rs*V_sN ]
  map<int,int>::const_iterator s1=interface.begin();
  for (;s1!=interface.end();++s1) {
    VgV_rr -= p_sys->Mvoisin(del_site,s1->first)*arr2micro<Tmicromatrix>(GF(s1->second,ALL,rec_site,ALL))*p_sys->Mvoisin(del_site,rec_z).hconjugate();
    VgV_rr -= p_sys->Mvoisin(del_site,rec_z)*arr2micro<Tmicromatrix>(GF(rec_site,ALL,s1->second,ALL))*p_sys->Mvoisin(del_site,s1->first).hconjugate();
  };
  // VgV_rr = VgV-\sum_{ss',-r}V_Ns*g_ss'*V_s'N where g_rr is not included
  s1=interface.begin();
  for (;s1!=interface.end();++s1) {
    map<int,int>::const_iterator s2=interface.begin();
    for (;s2!=interface.end();++s2) 
      VgV_rr-=p_sys->Mvoisin(del_site,s1->first)*arr2micro<Tmicromatrix>(GF(s1->second,ALL,s2->second,ALL))*p_sys->Mvoisin(del_site,s2->first).hconjugate();
  };
  Tmicromatrix invV=(p_sys->Mvoisin(del_site,rec_z)).inverse(); // invV = (V_Nr)^{-1}
  GF(rec_site,ALL,rec_site,ALL) = (invV * VgV_rr * invV.hconjugate()).micro2arr();
  return;
};


// update smallGF vector (g_ra) of all hopping from recovered site, here -r- is recovered site, and -a- is all index of smallGF
// based on  G_Na=sum_s G_NN*V_Ns*g_sa;  we extract g_ra for recovered site -r-
template<class Tmicromatrix> void knit<Tmicromatrix>::backward_g_ra(int del_site,const pair<int,int>& rec_pair, const map<int,int>& interface){
  // rec_pair is pair <z,rec_site>, where z - is hopping index from "new" site to recovered site
  const int rec_site=rec_pair.second, rec_z=rec_pair.first;
  if (rec_z == sys_inf::outsample) return; // do nothing if there is no site to be recovered
  Array<COMPLEX,2> G_NNinverse(TMP.G_NN.copy()); Inverse(G_NNinverse);//inverse of G_NN
  Tmicromatrix invV=(p_sys->Mvoisin(del_site,rec_z)).inverse(); // invV = (V_Nr)^{-1}
  for (int a=0; a<pos_new.ftaille();++a){ // for all smallGF indexes
    Tmicromatrix partVg; // intermediate vector-variable partVg_a = \sum_{s,-r}V_Ns*g_sa where g_ra for recovered site is not included
    partVg*=0.;
    for (map<int,int>::const_iterator s=interface.begin();s!=interface.end();++s) 
      partVg += p_sys->Mvoisin(del_site,s->first) * arr2micro<Tmicromatrix>(GF(s->second,ALL,a,ALL));
    Tmicromatrix fullVg = arr2micro<Tmicromatrix>(matmul(G_NNinverse,TMP.G_Na(New,ALL,a,ALL))); // fullVg_a = \sum_{s}V_Ns*g_sa; sum over all -s-
    GF(rec_site,ALL,a,ALL) = (invV *(fullVg-partVg)).micro2arr();
  };
return;
};


// update smallGF vector (g_ar) of all hopping to recovered site, here -r- is recovered site, and -a- is all index of smallGF
// based on G_aN=sum_s g_as*V_sN*G_NN; we extract g_ar for recovered site -r- 
template<class Tmicromatrix> void knit<Tmicromatrix>::backward_g_ar(int del_site,const pair<int,int>& rec_pair, const map<int,int>& interface){
  // rec_pair is pair <z,rec_site>, where z - is hopping index from "new" site to recovered site
  const int rec_site=rec_pair.second, rec_z=rec_pair.first;
  if (rec_z == sys_inf::outsample) return; // do nothing if there is no site to be recovered
  Array<COMPLEX,2> G_NNinverse(TMP.G_NN.copy()); Inverse(G_NNinverse);//inverse of G_NN
  Tmicromatrix invVconj=(p_sys->Mvoisin(del_site,rec_z).hconjugate()).inverse(); // invVconj = (V_rN)^{-1}=(V_Nr.conj)^{-1}
  for (int a=0; a<pos_new.ftaille();++a){
    Tmicromatrix partgV; // intermediate vector-variable partgV_a = \sum_{s,-r}g_as*V_sN where g_ar for recovered site is not included
    partgV*=0.;
    for (map<int,int>::const_iterator s=interface.begin();s!=interface.end();++s) 
      partgV += arr2micro<Tmicromatrix>(GF(a,ALL,s->second,ALL)) * (p_sys->Mvoisin(del_site,s->first)).hconjugate();
    Tmicromatrix fullgV = arr2micro<Tmicromatrix>(matmul(TMP.G_aN(a,ALL,New,ALL),G_NNinverse)); // fullgV_a = \sum_{s}g_as*V_sN; sum over all -s-
    GF(a,ALL,rec_site,ALL) = ((fullgV-partgV)*invVconj).micro2arr();
  };
return;
};


// Backward all temporal GF elements, while deleting del_site
// it overwrites all wrongly calculated in the previous step values, order of operations is very important !!!!
template<class Tmicromatrix> void knit<Tmicromatrix>::backward_all(int del_site){
  // two possible choice either we recover GF element from memory or we calculate them
  // 1) recover from memory
  if ( pos.ftaille() < pos_new.ftaille() || SAV.saving_level == -1 ) // recover GF element from memory and exit
    for (int z=0; z<p_sys->fzmax(); ++z){
      const int& nn=p_sys->voisin(del_site,z); // nearest neighbor of del_site
      if (nn==sys_inf::outsample) continue; // if the neighbor is out of the sample do nothing
      // for all recovered sites: present in the smallGF interface, but not in bigGF intreface
      if ( pos_new.s2g(nn)>=0 && pos.s2g(nn)<0 ){
	const int& rec_site=nn; // recovered site system index
	const int& rs=pos_new.s2g(nn); // recovered site small GF index
#ifdef _DEBUG_
	if (SAV.map_g_ra.find(rec_site)==SAV.map_g_ra.end()) ERROR("in knit::backward_all no g_ra value was saved, no backward possible"); 
	if (SAV.map_g_ar.find(rec_site)==SAV.map_g_ar.end()) ERROR("in knit::backward_all no g_ar value was saved, no backward possible"); 
#endif
	Range All_a(0,pos_new.ftaille()-1); // -a- index range
	GF(Range(rs,rs), ALL, All_a, ALL)=SAV.map_g_ra.find(rec_site)->second;
	GF(All_a, ALL, Range(rs,rs), ALL)=SAV.map_g_ar.find(rec_site)->second;
	//erase recovered elements from memory
	SAV.map_g_ra.erase(rec_site);
	SAV.map_g_ar.erase(rec_site);
      };
    }
  //2) calculations without memory recovering
  else { 
    // calculate first the interface of deleted site, from where the recovered site is excluded
    map<int,int> interface=pos_new.interface(del_site); // interface map of pairs <z,smallGFindex>
    int rec_siteGF=position<Tmicromatrix>::outlace; // recovered site, that is present in the smallGF interface, but not in those of bigGF
    int rec_z=sys_inf::outsample; // hopping index from del_site to recovered site; 
    for (map<int,int>::const_iterator CI=interface.begin();CI!=interface.end();++CI)
      if (pos.s2g(pos_new.g2s(CI->second))<0) 
	{rec_siteGF=CI->second;
#ifdef _DEBUG_
	if (rec_z!=sys_inf::outsample) ERROR("in knit::enleversite(); trying to recover more then one site without using of saved GF elements");
#endif
	rec_z=CI->first;
	};
    pair<int,int> rec_pair(rec_z,rec_siteGF); //pair of recovered site <z,smallGFindex>
    // interface is constructed
    // recalculate g_ar, g_ra, g_rr only if there is site to be recovered
    if (rec_siteGF != position<Tmicromatrix>::outlace){
      interface.erase(rec_z); // delete recovered site from the interface
      backward_g_ar(del_site,rec_pair,interface);
      backward_g_ra(del_site,rec_pair,interface);
      backward_g_rr(del_site,rec_pair,interface);
    }
  };
  return;
};


// add to SAV.mapG_aN {Na,NN} paires of <New_sys_index,GFelements> where new=added_site
template<class Tmicromatrix> void knit<Tmicromatrix>::update_Gnew_map(int added_site){
  GF_type G_Na(1,MicroDim,pos.ftaille(),MicroDim);// G_Na -- copy GF elements with "small" GF indexes
  GF_type G_aN(pos.ftaille(),MicroDim,1,MicroDim);// G_aN -- copy GF elements with "small" GF indexes
  for (int i_small=0; i_small<pos.ftaille();++i_small){
    int i_big=pos_new.s2g(pos.g2s(i_small));
    // update all but recovered sites, that are present in smallGF, but not in the bigGF
    if (i_big < 0) continue; // if the site does not belong to bigGF interface then do nothing
    G_Na(New,ALL,i_small,ALL)=matmul(TMP.G_NN, TMP.G_Na(New,ALL,i_big,ALL)); //reindex and renormalize G_Na with "small" index
    G_aN(i_small,ALL,New,ALL)=matmul(TMP.G_aN(i_big,ALL,New,ALL), TMP.G_NN); //reindex and renormalize G_aN with "small" index
  };
  SAV.mapG_NN.insert( SAV.mapG_NN.end(), make_pair(added_site,TMP.G_NN.copy()) ); // save G_NN
  SAV.mapG_Na.insert( SAV.mapG_Na.end(), make_pair(added_site,G_Na) ); // save G_Na
  SAV.mapG_aN.insert( SAV.mapG_aN.end(), make_pair(added_site,G_aN) ); // save G_aN
  return;
};


//add to SAV.map_g_ra {ar} paire of <rec_site_sys_index,GFelements>
// where  rec_site are all the neighbors of added_site that would need to be recovered in backward knitting
template<class Tmicromatrix> void knit<Tmicromatrix>::update_gRec_map(int added_site){
  for (int z=0; z<p_sys->fzmax(); ++z){
    const int& nn=p_sys->voisin(added_site,z); // nearest neighbor of added_site
    if (nn==sys_inf::outsample) continue; // if the neighbor is out of the sample do nothing
    // for all recovered sites: present in the smallGF interface, but not in bigGF intreface
    if ( pos.s2g(nn)>=0 && pos_new.s2g(nn)<0 ){
      const int& rec_site=nn; // recovered site system index
      const int& rs=pos.s2g(nn); // recovered site small GF index
      SAV.g_rr(rec_site)<=GF(Range(rs,rs),ALL,Range(rs,rs),ALL);
      Range All_a(0,pos.ftaille()-1); // -a- index range
      SAV.map_g_ra.insert(make_pair(rec_site, GF(Range(rs,rs), ALL, All_a, ALL).copy() ) );
      SAV.map_g_ar.insert(make_pair(rec_site, GF(All_a, ALL, Range(rs,rs), ALL).copy() ) );
    };
  };
  return;
};


//********************************** DIRECT *************************************** //
// direct inversion
template<class Tmicromatrix>
direct<Tmicromatrix>::direct(const sys_inf& S, int iii, int ffi): 
  p_sys(&S), ii(iii), fi(ffi==-1?S.fsize()-1:ffi), 
  HnoLead(fi+1,Tmicromatrix::dim(),fi+1,Tmicromatrix::dim()),
  GF(fi+1,Tmicromatrix::dim(),fi+1,Tmicromatrix::dim())
{
#ifdef _DEBUG_
  if (ii < 0 || fi >= p_sys->fsize() ) ERROR("in direct() constructor: (ii,fi) out of range ");
#endif
  // initialization of the Hamiltonian without leads
  HnoLead=0.;
  for (int i=0;i<=fi;++i){
    HnoLead(i,ALL,i,ALL)=p_sys->Msite(i).micro2arr();
    for (int z=0;z<p_sys->fzmax();++z){
      const int j=p_sys->voisin(i,z);
      if (j == sys_inf::outsample || j>fi) continue;
      HnoLead(i,ALL,j,ALL)=p_sys->Mvoisin(i,z).micro2arr();
    };
  };
};

// calculate GF for energy E
template<class Tmicromatrix>
void direct<Tmicromatrix>::calculate4E(COMPLEX EE){
  E=EE;
  // GF= (E-Hnolead-SelfEnergy)^{-1}
  GF=0.; // reinitialize GF
  GF_type& fullH(GF);
  // diagonal part = E
  for (int i=0;i<=fi;++i)
    for (int subi=0;subi<Tmicromatrix::dim();++subi)
      fullH(i,subi,i,subi)=E;
  // add Hamiltonian of the system without leads
  fullH-=HnoLead;
  // find leads included in the system
  set<int> included_leads;
  for (int i=0;i<=fi;++i) 
    if (p_sys->sys2res(i)>=0) 
      included_leads.insert(p_sys->sys2res(i)); // add this lead to included leads
  // add self energy of leads
  set<int>::const_iterator CI=included_leads.begin();
  for (;CI!=included_leads.end();++CI){
    const int l=*CI; // lead index
    GF_type SE=p_sys->p_lead(l)->selfE(E);
    for (int li=0;li<p_sys->lead_size(l);++li)
      for (int lj=0;lj<p_sys->lead_size(l);++lj){
	const int i=p_sys->res2sys(l,li); // system index of li
	const int j=p_sys->res2sys(l,lj); // system index of lj
#ifdef _DEBUG_
	if (i < ii || i > fi ) ERROR("in direct::calculate4E(): partially added leads are not implemented ");
#endif
	fullH(i,ALL,j,ALL) -= SE(li,ALL,lj,ALL);
      };
  };
  Inverse(GF);
  return;
};


//********************************** SEW ****************************************** //
// constructor from knit of entire system
// attention construction variable -knit- would change during sewing
template<class Tmicromatrix>
sew<Tmicromatrix>::sew(knit<Tmicromatrix>& K): p_sys(K.p_sys),  kn(K), posL(K.pos), posL_new(K.pos),
					       posR(), posR_new(p_sys->fsize()-1,*p_sys,posL.fwhereAddLead()),
					       GFLL(K.SAV.GFLL), SE(K.SAV.SE), gf(K.GF), 
					       SI(K.GF.shape()), GF(K.GF.shape()),
					       GFIL(p_sys->fNres()), GFLI(p_sys->fNres()),
					       GFOL(p_sys->fNres()), GFLO(p_sys->fNres()), GFOO(1,MicroDim,1,MicroDim),
					       Gless(p_sys->fNres()), GnotK(p_sys->fsize(), MicroDim, p_sys->fzmax()+1, MicroDim)
{
#ifdef _DEBUG_
  // check if knit is done for entire system
  if (kn.fpos().fdebut() != 0 || kn.fpos().ffin() != p_sys->fsize()-1 ) ERROR("in sew(const knit&): trying to construct sew from not finished knit");
  if (kn.fpos().get_init_pos() != 0 ) ERROR("in sew(const knit&): trying to construct sew from knit that did not started at zero");
#endif
  // INITIALIZATION of sew private variables
  //we do not perform any calculations at construction
  // ** Os  -- site (sys index) for which we will calculate all GF_lesser elements
  Os=p_sys->fsize(); // it's given o purpose outsample value 
  // ** initialization of position and knit
  // posL  corresponds to full system
  // posL_new corresponds to full system
  // posR   - is constructed by default and corresponds to an empty position
  // posR_new corresponds to last site (complementary to posL.reculer() position)
  // as we do not perform any calculations this initial value are not important
  // ** preinitialization is done for gf, GFLL and SE
  // ** initialization of SI and GF to zero
  SI=COMPLEX(0.);
  GF=COMPLEX(0.);
  // ** resize GFLI, GFIL, GFLO, GFOL, Gless
  // ** and initialization to zero
  for (int l=0;l<p_sys->fNres();l++) {// for every lead
    GFIL(l).resize(kn.GF.extent(0),   MicroDim, p_sys->lead_size(l), MicroDim);
    GFIL(l)=COMPLEX(0.);
    GFLI(l).resize(p_sys->lead_size(l), MicroDim, kn.GF.extent(0),   MicroDim);
    GFLI(l)=COMPLEX(0.);
    GFOL(l).resize(1,   MicroDim, p_sys->lead_size(l), MicroDim);
    GFOL(l)=0.;
    GFLO(l).resize(p_sys->lead_size(l), MicroDim, 1,   MicroDim);
    GFLO(l)=0.;
    // onsite Glesser and GnotK values are stored in (l,zmax) element, that's why the size is zmax+1
    Gless(l).resize(p_sys->fsize(),     MicroDim, p_sys->fzmax()+1,    MicroDim);
    Gless(l)=COMPLEX(0.);
  };
  // ** GnotK initialization to zero
  GnotK=COMPLEX(0.);
  // CALCULATION
  // no calculation in constructor
  // PREPARATION FOR THE NEXT STEP
  // ** update of SI
  // there is no right interface => SI  = 0
  // ** update of Os;
  Os--;// site (sys index) for which we will calculate all GF_lesser elements at the next step
  // ** update positions
  // posL - is what it should be (full system with Os)
  posL_new.reculer(la_fin); //(full system without Os)
  // posR - is constructed by default and corresponds to an empty position
  // posR_new - is what it should be (complementary to the full system without Os)
  // kn - is what it should be  (full system with Os)
 
  // ** Initilization of Gless and GnotK for leads interfaces
  for (int l=0;l<p_sys->fNres();l++) // for every lead
    for (int li=0;li<p_sys->lead_size(l);li++){// for every element of lead 
      const int si = p_sys->res2sys(l,li); // sys index of leads site
      for (int z=0;z<=p_sys->fzmax();++z){// for every neighbor of lead
	const int vli = (z==p_sys->fzmax()) ? li :p_sys->lead_voisin(l,li,z); // voisin lead_index of si
	if (vli < 0) continue; // do nothing if this voisin does not exist
	for (int ll=0;ll<p_sys->fNres();ll++){ // calculation of Gless part corresponding to lead ll
	  const GF_type& G_si_all(GFLL(l,ll)(Range(li,li),ALL,ALL,ALL));
	  const GF_type& G_vsi_all(GFLL(l,ll)(Range(vli,vli),ALL,ALL,ALL));
	  GF_type tmpGFelem(1,MicroDim,1,MicroDim);
	  matmul3_blas(G_si_all,SE(ll),G_vsi_all,tmpGFelem,'n','n','c');
	  Gless(ll)(si,ALL,z,ALL)=tmpGFelem(0,ALL,0,ALL);
	};
	const int vi=p_sys->res2sys(l,vli); // system index of voisin
	GnotK(si,ALL,z,ALL)=K.G(si,vi);
      };
    };

  // if Os is not in the left interface
  // we use a trick we write gf(Os,ALL), gf(ALL,Os) and gf(Os,Os) to size+1 line of kn.GF and then define Or constant that would point to this line, if Os does not belongs to the left interface then we recover data from SAV variable: one should then use Or variable as Os
  // Or - is GF index of left interface posL if Os exists and it is (size+1) site if it does not; r - as recovery
  updateOr();
  //**end

#ifdef _DEBUG_VERY_LONG_
  // VERY EXPENSIVE TEST, direct inversion calculations of GF
  direct<Tmicromatrix> directGF(*p_sys);
  directGF.calculate4E(kn.E);
  cout<<"\n WARNING full GREEN FUNCTION was calculated using DIRECT INVERSION\n";
  dGF<=directGF.G();
#endif //_DEBUG_VERY_LONG_

};


// get full GF between -lead1- and -lead2- with lead indexes -i1- and -i2-
template<class Tmicromatrix>
inline Tmicromatrix sew<Tmicromatrix>::getG_LL(int i1,int lead1,int i2,int lead2) const {
#ifdef _DEBUG_
  if (lead1<0 || lead1>=p_sys->fNres() || lead2<0 || lead2>=p_sys->fNres() ) ERROR("in sew::getG_LL(i,li,j,lj) lead index is out of range");
  if (i1<0 || i1>=p_sys->lead_size(lead1)) ERROR("in sew::getG_LL(i,li,j,lj) index do not belongs to lead1 interface");
  if (i2<0 || i2>=p_sys->lead_size(lead2)) ERROR("in sew::getG_LL(i,li,j,lj) index do not belongs to lead2 interface");
#endif
  return arr2micro<Tmicromatrix>(GFLL(lead1,lead2)(i1,ALL,i2,ALL));
};

// get self energy SE for lead -li- with lead indexes -i- and -j-
template<class Tmicromatrix>
inline Tmicromatrix sew<Tmicromatrix>::getSE(int i,int j,int li) const {
#ifdef _DEBUG_
  if (li<0 || li>=p_sys->fNres()) ERROR("in sew::getSE(i,j,li) lead index is out of range");
  if (i<0 || i>=p_sys->lead_size(li)) ERROR("in sew::getSE(i,j,li) index i do not belongs to lead interface");
  if (j<0 || j>=p_sys->lead_size(li)) ERROR("in sew::getSE(i,j,li) index j do not belongs to lead interface");
#endif
  return arr2micro<Tmicromatrix>(SE(li)(i,ALL,j,ALL));
};


// ** Or update
// if Os is not in the left interface
// we use a trick we write gf(Os,ALL), gf(ALL,Os) and gf(Os,Os) to size+1 line of kn.GF and then define Or constant that would point to this line, if Os does not belongs to the left interface then we recover data from SAV variable: one should then use Or variable as Os
// Or - is GF index of left interface posL if Os exists and it is (size+1) site if it does not; r - as recovery
// dependance on gf
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateOr(){
  Or = (posL.s2g(Os)>=0) ? posL.s2g(Os) : posL.ftaille();
  if (posL.s2g(Os) == Or) return; // no copying needed
  // ** copy recovered values into size+1 indexes
  if (posL.s2g(Os)<0){
#ifdef _DEBUG_
    if ( kn.SAV.mapG_NN.find(Os) == kn.SAV.mapG_NN.end() ) ERROR("in sew.backward(): Os that does not belongs to the interface is not in SAV.mapG_NN");
    if ( kn.SAV.mapG_Na.find(Os) == kn.SAV.mapG_Na.end() ) ERROR("in sew.backward(): Os that does not belongs to the interface is not in SAV.mapG_Na");
    if ( kn.SAV.mapG_aN.find(Os) == kn.SAV.mapG_aN.end() ) ERROR("in sew.backward(): Os that does not belongs to the interface is not in SAV.mapG_aN");
#endif
    // positions correspond to the system without last site (posL_new)
    const Array<COMPLEX,2>& G_NN = kn.SAV.mapG_NN.find(Os)->second;
    const GF_type& G_aN=kn.SAV.mapG_aN.find(Os)->second;
    const GF_type& G_Na=kn.SAV.mapG_Na.find(Os)->second;
    for (int i_old=0; i_old<posL.ftaille();++i_old) { // for every posL
      const int i_new=posL_new.s2g(posL.g2s(i_old));
#ifdef _DEBUG_
      if (i_new<0) ERROR("in sew.backward(): for recovering case posL_new > posL, so i_new should always be well defined (>=0)");
      if (Or < posL.ftaille() ) ERROR("in sew.backward(): for recovering case recovering site is overwriting existing values ");
#endif      
      gf(Or,ALL,i_old,ALL)=G_Na(0,ALL,i_new,ALL); // small (new) position variables are used in G_Na
      gf(i_old,ALL,Or,ALL)=G_aN(i_new,ALL,0,ALL); // small (new) position variables are used in G_aN
    };
    gf(Or,ALL,Or,ALL)=G_NN;
  };
  return;
};


// Gless calculations
// ** Gless(l)(Os,z) = G_{Os,a_l} \Sigma_less^(l)_{a_l,b_l} G^H_{voisin(Os,z),b_l}
// ** Gless(l)(Os,zmax) = G_{Os,a_l} \Sigma_less^(l)_{a_l,b_l} G^H_{Os,b_l}
// we take \Sigma_less^(l)_{a_l,b_l}= \Sigma_{a_l,b_l} - \Sigma^(H)_{a_l,b_l} where \Sigma is a self energy for the lead -l-
// Gless calculations are made so it function also for zero size right position
// dependance on GFIL GFOL SE
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateGless(){
  for (int l=0;l<p_sys->fNres();l++) {// for every lead
    GF_type tmpGFsite(1,MicroDim,1,MicroDim); tmpGFsite=0.;
    matmul3_blas(GFOL(l),SE(l),GFOL(l),tmpGFsite,'n','n','c');
    Gless(l)(Os,ALL,p_sys->fzmax(),ALL) =  tmpGFsite(0,ALL,0,ALL);
    tmpGFsite.transposeSelf(thirdDim,fourthDim,firstDim,secondDim);
    Gless(l)(Os,ALL,p_sys->fzmax(),ALL) = conj(tmpGFsite(0,ALL,0,ALL));
    const map<int,int> interface=posR.interface(Os); // get right interface of site -Os- <z_fromOs,right_GFind>  
    for (map<int,int>::const_iterator vR=interface.begin(); vR!=interface.end();++vR){
      GF_type GFvL(GFIL(l)(Range(vR->second,vR->second),ALL,ALL,ALL));
      GF_type tmpGFelem(1,MicroDim,1,MicroDim); tmpGFelem=0.;
      matmul3_blas(GFOL(l),SE(l),GFvL,tmpGFelem,'n','n','c');
      Gless(l)(Os,ALL,vR->first,ALL)  = tmpGFelem(0,ALL,0,ALL); 
      matmul3_blas(GFOL(l),SE(l),GFvL,tmpGFelem,'n','c','c');
      Gless(l)(Os,ALL,vR->first,ALL) -= tmpGFelem(0,ALL,0,ALL);// Gless(Os,vs)
      Gless(l)(p_sys->voisin(Os,vR->first),ALL,p_sys->z_voisin(Os,vR->first),ALL) 
	=  -conj(Gless(l)(Os,ALL,vR->first,ALL).transpose(secondDim,firstDim)); // Gless(vs,Os)
    };
  };
  return;
};

// full GF (not Keldysh) Os-elements copying
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateGnotK(const GF_type& GFO, const GF_type& OGF){
  // GnotK onsite calculations
  GnotK(Os,ALL,p_sys->fzmax(),ALL) = GFOO(0,ALL,0,ALL);
  // GnotK for nearest neighbors are copied from OGF
  map<int,int> interface=posR.interface(Os); // get right interface of site -Os- <z_fromOs,right_GFind>  
  for (map<int,int>::const_iterator vR=interface.begin(); vR!=interface.end();++vR){
    GnotK(Os,ALL,vR->first,ALL) = OGF(0,ALL,vR->second,ALL); // G_Os_voisin 
    GnotK(p_sys->voisin(Os,vR->first),ALL,p_sys->z_voisin(Os,vR->first),ALL) // G_voisin_Os
      = GFO(vR->second,ALL,0,ALL);
  };      
  return;
};


// calculation of GFO and OGF for right leads
// ** G_{Os,a_r} and G_{a_r,Os}    a_r - are all the right position sites
//  G_{a_r,Os}= \sum_{j_r} G_{a_r,j_r}*Vg_{j_r} - vector GFO
//  G_{Os,a_r}= \sum_{j_r} gV_{j_r}*G_{j_r,a_r} - line OGF
// where gV and Vg are defined as following:
// Vg_{j_r} = \sum_{i_l} V_{j_r,i_l} * g_{i_l,Os}  - is the right interface contiguous vector of minimal size
// gV_{j_r} = \sum_{i_l} g_{Os,i_l} * V_{i_l,j_r} - is the right interface contiguous line(conjugate vector) of minimal size
// GFO, OGF calculations are made so it function also for zero size right position
// dependance on gf, GF
template<class Tmicromatrix>
void sew<Tmicromatrix>::getOright(GF_type& GFO, GF_type& OGF) const{
  // first step
  // ** gV and Vg calculations
  // Vg_{j_r} = \sum_{i_l} V_{j_r,i_l} * g_{i_l,Os}  - is the right interface contiguous vector of minimal size
  // gV_{j_r} = \sum_{i_l} g_{Os,i_l} * V_{i_l,j_r} - is the right interface contiguous line(conjugate vector) of minimal size
  // j_r vary from first lead's site that belongs to the right interface to last right position site 
  // gV_{j_r} and Vg_{j_r} are set to -0- for all j_r that do not belong to the interface
  // gV, Vg calculations are made so it function also for zero size right position
  GF_type gV,Vg;
  int first_GFind=posR.ftaille(); // first GFindex that belongs to the right interface
  for (int jR=0; jR<posR.ftaille();++jR)
    if  ( posR.nv_g(jR) != 0 ) {
      first_GFind=jR; // set first GF index
      break; // break for loop
    };
  Vg.resize(posR.ftaille()-first_GFind, MicroDim, 1, MicroDim); // vector
  gV.resize(1, MicroDim, posR.ftaille()-first_GFind,MicroDim);  // line
  // initialize to zero
  Vg=COMPLEX(0.); gV=COMPLEX(0.); 
  for (int jR=first_GFind; jR<posR.ftaille();++jR){
    if (posR.nv_g(jR) == 0 ) continue;// for not interface sites gV=Vg=0 was already set
    else {
      // note that Vg(gV) indexes are offset by first_GF_ind
      Array<COMPLEX,2> Vg_elem=Vg(jR-first_GFind,ALL,0,ALL); // reference to Vg element
      Array<COMPLEX,2> gV_elem=gV(0,ALL,jR-first_GFind,ALL); // reference to gV element
      const int sjR=posR.g2s(jR); // system index of the site for which we calculate Vg
      const map<int,int> interface=posL.interface(sjR); // get left interface of site -jR- <z,left_GFind>
      for (map<int,int>::const_iterator iL=interface.begin(); iL!=interface.end();++iL){ 
	const Array<COMPLEX,2>& V_jR_iL=p_sys->Mvoisin(sjR,iL->first).micro2arr();
	plus_matmul( V_jR_iL, gf(iL->second,ALL,Or,ALL), Vg_elem);
	const Array<COMPLEX,2>& V_iL_jR=p_sys->Mvoisin(sjR,iL->first).hconjugate().micro2arr();
	plus_matmul( gf(Or,ALL,iL->second,ALL), V_iL_jR, gV_elem);
      };
    };
  };
  // Vg, gV are constructed

  //GFO OGF calculations
  OGF.resize(1,MicroDim,posR.ftaille(),MicroDim); OGF=0.; // OGF is a GF between Os and right position
  GFO.resize(posR.ftaille(),MicroDim,1,MicroDim); GFO=0.; // GFO is a GF between right position and Os
  // matmul_blas does nothing for zero size arrays
  matmul_blas( gV, 
	       subArray<COMPLEX,4>(GF,shape(first_GFind,0,0,0), (posR.ftaille()-first_GFind)*MicroDim, posR.ftaille()*MicroDim), 
	       OGF );
  matmul_blas( subArray<COMPLEX,4>(GF,shape(0,0,first_GFind,0), posR.ftaille()*MicroDim, (posR.ftaille()-first_GFind)*MicroDim), 
	       Vg, 
	       GFO );

#ifdef _DEBUG_VERY_LONG_ 
  // DIRECT INVERSION COMPARISON
  for (int iR=0; iR<posR.ftaille();++iR){
    if (dGF.extent(0) != p_sys->fsize()) break; // do nothing if dGF was not initialized
    const int siR=posR.g2s(iR); // system index of iR
    if  ( ! is_equal( GFO(iR,ALL,0,ALL), dGF(siR,ALL,Os,ALL))) ERROR("in sew.getOright(): comparision of calculated GF(GFO) with one obtained using direct inversion failed");
    if  ( ! is_equal( OGF(0,ALL,iR,ALL), dGF(Os,ALL,siR,ALL))) ERROR("in sew.getOright(): comparison of calculated GF(OGF) with one obtained using direct inversion failed");
  };
#endif //_DEBUG_VERY_LONG_

#ifdef _DEBUG_ // for lead sites compare calculated value with one obtained during forward knitting 
  // different scenarios depending on wether Os belong to any lead, and if this lead is to be sewed
  const int del_lead = p_sys->sys2res(Os);
  const int li_Os = p_sys->sys2res_ind(Os);
  if (del_lead != sys_inf::not_lead) {
    for (int iR=0; iR<posR.ftaille();++iR){
      const int siR=posR.g2s(iR); // system index of iR
      const int l=p_sys->sys2res(siR); // lead to which belong's iR
      const int li=p_sys->sys2res_ind(siR);// lead index of iR
      if (l == sys_inf::not_lead) continue; // not for lead's sites there is no information to compare with
      if  ( ! is_equal( GFO(iR,ALL,0,ALL), GFLL(l,del_lead)(li,ALL,li_Os,ALL)))
  	ERROR("in sew.getOright(): lead sites compare of calculated GF(GFO) with one obtained during forward knitting failed");
      if  ( ! is_equal( OGF(0,ALL,iR,ALL), GFLL(del_lead,l)(li_Os,ALL,li,ALL)))
  	ERROR("in sew.getOright(): lead sites compare of calculated GF(OGF) with one obtained during forward knitting failed");
    };
  };
#endif
  return;
};


// calculation of GFOL, GFLO for all leads and onsite GFOO
// for right lead just copy saved in OGF and GFO data, for left lead use:
// ** G_{Os,a_l} and G_{a_l,Os}    a_l - is the left leads site
//  G_{a_l,Os}= g_{a_l,Os} + \sum_{i_l,j_l} g_{a_l,i_l}*SI_{i_l,j_l}*g_{j_l,Os} - vector
//  G_{Os,a_l}= g_{Os,a_l} + \sum_{i_l,j_l} g_{Os,i_l}*SI_{i_l,j_l}*g_{j_l,a_l} - line
// where gSI and SIg are defined as following
// SIg_{j_l} = \sum_{i_l} SI_{j_l,i_l} * g_{i_l,Os}  - is the left interface contiguous vector of minimal size
// gSI_{j_l} = \sum_{i_l} g_{Os,i_l} * SI_{i_l,j_l} - is the left interface contiguous line(conjugate vector) of minimal size
// GFOL, GFLO calculations are made so it function also for zero size right position
// dependance on GFO, OGF, SI, gf
template<class Tmicromatrix>
void sew<Tmicromatrix>::getOlead(const GF_type& GFO, const GF_type& OGF){
  // preliminairy calculations
  // ** gSI and SIg calculations
  // SIg_{j_l} = \sum_{i_l} SI_{j_l,i_l} * g_{i_l,Os}  - is the left interface contiguous vector of minimal size
  // gSI_{j_l} = \sum_{i_l} g_{Os,i_l} * SI_{i_l,j_l} - is the left interface contiguous line(conjugate vector) of minimal size
  // j_l vary from first lead's site that belongs to the left interface to last left position site 
  // gSI_{j_l} and SIg_{j_l} are set to -0- for all j_l that do not belong to the interface
  // gSI, SIg calculations are made so it function also for zero size right position
  int first_FGind=posL.ftaille(); // first GFindex that belongs to the left interface
  for (int jL=0; jL<posL.ftaille();++jL)
    if  ( posL.nv_g(jL) != 0 ) {
      first_FGind=jL; // set first GF index for left interface
      break; // break for loop
    };
  GF_type SIg(posL.ftaille()-first_FGind, MicroDim, 1, MicroDim); // vector
  GF_type gSI(1, MicroDim, posL.ftaille()-first_FGind,MicroDim);  // line
  GF_type gfOs(gf(Range(first_FGind,posL.ftaille()-1), ALL, Range(Or,Or), ALL). copy()); // minimal contiguous copy of gf_{interface,Os}
  GF_type Osgf(gf(Range(Or,Or), ALL, Range(first_FGind,posL.ftaille()-1), ALL). copy()); // minimal contiguous copy of gf_{Os,interface}
  // initialize to zero all gfOs(i_l) and Osgf(i_l) for all i_l that do not belong to the interface
  for (int jL=first_FGind; jL<posL.ftaille();++jL) if (posL.nv_g(jL) == 0 )  // gfOs and Osgf indexes are offset by first_FGind
    {Osgf(0,ALL,jL-first_FGind,ALL)=COMPLEX(0.);gfOs(jL-first_FGind,ALL,0,ALL)=COMPLEX(0.);}// for not interface sites set gfOs=Osgf=0
  matmul_blas( Osgf, 
	       subArray<COMPLEX,4>(SI,shape(first_FGind,0,first_FGind,0), (posL.ftaille()-first_FGind)*MicroDim), 
	       gSI );
  matmul_blas( subArray<COMPLEX,4>(SI,shape(first_FGind,0,first_FGind,0), (posL.ftaille()-first_FGind)*MicroDim), 
	       gfOs, 
	       SIg );
  // initialize to zero all SIg(i_l) and gSI(i_l) for all i_l that do not belong to the interface
  for (int jL=first_FGind; jL<posL.ftaille();++jL) if (posL.nv_g(jL) == 0 )  // gSI and SIg indexes are offset by first_FGind
    {gSI(0,ALL,jL-first_FGind,ALL)=COMPLEX(0.);SIg(jL-first_FGind,ALL,0,ALL)=COMPLEX(0.);}// for not interface sites set gSI=SIg=0

  // calculation of GFOL and GFLO for all leads
  // for right lead just copy saved in OGF and GFO data, for left lead use:
  // ** G_{Os,a_l} and G_{a_l,Os}    a_l - is the left leads site
  //  G_{a_l,Os}= g_{a_l,Os} + \sum_{i_l,j_l} g_{a_l,i_l}*SI_{i_l,j_l}*g_{j_l,Os} - vector
  //  G_{Os,a_l}= g_{Os,a_l} + \sum_{i_l,j_l} g_{Os,i_l}*SI_{i_l,j_l}*g_{j_l,a_l} - line
  // GFOL, GFLO calculations are made so it function also for zero size right position
  for (int l=0;l<p_sys->fNres();l++) {// for every lead
    if (posL.flead2order(l) == sys_inf::not_lead) {// for right lead copy saved in GFO and OGF data
      const int offset=posR.flead_offset(l);
      const int last_site=offset+p_sys->lead_size(l)-1;
      GFOL(l)(0,ALL,ALL,ALL)=OGF(0,ALL,Range(offset,last_site),ALL);
      GFLO(l)(ALL,ALL,0,ALL)=GFO(Range(offset,last_site),ALL,0,ALL);
    }
    else{// for left lead first set G_{a_l,Os}= g_{a_l,Os} and then add missing sum using SIg and gSI data
      const int offset=posL.flead_offset(l);
      const int last_site=offset+p_sys->lead_size(l)-1;
      GFOL(l)(0,ALL,ALL,ALL)=gf(Or,ALL,Range(offset,last_site),ALL);
      GFLO(l)(ALL,ALL,0,ALL)=gf(Range(offset,last_site),ALL,Or,ALL);
      if (posR.ftaille()!=0){ // do nothing for zero size right position
	matmul_blas( gSI, 
		     subArray<COMPLEX,4>(gf,shape(first_FGind,0,offset,0), (posL.ftaille()-first_FGind)*MicroDim, p_sys->lead_size(l)*MicroDim), 
		     GFOL(l),
		     COMPLEX(1.), COMPLEX(1.) );
	matmul_blas( subArray<COMPLEX,4>(gf,shape(offset,0,first_FGind,0), p_sys->lead_size(l)*MicroDim, (posL.ftaille()-first_FGind)*MicroDim), 
		     SIg, 
		     GFLO(l),
		     COMPLEX(1.), COMPLEX(1.) );
      };
    };
  };
  
  // GFOO onsite calculations
  GFOO(0,ALL,0,ALL) = gf(Or,ALL,Or,ALL);
  matmul_blas( Osgf, SIg, GFOO, COMPLEX(1.), COMPLEX(1.));

#ifdef _DEBUG_VERY_LONG_ 
  // DIRECT INVERSION COMPARISON
  if (dGF.extent(0) == p_sys->fsize()) // only if dGF was initialized
    if  ( ! is_equal( GFOO(0,ALL,0,ALL), dGF(Os,ALL,Os,ALL)))
      ERROR("in sew.getOlead(): comparision of calculated GF(GFOO) with one obtained using direct inversion failed");
#endif //_DEBUG_VERY_LONG_


#ifdef _DEBUG_ // for lead sites compare calculated value with one obtained during forward knitting 
  const int del_lead = p_sys->sys2res(Os);
  const int li_Os = p_sys->sys2res_ind(Os);
  if (del_lead != sys_inf::not_lead)   // for Os that belong to any lead
    if  ( ! is_equal( GFOO(0,ALL,0,ALL), GFLL(del_lead,del_lead)(li_Os,ALL,li_Os,ALL)))
      ERROR("in sew.getOlead(): lead sites compare of calculated GF (GFOO) with one obtained during forward knitting failed");
#endif

  return;
};



// ** update GF ( full GF of right interface) new right position is used
// update GF are made so it functions also for zero size right position
//dependance on GFO, OGF and GFOO
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateGF(const GF_type& GFO,const GF_type& OGF){
  // reindex GF matrix for right position using new GFidexes
  // only element with changed GFindexes are updated
  reindex(posR_new,posR,GF);
  // update GF for lastly added site Os
  for (int i_new=0; i_new<posR_new.ftaille();++i_new){
    const int Ogn=posR_new.s2g(Os); // new GFindex of Os
    if (Ogn < 0) break;// stop loop if Os site does not belongs to the new position
    if (i_new == Ogn) GF(Ogn,ALL,Ogn,ALL)=GnotK(Os,ALL,p_sys->fzmax(),ALL);// onsite element
    else{// all other elements
      const int i_old=posR.s2g(posR_new.g2s(i_new));
      GF(Ogn,ALL,i_new,ALL)=OGF(0,ALL,i_old,ALL);
      GF(i_new,ALL,Ogn,ALL)=GFO(i_old,ALL,0,ALL);
    };
  };
 return;
};

// ** update SI ("self energy" of the right interface)
// definition SI_{i_l,j_l} = \sum_{i_r,j_r} V_{i_l,j_r}*G_{j_r,i_r}*V_{i_r,j_l}
// update SI are made so it function also for zero size right position
// dependance on updated (new) GF of right interface
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateSI(){
  // if neither i_l nor j_l are not the nearest neighbors of Os then SI is the same
  // if one of i_l or j_l is the nearest neighbors of Os then SI is modified
  // SInew_{i_l,j_l} =
  // = SI_{i_l,j_l} +\sum_{i_r, no Os} [V_{i_l,Os}*G_{Os,i_r}*V_{i_r,j_l} + V_{i_l,i_r}*G_{i_r,Os}*V_{Os,j_l}]+V_{i_l,Os}*G_{Os,Os}*V_{Os,j_l}
  // we will separate update of SI in few steps
  // SInew_{i_l,j_l} = SI_{i_l,j_l} + V_{i_l,Os}*GV_{j_l} + VG_{i_l}*V_{Os,j_l} + V_{i_l,Os}*G_{Os,Os}*V_{Os,j_l}
  // first SInew_{i_l,j_l} = SI_{i_l,j_l} reindex common parts of SI
  // then calculate GV, VG and 
  // finally add all together

  // Os is the only site that does not belongs to new left interface anymore => 
  // * set SI_{Os,i_l}=SI_{j_l,Os}=SI_{Os,Os}=0, 
  if (posL.s2g(Os)>0) { // if Os was part of old left interface
    SI(posL.s2g(Os), ALL, ALL,          ALL)=COMPLEX(0.); 
    SI(ALL,          ALL, posL.s2g(Os), ALL)=COMPLEX(0.);
  };


  // * reindex common part of SI
  // update SI matrix for right position using new GFidexes
  // only element with changed GFindexes are needed to be updated
  reindex(posL_new,posL,SI);


  // for all "new" sites of left interface 
  // * set SI_{new,i_l}=SI_{j_l,new}=SI_{new,new}=0, 
  for (int z=0; z<p_sys->fzmax();++z){ // for all neighbors of Os
    const int vis=p_sys->voisin(Os,z); // system index of voisin of Os 
    if (vis == sys_inf::outsample) continue; // if voisin is outsample do nothing
    // if voisin was not part of old left interface and belong to the new one 
    // set to zero corresponding SI values
    if (posL_new.s2g(vis)>=0 && posL.s2g(vis)<0) { 
      SI(posL_new.s2g(vis), ALL, ALL,          ALL)=COMPLEX(0.); 
      SI(ALL,          ALL, posL_new.s2g(vis), ALL)=COMPLEX(0.);
    };
  };

  // * recalculate SI for all nearest neighbors of Os, that are part of new left interface

  // first we construct line GV and vector VG using new left interface indexes
  // GV_{j_l}=\sum_{i_r, no Os} G_{Os,i_r}*V_{i_r,j_l}
  // VG_{j_l}=\sum_{i_r, no Os} V_{j_l,i_r}*G_{i_r,Os}
  GF_type VG(posL_new.ftaille(), MicroDim, 1, MicroDim); // vector
  GF_type GV(1, MicroDim, posL_new.ftaille(), MicroDim); // line
  // initialize to zero
  VG=COMPLEX(0.); GV=COMPLEX(0.); 
  for (int jL=0; jL<posL_new.ftaille();++jL){
    const int Ogn=posR_new.s2g(Os); // new right GF index of Os 
    if (Ogn<0) break; // VG and GV are set to zero if Os do not belongs to the new right interface 
    if (posL_new.nv_g(jL) == 0 ) continue;// for non interface sites GV=VG=0 was already set
    else {
      Array<COMPLEX,2> VG_elem=VG(jL,ALL,0,ALL); // reference to VG element
      Array<COMPLEX,2> GV_elem=GV(0,ALL,jL,ALL); // reference to GV element
      const int sjL=posL_new.g2s(jL); // system index of the site for which we calculate VG
      const map<int,int> interface=posR_new.interface(sjL); // get right interface of site -jL- <z,right_GFind>
#ifdef _DEBUG_
      if (interface.size()==0) ERROR("in sew.backward() the interface should not be empty");
#endif
      for (map<int,int>::const_iterator iR=interface.begin(); iR!=interface.end();++iR){ 
	if (posR_new.g2s(iR->second) == Os) continue; // exclude Os from sum
	const Array<COMPLEX,2>& V_jL_iR=p_sys->Mvoisin(sjL,iR->first).micro2arr();
	plus_matmul( V_jL_iR, GF(iR->second,ALL,Ogn,ALL), VG_elem);
	const Array<COMPLEX,2>& V_iR_jL=p_sys->Mvoisin(sjL,iR->first).hconjugate().micro2arr();
	plus_matmul( GF(Ogn,ALL,iR->second,ALL), V_iR_jL, GV_elem);
      };
    };
  };  

  //* SInew_{i_l,j_l} = SI_{i_l,j_l} + V_{i_l,Os}*GV_{j_l} + VG_{i_l}*V_{Os,j_l} + V_{i_l,Os}*G_{Os,Os}*V_{Os,j_l}
  const map<int,int> interface1=posL_new.interface(Os); // get new left interface of site -Os- <z,left_GFind>
  const int Ogn=posR_new.s2g(Os); // new right GF index of Os 
  for (map<int,int>::const_iterator iL=interface1.begin(); iL!=interface1.end();++iL){ 
    if (Ogn<0) break; // if Os do not belongs to the new right interface stop 
    GF_type V_Os_iL(1,MicroDim,1,MicroDim);
    V_Os_iL(0,ALL,0,ALL)=p_sys->Mvoisin(Os,iL->first).micro2arr();
    matmul_blas(subArray<COMPLEX,4>(VG), subArray<COMPLEX,4>(V_Os_iL), 
		subArray<COMPLEX,4>(SI,shape(0,0,iL->second,0),posL_new.ftaille()*MicroDim,MicroDim),
		COMPLEX(1.),COMPLEX(1.));
    GF_type V_iL_Os(1,MicroDim,1,MicroDim);
    V_iL_Os(0,ALL,0,ALL)=p_sys->Mvoisin(Os,iL->first).hconjugate().micro2arr();
    matmul_blas( subArray<COMPLEX,4>(V_iL_Os),subArray<COMPLEX,4>(GV), 
		 subArray<COMPLEX,4>(SI,shape(iL->second,0,0,0),MicroDim,posL_new.ftaille()*MicroDim),
		 COMPLEX(1.),COMPLEX(1.));
    const map<int,int> interface2=posL_new.interface(Os); // get new left interface of site -Os- <z,left_GFind>
    for (map<int,int>::const_iterator jL=interface2.begin(); jL!=interface2.end();++jL){ 
      GF_type V_Os_jL(1,MicroDim,1,MicroDim);
      V_Os_jL(0,ALL,0,ALL)=p_sys->Mvoisin(Os,jL->first).micro2arr();
	SI(iL->second,ALL,jL->second,ALL) += matmul(V_iL_Os(0,ALL,0,ALL), GF(Ogn,ALL,Ogn,ALL), V_Os_jL(0,ALL,0,ALL));
    };
  };
  //finished update of SI
  return;
};


// ** update GFLI ( full GF of right interface) new right position is used
// update GF are made so it functions also for zero size right position
//dependance on GFLO, GFOL
template<class Tmicromatrix>
void sew<Tmicromatrix>::updateGFLI(){
  // reindex GFLI and GFIL matrixes for right position using new GFidexes
  // only element with changed GFindexes are updated
  for (int l=0; l<p_sys->fNres();++l){ // for each lead
    reindex_second(posR_new,posR,GFLI(l));
    reindex_first(posR_new,posR,GFIL(l));
  };
  const int Ogn=posR_new.s2g(Os); // new GFindex of Os
  if (Ogn < 0) return;// do nothing else if Os site does not belongs to the new position
  // update GFLI and GFIL for lastly added site Os
  for (int l=0; l<p_sys->fNres();++l){ // for each lead
    GFIL(l)(Ogn,ALL,ALL,ALL)=GFOL(l)(0,ALL,ALL,ALL);
    GFLI(l)(ALL,ALL,Ogn,ALL)=GFLO(l)(ALL,ALL,0,ALL);
  };
 return;
};



// ** update GF ( full GF of right interface) when sewing lead -del_lead-;  new right position is used
// update GF are made so it functions also for zero size right position
//dependance on GF, gf
template<class Tmicromatrix>
void sew<Tmicromatrix>::lead_updateGF(int del_lead){
  // calculate GF between new right inner interface and lead -del_lead- (GFlead, leadGF)
  // first step 
  // ** gV and Vg calculations analoguous to those of getOright
  // Vg_{j_r,a} = \sum_{i_l} V_{j_r,i_l} * g_{i_l,a}  - is the (right interface,del_lead) contiguous matrix of minimal first dimension (right interface size)
  // gV_{a,j_r} = \sum_{i_l} g_{a,i_l} * V_{i_l,j_r} - is the (del_lead, right interface) contiguous matrix of minimal second dimension (right interface size)
  // j_r vary from first lead's site that belongs to the right interface to last right position site 
  // gV_{ALL,j_r} and Vg_{j_r,ALL} are set to -0- for all j_r that do not belong to the interface
  // gV, Vg calculations are made so it function also for zero size right position
  GF_type gV,Vg;
  int first_GFind=posR.ftaille(); // first GFindex that belongs to the right interface
  for (int jR=0; jR<posR.ftaille();++jR)
    if  ( posR.nv_g(jR) != 0 ) {
      first_GFind=jR; // set first GF index
      break; // break for loop
    };
  Vg.resize(posR.ftaille()-first_GFind, MicroDim, p_sys->lead_size(del_lead), MicroDim); 
  gV.resize(p_sys->lead_size(del_lead), MicroDim, posR.ftaille()-first_GFind,MicroDim);  
  // initialize to zero
  Vg=COMPLEX(0.); gV=COMPLEX(0.);
  for (int jR=first_GFind; jR<posR.ftaille();++jR){
    if (posR.nv_g(jR) == 0 ) continue;// for not interface sites gV=Vg=0 was already set
    else {
      // note that Vg(gV) indexes are offset by first_GF_ind
      Range lead_r=posL.lead_range(del_lead); // lead range for deleted lead in left position
      GF_type Vg_row(1,MicroDim,Vg.extent(2),MicroDim); Vg_row=0.;// reference to Vg line
      GF_type gV_col(gV.extent(0),MicroDim,1,MicroDim); gV_col=0.;// reference to gV row
      const int sjR=posR.g2s(jR); // system index of the site for which we calculate Vg
      const map<int,int> interface=posL.interface(sjR); // get left interface of site -jR- <z,left_GFind>
      for (map<int,int>::const_iterator iL=interface.begin(); iL!=interface.end();++iL){ 
	GF_type V_jR_iL(1,MicroDim,1,MicroDim);
	V_jR_iL(0,ALL,0,ALL)=p_sys->Mvoisin(sjR,iL->first).micro2arr();
	const GF_type temp_gf_row = gf(Range(iL->second,iL->second),ALL,lead_r,ALL).copy(); // contiguous copy of gf
	const GF_type temp_gf_col = gf(lead_r,ALL,Range(iL->second,iL->second),ALL).copy(); // contiguous copy of gf
	matmul_blas(V_jR_iL, temp_gf_row, Vg_row,COMPLEX(1.),COMPLEX(1.));
	GF_type V_iL_jR(1,MicroDim,1,MicroDim);
	V_iL_jR(0,ALL,0,ALL)=p_sys->Mvoisin(sjR,iL->first).hconjugate().micro2arr();
	matmul_blas( temp_gf_col, V_iL_jR, gV_col,COMPLEX(1.),COMPLEX(1.));
      };
      Vg(jR-first_GFind,ALL,ALL,ALL)=Vg_row(0,ALL,ALL,ALL); // write to Vg line
      gV(ALL,ALL,jR-first_GFind,ALL)=gV_col(ALL,ALL,0,ALL);  // write to gV row
    };
  };
  // Vg, gV are constructed

  //GFlead leadGF calculations
  GF_type leadGF(p_sys->lead_size(del_lead),MicroDim,posR.ftaille(),MicroDim);  // leadGF is a GF between del lead and right position
  GF_type GFlead(posR.ftaille(),MicroDim,p_sys->lead_size(del_lead),MicroDim);  // GFO is a GF between right position and del_lead
  // matmul_blas does nothing for zero size arrays
  matmul_blas( gV, 
	       subArray<COMPLEX,4>(GF,shape(first_GFind,0,0,0), (posR.ftaille()-first_GFind)*MicroDim, posR.ftaille()*MicroDim), 
	       leadGF );
  matmul_blas( subArray<COMPLEX,4>(GF,shape(0,0,first_GFind,0), posR.ftaille()*MicroDim, (posR.ftaille()-first_GFind)*MicroDim), 
	       Vg, 
	       GFlead );

  //GFlead, leadGF are constructed (posL index is used)

  // reindex GF matrix for right position using new GFidexes
  // only element with changed GFindexes are updated
  reindex(posR_new,posR,GF);

  // update GF for the lead -del_lead-
  const Range lead_r=posR_new.lead_range(del_lead);
  GF(lead_r,ALL,lead_r,ALL)=GFLL(del_lead,del_lead)(ALL,ALL,ALL,ALL);// diagonal lead-lead elements
  // lead-right_interface are recovered from GFlead, leadGF matrixes
  for (int i_new=0; i_new<posR_new.ftaille();++i_new){
    const int i_lead=p_sys->sys2res(posR_new.g2s(i_new)); // to which lead is connected i_new 
    if ( i_lead == del_lead) continue;// if i_new is connected to the del_lead then do nothing this value were already set
    else{// all other elements
      const int i_old=posR.s2g(posR_new.g2s(i_new));
      GF(lead_r,ALL,i_new,ALL)=leadGF(ALL,ALL,i_old,ALL);
      GF(i_new,ALL,lead_r,ALL)=GFlead(i_old,ALL,ALL,ALL);
    };
  };
 return;
};


// ** update SI ("self energy" of the right interface)
// definition SI_{i_l,j_l} = \sum_{i_r,j_r} V_{i_l,j_r}*G_{j_r,i_r}*V_{i_r,j_l}
// update SI are made so it function also for zero size right position
// dependance on updated (new) GF of right interface
template<class Tmicromatrix>
void sew<Tmicromatrix>::lead_updateSI(int del_lead){
  // if neither i_l nor j_l are not the nearest neighbors of the del_lead then SI are the same
  // if one of i_l or j_l is the nearest neighbors of del_lead then SI are modified, we recalculate them using definition

  // all del lead's is the only site that does not belongs to new left interface anymore => 
  // * set SI_{li,i_l}=SI_{j_l,li}=SI_{li,lj}=0, for il \in del_lead 
  for (int li=0;li<p_sys->lead_size(del_lead);++li) { // for all elements of del lead
    const int sil=p_sys->res2sys(del_lead,li); //  system index for lead's sites
#ifdef _DEBUG_
    if (posL.s2g(sil)<0) ERROR("in lead_updateSI: all lead's sites should belong to left interface when delete lead");
#endif
    SI(posL.s2g(sil), ALL, ALL,          ALL)=0.; 
    SI(ALL,          ALL, posL.s2g(sil), ALL)=0.;
  };

  // * reindex common part of SI
  // update SI matrix for right position using new GFidexes
  // only element with changed GFindexes are needed to be updated
  reindex(posL_new,posL,SI);

  // * recalculate SI for all nearest neighbors of del_lead, that are part of new left interface
  // we are using definition of SI:
  // SI_{i_l,j_l} = \sum_{i_r,j_r} V_{i_l,j_r}*G_{j_r,i_r}*V_{i_r,j_l}

  // first find a list of sites that should be modified
  set<int> sys_ind_set; //set of system indexes for whick SI should be recalculated
  for (int jL=0; jL<posL_new.ftaille();++jL){
    if (posL_new.nv_g(jL) == 0) continue; // for non interface sites do nothing
    for (int z=0; z<p_sys->fzmax();++z){
      const int vsi=p_sys->voisin(posL_new.g2s(jL),z); // voisin system index
      if (vsi == sys_inf::outsample) continue;
      if (p_sys->sys2res(vsi) == del_lead) sys_ind_set.insert(posL_new.g2s(jL));
    };
  };
  // SI(mod_index,all_index)
  for (set<int>::const_iterator piL=sys_ind_set.begin();piL!=sys_ind_set.end();++piL){ // for all this index SI is recalculated
    const int siL=*piL; // system index of iL
    const int iL= posL_new.s2g(siL); // new GF index of iL
    for (int jL=0; jL<posL_new.ftaille();++jL){ // all interface sites of SI
      if (posL_new.nv_g(jL) == 0) continue; // for non interface sites do nothing
      const int sjL=posL_new.g2s(jL); // system index of jL
      // set initial value to zero for recalculated element 
      SI(iL,ALL,jL,ALL) = COMPLEX(0.); 
      // reference to modified elements of SI
      Array<COMPLEX,2> SI_iL_jL= SI(iL,ALL,jL,ALL);
      for (int zi=0; zi<p_sys->fzmax();++zi){
	const int svi = p_sys->voisin(siL,zi); // system index of voisin iL
	if ( svi == sys_inf::outsample || posR_new.s2g(svi) < 0) continue;  // if this nn does not belong to new right position then do nothing
	const Array<COMPLEX,2>& V_iL_iR=p_sys->Mvoisin(siL,zi).micro2arr();
	for (int zj=0; zj<p_sys->fzmax();++zj){
	  const int svj = p_sys->voisin(sjL,zj); // system index of voisin jL
	  if ( svj == sys_inf::outsample || posR_new.s2g(svj) < 0) continue;  // if this nn does not belong to new right position then do nothing
	  const Array<COMPLEX,2>& V_jR_jL=p_sys->Mvoisin(sjL,zj).hconjugate().micro2arr();
	  const Array<COMPLEX,2> GV_jR_jL = matmul(GF(posR_new.s2g(svi),ALL,posR_new.s2g(svj),ALL), V_jR_jL);
	  plus_matmul( V_iL_iR, GV_jR_jL, SI_iL_jL );
	};
      };      
    }; 
  };
  // SI(all_index, mod_index)
  for (set<int>::const_iterator piL=sys_ind_set.begin();piL!=sys_ind_set.end();++piL){ // for all this index SI is recalculated
    const int siL=*piL; // system index of iL
    const int iL= posL_new.s2g(siL); // new GF index of iL
    for (int jL=0; jL<posL_new.ftaille();++jL){ // all interface sites of SI
      if (posL_new.nv_g(jL) == 0) continue; // for non interface sites do nothing
      const int sjL=posL_new.g2s(jL); // system index of jL
      // set initial value to zero for recalculated element 
      SI(jL,ALL,iL,ALL) = COMPLEX(0.); 
      // reference to modified elements of SI
      Array<COMPLEX,2> SI_jL_iL= SI(jL,ALL,iL,ALL);
      for (int zi=0; zi<p_sys->fzmax();++zi){
	const int svi = p_sys->voisin(siL,zi); // system index of voisin iL
	if ( svi == sys_inf::outsample || posR_new.s2g(svi) < 0) continue;  // if this nn does not belong to new right position then do nothing
	const Array<COMPLEX,2>& V_iR_iL=p_sys->Mvoisin(siL,zi).hconjugate().micro2arr();
	for (int zj=0; zj<p_sys->fzmax();++zj){
	  const int svj = p_sys->voisin(sjL,zj); // system index of voisin jL
	  if ( svj == sys_inf::outsample || posR_new.s2g(svj) < 0) continue;  // if this nn does not belong to new right position then do nothing
	  const Array<COMPLEX,2>& V_jL_jR=p_sys->Mvoisin(sjL,zj).micro2arr();
	  const Array<COMPLEX,2> GV_iR_iL = matmul(GF(posR_new.s2g(svj),ALL,posR_new.s2g(svi),ALL), V_iR_iL);
	  plus_matmul( V_jL_jR, GV_iR_iL, SI_jL_iL );
	};
      };      
    }; 
  };
  //finished update of SI
  return;
};


// ** update GFLI ( full GF of right interface) when sewing lead -del_lead- 
// new right position is used
// update GF are made so it functions also for zero size right position
// dependance on GFLL 
template<class Tmicromatrix>
void sew<Tmicromatrix>::lead_updateGFLI(int del_lead){
  // reindex GFLI and GFIL matrixes for right position using new GFidexes
  // only element with changed GFindexes are updated
  for (int l=0; l<p_sys->fNres();++l){ // for each lead
    reindex_second(posR_new,posR,GFLI(l));
    reindex_first(posR_new,posR,GFIL(l));
  };
  const Range lead_r=posR_new.lead_range(del_lead); // range of new GFindex for lead -del_lead- 
  // update GFLI and GFIL for lastly added site Os
  for (int l=0; l<p_sys->fNres();++l){ // for each lead
    GFIL(l)(lead_r,ALL,ALL,ALL)=GFLL(del_lead,l)(ALL,ALL,ALL,ALL);
    GFLI(l)(ALL,ALL,lead_r,ALL)=GFLL(l,del_lead)(ALL,ALL,ALL,ALL);
  };
 return;
};



// ** GF test (Green function of the right interface)
// we compare full GF of right interface with those obtained by direct inversion algorithm 
// dependance on dGF and GF
template<class Tmicromatrix>
bool sew<Tmicromatrix>::GF_Test() const{
  if (dGF.extent(0) != p_sys->fsize()) return true; // do nothing if dGF was not initialized
  if (posR.ftaille() == 0) return true; // do nothing if for zero size GF
  GF_type GF2test(posR.ftaille(),MicroDim,posR.ftaille(),MicroDim); GF2test=0.;
  // DIRECT INVERSION COMPARISON
  for (int iR=0; iR<posR.ftaille();++iR){
    const int siR=posR.g2s(iR); // system index of iR
    for (int jR=0; jR<posR.ftaille();++jR){
      const int sjR=posR.g2s(jR); // system index of iR
      GF2test(iR,ALL,jR,ALL)=dGF(siR,ALL,sjR,ALL);
    };
  };
  return  is_equal( GF(posR.range(),ALL,posR.range(),ALL), GF2test );
};


// ** GFnotK test (non Keldysh Green function  final test)
// we compare full GF of completely sewed system with those obtained by direct inversion algorithm 
// dependance on dGF and GFnotK
template<class Tmicromatrix>
bool sew<Tmicromatrix>::GnotK_Test() const{
  if (dGF.extent(0) != p_sys->fsize()) return true; // do nothing if dGF was not initialized
  if (Os != 0) ERROR("GnotK_Test() is not possible for not completely sewed system");
  GF_type GF2test(p_sys->fsize(),MicroDim,p_sys->fzmax()+1,MicroDim); GF2test=0.;
  // DIRECT INVERSION COMPARISON
  for (int i=0; i<p_sys->fsize();++i){
    // onsite matrix elements
    GF2test(i,ALL,p_sys->fzmax(),ALL)=dGF(i,ALL,i,ALL);
    for (int z=0; z<p_sys->fzmax();++z){
      const int vi=p_sys->voisin(i,z); // voisin of i
      if (vi == sys_inf::outsample) continue;
      GF2test(i,ALL,z,ALL)=dGF(i,ALL,vi,ALL);
    };
  };
  return  is_equal( GnotK, GF2test );
};



// ** SI test ("self energy" of the right interface)
// we recalculate full SI using definition SI_{i_l,j_l} = \sum_{i_r,j_r} V_{i_l,j_r}*G_{j_r,i_r}*V_{i_r,j_l}
// and compare it with existing value
// dependance on GF
template<class Tmicromatrix>
bool sew<Tmicromatrix>::SI_Test() const{
  GF_type SI2test(SI.shape()); SI2test=0.;
  // SI2test reculations
  for (int iL=0;iL<posL.ftaille();++iL){ // for all this index SI is recalculated
    const int siL=posL.g2s(iL); // system index of iL
    if (posL.nv_g(iL) == 0) continue; // for non interface sites do nothing
    for (int jL=0; jL<posL.ftaille();++jL){ // all left sites of SI
      if (posL.nv_g(jL) == 0) continue; // for non interface sites do nothing
      const int sjL=posL.g2s(jL); // system index of jL
      // set initial value to zero for recalculated element 
      SI2test(iL,ALL,jL,ALL) = COMPLEX(0.); 
      // reference to modified elements of SI
      Array<COMPLEX,2> SI_iL_jL= SI2test(iL,ALL,jL,ALL);
      for (int zi=0; zi<p_sys->fzmax();++zi){
	const int svi = p_sys->voisin(siL,zi); // system index of voisin iL
	if ( svi == sys_inf::outsample || posR.s2g(svi) < 0) continue;  // if this nn does not belong to right position then do nothing
	const Array<COMPLEX,2>& V_iL_iR=p_sys->Mvoisin(siL,zi).micro2arr();
	for (int zj=0; zj<p_sys->fzmax();++zj){
	  const int svj = p_sys->voisin(sjL,zj); // system index of voisin jL
	  if ( svj == sys_inf::outsample || posR.s2g(svj) < 0) continue;  // if this nn does not belong to right position then do nothing
	  const Array<COMPLEX,2>& V_jR_jL=p_sys->Mvoisin(sjL,zj).hconjugate().micro2arr();
	  const Array<COMPLEX,2> GV_jR_jL = matmul(GF(posR.s2g(svi),ALL,posR.s2g(svj),ALL), V_jR_jL);
	  plus_matmul( V_iL_iR, GV_jR_jL, SI_iL_jL );
	};
      };      
    }; 
  };  
  return is_equal(SI2test(posL.range(), ALL, posL.range(), ALL),  SI(posL.range(), ALL, posL.range(), ALL));
};

// sew one step backward
template<class Tmicromatrix>
void sew<Tmicromatrix>::backward(){
  // by convention at the begining of each step position corresponds 
  // to workning ones, it's at the end of the step that we prepare positions for the next step
  // posL - left system with Os
  // posL_new - left system without Os
  // posR - complementary to the right system with Os
  // posR_new - complementary to the right system without Os
  // kn - left system with Os  
#ifdef _DEBUG_
  if (Os < 0) ERROR("in sew.backward:trying calculate non-existing sites Os<0 ");
  // check of left positions
  if (posL.fdebut() != 0 || posL.ffin() != Os ) ERROR("in sew(const knit&): position variable does not correspond to conventional value");
  if (Os !=0){ // for Os==0 new positions are not defined
    posL_new.avancer(la_fin);
    if ( !(posL_new==kn.pos) ) ERROR("in sew(const knit&): position variable does not correspond to conventional value");
    posL_new.reculer(la_fin);
  }
  // for right position check is not possible, as avancer*reculer=not_identity because whereAddLead is explicitly set
#endif

  // ALL PRIVATE VARIABLES ARE SET TO PERFORM CALCULATIONS 

  // OTHER SCENARIOS
  // A - first step (posR - is empty)
  // B - Os \in leads
  // C - no Os in the left interface

  // FULL SCENARIO, works also for A and C
  // for scenario C we use a trick we write gf(Os,ALL), gf(ALL,Os) and gf(Os,Os) to size+1 line of kn.GF and then define Or constant that would point to this line, if Os does not belongs to the left interface then we recover data from SAV variable: one should then use Or variable as Os
  // Or - is GF index of left interface posL if Os exists and it is (size+1) site if it does not; r - as recovery

  // ** GFO, GFO calculations
  // update full GF between Os and right interface
  // dependance on gf, GF
  GF_type GFO,OGF;
  // OGF is a GF between Os and right position
  // GFO is a GF between right position and Os
  getOright(GFO,OGF);

  // ** GFLO, GFOL and GFOO calculations
  // update full GF between Os and left interface
  // dependance on gf, SI,  GFO, OGF
  getOlead(GFO,OGF);

  //** GF
  // ** calculations of Gless
  // dependance on GFIL GFOL SE
  updateGless();

  // ** GnotK calculations
  // GnotK calculations are made so it function also for zero size right position
  // dependance on GFOO, GFO, OGF
  updateGnotK(GFO, OGF);

  // PREPARATION FOR THE NEXT STEP
  if (Os==0) return; // no further update for the last site

  // no update needed for GF and SI if Os \in lead and lead is still present in new left position (positions would not change)
  // if Os is \in lead and this lead was deleted from new left position then update GF and SI not just for Os but for all lead sites
  
  // different scenarios depending on wether Os belong to any lead, and if this lead is to be sewed
  const int del_lead = p_sys->sys2res(Os);

  // ** update GF (full GF for right position) new right position is used
  // update GF are made so it functions also for zero size right position
  //dependance on GFO, OGF and GFOO
  if (del_lead == sys_inf::not_lead) updateGF(GFO,OGF); // no common update if site is a lead site
  else if (posL.fwhereAddLead(del_lead) == Os){
    lead_updateGF(del_lead); // special update when sewing lead 
  }; 

  // ** update SI ("self energy" of the right interface)
  // definition SI_{i_l,j_l} = \sum_{i_r,j_r} V_{i_l,j_r}*G_{j_r,i_r}*V_{i_r,j_l}
  // dependance on updated GF
  if (del_lead == sys_inf::not_lead) updateSI();// no common update if site is a lead site
  else if (posL.fwhereAddLead(del_lead) == Os){
    lead_updateSI(del_lead); // special update when sewing lead 
  }; 

  // ** update GFLI ( full GF of right interface) new right position is used
  // update GF are made so it functions also for zero size right position
  //dependance on GFLO, GFOL
  if (del_lead == sys_inf::not_lead) updateGFLI();// no common update if site is a lead site
  else if (posL.fwhereAddLead(del_lead) == Os){
    lead_updateGFLI(del_lead); // special update when sewing lead 
  };
  
  // ** update of Os;
  Os--;// site (sys index) for which we will calculate all GF_lesser elements at the next step

  // ** advance positions
  // first old positions to new one
  kn.backward(la_fin); // posL reculer() at the same time
  // for the first step initialize posR to posR_new, else go one step forward
  if (posR.ftaille() == 0 && posR_new.ffin() == p_sys->fsize()-1) posR=posR_new;
  else posR.avancer(le_debut);
  // now all new positions should be equal to old ones
#ifdef _DEBUG_LONG_ 
  if (!(posL == posL_new)) ERROR("In sew::backward() posL != posL_new where it should be");
  if (!(posR == posR_new)) ERROR("In sew::backward() posR != posR_new where it should be");
#endif
#ifdef _DEBUG_ 
  if (max(GF.extent(0),GF.extent(3)) < posR.ftaille()+p_sys->fzmax()+1) 
    ERROR("In sew::backward() size allocated for GF is not sufficient for right interface");
#endif
  // update new positions
  if (Os != 0) { // no further update for the last site
    posL_new.reculer(la_fin);
    posR_new.avancer(le_debut);
  };
  // posL - left system with new Os
  // posL_new - left system without new Os
  // posR - complementary to the right system with new Os
  // posR_new - complementary to the right system without new Os
  // kn - left system with next Os  

  // ** update Or
  updateOr();  

  //varios tests
#ifdef _DEBUG_LONG_
  if ( ! GF_Test() ) ERROR("in sew.backward(): GF recalculated using dGF is not equal to current value");
  if ( ! SI_Test() ) ERROR("in sew.backward(): SI recalculated using GF is not equal to current value");
#endif
  
  return;
};



// sew completely
template<class Tmicromatrix>
void sew<Tmicromatrix>::sew2end(){
  for (int i=0; i<p_sys->fsize();++i) backward();
#ifdef _DEBUG_VERY_LONG_ //DIRECT INVERSION
  if ( ! GnotK_Test() ) ERROR("in sew.sew2end(): GFnotK recalculated using dGF is not equal to obtained value");
#endif
  return;
};

/*** TO DO *****
1) check order of multiplicatin for matrix G_NN*G_aN*G_Na
*/
