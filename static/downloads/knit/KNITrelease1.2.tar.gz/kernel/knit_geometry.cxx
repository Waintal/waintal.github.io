// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################



/// real copy operator for maps composed of blitz::Arrays elements
template<class T,int n>
void map_copy( map<int,const Array<T,n> > & lM, const map<int,const Array<T,n> >& rM){
  lM.clear(); // clear old maps values for lesft map
  typename map<int,const Array<T,n> >::const_iterator CI=rM.begin();
  for (;CI!=rM.end();++CI) lM.insert(lM.end(), make_pair(CI->first,(CI->second).copy()));
  return;
};


// ********************TEMPLATE FUNCTIONS******************* //
// **************** for position and position_knit ********* //

// ********************************* GLOBAL FUNCTIONS ********************************//

/// new_old map is a list of pairs correspondance between old and new indexes. In fact if we add just a single site to the lace, then most of indexes stay unchanges, and only those that have been deleted from the lace may change theirs index. We keep this information in the corresponding map<int,int> in order to perform faster new->old Tensor index conversion.
// construct map of pairs of indexes <new,old>: This map keeps information about indexes difference in pos_new and pos_old 
// we use the set of pos_new.changed_GF_ind. 
// this map do not contains any sites present in pos_new and have no old_ind correspondance
template<class Tmicromatrix>
void get_new_old_map(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, map<int,int>& M_no ){
  M_no.clear(); // clear input value of new old map
  if (pos_old.ftaille() == 0 || pos_new.ftaille() == 0) return; // nothing to do for empty initial position
#ifdef _DEBUG_ // check if pos_new and pos are different
  if (pos_old.fdebut()==pos_new.fdebut()&&pos_old.ffin()==pos_new.ffin()) ERROR("in get_new_old_map(pos,pos,map): new and old position are the same");
  // pos_new should be derived from pos_old by single movement operation
  if ( abs(pos_new.fdebut()-pos_old.fdebut())>1 || abs(pos_new.ffin()-pos_old.ffin())>1 ) ERROR("in get_new_old_map(pos,pos,map) pos_new is not derectly derived from pos_old");
#endif
  const set<int>& new_ind=pos_new.changed_GF_ind(); //set of indexes of pos_new that were changed during last avancer or reculer operation
  set<int>::const_iterator p_new_ind=new_ind.begin();
  for (;p_new_ind!=new_ind.end();++p_new_ind) {
    // stop map construction for index that are bigger then position itself (this situation could happen when we add lead => many sites in a row)
    if (*p_new_ind >= pos_new.ftaille()) break; 
    int old_ind=pos_old.s2g(pos_new.g2s(*p_new_ind));
    // do not include sites that were added to pos_new and have no old_ind correspondance
    if (old_ind < 0) continue;
    // do not include sites that happens to have the same old-new indexes
    if (old_ind == *p_new_ind) continue; 
    M_no[*p_new_ind]=old_ind;
  };
#ifdef _DEBUG_
  // check if new_ind is in pos_new range
  if ( M_no.size() !=0 && (--M_no.end())->first >= pos_new.ftaille()) ERROR("in get_new_old_map(pos,pos,map): in new_old map first index is out of range");
  if (new_ind.size()>pos_new.ftaille()) ERROR("in get_new_old_map(pos,pos,GF): the size of the changed_GF_ind is bigger then correspondent position");
  if (M_no.size()>new_ind.size()) ERROR("in get_new_old_map(pos,pos,GF): the size of the <new,old> map is not correct");
#endif
  return;
};

// Global function that reindex tensor Ten(i,ALL,j,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be derectly derived from pos_old by single movement (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& Ten){
  if (pos_old.ftaille() == 0 || pos_new.ftaille() == 0 || Ten.size() ==0) return; // nothing to do for empty initial position
#ifdef _DEBUG_ // check if pos_new and pos are different
  if (pos_old.fdebut()==pos_new.fdebut()&&pos_old.ffin()==pos_new.ffin()) ERROR("in reindex(pos,pos,GF): new and old position are the same");
  // pos_new should be derived from pos_old by single movement operation
  if ( abs(pos_new.fdebut()-pos_old.fdebut())>1 || abs(pos_new.ffin()-pos_old.ffin())>1 ) ERROR("in reindex(pos,pos,GF) pos_new is not derectly derived from pos_old");
  const int min_Ten_dim=min(Ten.extent(0),Ten.extent(2));
  const int max_pos_dim=max(pos_new.ftaille(),pos_old.ftaille());
  if (min_Ten_dim < max_pos_dim) ERROR("in reindex(pos,pos,GF): one of the position could not describe this GF");
#endif

  // FIRST: MAP
  /// new_old map is a list of pairs correspondance between old and new indexes. In fact if we add just a single site to the lace, then most of indexes stay unchanges, and only those that have been deleted from the lace may change theirs index. We keep this information in the corresponding map<int,int> in order to perform faster new->old Tensor index conversion.
  // construct map of pairs of indexes <new,old>: This map keeps information about indexes difference in pos_new and pos_old 
  // this map do not contains any sites present in pos_new and have no old_ind correspondance
  map<int,int> M_no; // new old map
  get_new_old_map(pos_new,pos_old,M_no);

  //SECOND: SAVE part of Ten
  // save all row and columns of Ten for changed indexes in Ten_row \in Mat(map_size,min_pos_size) Ten_col \in Mat(min_pos_size, map_size)
  // first index order in Ten_row is the same as in iterator of M_no map, second index order is the same as in pos_new indexes
  // for Ten_col index order is opposite to those of g_row
  const int microDim = Tmicromatrix::dim();
  GF_type Ten_row(M_no.size(),microDim,pos_new.ftaille(),microDim), Ten_col(pos_new.ftaille(),microDim,M_no.size(),microDim);
  map<int,int>::const_iterator s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i){ // for each index of new_old map we save correspondant row and column of Ten
#ifdef _DEBUG_ // check if pos_new and pos 
    if (s->second >= Ten.extent(0) || s->second >= Ten.extent(2) ) ERROR("in reindex(pos,pos,GF): new_old map is out of range");
#endif
    Ten_row(i,ALL,ALL,ALL)=Ten(s->second,ALL,pos_new.range(),ALL); // whole row save
    Ten_col(ALL,ALL,i,ALL)=Ten(pos_new.range(),ALL,s->second,ALL); // whole column save
    for (map<int,int>::const_iterator ss=M_no.begin(); ss!=M_no.end(); ++ss) { // correction due to =>
#ifdef _DEBUG_ // check if pos_new and pos 
      if (ss->second >= Ten.extent(0) || ss->second >= Ten.extent(2) ) ERROR("in reindex(pos,pos,GF): new_old map is out of range");
#endif
      Ten_row(i,ALL,ss->first,ALL)=Ten(s->second,ALL,ss->second,ALL); // => changes inside the row
      Ten_col(ss->first,ALL,i,ALL)=Ten(ss->second,ALL,s->second,ALL); // => changes inside the column
    };
  };
  
  //THIRD: WRITE saved part of Ten
  // !!! as sizes of pos_new and pos_old are not necessairily the same =>
  // => write operation change Ten's elements between changed-index sites and new site (added during last movement operation),
  // !!! so the order of operations forwardG_aN, reindex(G) and updateG_aN is correct and very important
  s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i){ // for each index of new_old map we write correspondant row and column of Ten
    Ten(s->first,ALL,pos_new.range(),ALL)=Ten_row(i,ALL,ALL,ALL); // whole row write
    Ten(pos_new.range(),ALL,s->first,ALL)=Ten_col(ALL,ALL,i,ALL); // whole column write
  };
 return;
};


// Global function that reindex just first index of tensor Ten(i,ALL,lj,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be derectly derived from pos_old by single movement (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex_first(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& Ten){
  if (pos_old.ftaille() == 0 || pos_new.ftaille() == 0 || Ten.size() ==0 ) return; // nothing to do for empty initial position
#ifdef _DEBUG_ // check if pos_new and pos are different
  if (pos_old.fdebut()==pos_new.fdebut()&&pos_old.ffin()==pos_new.ffin()) ERROR("in reindex_first(pos,pos,GF): new and old position are the same");
  // pos_new should be derived from pos_old by single movement operation
  if ( abs(pos_new.fdebut()-pos_old.fdebut())>1 || abs(pos_new.ffin()-pos_old.ffin())>1 ) ERROR("in reindex_first(pos,pos,GF) pos_new is not derectly derived from pos_old");
  const int max_pos_dim=max(pos_new.ftaille(),pos_old.ftaille());
  if (Ten.extent(0) < max_pos_dim) ERROR("in reindex_first(pos,pos,GF): one of the position could not descrite this GF");
#endif

  // FIRST: MAP
  /// new_old map is a list of pairs correspondance between old and new indexes. In fact if we add just a single site to the lace, then most of indexes stay unchanges, and only those that have been deleted from the lace may change theirs index. We keep this information in the corresponding map<int,int> in order to perform faster new->old Tensor index conversion.
  // construct map of pairs of indexes <new,old>: This map keeps information about indexes difference in pos_new and pos_old 
  // this map do not contains any sites present in pos_new and have no old_ind correspondance
  map<int,int> M_no; // new old map
  get_new_old_map(pos_new,pos_old,M_no);

  //SECOND: SAVE part of Ten
  // save all row of Ten for changed indexes in Ten_row \in Mat(map_size,Ten.extent(2))
  // first index order in Ten_row is the same as in iterator of M_no map, second index order is the same as in pos_new indexes
  // for Ten_col index order is opposite to those of g_row
  const int microDim = Tmicromatrix::dim();
  GF_type Ten_row(M_no.size(),microDim,Ten.extent(2),microDim);
  map<int,int>::const_iterator s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i) // for each index of new_old map we save correspondant row of Ten
    Ten_row(i,ALL,ALL,ALL)=Ten(s->second,ALL,ALL,ALL); // whole row save

  //THIRD: WRITE saved part of Ten
  // !!! as sizes of pos_new and pos_old are not necessairily the same =>
  // => write operation change Ten's elements between changed-index sites and new site (added during last movement operation),
  // !!! so the order of operations forwardG_aN, reindex(G) and updateG_aN is correct and very important
  s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i) // for each index of new_old map we write correspondant row of Ten
    Ten(s->first,ALL,ALL,ALL)=Ten_row(i,ALL,ALL,ALL); // whole row write
 return;
};


// Global function that reindex just third index of tensor Ten(li,ALL,j,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be directly derived from pos_old by single movement (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex_second(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& Ten){
  if (pos_old.ftaille() == 0  || pos_new.ftaille() == 0 || Ten.size() ==0) return; // nothing to do for empty initial position
#ifdef _DEBUG_ // check if pos_new and pos are different
  if (pos_old.fdebut()==pos_new.fdebut()&&pos_old.ffin()==pos_new.ffin()) ERROR("in reindex_second(pos,pos,GF): new and old position are the same");
  // pos_new should be derived from pos_old by single movement operation
  if ( abs(pos_new.fdebut()-pos_old.fdebut())>1 || abs(pos_new.ffin()-pos_old.ffin())>1 ) ERROR("in reindex_second(pos,pos,GF) pos_new is not derectly derived from pos_old");
  const int max_pos_dim=max(pos_new.ftaille(),pos_old.ftaille());
  if (Ten.extent(2) < max_pos_dim) ERROR("in reindex_second(pos,pos,GF): one of the position could not descrite this GF");
#endif

  // FIRST: MAP
  /// new_old map is a list of pairs correspondance between old and new indexes. In fact if we add just a single site to the lace, then most of indexes stay unchanges, and only those that have been deleted from the lace may change theirs index. We keep this information in the corresponding map<int,int> in order to perform faster new->old Tensor index conversion.
  // construct map of pairs of indexes <new,old>: This map keeps information about indexes difference in pos_new and pos_old 
  // this map do not contains any sites present in pos_new and have no old_ind correspondance
  map<int,int> M_no; // new old map
  get_new_old_map(pos_new,pos_old,M_no);

  //SECOND: SAVE part of Ten
  // save all row of Ten for changed indexes in Ten_col \in Mat(Ten.extent(0),map_size)
  // first index order in Ten_row is the same as in iterator of M_no map, second index order is the same as in pos_new indexes
  // for Ten_col index order is opposite to those of g_row
  const int microDim = Tmicromatrix::dim();
  GF_type Ten_col(Ten.extent(0),microDim,M_no.size(),microDim);
  map<int,int>::const_iterator s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i) // for each index of new_old map we save correspondant col of Ten
    Ten_col(ALL,ALL,i,ALL)=Ten(ALL,ALL,s->second,ALL); // whole col save

  //THIRD: WRITE saved part of Ten
  // !!! as sizes of pos_new and pos_old are not necessairily the same =>
  // => write operation change Ten's elements between changed-index sites and new site (added during last movement operation),
  // !!! so the order of operations forwardG_aN, reindex(G) and updateG_aN is correct and very important
  s=M_no.begin();
  for (int i=0;s!=M_no.end();++s,++i) // for each index of new_old map we write correspondant row of Ten
    Ten(ALL,ALL,s->first,ALL)=Ten_col(ALL,ALL,i,ALL); // whole col write
 return;
};


// cout<< operator for postion
template<class Tmicromatrix>
ostream& operator<<(ostream& output, const position<Tmicromatrix>& pos){
  output<<"taille="<<pos.taille<<endl;
  //  output<<"system to GF="<<pos.s2g_array<<endl;
  output<<"GF to system="<<pos.g2s_array(Range(0,pos.taille-1))<<endl;
  //output<<"systeme print"<<endl<<*(pos.p_sys)<<endl;
  return output;
};

// cout<< operator for postion_knit
template<class Tmicromatrix>
ostream& operator<<(ostream& output, const position_knit<Tmicromatrix>& pos){
  if (pos.taille == 0) {output<<"Empty position\n";return output;};
  output<<"debut="<<pos.debut<<" fin="<<pos.fin<<endl;
  output<<"started at index="<<pos.init_pos<<endl;
  output<<"Nearest neighbors number  "<<pos.nv_s_array<<endl;
//   if (pos.changed_GF_ind_set.size()!=0){
//     output<<"GFindex that changed during last advance operation\n <";
//     output<<pos.changed_GF_ind_set<<endl;
//   };  //  else output<<"no GFindex are changed during last advance operation\n";
  output<<position<Tmicromatrix>(pos)<<endl;
  return output;
};


// calculate maximum GF size
// ATTENTION!!! this size should be multiplied by Tmicromatrix::dim() in order to obtain Array of complex
// !!! position_knit variable is used 
template <class Tmicromatrix>
int max_GF_size(const systeme_infini<Tmicromatrix>& S, int init_pos){
  position_knit<Tmicromatrix> pos(init_pos,S);
  int max_taille=1;
  int max_taille_right=pos.ftaille(); //initial max size of right interface
  int max_taille_left=0; //initial max size of left interface
  if (init_pos < S.fsize()-1 ) { //advance to the end
    while(pos.ffin()!=S.fsize()-1) {pos.avancer(la_fin); if (pos.ftaille()>max_taille_right) max_taille_right=pos.ftaille();};
    while(pos.ffin()!=init_pos) pos.reculer(la_fin); // come back to initial position 
  };
  if (init_pos > 0 )  //advance to the beginning
    while(pos.fdebut()!=0) {pos.avancer(le_debut); if (pos.ftaille()>max_taille_left) max_taille_left=pos.ftaille();};
  max_taille=max_taille_left + max_taille_right;
  max_taille += S.fzmax()+1; // during a single iteration actual GF_size could be bigger by zmax+1 then final one. For example if one fills a single site hole 
  return max_taille; // next line is to be implemented in future, test of GF size should be modified 
  //if (max_taille>S.fsize()) return S.fsize(); else return max_taille;
};


// forward - backward test for postion_knit variable for given infinite system:
// we create position_knit variable then make back and forth knit, then we knit forward to get the whole system and then once again back and forth from both ends, and finally we knit backward to initial position. At each step we compare that back and forth operation does not change position_knit 
// all this is made for three different starting points: debut(O), fin(size-1),midddle(size/2)
template<class Tmicromatrix>
bool position_bfTEST(const systeme_infini<Tmicromatrix>& S){
  const int sys_size=S.fsize();
  int starting_point;
  bool result=true;
  cout<<"For this starting points:\n";
  for (int i=1;i<=3;++i) { // three different starting points
    switch (i){
    case 1:
      starting_point=0;
      break;
    case 2:
      starting_point=sys_size-1;
      break;
    case 3:
      starting_point=(sys_size-1)/2;
      break;
    default:
      return false;
    };
    cout<<"site "<<starting_point<<endl;
    position_knit<Tmicromatrix> posit(starting_point,S);
    position_knit<Tmicromatrix> start_pos(posit);
    //avancer-reculer from tail only if it's not the last site 
    if (starting_point < sys_size-1 ) {posit.avancer(la_fin);  posit.reculer(la_fin);}
    if ( !(start_pos == posit) ) result=false;
    //avancer-reculer from head only if it's not the first site 
    if (starting_point > 0) {posit.avancer(le_debut);posit.reculer(le_debut);}
    if ( !(start_pos == posit) ) result=false;
    // knit forward to get entire lace
    posit.avancer(ToZero);   posit.avancer(ToEnd); 
    position_knit<Tmicromatrix> copy_pos(posit);
    //reculer-avancer from tail test; only this test would work as last advance operation was made ToEnd
    if ( sys_size>=3 && starting_point != sys_size-1) {posit.reculer(la_fin); posit.avancer(la_fin);}
    if ( !(copy_pos == posit) ) result=false;
    //knit_back to starting point
    posit.reculer(FromEnd); posit.reculer(FromZero);
    if ( !(start_pos == posit) ) result=false;
  };
  if (result) cout<<"Back&forth TEST for POSITION_KNIT is passed with sucess.\n";
  else  cout<<"Back&forth TEST for POSITION_KNIT failed !!!\n";
  return result;
};



//************************POSITION member functions*************************************//

// copy constructor
// Since copy constructor for Arrays is defined as reference passing we redefine all copy constructors containing it
template<class Tmicromatrix>
position<Tmicromatrix>::position(const position<Tmicromatrix>& pos):
  s2g_array(pos.s2g_array.copy()), g2s_array(pos.g2s_array.copy()),
     taille(pos.taille), p_sys(pos.p_sys)
{};


// assignment operator
template<class Tmicromatrix>
position<Tmicromatrix>& position<Tmicromatrix>::operator=(const position<Tmicromatrix>& pos){
  s2g_array<=pos.s2g_array;
  g2s_array<=pos.g2s_array;
  taille=pos.taille;
  p_sys=pos.p_sys;
#ifdef _DEBUG_LONG_// test of GF <-> system correspondance. Verify if g2s and s2g are inversed functions
  if (!s2gTEST()) ERROR("in position copy constructor; test of GF <-> system correspondance failed");
#endif
  return *this;
};


// bool compare operator
template<class Tmicromatrix>
bool position<Tmicromatrix>::operator==(const position<Tmicromatrix>& pos) const{
  if (taille == 0 && pos.taille == 0) return true; // two empty positions are equal
#ifdef _DEBUG_LONG_// test of GF <-> system correspondance. Verify if g2s and s2g are inversed functions
  if (!s2gTEST()) ERROR("in position == operation; test of GF <-> system correspondance failed");
#endif
  if (taille != pos.taille) return false;
  if (any(s2g_array != pos.s2g_array)) return false;
  if (any(g2s_array(Range(0,taille-1)) != pos.g2s_array(Range(0,taille-1)))) return false;
  return true;
};


// function call of position::s2g array  element copy
template<class Tmicromatrix>
inline int position<Tmicromatrix>::s2g(int s_ind) const {
  if (s_ind==sys_inf::outsample) return sys_inf::outsample;// outsample sites returns also outsample 
  else return s2g_array(s_ind);
};
// function call of position::s2g array element reference
template<class Tmicromatrix>
inline int& position<Tmicromatrix>::s2g(int s_ind) {
#ifdef _DEBUG_
  if (s_ind==sys_inf::outsample) ERROR("in position::s2g trying to modify s2g(outsample)");
#endif
  return s2g_array(s_ind);
};


// function call of position::g2s array element copy
template<class Tmicromatrix>
inline int position<Tmicromatrix>::g2s(int GF_ind) const {
  if (GF_ind==sys_inf::outsample) return sys_inf::outsample;// outsample sites returns also outsample 
  else return g2s_array(GF_ind);
};
// function call of postion::g2s array element reference
template<class Tmicromatrix>
inline int& position<Tmicromatrix>::g2s(int GF_ind) {
#ifdef _DEBUG_
  if (GF_ind==sys_inf::outsample) ERROR("in position::g2s trying to modify g2s(outsample)");
#endif
  return g2s_array(GF_ind);
};   


// Calculations of interface pairs which consists of both voisin index and GF index for in-lace nearest neighbors of the site -ind- <z,GF_ind>, it's used in summation of type sum_a V_ba*g_aa'
// via -b-(sys_index) we get its interface sites -a-(GFindex), and voisin index -z- is needed to calculate V_ba. So all g_aa' are got directly in GF_indexes, and corresponding V_ba are got via (b,z) pairs 
template<class Tmicromatrix>
const map<int,int> position<Tmicromatrix>::interface(int ind) const{ //checked
  map<int,int> I;
  if (taille==0) return I; // return empty map for zero size systems
  for (int z=0; z<p_sys->fzmax(); ++z) {
    const int& nn=p_sys->voisin(ind,z); // nearest neighbor with system index
    if (nn!=sys_inf::outsample && s2g(nn)>=0) I[z]=s2g(nn); // if the nn is an interface site then add it to interface
  };
  return I;
};


// Calculations of interface pairs which consists of both voisin index and GF index for in-lace nearest neighbors of the site -ind- <z,GF_ind>, it's used in summation of type sum_a V_ba*g_aa'
// via -b-(sys_index) we get its interface sites -a-(GFindex), and voisin index -z- is needed to calculate V_ba. So all g_aa' are got directly in GF_indexes, and corresponding V_ba are got via (b,z) pairs 
template<class Tmicromatrix>
void position<Tmicromatrix>::set_interface(int ind, map<int,int>& I) const{ //checked
  I.clear();//clear old value
  for (int z=0; z<p_sys->fzmax(); ++z) {
    const int& nn=p_sys->voisin(ind,z); // nearest neighbor with system index
    if (nn!=sys_inf::outsample && s2g(nn)>=0) I[z]=s2g(nn); // if the nn is an interface site then add it to interface
  };
  return;
};


// Calculations of interface pairs for each lead's element. This pairs consist of both voisin index and GF index for in-lace nearest neighbors of the site -ind- <z,GF_ind>, it's used in summation of type sum_a V_ba*g_aa'
// via -b-(sys_index) we get its interface sites -a-(GFindex), and voisin index -z- is needed to calculate V_ba. So all g_aa' are got directly in GF_indexes, and corresponding V_ba are got via (b,z) pairs 
template<class Tmicromatrix>
Array<map<int,int>,1> position<Tmicromatrix>::interfaceLead(int lead) const{
  Array<map<int,int>,1> V(p_sys->lead_size(lead));
  for (int i=0;i<V.rows();++i)  V(i)=interface(p_sys->res2sys(lead,i));
  return V;
};


// test of GF <-> system correspondance. Verify if g2s and s2g are inversed functions
#ifdef _DEBUG_LONG_
template<class Tmicromatrix>
bool position<Tmicromatrix>::s2gTEST() const{
  for (int indGF=0;indGF<taille;++indGF) if (s2g_array(g2s_array(indGF))!=indGF) return false;
  return true;
};
#endif


//************************POSITION_KNIT member functions*************************************//


// copy constructor
// Since copy constructor for Arrays is defined as reference passing we redefine all copy constructors containing it
template<class Tmicromatrix>
position_knit<Tmicromatrix>::position_knit(const position_knit& pos) : Base(pos), debut(pos.debut), fin(pos.fin),init_pos(pos.init_pos),
								       nv_s_array(pos.nv_s_array.copy()), changed_GF_ind_set(pos.changed_GF_ind_set), 
								       whereAddLead(pos.whereAddLead.copy()), lead_offset(pos.lead_offset.copy()),
								       lead2order(pos.lead2order.copy()), order2lead(pos.order2lead)
{};


// assignement operator
template<class Tmicromatrix>
position_knit<Tmicromatrix>& position_knit<Tmicromatrix>::operator=(const position_knit& pos){
  //*static_cast<Base*>(this)=pos; //another way of base assignement
  Base::operator=(pos);// Base assignement
  debut=pos.debut;
  fin=pos.fin;
  init_pos=pos.init_pos;
  nv_s_array<=pos.nv_s_array;
  whereAddLead<=pos.whereAddLead;
  lead_offset<=pos.lead_offset;
  lead2order<=pos.lead2order;
  order2lead=pos.order2lead;
  changed_GF_ind_set=pos.changed_GF_ind_set;
  return *this;
};


// constructor of position_knit from a single site. If this site is connected to the lead all lead's site should be added
// whereAddLead is optional variable, if not set then automaticly calculated values are used; once used it is reset during reculer()!!!
template<class Tmicromatrix>
position_knit<Tmicromatrix>::position_knit(int indice, const sys_inf& S, const Array<int,1>& wwhereAddLead=Array<int,1>()):
  whereAddLead(wwhereAddLead.copy()), lead_offset(S.fNres()), lead2order(S.fNres()) {
  Base::p_sys=&S;
  // check if -indice- is connected to any lead 
  const int lead_number=Base::p_sys->sys2res(indice);
  const int system_size=Base::p_sys->fsize();
  //all initial values of where-add-lead are set to outsample if it was not passed as parameter
  if ( whereAddLead.size()==0 ){
    whereAddLead.resize(S.fNres());
    whereAddLead=sys_inf::outsample;
  }
  //initialize lead => order of adding correspondance
  lead2order =sys_inf::not_lead;
  //initialize lead offset,ie first index in GF for first element of the lead
  lead_offset=sys_inf::not_lead;
  // resizing of arrays variables
  Base::s2g_array.resize(system_size);
  Base::g2s_array.resize(system_size); // max_GF_size is to be used instead of system_size, not possible with current difinition of max_GF_size
  nv_s_array.resize(system_size);
#ifdef _DEBUG_
  if (N2P(system_size)<Base::outlace) ERROR("in position_knit(int, system+lead) system_size > outlace: redefine outlace from INT_MIN to LIN_MIN");
#endif
  // we set the default values for s2g g2s and nv_s arrays so one could easily pinpoint them among others, anyway only value already knitted out are important
  Base::s2g_array=Base::outlace; // initial values meaning that this sites were not yet touched by the knitting
  Base::g2s_array=Base::outlace; // initial values meaning that this sites were not yet touched by the knitting
  nv_s_array=-Base::p_sys->fzmax(); // initial number of nearest neighbors is set to impossible value= -zmax of the system
  // initialization of position variables
  Base::taille=0;
  // initialization of position_knit variables
  init_pos=indice;
  debut=indice;
  fin=indice;
  // add just a single site or a whole lead 
  debut++; avancer(le_debut); // here we make a trick, advancing from non-existing debut
  //old version without tricks
//   if (lead_number==sys_inf::not_lead) addsite(indice); //add initial site
//   else { // we add a whole lead if site is connected to it 
//     lead_offset(lead_number)=0;
//     lead2order(lead_number)=0;
//     order2lead[0]=lead_number;
//     whereAddLead(lead_number)=indice;
//     for (int li=0; li<Base::p_sys->lead_size(lead_number);++li) // for every site of leads interface
//       addsite(Base::p_sys->res2sys(lead_number,li)); // add all sites of the lead
//   };
};


// bool compare operator ==, for position_knit
template<class Tmicromatrix>
bool position_knit<Tmicromatrix>::operator==(const position_knit& pos) const { 
  if (debut!=pos.debut || fin!=pos.fin || init_pos!=pos.init_pos) return false;
  if (any(nv_s_array != pos.nv_s_array) ) return false;
  if (!(Base::operator==(pos))) return false;
  return true;
};

///< size of inner interface, ie leads do not taken into account
template<class Tmicromatrix>
int position_knit<Tmicromatrix>::inner_interface_size() const{
  const int last_lead=order2lead(order2lead.size()-1);
  const int total_lead_size=lead_offset(last_lead) + Base::p_sys->lead_size(last_lead);
  return (Base::taille-total_lead_size);
};

// avancer(debut_fin); debut_fin==
// la_fin, then lace advanced at the end by one site
// le_debut, then lace advanced at the beginning
// ToEnd, advance to the End of the lace
// ToZero, advance to the Beggining of the lace
template<class Tmicromatrix>
void position_knit<Tmicromatrix>::avancer(const moveType& debut_fin)
{ 
#ifdef _DEBUG_LONG_ // check if we don't try to advance outside of the sample
  if (debut_fin == FromEnd || debut_fin == FromZero)  ERROR("In position_knit::avancer() not correct argument is used");
  if (Base::p_sys->fsize()-1==fin&&debut_fin==la_fin) ERROR("In position_knit::avancer() trying to add site beyond the last one");
  if (debut_fin==le_debut&&debut==0) ERROR("In position_knit::avancer() trying to advance to -1 site");
#endif
  // the site index that is added to the lace depend on debut_fin variable
  // if debut_fin==+1, then we add site to the end, if debut_fin==-1 we add site to the beginning
  if (debut_fin == le_debut || debut_fin == la_fin){
    changed_GF_ind_set.clear();  // clear last iteration  value
    int added_site=sys_inf::outsample; // system index of the site to be added
    if (debut_fin==le_debut) {debut--;added_site=debut;}
    if (debut_fin==la_fin)   {fin++;  added_site=fin;};
    // added_lead indicates to which lead is connected added site
    // added_lead=not_lead if the site is not connected to any lead
    const int added_lead=Base::p_sys->sys2res(added_site); 
    // add just a single site or a whole lead
    if (added_lead==sys_inf::not_lead) addsite(added_site); //add just a single site
    // add a whole lead if it still not connected or it was set to add it at this point
    else if (whereAddLead(added_lead) == sys_inf::outsample || whereAddLead(added_lead)==added_site) {
      const int add_order=order2lead.size(); // order of adding of the current lead
      lead2order(added_lead)=add_order;
      order2lead[add_order]=added_lead;
      if (add_order==0) lead_offset(added_lead)=0;// if this is the first lead lead_offset is zero
      else {// lead offset is displaced from previous value by prevoius lead size
	const int previous_lead=order2lead[add_order-1];
	lead_offset(added_lead)=lead_offset(previous_lead) + Base::p_sys->lead_size(previous_lead);
      };
      whereAddLead(added_lead)=added_site;
      for (int li=0; li<Base::p_sys->lead_size(added_lead);++li) // for every site of leads interface
	addsite(Base::p_sys->res2sys(added_lead,li)); // add all sites of the lead
    };
  };
  // advance till the end of the lace
  if (debut_fin==ToEnd) while(fin != Base::p_sys->fsize()-1) avancer(la_fin); 
  // advance till the beginning of the lace
  if (debut_fin==ToZero) while(debut != 0) avancer(le_debut); 
  return;
};


//reculer(debut_fin); debut_fin==
// la_fin, then lace is reduced at the end by one site
// le_debut, then lace is reduced at the beginning
// FromZero, completely reduce from zero-site (debut) of the lace
// FromEnd, completely reduce from the end (fin) of the lace
template<class Tmicromatrix>
void position_knit<Tmicromatrix>::reculer(const moveType& debut_fin){
#ifdef _DEBUG_LONG_ // check if we don't use wrong move variables
  if (debut_fin == ToEnd || debut_fin == ToZero)  ERROR("In position_knit::reculer() not correct argument is used");
#endif
  // the site index that is added to the lace depend on debut_fin variable
  // if debut_fin==+1, then we suppress site at the end, if debut_fin==-1 we suppress site at the beginning
  if (debut_fin == le_debut || debut_fin == la_fin){
#ifdef _DEBUG_LONG_ // check if we don't try to advance outside of the sample
    if (fin == debut) ERROR("In position_knit::reculer() trying to suppress the last site");
#endif
    changed_GF_ind_set.clear();  // clear last iteration  value
    int deleted_site=sys_inf::outsample; // system index of the site to be deleted
    if (debut_fin==le_debut) {deleted_site=debut;debut++;}
    if (debut_fin==la_fin)   {deleted_site=fin;fin--;};
    // deleted_lead indicates to which lead is connected deleted_site
    // deleted_lead=not_lead if the site is not connected to any lead
    const int deleted_lead=Base::p_sys->sys2res(deleted_site); 
    // suppress just a single site or a whole lead
    if (deleted_lead==sys_inf::not_lead) delsite(deleted_site); //suppress just a single site
    else if (whereAddLead(deleted_lead)==deleted_site){ // suppress a lead at the same moment it was added using whereAddLead
      for (int li=Base::p_sys->lead_size(deleted_lead)-1; li>=0;--li) // for every elements of leads interface
	delsite(Base::p_sys->res2sys(deleted_lead,li)); // delete all elements of the lead
      lead2order(deleted_lead)=sys_inf::not_lead;
      order2lead.erase(--order2lead.end());// erase last element 
      lead_offset(deleted_lead)=sys_inf::not_lead;
      whereAddLead(deleted_lead) = sys_inf::outsample; // reinialize value of whereAddLead
    };
  };
  // stepback till the initial position of the lace from its head(debut)
  if (debut_fin==FromZero) while(debut != init_pos) reculer(le_debut);
  // stepback till the initial position of the lace from its tail(fin)
  if (debut_fin==FromEnd) while(fin != init_pos) reculer(la_fin);
  return;
};


//addsite(addedsite) add -addedsite- to the position_knit (use system index notations), it is necessairy to add lead sites
template<class Tmicromatrix>
void position_knit<Tmicromatrix>::addsite(int addedsite){
#ifdef _DEBUG_LONG_ // check if we don't try to advance outside of the sample
  if (addedsite<0) ERROR("In position_knit::addsite() trying to add site before the first one");
  if (addedsite>=Base::p_sys->fsize()) ERROR("In position_knit::addsite() trying to add site beyond the last one");
  if (Base::s2g(addedsite)!=Base::outlace) ERROR("In position_knit::addsite() trying to add site that is already inside lace");
#endif
  // FIRST analyse all neighbors
  const  Array<int,1> les_voisins=Base::p_sys->vvoisin(addedsite);
  nv_s_array(addedsite)=Base::p_sys->fzmax(); // set the initial number of nearest neighbours to its maximal value zmax
  for (int z=0;z<Base::p_sys->fzmax();++z){   // loop over all nearest neighbors
    int le_voisin=les_voisins(z);             // system index of the neighbor
    // different scenarios depending on the neighbor positions
    if (le_voisin==sys_inf::outsample) nv_s_array(addedsite)--;  //if the neighbor is outside the sample -> descrease nearest neighbors number
    else{ // the neighbor is inside the sample
#ifdef _DEBUG_LONG_ // check if the neighbor belongs to the interface sites
      // In fact it's impossible to have a nn of actually added site, that is out of knitting. 
      //Explanation: this nn has at least one external contact with actually added site, so it's nv_s value should be at least equal to one.
      if ((Base::s2g(le_voisin)<0&&Base::s2g(le_voisin)>=N2P(Base::p_sys->fsize()))) 
	ERROR("in position_knit::addsite added site has a neighbor that was already excluded from interface sites"); 
#endif
      //if the neighbor is inside the sample and it was already  passed by the knitting (in-lace neighbors)
      // one of the methods to check if the site is in-lace consist of looking it's s2g() value
      if (Base::s2g(le_voisin)!=Base::outlace) {
	nv_s_array(le_voisin)--;  // decrease the number of connections for the neighbor
	nv_s_array(addedsite)--;  // decrease the number of connections for the added site itself
	// if the neighbor has no more connections to not added sites (nv_s==0), and it don't belong to the lead interface (sys2res=not_lead), then this neighbor should be removed from the interface
	if (nv_s_array(le_voisin)==0&&Base::p_sys->sys2res(le_voisin)==sys_inf::not_lead) {
	  const int& deleted=le_voisin;     // site to be deleted from the interface
	  int deletedGF=Base::s2g(deleted); // -deleted- GF index
	  Base::s2g(deleted)=N2P(deletedGF);// GF index of -deleted- site is "saved" via negative value; NPS=negative to positive bijection
	  if (deletedGF!=Base::taille-1) {  // if deleted site is not the last one in g2s we replace it by those from the top of the g2s list
	    changed_GF_ind_set.insert(deletedGF);          // this indexGF will not be the same in advanced and initial positions
	    Base::g2s(deletedGF)=Base::g2s(Base::taille-1);// -deleted-'s GF index is taken by the site with the biggest GF index (taille-1)
	    Base::s2g(g2s(Base::taille-1))=deletedGF;      // the reverse function for the biggest GF index site is also modified 
	  };
	  Base::taille--;                      // the number of the interface sites is decreased
	};//site was deleted
      };
    };   
  };
  // SECOND -added- site is added to the system
  Base::s2g(addedsite)=Base::taille;
  Base::g2s(Base::taille)=addedsite;
  Base::taille++;
  // if added site has nv_s==0 then we delete it, it's made because then we keep track of the fact that this site was knitted out
  if (nv_s(addedsite)==0&&Base::p_sys->sys2res(addedsite)==sys_inf::not_lead) {Base::s2g(addedsite)=N2P(Base::s2g(addedsite));Base::taille--;}
  // THIRD we apply our fixed GFposition for leads sites
  //if -added- site belongs to the lead -l- and has index_lead -li- then put it in position lead_offset(l)+li 
  else if (Base::p_sys->sys2res(addedsite)!=sys_inf::not_lead){
    const int& indGF4lead=lead_offset(Base::p_sys->sys2res(addedsite)) + Base::p_sys->sys2res_ind(addedsite);
    const int& site2replace=Base::g2s(indGF4lead);
#ifdef _DEBUG_
    if (indGF4lead >= Base::taille) {
      cout<<"debut="<<debut<<"\t fin="<<fin<<endl;
      cout<<"indGFlead="<<indGF4lead<<"\t taille="<<Base::taille<<endl;
      ERROR("WARNING position_knit::addsite() : fixed position for lead's site is out of range");
    };
#endif
    //move "site to be replaced" on top 
    Base::s2g(site2replace)=Base::taille-1;
    Base::g2s(Base::taille-1)=site2replace;
    //put lead's site on it's fixed place
    Base::s2g(addedsite)=indGF4lead;
    Base::g2s(indGF4lead)=addedsite;  
    // both exchanged GF indexes will not be the same in advanced and initial positions
    changed_GF_ind_set.insert(Base::taille-1);
    changed_GF_ind_set.insert(indGF4lead);
  };
#ifdef _DEBUG_LONG_
  Base::s2gTEST();// test of GF <-> system correspondance. Verify if g2s and s2g are inversed functions
#endif
  return;
};


//delsite(deleted_site) delete -deleted_site- from the position_knit (use system index notations), it is necessairy to suppress lead sites
template<class Tmicromatrix>
void position_knit<Tmicromatrix>::delsite(int deleted_site){
#ifdef _DEBUG_LONG_ // check if we don't try to delete sites outside of the sample
  if (deleted_site<0) ERROR("In position_knit::delsite() trying to suppress site before the first one");
  if (deleted_site>=Base::p_sys->fsize()) ERROR("In position_knit::delsite() trying to suppress site beyond the last one");
  if (Base::s2g(deleted_site)==Base::outlace) ERROR("In position_knit::delsite() trying to suppress site that is not inside the lace");
#endif
  // First we check if it is the fixed GFposition for leads sites 
  //if -deleted- site belongs to the lead -l- and has index_lead -li- then put it on top, and at the same time put "top" site in position lead_offset(l)+li 
  if (Base::p_sys->sys2res(deleted_site)!=sys_inf::not_lead){
    const int& indGF4lead=lead_offset(Base::p_sys->sys2res(deleted_site)) + Base::p_sys->sys2res_ind(deleted_site);
    const int top_site=Base::g2s(Base::taille-1);
#ifdef _DEBUG_
    if (indGF4lead >= Base::taille) 
      ERROR("WARNING in position_knit::delsite() : fixed position for lead's site is out of range");
    if (indGF4lead != Base::s2g(deleted_site))
      ERROR("position_knit::delsite() : leads site that is to be deleted was not saved on its fixed position for lead's site");
#endif
    // both exchanged GF indexes will not be the same in advanced and initial positions
    changed_GF_ind_set.insert(Base::taille-1);
    changed_GF_ind_set.insert(indGF4lead);
    //move "top site" on fixed GF position for leads sites 
    Base::s2g(top_site)=indGF4lead;
    Base::g2s(indGF4lead)=top_site;
    //put lead's site on the top
    // AAA Next two lines are not really needed while lead site is allways deleted from the interface in the next operation
    Base::s2g(deleted_site)=Base::taille-1;
    Base::g2s(Base::taille-1)=deleted_site;
  };
  // if deleted site is present in the lace (s2g>=0) then we reduce actual size of the sample  
  if (Base::s2g(deleted_site)>=0) Base::taille--;
  // site is deleted from the system: s2g and nv_s are set to the "outlace" values
  Base::s2g(deleted_site)=Base::outlace;
  nv_s_array(deleted_site) = -Base::p_sys->fzmax();   //conventional non realistic value -zmax
  const  Array<int,1> les_voisins=Base::p_sys->vvoisin(deleted_site);
  for (int z=Base::p_sys->fzmax()-1;z>=0;--z) {   // loop over all nearest neighbors
    int le_voisin=les_voisins(z);             // system index of the neighbor
    // different scenarios depending on the neighbor positions
    //if the neighbor is outside of the sample or  do nothing    
    if (le_voisin==sys_inf::outsample) continue;
    //if the neighbor was deleted by knitting => add it to lace
    if (nv_s(le_voisin)==0 && Base::s2g(le_voisin)<0 ) {
      Base::taille++;
      const int& added=le_voisin;     // site to be added to the interface
      const int addedGF=N2P(Base::s2g(added)); // added will have this GF index
      // if this site is not to be added as the last one
      // then first move actual addedGF pair on the top
      if ( addedGF != Base::taille-1) {Base::g2s(Base::taille-1)=Base::g2s(addedGF); Base::s2g(Base::g2s(addedGF))=Base::taille-1;};
      changed_GF_ind_set.insert(addedGF);        // this indexGF will not be the same in advanced and initial positions
      changed_GF_ind_set.insert(Base::taille-1); // this indexGF will not be the same in advanced and initial positions
      //update added site system <-> GF correspondance, and nv_s
      Base::s2g(added)=addedGF;
      Base::g2s(addedGF)=added;
    };
    if (nv_s(le_voisin)>=0 ) nv_s(le_voisin)++;
  };
#ifdef _DEBUG_LONG_
  Base::s2gTEST();// test of GF <-> system correspondance. Verify if g2s and s2g are inversed functions
#endif
};
