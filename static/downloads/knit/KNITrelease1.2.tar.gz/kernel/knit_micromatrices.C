// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include "knit_micromatrices.h"

/***********functions not declaired inside scalarM**************/
// cout<<
ostream& operator<<(ostream& output, const scalarM& a)
  {
 cout.precision(3);
 cout<<fixed;
 output<<a(0,0);
 return output;
  };

/** This mode permit to test micromatrices implementation
c++ -llapack -D_TESTING_ -D_DEBUG_ -O2 -o test.out knit_micromatrices.C **/
#ifdef _TESTING_

int rank=0;
int size=1;

int main(){

  typedef vectorM<2> testM;
  vectorM<2> A,B,C,D;

// construction of matrix

  A(0,0)=2;A(0,1)=3;
  A(1,0)=1;A(1,1)=2;
  cout<<"A=int --"<<endl<<A<<endl;
  B(0,0)=2.5; B(0,1)=0.5;
  B(1,0)=1.5; B(1,1)=3.5;
  cout<<"B=double --"<<endl<<B<<endl;
  C(0,0)=COMPLEX(1,3);  C(0,1)=COMPLEX(3,3);
  C(1,0)=COMPLEX(2,3);  C(1,1)=COMPLEX(0,3);
  cout<<"C=COMPLEX --"<<endl<<C<<endl;
  D=A+B;
  cout<<"D=A+B  --- "<<endl<<D<<endl;
  D+=A; 
  cout<<"D+=A  --- "<<endl<<D<<endl;
  D=2+A; 
  cout<<"D+=2  --- "<<endl<<D<<endl;
  D*=A;
  cout<<"D*=A  ---- "<<endl<<D<<endl;
  D*=COMPLEX(0,1);
  cout<<"D*= i  ---- "<<endl<<D<<endl;
  cout<<"D.inverse()  ---- "<<endl<<D.inverse()<<endl;
  cout<<"C.hconjugate()  ---- "<<endl<<C.hconjugate()<<endl;
  Array<COMPLEX,2> AA(C.micro2arr());
  cout<<"micro2array"<<AA<<endl;
  cout<<"array2micro"<<endl<<arr2micro<testM>(AA)<<endl;
  D=A*B;
  cout<<"D=A*B  ---- "<<endl<<D<<endl;
  D=C*C;
  cout<<"D=C^2=  ---- "<<endl<<D<<endl;
  D*=4;
  cout<<"D*=4=  ---- "<<endl<<D<<endl;
  D=2*C;
  cout<<"D=2*C=  ---- "<<endl<<D<<endl;
  D=C*3;
  cout<<"D=C*3=  ---- "<<endl<<D<<endl;

  cout<<endl<<"SCALAR MATRIX EXAMPLES"<<endl<<endl;
  scalarM a,b,c,d;

// construction of matrix

  a(0,0)=2;
  cout<<"a=int --"<<a<<endl;
  b(0,0)=2.2345;
  cout<<"b=double --"<<b<<endl;
  c(0,0)=COMPLEX(1,3);
  cout<<"c=COMPLEX --"<<c<<endl;
  d=a+b;
  cout<<"d=a+b  --- "<<d<<endl;
  d+=a;
  cout<<"d+=a  --- "<<d<<endl;
  d=a*b;
  cout<<"d=a*b  ---- "<<a*b<<endl;
  d=c*c;
  cout<<"d=c^2=  ---- "<<d<<endl;
  d*=4;
  cout<<"d*=4=  ---- "<<d<<endl;
  d=2*c;
  cout<<"d=2*c=  ---- "<<d<<endl;
  d=c*3;
  cout<<"d=c*3=  ---- "<<d<<endl;

  return 0;
};
#endif
