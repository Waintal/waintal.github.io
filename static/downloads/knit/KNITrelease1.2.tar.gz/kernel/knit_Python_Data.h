// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef READ_PYTHON
#define READ_PYTHON

#include <string>
#include <sstream>
#include <vector>
#include <complex>

#ifndef FATAL
#define FATAL(s) { std::clog<<"FATAL : "<<s<<endl; exit(1);}
#endif

#ifndef COMPLEX
#define COMPLEX complex<double>
#endif

using namespace std;

namespace PythonData {

/** Policy for Python_Data : 
    
   Strict = the data must be present or the program stops

   Optional = it is optional. If not present a standard default is returned.
 */
enum Policy {Strict,Optional};

/** A simple class to embed the python interpreter for the purpose of inputs (and outputs!)

   Usage : 

         - The input file is digested by the class at construction. 
	   One can then pick up the values from the file,
           or change their value, print the defined data (output) as a python input file...
           Outputs can then be inputs of another program......

	 - The input file is a python file, so one can use any python command.
	   - "from math import *" is automatically done.
           - a new command include has been added : include("file1") e.g.
           - Warning : Don't use variables starting with _, except for local calculations. (some are used for internal work)
	   - The boolean are new (python>2.3) so use integers for portability... (method I can load a boolean as an integer).

	   	   
	 -  There can be only one instance of the class at a time.
            otherwise the python interpreter has trouble (double initialisation)
            But in general, one has only one input file (if many, use
            the include command I added to python....)

	 -  A correct usage of the class : 
	      Python_Data *DATA = new Python_Data(file_name,preamble);
	      all constructors of various classes that require data
	      delete DATA
	      run the calculations.
	   i.e. the class only lives during the initialisation of the calculations, and 
	   can free memory for the calculations. Moreover, at the end of the init, one is
	   sure that all necessary data are present and the calculation will be done until the end.
	   
	 - To do : one can also dynamically load the lib (to clear the interpreter from the memory after delete DATA),
	   but I am not sure of the portability of this : some machines don't like shared libraries....

*/
class Python_Data
{
public:

  /** python_script is the name of the file to be interpreted
      Python is loaded in memory, it loads the file and interprets it completely (with an exception if error).
      preamble_add_on is a piece of python code to be executed before the script (e.g. a modification 
      of sys.path, an inclusion of a file common to the project : cf lisa code).
 */
  Python_Data (string python_script, string preamble_add_on="");

  /**
     Same but the input file is taken from argv
     if -test is given, the destruction of the object will stop the program
  */
  Python_Data(int argc, char *argv[],string preamble_add_on="");

  /** Clear the python interpreter from memory */
  ~Python_Data();
  
  /** Execute a python command in the interpreter. Returns the output. */
  string exec(string s);

   /** Check if the element nom exist in the interpreter. */
  bool exists(const char * nom);

  /** Returns in a string all defined quantities except _ones (the one starting with a _)
      sorted and written as in a python file (read for input therefore).
  */
  string all();
  
  /** Picks an integer (same as get(nom,i...))  */
  int    I( char * nom, const char * mess="", Policy pol=Strict,int defaut=0);
  
  /** Picks a double  */
  double D( char * nom, const char * mess="", Policy pol=Strict,double defaut=0);

  /** Picks a string */
  string S( char * nom, const char * mess="", Policy pol=Strict,string defaut="");

  /** Picks a boolean  */
  bool B( char * nom, const char * mess="", Policy pol=Strict,bool defaut=false){return(I(nom,mess,pol,(defaut ? 1:0)));}

  /** pick up the variable with name 'nom' and check type. */
  void get( char * nom, bool & b, const char * mess="", Policy pol=Strict,bool defaut=false) {int i = I(nom,mess,pol,defaut); b=(i!=0);}

  /** pick up the variable with name 'nom' and check type. */
  void get( char * nom, int & i, const char * mess="", Policy pol=Strict,int defaut=0) {i = I(nom,mess,pol,defaut);}

  /**  pick up the variable with name 'nom' and check type. */
  void get( char * nom, double & f, const char * mess="", Policy pol=Strict,double defaut=0) {f = D(nom,mess,pol,defaut);}

  /**  pick up the variable with name 'nom' and check type.Exceptions if error  */
  void get( char * nom, string & s, const char * mess="", Policy pol=Strict,string defaut="") {s = S(nom,mess,pol,defaut);}

  /** Pick up a list of int
      Note that it can read tuples as well as lists
  */
  bool get( char * nom, vector<int> & i_arr, const char * mess="", Policy pol=Strict);

  /** Pick up a list of floats
      Note that it can read tuples as well as lists
  */
  bool get( char * nom, vector<double> & f_arr, const char * mess="", Policy pol=Strict);

 /** Pick up a list of double complex
      Note that it can read tuples as well as lists
  */
  bool get( char * nom, vector<COMPLEX> & f_arr, const char * mess="", Policy pol=Strict);

  /** Pick up a matrix of int
   */
  bool get( char * nom, vector< vector<int> > & i_arr, const char * mess="", Policy pol=Strict);
  
  /** Pick up a matrix of float
  */
  bool get( char * nom, vector< vector<double> > & f_arr, const char * mess="", Policy pol=Strict);
  
  /** Pick up a matrix of double complex
  */
  bool get( char * nom, vector< vector<COMPLEX> > & f_arr, const char * mess="", Policy pol=Strict);
  
  /** Pick up an 3d-array of int
   */
  bool get( char * nom, vector<vector< vector<int> > > & i_arr, const char * mess, Policy pol=Strict);

  /** Pick up an 3d-array of float
  */
  bool get( char * nom, vector<vector< vector<double> > > & f_arr, const char * mess="", Policy pol=Strict);

  /** Pick up an 3d-array of double complex
  */
  bool get( char * nom, vector<vector< vector<COMPLEX> > > & f_arr, const char * mess="", Policy pol=Strict);


  /** Inverse operation : we can put a value back 
   */
  template<class T>
    void put ( char * nom,T val)
    { stringstream fs;  fs << nom << " = "<< val << endl; exec(fs.str());}
  
  // A bit different implementations
  inline void put( char* nom, const char *c){put(nom,string(c));}
  void put( char* nom, string s);

  void put ( char * nom,vector<int> val);

  void put ( char * nom,vector<double> val);
  
  void put ( char * nom,vector< vector<int> > val);

  void put ( char * nom,vector< vector<double> > val);
            
private:
  bool test_mode;
  void for_construct(string python_script,string preamble_add_on);

};

}

#endif

 
