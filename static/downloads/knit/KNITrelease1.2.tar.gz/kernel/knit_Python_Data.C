// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include <Python.h>
#include "knit_Python_Data.h"
#include <stdio.h>
#include <iostream>
#include <sstream>

using namespace PythonData;

PyObject* main_namespace;
bool in_use = false; // to avoid multiple instances.

/***********************************************************/

void fail(const char *nom, char * error, const char * mess)
{
  stringstream fs;
  fs << "The element "<< nom<< " "<<error << endl;
  fs << "\nDescription : "<<mess<<endl;
  FATAL(fs.str());
}

PyObject *pyo(const char *nom, const char * mess, Policy pol)
{
  //fs<<"_tmp=string.strip('"<<nom<<"')\n"<<ends; exec(fs.str());
  //*nom =S("_tmp").c_str(); // Necessary smaller
  PyObject* pElem = PyDict_GetItemString(main_namespace, nom);
  
  {
    stringstream fs;
    fs<<"__requis__['"<<nom<<"']='"<<mess<<"'\n"<<ends;string s(fs.str());
    PyRun_SimpleString((char *)s.c_str());
  }

  if ((pElem==NULL) && (pol==Strict))  fail(nom,"does not exist",mess);
  if (pElem==NULL) {
     stringstream fs;
     fs<<"__pastrouve__['"<<nom<<"']='"<<mess<<"'\n"<<ends;string s(fs.str());
     PyRun_SimpleString((char *)s.c_str());
  }
  return(pElem);
}


/***********************************************************/
Python_Data::Python_Data(int argc, char *argv[],string preamble_add_on)
{
  test_mode=false;
  
  bool ok=false;string fich;
  if (argc>=2) {
    if ((string(argv[1])=="-test")&&(argc>=3))  {ok=true; fich=argv[2];test_mode=true;}
    else {ok=true; fich=argv[1];}
  }
  if (!ok) FATAL("Usage : program input_file  OR program -test input_file");
  for_construct(fich,preamble_add_on);
}

/***********************************************************/

Python_Data::Python_Data(string python_script,string preamble_add_on)
{
  test_mode =false;
  for_construct(python_script,preamble_add_on);
}
/***********************************************************/

void Python_Data::for_construct(string python_script,string preamble_add_on)
{
  if (in_use) {
    FATAL("FATAL : There is already a Python_Data class using the interpreter");
  }
  
  Py_Initialize();
  PyObject* main_module    = PyImport_AddModule("__main__");
  main_namespace = PyModule_GetDict(main_module);
  Py_INCREF(main_namespace);

  FILE *fp = fopen(python_script.c_str(),"r");
  if (!fp) 
    {  
      stringstream fs;
      fs<< "File "<< python_script<<" not found ";
      FATAL(fs.str());
    }
  else
    {
      // First the preamble 

      char *preamble = "from math import *  \n\
___local_for_include_DONT_CHANGE = locals() \n\
def include(f) :                              \n\
    global ___local_for_include_DONT_CHANGE      \n\
    execfile(f,globals(),___local_for_include_DONT_CHANGE)   \n\
class StdoutCatcher:  \n\
     def __init__(self):\n\
        self.data = ''                \n\
     def write(self, stuff):            \n\
        self.data = self.data + stuff    \n\
import sys,os                             \n\
sys.stdout = StdoutCatcher()              \n\
_old_local = locals().copy()              \n\
sys.path = ['./'] + sys.path \n\
__requis__={} \n\
__pastrouve__={} \n\
";
      
      PyRun_SimpleString(preamble);
      char *c22 = new char[preamble_add_on.length()+1]; strcpy(c22,preamble_add_on.c_str());
      if (PyRun_SimpleString(c22)) FATAL("Error in the preamble of the script");
      delete c22;
      c22 = new char[python_script.length()+1]; strcpy(c22,python_script.c_str());
      if (PyRun_SimpleFile(fp,c22)) FATAL("Error in the script interpretation");
      delete c22;
      // do something ?
    }
  
  in_use = true;
}

/***********************************************************/

Python_Data::~Python_Data() 
{   
  Py_Finalize();
  in_use =false;
  if (test_mode) {cout<<"TEST MODE : TEST SUCCESSFULL"<<endl;exit(0);}
}

/***********************************************************/

bool Python_Data::exists(const char * nom)
{
  PyObject* pElem = pyo(nom,"",Optional);
  return (pElem!=NULL);
}

/***********************************************************/

string  Python_Data::exec(string s) 
{ 
  // Clear the output !
  PyRun_SimpleString("sys.stdout.data=''"); 
  PyRun_SimpleString((char *)s.c_str());
  PyRun_SimpleString("__tmp = sys.stdout.data"); 
  return(S("__tmp"));
}


/***********************************************************/

string Python_Data::all()
{ 
  return ( exec(" \n\
print '# List of all defined variables' \n\
_l = locals().keys() \n\
_l.sort() \n\
for _x in _l : \n\
  if not(_x in _old_local) and (_x[0]!='_') and (locals()[_x]!=None) and (type(_x)!=type(sys)) :\n\
    print _x,'=',locals()[_x]\n\
print '#'\n\
"));
}


/***********************************************************/

int  Python_Data::I(char *nom, const char * mess, Policy pol, int defaut)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);
  if (pElem==NULL) return(defaut); // default case
  
  if (PyInt_Check(pElem))
    return(PyInt_AsLong(pElem));
  else fail(nom," is not an integer !",mess);
  return(0);
}

/***********************************************************/

double  Python_Data::D(char *nom, const char * mess, Policy pol, double defaut)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);;if (pElem==NULL) return(defaut);
  
  if (PyInt_Check(pElem))  return(double(PyInt_AsLong(pElem)));
  if (PyFloat_Check(pElem)) return( PyFloat_AsDouble(pElem));
  else fail(nom , " is not an integer or a float  !",mess);
  return(0);
}

/***********************************************************/

string Python_Data::S( char *nom, const char * mess, Policy pol,string defaut)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(defaut);
  
  if (PyString_Check(pElem))  
    return(PyString_AsString(pElem));
  else fail(nom," is not a string !",mess);
  return("");
}

/***********************************************************/

bool is_list(PyObject* pElem, char * nom)
{ 
  stringstream fs;
  if ((!PyList_Check(pElem)) && (!PyTuple_Check(pElem)))
    fail(nom," is not a list or a tuple !","");
  return ( PyList_Check(pElem));
}


/***********************************************************/

vector<int> trans_list_int(bool  list_not_tuple, PyObject* pElem)
{ 
  stringstream fs;
  vector<int> i_arr;
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      if (!PyInt_Check(p))
	{
	  fs << "The element number  "<< i+1<< " of the list is not an integer !" << endl;
	  FATAL(fs.str());
	}
      i_arr.push_back(PyInt_AsLong(p));
    }
  return(i_arr);
}

/***********************************************************/

vector<double> trans_list_double(bool  list_not_tuple, PyObject* pElem)
{ 
  stringstream fs;
  vector<double> f_arr;
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      if ((!PyInt_Check(p)) && (!PyFloat_Check(p)))
	{
	  fs << "The element number  "<< i+1<< " of the list is not an integer or a float !" << endl;
	  FATAL(fs.str());
	}
       if (PyInt_Check(p))  f_arr.push_back(PyInt_AsLong(p));
       if (PyFloat_Check(p))  f_arr.push_back(PyFloat_AsDouble(p));
    }
  return(f_arr);
}

/***********************************************************/

vector<COMPLEX> trans_list_complex(bool  list_not_tuple, PyObject* pElem)
{ 
  stringstream fs;
  vector<COMPLEX> f_arr;
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      if ((!PyInt_Check(p)) && (!PyFloat_Check(p)) && (!PyComplex_Check(p)))
	{
	  fs << "The element number  "<< i+1<< " of the list is not an integer or a float !" << endl;
	  FATAL(fs.str());
	}
       if (PyInt_Check(p))  f_arr.push_back(PyInt_AsLong(p));
       if (PyFloat_Check(p))  f_arr.push_back(PyFloat_AsDouble(p));
       if (PyComplex_Check(p)) { COMPLEX z(PyComplex_RealAsDouble(p),PyComplex_ImagAsDouble(p));f_arr.push_back(z);}
    }
  return(f_arr);
}


/***********************************************************/

bool Python_Data::get( char * nom,  vector<int> & i_arr, const char * mess, Policy pol)
{
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);
  bool list_not_tuple = is_list(pElem,nom);
  i_arr = trans_list_int( list_not_tuple,pElem);
  return(true);
}

/***********************************************************/

bool Python_Data::get( char * nom,  vector<double> & f_arr, const char * mess, Policy pol)
{
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);    
  bool list_not_tuple = is_list(pElem,nom);
  f_arr = trans_list_double( list_not_tuple,pElem);
  return(true);
}

/***********************************************************/

bool Python_Data::get( char * nom,  vector<COMPLEX> & f_arr, const char * mess, Policy pol)
{
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);    
  bool list_not_tuple = is_list(pElem,nom);
  f_arr = trans_list_complex( list_not_tuple,pElem);
  return(true);
}

/***********************************************************/

 bool Python_Data::get( char * nom, vector< vector<int> > & i_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol); if (pElem==NULL) return(false);  
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p,nom);//string(nom) + string(": Level 2"));
      i_arr.push_back(trans_list_int( list_not_tuple2,p));
    }
  return(true);
}


/***********************************************************/

 bool Python_Data::get( char * nom, vector< vector<double> > & f_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);    
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p,nom);
      f_arr.push_back(trans_list_double( list_not_tuple2,p));
    }
  return(true);
}

/***********************************************************/

 bool Python_Data::get( char * nom, vector< vector<COMPLEX> > & f_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);    
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p,nom);
      f_arr.push_back(trans_list_complex( list_not_tuple2,p));
    }
  return(true);
}

/***********************************************************/

 bool Python_Data::get( char * nom, vector<vector< vector<int> > > & i_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p2 = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p2,nom);//string(nom) + string(": Level 2"));
      int Taille2 = (list_not_tuple2 ?  PyList_Size(p2) :PyTuple_Size(p2));
      vector<vector<int> > i_arr1;
      for (int i2=0;i2<Taille2;i2++) 
	{
	  PyObject *p3 = (list_not_tuple ?  PyList_GetItem(p2,i2) : PyTuple_GetItem(p2,i2));
	  bool list_not_tuple3 = is_list(p3,nom);
	  i_arr1.push_back(trans_list_int( list_not_tuple3,p3));
	}
      i_arr.push_back(i_arr1);
    }
  return(true);
}

/***********************************************************/

 bool Python_Data::get( char * nom, vector<vector< vector<double> > > & f_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);   
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p2 = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p2,nom);//string(nom) + string(": Level 2"));
      int Taille2 = (list_not_tuple2 ?  PyList_Size(p2) :PyTuple_Size(p2));
      vector<vector<double> > f_arr1;
      for (int i2=0;i2<Taille2;i2++) 
	{
	  PyObject *p3 = (list_not_tuple ?  PyList_GetItem(p2,i2) : PyTuple_GetItem(p2,i2));
	  bool list_not_tuple3 = is_list(p3,nom);
	  f_arr1.push_back(trans_list_double( list_not_tuple3,p3));
	}
      f_arr.push_back(f_arr1);
    }
  return(true);
}

/***********************************************************/

 bool Python_Data::get( char * nom, vector<vector< vector<COMPLEX> > > & f_arr, const char * mess, Policy pol)
{
  stringstream fs;
  PyObject* pElem = pyo(nom,mess,pol);if (pElem==NULL) return(false);   
  bool list_not_tuple = is_list(pElem,nom);
  
  int Taille = (list_not_tuple ?  PyList_Size(pElem) :PyTuple_Size(pElem));
  for (int i=0;i<Taille;i++) 
    {
      PyObject *p2 = (list_not_tuple ?  PyList_GetItem(pElem,i) : PyTuple_GetItem(pElem,i));
      bool list_not_tuple2 = is_list(p2,nom);//string(nom) + string(": Level 2"));
      int Taille2 = (list_not_tuple2 ?  PyList_Size(p2) :PyTuple_Size(p2));
      vector<vector<COMPLEX> > f_arr1;
      for (int i2=0;i2<Taille2;i2++) 
	{
	  PyObject *p3 = (list_not_tuple ?  PyList_GetItem(p2,i2) : PyTuple_GetItem(p2,i2));
	  bool list_not_tuple3 = is_list(p3,nom);
	  f_arr1.push_back(trans_list_complex( list_not_tuple3,p3));
	}
      f_arr.push_back(f_arr1);
    }
  return(true);
}

/***********************************************************/

void Python_Data::put( char* nom, string s)
  { 
    stringstream fs;  
    fs << nom << " ='"<< s << "'"<<endl; 
    exec(fs.str());
  }

/***********************************************************/

void Python_Data::put ( char * nom,vector<int> val)
{ 
  stringstream fs;   fs << nom << " = ["; 
  for (uint i=0; i<val.size();i++) fs << val[i] << ",";
  fs <<"]"<<endl;
  exec(fs.str());
}

void Python_Data::put ( char * nom,vector<double> val)
{ 
  stringstream fs;  fs << nom << " = ["; 
  for (uint i=0; i<val.size();i++) fs << val[i] << ",";
  fs <<"]"<<endl;
  exec(fs.str());
}


/***********************************************************/


void Python_Data::put (char * nom,vector<vector <int> > val)
{ 
  stringstream fs;   fs << nom << " = ["; 
  for (uint i=0; i<val.size();i++) 
    {
      fs << "[";
      for (uint j=0; j<val[i].size();j++) fs<<val[i][j] << ",";
      fs <<"],"<<endl;
    } 
  fs <<"]"<<endl;
  exec(fs.str());
}

void Python_Data::put (char * nom,vector< vector<double> > val)
{ 
  stringstream fs;   fs << nom << " = ["; 
  for (uint i=0; i<val.size();i++) 
    {
      fs << "[";
      for (uint j=0; j<val[i].size();j++) fs<<val[i][j] << ",";
      fs <<"],"<<endl;
    } 
  fs <<"]"<<endl;
  exec(fs.str());
}

/***********************************************************/
