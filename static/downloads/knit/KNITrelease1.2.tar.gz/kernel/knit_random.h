// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


// file "random.hpp"
// written by Jerome Houdayer
// see file "random.hlp" for more informations
// see file "random.cpp" for implementation
// see file "random_ex.cpp" for example

// RCS header $Id: random.hpp,v 1.1 2001/11/30 12:35:56 houdayer Exp $

#ifndef Random_Hpp_
#define Random_Hpp_
// file "general.hpp"
// written by Jerome Houdayer
// See file "general.hlp" for more informations
// RCS header $Id: general.hpp,v 1.1 2001/11/30 12:20:14 houdayer Exp houdayer $

#ifndef General_Hpp_
#define General_Hpp_

#include <new>
#include <typeinfo>
#include <string>

#include <math.h>
#include <stdlib.h>

#include <iostream>
#include <fstream>
#include <iomanip>
#include <sstream>

typedef unsigned short ushort;
typedef unsigned int uint;
typedef unsigned long ulong;

typedef int int32bits;
//typedef long int64bits;
typedef uint uint32bits;
//typedef ulong uint64bits;

using namespace std;

template <class X> inline void Swap(X &a, X &b)
{X tmp = a; a = b; b = tmp;}

template <class X, class Y> inline bool operator != (const X &a, const Y &b)
{return !(a==b);}

template <class X, class Y> inline bool operator > (const X &a, const Y &b)
{return b<a;}

template <class X, class Y> inline bool operator <= (const X &a, const Y &b)
{return !(b<a);}

template <class X, class Y> inline bool operator >= (const X &a, const Y &b)
{return !(a<b);}

template <class X> inline const X &Min(const X &a, const X &b)
{return (a<b) ? a : b;}

template <class X> inline const X &Max(const X &a, const X &b)
{return (a<b) ? b : a;}

#endif


typedef uint32bits r_int;

//              **********************************
//              *                                * 
//              * 1. Definition of the interface *
//              *                                * 
//              **********************************

// a practical interface to the generators
// the last 5 member functions are freely
// adapted from Numerical Recipes

template <class generator> class randinterface {
public :
  randinterface();                         // the constructor
  void Seed(r_int seed);                   // to set the seed (default is 1)
  r_int Max();                             // the greatest possible value
  r_int Next();                            // the next row random number
  double Double();                         // a random double in [0,1)
  double operator () ();                   // the same
  int Int(int k);                          // a random int in 0..k-1
  int operator () (int k);                 // the same
  int Int(int min, int max);               // a random int in min..max
  int operator () (int min, int max);      // the same
  int Bit();                               // 0 or 1 (proba .5)
  int Sign();                              // 1 or -1 (proba .5)
  bool Bool();                             // true or false (proba .5)
  bool Proba(double p);                    // true with proba p
  bool Metro(double K);                    // means Proba(exp(-K)) but faster
  double Exponential();                    // dist. e^-x (x>=0)
  double Gaussian();                       // dist. e^(-x^2/2)/sqrt(2pi)
  double Lorentzian();                     // dist. 1/(pi(1+x^2))
  double Gamma(int n);                     // dist. (x^(n-1)e^-x)/gamma(n)
  int Poisson(double t);                   // dist. (t^x e^-t)/x!
protected :
  generator gen;                           // the generator
  double scale;                            // for Double()
  r_int sign_thresh;                       // for Sign(), Bit() and Bool()
  bool savedgauss; double othergauss;      // for Gaussian() 
};

//           ************************************
//           *                                  *
//           * 2. Definitions of the generators *
//           *                                  *
//           ************************************

// **************************
// * 2.0 Model of generator *
// **************************

#ifdef IMPLEMENT_MY_GENERATOR   // not supposed to happen, but no problem if it does
class my_generator {
public :
  my_generator();  // initialization (Seed is always called by randinterface)
  ~my_generator(); // the destructor (you probably don't need it)
  r_int Max();     // returns the largest possible return value of Next()
  void Seed(r_int seed); // sets the seed (never given 0 by randinterface)
  r_int Next();          // returns the next random number (in 0..Max)
                         // Next() should be 'inline'
protected :
  // put your data here
};
#endif

// ****************************
// * 2.1 Definition of lingen *
// ****************************

// simple and relatively good congruential generator
// x_{n+1} = (a * x_n) modulo m

template <int a, int m> class lingen {
public :
  r_int Max() {return m - 1;}
  void Seed(r_int seed) {last = seed % m;}
  r_int Next() {
    int32bits z = last / (m / a);
    last = a * (last - (m / a) * z) - (m % a) * z;
    if (last<0) last += m;
    return last;
  }
protected :
  int32bits last;
};

typedef lingen<69621, 2147483647> lingen1;
typedef lingen<48271, 2147483647> lingen2;
typedef lingen<16807, 2147483647> lingen3;
typedef lingen<40014, 2147483563> lingen4;
typedef lingen<40692, 2147483399> lingen5;

// *****************************
// * 2.2 Definition of fastgen *
// *****************************

// very fast and dirty generator
// x_{n+1} = (1664525 * x_n + 1013904223) modulo 2^32

class fastgen {
public :
  r_int Max() {return 0xFFFFFFFF;}
  void Seed(r_int seed) {last = seed;}
  r_int Next() {return last = 1664525 * last + 1013904223;}
protected :
  r_int last;
};


// ****************************
// * 2.3 Definition of xorgen *
// ****************************

// deadly huge period generator, and also quite good and fast
// x_n = x_{n-k} + x_{n-p}
// period is at least 2^p - 1
// See 'The art of computer programming' by D. Knuth for more info

template <class clgen, int p, int k> class xorgen {
public :
  r_int Max() {return 0xFFFFFFFF;}
  void Seed(r_int seed) {
    clgen gen;
    gen.Seed(seed);
    for (int i=0 ; i<p ; i++) {
      r_int tmp = gen.Next();
      int s = (i & 31);
      data[i] = (s) ? (tmp << s) ^ (tmp >> (32-s)) : tmp;
      // this is a rotation of s bits to the left
    }
    p1 = data + k;
    p2 = data;
    for (int i=0 ; i<2*p ; i++) Next();
  }
  r_int Next() {
    if (++p1==data+p) { p1 = data; p2++; }
    else if (++p2==data+p) p2 = data;
    return (*p1 += *p2);
  }
protected :
  r_int *p1, *p2;
  r_int data[p];
};

typedef xorgen<fastgen, 9689, 4187> xorgen1;
typedef xorgen<fastgen, 9689, 471> xorgen2;
typedef xorgen<fastgen, 127, 30> xorgen3;
typedef xorgen<fastgen, 89, 38> xorgen4;


// ******************************
// * 2.4 Definition of criptgen *
// ******************************

// abstract generator which substracts two generators modulo the largest range

template <class clgen1, class clgen2> class criptgen {
public :
  criptgen() {
    if (gen1.Max()<gen2.Max() || gen1.Max()>2147483646) {
      cerr << "Error in criptgen : gen1 must have a larger range than gen2\n";
      cerr << "and must return numbers strictly less than 2^31-1\n";
      exit(-1);
    }
    shift = 1 + gen1.Max();
  }
  r_int Max() const
    {return gen1.Max();}
  void Seed(r_int seed)
    {gen1.Seed(seed); gen2.Seed(seed);}
  r_int Next() {
    int32bits result = int32bits(gen1.Next()) - int32bits(gen2.Next());
    if (result<0)
      result += shift;
    return result;
  }
protected :
  int32bits shift;
  clgen1 gen1;
  clgen2 gen2;
};

// ******************************
// * 2.5 Definition of shiftgen *
// ******************************

// the same as cryptgen (but with addition) when the largest range is 2^32

template <class clgen1, class clgen2> class shiftgen {
public :
  shiftgen() {
    if (gen1.Max()!=0xFFFFFFFF) {
      cerr << "Error in shiftgen : gen1 must have a range = 0..2^32-1\n";
      exit(-1);
    }
  }
  r_int Max()
    {return 0xFFFFFFFF;}
  void Seed(r_int seed)
    {gen1.Seed(seed); gen2.Seed(seed);}
  r_int Next()
    {return gen1.Next() + gen2.Next();}
protected :
  clgen1 gen1;
  clgen2 gen2;
};


//              ********************************************
//              *                                          *
//              * 3. Predefined types of random generators *
//              *                                          *
//              ********************************************

typedef randinterface<fastgen> fastrandom;
typedef randinterface<lingen1> simplerandom;
typedef randinterface<xorgen1> goodrandom;
typedef randinterface<shiftgen<xorgen1, fastgen> > bestrandom;
typedef randinterface<shiftgen<xorgen1, xorgen3> > superrandom;

extern goodrandom Random;

//              ***************************************
//              *                                     *
//              *  4 Implementation of randinterface  *
//              *                                     *
//              ***************************************

template <class generator>
inline r_int randinterface<generator>::Max()
{return gen.Max();}

template <class generator>
inline r_int randinterface<generator>::Next()
{return gen.Next();}
  
template <class generator>
inline double randinterface<generator>::Double()
{return scale * Next();}

template <class generator>
inline double randinterface<generator>::operator () ()
{return Double();}

template <class generator>
inline int randinterface<generator>::Int(int k)
{return int(k * Double());}

template <class generator>
inline int randinterface<generator>::operator () (int k)
{return Int(k);}

template <class generator>
inline int randinterface<generator>::Int(int min, int max)
{return min + Int(max - min + 1);}

template <class generator>
inline int randinterface<generator>::operator () (int min, int max)
{return Int(min, max);}

template <class generator>
inline int randinterface<generator>::Bit()
{ return (Next()>sign_thresh); }

template <class generator>
inline bool randinterface<generator>::Bool()
{ return (Next()>sign_thresh); }

template <class generator>
inline int randinterface<generator>::Sign()
{ return (Next()>sign_thresh) ? 1 : -1; }

template <class generator>
inline bool randinterface<generator>::Proba(double p)
{
  if (p<=0)
    return false;
  else if (p>=1)
    return true;
  else
    return Double() < p;
}

template <class generator>
randinterface<generator>::randinterface()
{
  Seed(1);
  scale = 1 / (1.0 + gen.Max());
  sign_thresh = gen.Max() / 2;
}

template <class generator>
void randinterface<generator>::Seed(r_int seed)
{
  savedgauss = false;
  if (seed==0)
    seed = 1396401548; // nothing special with that number
  gen.Seed(seed);
}

// Metro implements a trick to be faster than Proba(exp(-K));
template <class generator>
bool randinterface<generator>::Metro(double K)
{
  if (K<=0)
    return true;
  if (K>23)
    return false; // exp(-23) is less than the precision on Double()

  double rnd = Double();
  // the following tests are based on the fact that exp(x) is convex
  // thus (1) exp(x) >= exp(x0) (1 + x - x0)
  // and (2) exp(x) <= exp(x0) + (x-x0) (exp(x1)-exp(x0))/(x1-x0)
  // (for x0<=x<=x1)
  
  switch (int(K)) {
  case 0:
    // these 2 tests deal with 92% of the cases (for 0<K<1)
    if ((1.5-K)*0.60653065971263342>rnd)
      return true;                  // (1) with x0 = -0.5
    if (1-K*0.63212055882855768<rnd)
      return false;                 // (2) with x0 = 0 and x1 = -1
    break;
  case 1:
    // these 2 tests deal with 97% of the cases (for 1<=K<2)
    if (0.60042359910627195-K*0.23254415793482963<rnd)
      return false;                 // (2) with x0 = -1 and x1 = -2
    if ((2.5-K)*0.22313016014842983>rnd)
      return true;                  // (1) with x0 = -1.5
    break;
  case 2:
    // these 2 tests deal with 99% of the cases (for 2<=K<3)
    if (0.30643171297411019-K*0.085548214868748749<rnd)
      return false;                 // (2) with x0 = -2 and x1 = -3
    if ((3.5-K)*0.082084998623898795>rnd)
      return true;                  // (1) with x0 = -2.5
    break;
  case 3:
    // these 2 tests deal with 99% of the cases (for 3<=K<4)
    if (0.14420135680525323-K*0.031471429479129763<rnd)
      return false;                 // (2) with x0 = -3 and x1 = -4
    if ((4.5-K)*0.030197383422318501>rnd)
      return true;                  // (1) with x0 = -3.5
    break;
  default:
    // this test deals with 98% of the cases (for 4<=K<23)
    if (0.0183156388887341803<rnd) return false;
  }

  return exp(-K)>rnd;
}

template <class generator>
double randinterface<generator>::Exponential()
{
  double x;
  while ((x = Double())==0);
  return -log(x);
}

template <class generator>
double randinterface<generator>::Gaussian()
{
  if (savedgauss) {
    savedgauss = false;
    return othergauss;
  }
  double v1, v2, r;
  do {
    v1 = 2 * Double() - 1;
    v2 = 2 * Double() - 1;
    r = v1 * v1 + v2 * v2;
  } while(r>1 || r==0);
  savedgauss = true;
  r = sqrt(-2*log(r)/r);
  othergauss = v2 * r;
  return v1 * r;
}

template <class generator>
double randinterface<generator>::Lorentzian()
{
  double v1, v2;
  do {
    v1 = 2 * Double() - 1;
    v2 = 2 * Double() - 1;
  } while (v1==0 || v1*v1+v2*v2>1);
  return v2 / v1;
}

template <class generator>
double randinterface<generator>::Gamma(int n)
{
  double x;
  if (n<6) {
    do {
      x = 1;
      for (int i=0 ; i<n ; i++)
	x *= Double();
    } while (x==0);
    x = -log(x);
  }
  else {
    double p, y, m=n-1, s=sqrt(2*n-1);
    do {
      y = Lorentzian();
      x = s * y + m;
      if (x<=0) p = 0;
      else p = (1+y*y)*exp(m*log(x/m)-s*y);
    } while (!Proba(p));
  }
  return x;
}

template <class generator>
int randinterface<generator>::Poisson(double t)
{
  if (t<=0) return 0;
  int r;
  if (t<12) {
    double expt = exp(-t);
    for (t=1, r=-1 ; t>expt ; r++)
      t *= Double();
  }
  else {
    double st = sqrt(2*t), lt = log(t), gt = t * lt - lgamma(t+1);
    double y, p, rd;
    do {
      y = Lorentzian();
      rd = floor(st*y+t);
      if (rd<0) p = 0;
      else p = 0.9 * (1+y*y) * exp(rd*lt-lgamma(rd+1)-gt);
    } while (!Proba(p));
    r = int(rd);
  }
  return r;
}

#endif
