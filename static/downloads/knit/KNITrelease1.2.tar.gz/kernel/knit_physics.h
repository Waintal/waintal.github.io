// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef  knit_PHYSICS_
#define  knit_PHYSICS_
// Here we define some functions used to obtaine different observables
#include "blitz_addon.h"
#include "knit_general.h"
#include "knit_system.h"
#include "knit_geometry.h"
#include "knit_knit.h"

#include <blitz/array.h>

using namespace blitz;

// Transmission coefficient between leadA and leadB
template<class Tmicromatrix>
COMPLEX coef_T(const knit<Tmicromatrix>& kn,int leadA,int leadB) {
#ifdef _DEBUG_
  if (leadA<0 || leadA>=kn.p_system()->fNres() || leadB<0 || leadB>=kn.p_system()->fNres() ) 
    ERROR("in coef_T(knit,leadA,leadB) lead index is out of range");
#endif

  COMPLEX tr_result=0.;

  firstIndex ii;
  secondIndex jj;
  thirdIndex kk;
  fourthIndex ll;
  
  const GF_type SEleadA(kn.SE(leadA));
  const GF_type SEleadB(kn.SE(leadB));

  GF_type GammaA(SEleadA.shape());
  GF_type GammaB(SEleadB.shape());

  // Gamma = Sigma - Sigma^H
  GammaA=SEleadA(ii,jj,kk,ll)-conj(SEleadA(kk,ll,ii,jj));
  GammaB=SEleadB(ii,jj,kk,ll)-conj(SEleadB(kk,ll,ii,jj));
  // Green function between lead A and B
  const GF_type GFAB(kn.G_LL(leadA,leadB));
  // GammaAB=GammaA*GFAB
  const GF_type GammaGAB(matmul(GammaA,GFAB));
  // conjugate Green function between lead B and A
  GF_type GFBA(GFAB.extent(2),Tmicromatrix::dim(),GFAB.extent(0),Tmicromatrix::dim());
  GFBA=conj(GFAB(kk,ll,ii,jj));
  // GammaBA=GammaB*GFAB^H
  const GF_type GammaGBA(matmul(GammaB,GFBA));
  //resArr=GammaA*GF*GammaB*GF^H
  const GF_type  resArr(matmul(GammaGAB,GammaGBA));

  // calculation of trace
  // T=-Trace(resArr) - minus came from i*i from Gamma definition
  for (int lA=0;lA<GFAB.extent(0);++lA) for(int s=0;s<Tmicromatrix::dim();++s) tr_result+=resArr(lA,s,lA,s);
  return -tr_result;
}





// Transmission coefficient between leadA and leadB (using direct inversion)
template<class Tmicromatrix>
COMPLEX coef_T(const direct<Tmicromatrix>& dir,int leadA,int leadB) {
  COMPLEX tr_result=0.;

  firstIndex ii;
  secondIndex jj;
  thirdIndex kk;
  fourthIndex ll;

  const reservoir<Tmicromatrix>* rA=dir.p_system()->p_lead(leadA);
  const reservoir<Tmicromatrix>* rB=dir.p_system()->p_lead(leadB);

  const GF_type SEleadA(rA->selfE(dir.getE()));
  const GF_type SEleadB(rB->selfE(dir.getE()));
  GF_type GammaA(SEleadA.shape());
  GF_type GammaB(SEleadB.shape());
  // Gamma = Sigma - Sigma^H
  GammaA=SEleadA(ii,jj,kk,ll)-conj(SEleadA(kk,ll,ii,jj));
  GammaB=SEleadB(ii,jj,kk,ll)-conj(SEleadB(kk,ll,ii,jj));
  // Green function between lead A and B
  GF_type GFAB(rA->fsize(),Tmicromatrix::dim(),rB->fsize(),Tmicromatrix::dim());
  for (int lA=0;lA<dir.p_system()->lead_size(leadA);++lA)
    for (int lB=0;lB<dir.p_system()->lead_size(leadB);++lB)
      GFAB(lA,ALL,lB,ALL)=dir.G(dir.p_system()->res2sys(leadA,lA),dir.p_system()->res2sys(leadB,lB));
  const GF_type GammaGAB(matmul(GammaA,GFAB));
  GF_type GFBA(rB->fsize(),Tmicromatrix::dim(),rA->fsize(),Tmicromatrix::dim());
  GFBA=conj(GFAB(kk,ll,ii,jj));
  const GF_type GammaGBA(matmul(GammaB,GFBA));
  GF_type  resArr(matmul(GammaGAB,GammaGBA));
  // calculation of trace
  for (int lA=0;lA<rA->fsize();++lA) for(int s=0;s<Tmicromatrix::dim();++s) tr_result+=resArr(lA,s,lA,s);
  return -tr_result; 
};


#endif
