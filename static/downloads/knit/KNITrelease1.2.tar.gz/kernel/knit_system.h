// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef _knit_SYSTEM_
#define _knit_SYSTEM_
/** \file knit_system.h
Module containing the description of the system
(Hamiltonian and Leads). The Hamiltonian is described
in terms of micromatrices that carry the internal 
microscopic degrees of freedom (spin, electron/hole,...) **/

#include "blitz_addon.h"
#include "knit_micromatrices.h"
#include "knit_reservoir.h"

#include <blitz/array.h>
#include <fstream>
#include <map>
#include <set>

using namespace blitz;
typedef complex<double> COMPLEX;


//******************************************************************************** 
/// VARIOUS TECHNICAL DEFINITIONS                                               //*
//********************************************************************************

/// Green Function type GF(i,alpha,j,beta)    
typedef Array<COMPLEX,4> GF_type; 

/// permutation
class permutation{
 public:
  int operator()(const int i) const {return ou(i);};
 private:
  Array<int,1> ou;
};

/// Define <(less operator) in systeme<T>::map<Array<int,1>,int>
class cmp_Array{
 public:
  bool operator()(const Array<int,1>& a,const Array<int,1>& b) const; ///< less-operator a<b
};

/// cout operator<< for map<int,int> 
ostream& operator<<(ostream& output,const map<int,int>& M);
/// cout operator<< for set<int> 
ostream& operator<<(ostream& output,const set<int>& S);


//******************************************************************************** 
/// Describe a finite system Hamiltonian (without leads)                       //*
template <class Tmicromatrix>                                                  //*
class systeme{                                                                 //*
//********************************************************************************
  systeme& operator=(const systeme&); ///< hide the assignement operator
 public:
  systeme():size(0){};                                     ///<default constructor
  systeme(const systeme&);                                 ///<copy constructor
  int coord(int ind,int d) const;                          ///<coordinates d=[0..dim-1] x,y,z of a given site ind ie y of 10-th site = coord(10,1)
  Array<int,1> vcoord(int ind) const;                      ///<coordinates of a given site -ind- in 1D Array form 
  int indice(const Array<int,1>& coordinate) const;        ///<index for the given set of coordinates d=[0..dim-1] x,y,z
  int voisin(int ind,int z) const;                         ///<neighbour z with any index 
  Array<int,1> vvoisin(int ind) const;                     ///<neighbours in vector form with index -ind- 
  Tmicromatrix Mvoisin(int ind,int z) const;               ///<corresponding matrix element
  Array<Tmicromatrix,1> vMvoisin(int ind) const;           ///<corresponding matrix elements in vector form
  Tmicromatrix Msite(int ind) const;                       ///<diagonal      matrix element
  int fdim()  const {return dim;};                         ///<system dimension
  int fsize() const {return size;};                        ///<total number of sites in the system
  int fzmax() const {return zmax;};                        ///<system maximum coordinance
  int z_voisin(int ind,int z) const;                       ///< gives -z- of voisin(ind,z) that points to -ind-
  systeme<Tmicromatrix>& permutme(const permutation& per); ///<permute matrix index.
  //int  efficacity(const permutation& per);
  void sys_print();                                            ///<print all inner data 
  ///merge with system B. Overlapped part is taken from B system
  systeme& coller(const systeme<Tmicromatrix>& B);
  systeme& deplacer(const Array<int,1>& shift);            ///<move the system by the vector shift
  /// assign memory for the system of ssize
  systeme& reset(int ddim, int ssize, int zzmax);
  systeme& addsite(const Array<int,1>& voisins, const Array<Tmicromatrix,1>& hoppings, const Tmicromatrix& Hii, const Array<int,1>& coordinate); ///< add new single site to the system 
  systeme& movesite(const Array<int,1>& voisins, const Array<Tmicromatrix,1>& hoppings, const Tmicromatrix& Hii, const Array<int,1>& coordinate,int iii); ///< move -iii- site in the system
 systeme& translate_system( const Array<int,1>& delta); ///< shifts  a system on the vector delta 
  systeme& delete_site(int iii); ///< removes all links from and to the site  -iii- and puts it out of sample;
  // PYTHON functions
  // short version of addsite for Python
  systeme& add_site(const Array<int,1>& nns, const Tmicromatrix& t, const Tmicromatrix& Hii, const Array<int,1>& coordinate)
    {Array<int,1> voisins(shape(zmax)); voisins=outsample; voisins(Range(0,nns.size()-1))=nns.copy();Array<Tmicromatrix,1> hoppings(shape(zmax)); hoppings=Tmicromatrix();hoppings(Range(0,nns.size()-1))=t; addsite(voisins,hoppings,Hii,coordinate);return *this;};
  // short version of movesite for Python
  systeme& move_site(const Array<int,1>& nns, const Tmicromatrix& t, const Tmicromatrix& Hii, const Array<int,1>& coordinate, int iii)
    {Array<int,1> voisins(shape(zmax)); voisins=outsample; if (nns.size()>0) voisins(Range(0,nns.size()-1))=nns.copy();Array<Tmicromatrix,1> hoppings(shape(zmax)); hoppings=Tmicromatrix();if (nns.size()>0) hoppings(Range(0,nns.size()-1))=t; movesite(voisins,hoppings,Hii,coordinate,iii);return *this;};
  systeme& put_Hdiag(int ind,const Tmicromatrix& Hii) {Mdiag(ind)=Hii;return *this;};
  Tmicromatrix get_Hdiag(int ind) {return Mdiag(ind);};
  systeme& put_Hopp(int ind, int z, const Tmicromatrix& t) {Mhopp(ind,z)=t;
                                                            Mhopp(voisin(ind,z),z_voisin(ind,z))=t.hconjugate();
                                                            return *this;};
  systeme& add_Hopp(int ind, int ind2, const Tmicromatrix& t); ///< Add an non existent hopping element between ind and ind2.
  Tmicromatrix get_Hopp(int ind, int z) {return Mhopp(ind,z);};
  // end of PYTHON functions
  
  // bool TESTing utilities, return true if test succeeded
  ///testing utility compare the system with all protected variables, returns true if test is OK 
  bool comparer(int dimm, int sizee,int zmaxx,const Array<int,2>& xyzz, const map<Array<int,1>,int,cmp_Array>& indice_mapp, const Array<int,2>& hoppp, const Array<Tmicromatrix,2>& Mhoppp, const Array<Tmicromatrix,1>& Mdiagg) const;
  bool xyz2ind_mapTEST() const;            ///< test of xyz <-> indice_map correspondance
  static const int outsample=-1;           ///< this const is used to denote site outside of the sample
  // minus_z works only for square lattice!!! 
  static int minus_z(int z){return (z-2*(z%2)+1);}; // if z is hopping index for <ik> pair then minus z is hopping index for <ki>
 protected:
  int dim;                                 ///< dimension
  int size;                                ///< total number of sites in the system
  int zmax;                                ///< maximum coordinance
  Array<int,2> xyz;                        ///< xyz(ind,j)   contains coordinate j (0..dim-1) of site ind
  /// indice_map(coordinate) contains index of the site with coordinates[x=coordinate(0),y=coordinate(1),etc]
  map<const Array<int,1>,int,cmp_Array> indice_map;
  Array<int,2> hopp;                       ///< hopp(ind,z)  contains neighbour z (0..zmax-1) of site ind
  ///<nearest neighbors are taken as follow:\n 
  ///<for an even value of -z- z/2 coordinate is decreased by one;\n
  ///<for an odd value of -z- (z-1)/2 coordinate is increased by one
  Array<Tmicromatrix,2> Mhopp;             ///< Mhopp(ind,z) contains Matrix Element corresponding to hopp(ind,z)
  Array<Tmicromatrix,1> Mdiag;             ///< Mdiad(ind)   contains Diagonal Matrix Element for site ind
};

typedef systeme<scalarM> s_system;         ///< scalar system type 


/*********** functions not declaired inside system class ****************/
/// join two overlapped systems A and B into a single one. Overlapped part is taken from B system. 
template<class Tmicromatrix>
systeme<Tmicromatrix> coller(const systeme<Tmicromatrix>& A,const systeme<Tmicromatrix>& B)
{systeme<Tmicromatrix> AB=A;return AB.coller(B);};


//**********************RECTANGULAR SYSTEM*********************************
/// Rectangular system, D-dimensional rectangular system                //*
template<class Tmicromatrix>                                            //*
class systemerectangle : public systeme<Tmicromatrix>{                  //*
//*************************************************************************
  systemerectangle & operator=(const systemerectangle&); // hide assignement operator
 public: 
  typedef systeme<Tmicromatrix> Base;
 private:
  Array<int,1> LxLyLz;
  Array<int,1> OxOyOz;
  // Hhopp and Hdiag are used as reference matrix elements for analytic leads constructor
  Tmicromatrix Hhopp;     ///< hopping matrix element from ind=0 site to it's nearest neighbor with lowest -z- index
  Tmicromatrix Hdiag;     ///< diagonal matrix element of ind=0 site
  inline int indice_Dd(const Array<int,1>& xx);///< Gives index of vector -x- in D-dimensional sample LxLyLz
  inline void recursive_init(Array<int,1>& x,int n);///< Initialize protected variables of the Base class ie xyz and indice_map 
 public:  
  Tmicromatrix fHhopp() const {return Hhopp;};
  Tmicromatrix fHdiag() const {return Hdiag;};
  int real_dim() const;  ///< dimension of rectagular system ie if LxLyLz=1,3 then real_dim=1, systeme::dim=2
  /// Constructor from LxLyLz - system size, OxOyOz - point of origin, hopping V and on-site energy H_ii
  systemerectangle(Array<int,1>& LxLyLz,Array<int,1>& OxOyOz,const Tmicromatrix& V, const Tmicromatrix& H_ii);
  systemerectangle(){}; ///< default constructor
  systemerectangle(const systemerectangle<Tmicromatrix>& A); ///< copy constructor 
};

typedef systemerectangle<scalarM> s_systemrectangle;  ///<scalar rectangular system


/**********************GENERAL LEAD**********************************/
/// Describes a semi-infinite lead \n lead is an interface system + Green function of the interface 
template<class Tmicromatrix> 
class reservoir : public systeme<Tmicromatrix>{
 public:
  typedef systeme<Tmicromatrix> Base;
  reservoir(){};                                                  ///< default constructor
  virtual ~reservoir(){};                                         ///< virtual destructor 
  reservoir(const systeme<Tmicromatrix>& sys):Base(sys){};        ///< constructor from any system
  virtual GF_type green(COMPLEX E) const =0;                      ///< Green function of leads interface for the energy E
  virtual GF_type selfE(COMPLEX E) const =0;                      ///< self Energy of leads interface supposing it is connected via inter-slice hopping
  virtual pair<GF_type,GF_type> G_SE(COMPLEX E) const =0;         ///< pair of both Green function and self Energy of leads interface
};


//**********************NUMERIC LEAD***********************************************************************
/// Describes a numeric lead \n numeric lead is an interface system + interface bijection on itself     //*
template<class Tmicromatrix>                                                                            //*
class N_reservoir : public reservoir<Tmicromatrix>{                                                     //*
//*********************************************************************************************************
 public: 
  typedef systeme<Tmicromatrix> BBase;
  typedef reservoir<Tmicromatrix> Base;
  int Nchannels(COMPLEX E) const;
  N_reservoir(){};                               ///< default constructor
  virtual ~N_reservoir(){};                      ///< virtual destructor
  N_reservoir(const N_reservoir& R):             ///< copy constructor 
    Hhopp(R.Hhopp.copy()){};
  /// constructor from interface system, hopping Hamiltonian
  N_reservoir(const systeme<Tmicromatrix>& sys, const GF_type& HHhopp);
  /// constructor from interface system, hopping element (optionnally magnetic field is given flux=phi/phi_0)
  N_reservoir(const systeme<Tmicromatrix>& sys,const Tmicromatrix& hopp, double flux=0.);
  const GF_type getHdiag() const;              ///< get matrix containg intra-slice Hamiltonian
  /// modify inter-slice hopping in the lead
  Tmicromatrix get_leadHopp(int from, int to) {return arr2micro<Tmicromatrix>(Hhopp(from,ALL,to,ALL));};
  N_reservoir& put_leadHopp(int from, int to, const Tmicromatrix& t) {Hhopp(from,ALL,to,ALL)=t.micro2arr(); return *this;};
  virtual GF_type green(COMPLEX E) const;      ///< Green function of leads interface for the energy E
  virtual GF_type selfE(COMPLEX E) const;      ///< self Energy of leads interface supposing it is connected via inter-slice hopping
  ///< pair of both Green function and self Energy of leads interface
  virtual pair<GF_type,GF_type> G_SE(COMPLEX E) const; 
 private:
  GF_type Hhopp;                               ///< inter-slice hopping Hamiltonian
};


/**********************ANALYTIC LEAD**********************************/
/// Describes an analytic lead which are defined by explicit formular for GF
/// analytic leads are defined only for scalar hamiltonian (scalarM Hilbert space)
class A_reservoir : public reservoir<scalarM>{
 public: 
  typedef systeme<scalarM> BBase;
  typedef reservoir<scalarM> Base;
  A_reservoir(){};                                         ///< default constructor
  virtual ~A_reservoir(){};                                ///< virtual destructor
  A_reservoir(const s_systemrectangle& sys_rect);          ///< constructor from interface system given by rectangular system 
  void  print();                                           ///< print analytic reservoir on the screen
  friend ostream& operator<<(ostream&, const A_reservoir&);/// cout<< operation
  virtual GF_type green(const COMPLEX E) const;            ///< Green function of leads interface for the energy E
  virtual GF_type selfE(COMPLEX E) const;                  ///< self Energy of leads interface supposing it is connected via inter-slice hopping
  ///< pair of both Green function and self Energy of leads interface
  virtual pair<GF_type,GF_type> G_SE(COMPLEX E) const; 
 protected:
  scalarM diag;                                            ///< onsite diagonal matrix element for the lead
  scalarM hopp;                                            ///< hopping element inside lead
};



//next two declarations are needed just because we want to define friend template operator<< for the template class
template <class Tmicromatrix> class systeme_infini;


//***************************************************************************************************************************
/// Describes an infinite system with leads                                                                               //*
/// res2sys is two dimensional matrix of size (Nres,max_lead_size), which gives for any lead's site the site of the       //*
/// system connected to it; res2sys(lead,index_lead)=index_system; We choose also that all the sites of the lead's        //*
/// interface are connected to the system and that the hopping matrix elements from the lead to the system are exactly    //*
/// the same as those inside lead itself                                                                                  //*
/// sys2res contains the same information as res2sys array in the different form. It's a vector of system_size size.      //*
/// It is made for faster data access; sys2res(index_system)=lead;  if index_system is not connected to any lead, then    //*
/// its lead number is set to not_lead constant (=-1).                                                                    //*
template<class Tmicromatrix>                                                                                              //*
class systeme_infini : public systeme<Tmicromatrix>{                                                                      //*
//***************************************************************************************************************************
 public:
  typedef systeme<Tmicromatrix> Base;
  systeme_infini(){}; ///< default constructor
  systeme_infini(const systeme<Tmicromatrix>& sys_fini,const reservoir<Tmicromatrix>& res); ///< constructor of system connected to the single lead
  systeme_infini(const systeme_infini<Tmicromatrix>&);                                      ///< copy constructor
  systeme_infini& addlead(const reservoir<Tmicromatrix>& res);                              ///< connect a lead to the systeme_infini
  int fNres() const {return Nres;};                                                         ///< returns number of leads
  const reservoir<Tmicromatrix>* p_lead(int lead) const {return preservoirs(lead);};        ///< pointer to the lead number -lead-
  int res2sys(int lead,int index_lead) const;                                               ///< returns system sites connected to the leads
  int sys2res(int index_system) const;                                                      ///< returns lead's number for all connected sites
  int sys2res_ind(int index_system) const;                                                  ///< returns lead's index for all connected sites
  int lead_voisin(int lead, int li, int z) const;                                           ///< returns lead's index for voisin z of site (lead,li)
  int lead_size(int lead) const {return (preservoirs(lead))->fsize();};                     ///< returns lead's size for lead number -lead-
  int max_lead_size() const {return res2sys_arr.columns();};                                ///< maximum lead size
  
  static int const not_lead=-1;                           ///< sites that don't belong to lead interface are given sys2res() value equal not_lead
 
  // bool TESTing utilities, return true if test succeeded
  ///testing utility compare the system with all protected variables, returns true if test is OK 
  bool comparer(int Nress, const Array<int,2>& res2syss, const Array<int,1>& sys2ress) const;
  bool res2sysTEST() const;                                                                 ///< test of res2sys_arr <-> sys2res_arr correspondance 
private:
  int Nres;                                               ///< number of leads
  Array<const reservoir<Tmicromatrix>*,1> preservoirs;    ///< list of pointer to the leads
  Array<int,2> res2sys_arr;                               ///< list of system sites connected to the leads
  Array<int,1> sys2res_arr;                               ///< list of lead's number for all connected sites
  Array<int,1> sys2res_ind_arr;                           ///< list of lead's index for all connected sites
};

// include all template and inline functions
#include "knit_system.cxx"

#endif // _knit_SYSTEM_


