// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include "blitz_addon.h"
#include "knit_general.h"
#include "knit_system.h"
#include "knit_acos.h"



/// cout operator<< for map<int,int> 
ostream& operator<<(ostream& output,const map<int,int>& M){
map<int,int>::const_iterator CI=M.begin();
 output<<"map("<<M.size()<<')'<<endl;
 for (;CI!=M.end();++CI) output<<"first="<<CI->first<<"; second="
			       <<CI->second<<endl;
  return output;
};


/// cout operator<< for set<int> 
ostream& operator<<(ostream& output,const set<int>& S){
set<int>::const_iterator CI=S.begin();
 output<<"set("<<S.size()<<')'<<endl;
 for (;CI!=S.end();++CI) output<<" "<<*CI<<endl;
  return output;
};


/**********************ANALYTIC LEAD***********************/
/*** Describes an analytic lead which are defined by explicit formula for GF **/

// Print analytic lead data on the screen
void A_reservoir::print(){
  cout<<"Analytic lead printing\n";
  BBase::sys_print();
  cout<<"diag="<<diag<<endl;
  cout<<"hopp="<<hopp<<endl;
  return;
};

// Constructor from an abstract lead(res), hopping(V) and onsite (Hdiag) matrix elements
A_reservoir::A_reservoir(const s_systemrectangle& sys_rect)
 :Base(sys_rect), diag(sys_rect.fHdiag()), hopp(sys_rect.fHhopp()) {
#ifdef _DEBUG_ // the only implemented case is where leads interface is one-dimensional
  if (sys_rect.real_dim()!=1) ERROR("in A_reservoir constructor from systemerectangle the dimension of interface is not equal to one");
#endif
// matrix element is taken from reference matrix elements, the advantage is that Hhopp is defined for any rectangular system even if it has just single site. It could be used to introduce single point constact leads for example voltage probe
//  Base::Hhopp.resize(sys_rect.fsize());
//  for (int li=Base::Hhopp.lbound(firstDim);li<=Base::Hhopp.ubound(firstDim);++li) Base::Hhopp(li)=V;
#ifdef _DEBUG_LONG_
  if (hopp(0,0).real()>0) cout<<"in A_reservoir::A_reservoir hopping matrix element should be negatif hopp<0\n";
  if (hopp(0,0).imag()!=0.) cout<<"in A_reservoir::A_reservoir hopping matrix element should be real im(hopp)=0\n";
#endif
};

// Green function of leads interface for the energy E
// AAA Attention in GFDI and in knit V replaced by -V
GF_type A_reservoir::green(COMPLEX E) const{
  GF_type GFLead; // Green Function of the lead 
  int M=BBase::size;
  GFLead.resize(shape(M,1,M,1));
  // hopp(0,0) is a COMPLEX element of scalarM, this "complicated" notations is used in order to be consistent with general -mitromatrix- definition
#ifdef _DEBUG_
  if (abs(hopp(0,0).imag()) > 0.0000000000001*abs(hopp(0,0).real())) ERROR("A_reservoir::green() hopping is not real");
#endif
  analytic_semi_infini(hopp(0,0).real(), diag(0,0),E,M,GFLead);
  return GFLead;
};


// Self Energy of leads interface for the energy E, supposed it's connected via hopping -hopp- to the system
// AAA Attention in GFDI and in knit V replaced by -V
GF_type A_reservoir::selfE(COMPLEX E) const{
  GF_type GFLead; // Green Function of the lead 
  int M=BBase::size;
  GFLead.resize(shape(M,1,M,1));
  // hopp(0,0) is a COMPLEX element of scalarM, this "complicated" notations is used in order to be consistent with general -mitromatrix- definition
#ifdef _DEBUG_
  if (abs(hopp(0,0).imag()) > 0.0000000000001*abs(hopp(0,0).real())) ERROR("A_reservoir::selfE() hopping is not real");
#endif
  analytic_semi_infini(hopp(0,0).real(), diag(0,0),E,M,GFLead);
  GF_type SE(GFLead*hopp(0,0).real()*hopp(0,0).real());
  return SE;
};


// GF and Self Energy pair of lead
// AAA Attention in GFDI and in knit V replaced by -V
pair<GF_type,GF_type> A_reservoir::G_SE(COMPLEX E) const{
  GF_type GFLead; // Green Function of the lead 
  int M=BBase::size;
  GFLead.resize(shape(M,1,M,1));
  // hopp(0,0) is a COMPLEX element of scalarM, this "complicated" notations is used in order to be consistent with general -mitromatrix- definition
  analytic_semi_infini(hopp(0,0).real(), diag(0,0),E,M,GFLead);
  GF_type SE(GFLead*hopp(0,0).real()*hopp(0,0).real());
  return pair<GF_type,GF_type>(GFLead,SE);
};




// Define <(less operator) in systeme<T>::map<Array<int,1>,int>
// check if a<b
bool cmp_Array::operator()(const Array<int,1>& a,const Array<int,1>& b) const
{
  bool result=false;
  if (a.rows()!=b.rows()) {result=a.rows()<b.rows(); return result;};
  for(int i=a.lbound(firstDim);i<a.rows();++i) if (a(i)!=b(i)) {result=a(i)<b(i);return result;};
  return result;
};



/** This mode permit to test system implementation
c++ -c -O2  knit_micromatrices.C
c++ -c -O2  knit_acos.C
g++ -c -O2 -D_TESTING_ -D_DEBUG_ -I /usr/local/stow/Blitz_g++/include/  knit_system.C	
g++ -o test.out -O2 -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz knit_system.o knit_micromatrices.o knit_acos.o
**/


#ifdef _TESTING_

int rank=0;
int size=1;

int main(){
  //typedef vectorM<2> testM;
  typedef scalarM testM;

  cout<<"********* Creating system with 3 leads  ********\n";
  cout<<9<<"  "<<10<<"  "<<11<<endl
      <<6<<"  "<<7<<"   "<<8 <<endl
      <<3<<"  "<<4<<"   "<<5 <<"  "<<12<<endl
      <<0<<"  "<<1<<"   "<<2 <<endl
      <<13<<endl;
  Array<int,1> LxLyLz(2),OxOyOz(2);
  testM V,Hdiag;
  for (int i=0;i<testM::dim();++i) V(i,i)=-2.;
  for (int i=0;i<testM::dim();++i) Hdiag(i,i)=1.;
  // main system
  LxLyLz=3,4;
  OxOyOz=0,0;
  systemerectangle<testM> sys(LxLyLz,OxOyOz,V,Hdiag);
 
  // first lead
  LxLyLz=3,1;
  OxOyOz=1,1;
  systemerectangle<testM> lead_interface(LxLyLz,OxOyOz,2*V,2*Hdiag); // lead's interface
  N_reservoir<testM> lead(lead_interface,V); // create lead from its interface
  cout<<lead.green(0.1)(0,ALL,1,ALL); //test calculattion of GF
  //  cout<<"LEAD PRINTING"<<endl<<lead<<endl;
  systeme_infini<testM> sys_lead(sys,lead); // created systeme + lead

  // second lead
  LxLyLz=2,1;
  OxOyOz=0,3;
  systemerectangle<testM> lead_interface2(LxLyLz,OxOyOz,3*V,3*Hdiag); // lead's interface
  N_reservoir<testM> lead2(lead_interface2,V); // create lead from its interface
  sys_lead.addlead(lead2);
  // cout<<"SYSTEM+LEAD1+LEAD2 PRINTING"<<endl<<sys_lead<<endl;

  // third lead
  LxLyLz=1,2;
  OxOyOz=0,-1;
  systemerectangle<testM> lead_interface3(LxLyLz,OxOyOz,2*V,5*Hdiag); // lead's interface
  N_reservoir<testM> lead3(lead_interface3,V); // create lead from its interface
  sys_lead.addlead(lead3);
  cout<<sys_lead<<endl;

  cout<<"END of three lead creation test"<<endl;
  //END of three lead creation test
  //////////////////////////////////////////////////////////////
  cout<<"IF YOU TEST SCALARM then next three lines in systme.C code should be removed to continue more extensiv tests"<<endl;
  return 0;};
#endif
#ifdef ZHOPA
  

  cout<<"\nchoose which tests would you like to perform inside of knit_systeme.C\n\n";
  cout<<"******BEGIN of SYSTEM testing on manually checked example******\n\n";
  //choose which tests would you like to perform
  bool test_constructor=true;              //check of the systemerectangle constructor
  bool test_copy=true;                     //test copy constructor
  bool test_deplacer=true;                 //test deplacer member function
  bool test_coller=true;                   //test coller member function
  bool test_addlead=true;                  //test of systeme_infini::addlead
  bool print_on_screen=false;//weather to print full results on screen so one could compare it with those given at the end of this file
  // construction of the systemerectangle
  //system is created using costructor from size 2x3, initial position (10,100), hopping 2 and on-site energy 1
  /*
    3 4 5
    0 1 2
  */
  V(0,0)=-2.;
  Hdiag(0,0)=1.;
  /*********************CONSTRUCTOR TEST*************************************************/
  if (test_constructor) {
    //check of the systemerectangle constructor
    LxLyLz=3,2;
    OxOyOz=10,100;
    if (print_on_screen) {
      cout<<"check of the systemerectangle creation size="<<LxLyLz(1)<<"x"<<LxLyLz(0)<<endl;
      cout<<"system is created using costructor from size LxLyLz, initial position OxOyOz, hopping V and onsite energy Hdiag\n";
      cout<<"LxLyLz="<<LxLyLz<<endl;
      cout<<"OxOyOz="<<OxOyOz<<endl<<endl;
      cout<<"Hopping="<<V<<"    Hdiag="<<Hdiag<<endl;
    };
    s_systemrectangle A(LxLyLz,OxOyOz,V,Hdiag);
    if (print_on_screen) {cout<<"system created\n"; cout<<A<<endl;}
    // we compare with expected value using systeme member function comparer(dim,size,zmax,xyzz,indice_map,hopp,Mhopp,Mdiag)
    int dim=2;
    int size=product(LxLyLz);
    int zmax=2*dim;
    //initialize xyz array with manually checked values
    Array<int,2> xyz(size,dim);
    xyz =
      10,    100,
      11,    100,
      12,    100,
      10,    101,
      11,    101,
      12,    101;
    //initialize indice_map with manually checked values
    map<Array<int,1>,int,cmp_Array> indice_map;
    Array<int,1> vec(2);
    vec=10,100;
    indice_map[vec.copy()]=0;
    vec=10,101;
    indice_map[vec.copy()]=3;
    vec=11,100;
    indice_map[vec.copy()]=1;
    vec=11,101;
    indice_map[vec.copy()]=4;
    vec=12,100;
    indice_map[vec.copy()]=2;
    vec=12,101;
    indice_map[vec.copy()]=5;
    //initialize hopping array with manually checked values
    Array<int,2> hopp(size,zmax);
    hopp = 
      -1,  1, -1,  3, 
       0,  2, -1,  4,
       1, -1, -1,  5,
      -1,  4,  0, -1, 
       3,  5,  1, -1, 
       4, -1,  2, -1;
    //initialize Mhopp array with manually checked values
    Array<scalarM,2> Mhopp(size,zmax);
    scalarM nul; nul(0,0)=0.; // scalarM zero definition
    Mhopp =
      nul,  V, nul,   V, 
      V,    V, nul,   V, 
      V,  nul, nul,   V, 
      nul,  V,   V, nul, 
      V,    V,   V, nul, 
      V,  nul,   V, nul;
    //initialize diagonal matrix with manually checked values
    Array<scalarM,1> Mdiag(size);
    Mdiag = Hdiag;
    if (!A.comparer(dim,size,zmax,xyz,indice_map,hopp,Mhopp,Mdiag)) ERROR("system creation failed to passe example test");
    cout<<"\nsystemrectangle constructor is checked on 2x3 system with success\n\n";
  };
  /************************COPY TEST**********************************************/
  if (test_copy) {
    // copy check for system 1x2
    if (print_on_screen) cout<<"*******************************"<<endl
			     <<" copy check for system 1x2"<<endl;
    LxLyLz=2,1;
    OxOyOz=0,0;
    s_systemrectangle B(LxLyLz,OxOyOz,V,Hdiag);
    if (print_on_screen) {cout<<"******** 1x2 system ***********\n"; cout<<B<<endl;};
    s_systemrectangle C(B);
    if (print_on_screen) {cout<<"******** 1x2 copy of the system ***********\n"; cout<<C<<endl;};
    cout<<"\nsystem copy constructor is checked on 1x2 system with success\n\n";
  };
  if (test_deplacer) {
    // deplacer of the system 1x2
    LxLyLz=2,1;
    OxOyOz=0,0;
    s_systemrectangle DD(LxLyLz,OxOyOz,V,Hdiag);
    OxOyOz=3,5;
    if (print_on_screen) {
      cout<<"******** deplacer of the system ***********\n";
      cout<<"system displaced by the vector="<<OxOyOz<<endl;
    };
    DD.deplacer(OxOyOz);
    if (print_on_screen) cout<<DD<<endl;
    // we compare with expected value using systeme member function comparer(dim,size,zmax,xyzz,indice_map,hopp,Mhopp,Mdiag)
    int dim=2;
    int size=product(LxLyLz);
    int zmax=2*dim;
    //initialize xyz array with manually checked values
    Array<int,2> xyz(size,dim);
    xyz =
      3,    5,
      4,    5;
    //initialize indice_map with manually checked values
    map<Array<int,1>,int,cmp_Array> indice_map;
    Array<int,1> vec(2);
    vec=3,5;
    indice_map[vec.copy()]=0;
    vec=4,5;
    indice_map[vec.copy()]=1;
    //initialize hopping array with manually checked values
    Array<int,2> hopp(size,zmax);
    hopp = 
      -1,  1, -1, -1, 
       0, -1, -1, -1;
    //initialize Mhopp array with manually checked values
    Array<scalarM,2> Mhopp(size,zmax);
    scalarM nul; nul(0,0)=0.; // scalarM zero definition
    Mhopp =
      nul,   V, nul, nul, 
      V,   nul, nul, nul;
    //initialize diagonal matrix with manually checked values
    Array<scalarM,1> Mdiag(size);
    Mdiag = Hdiag;
    if (!DD.comparer(dim,size,zmax,xyz,indice_map,hopp,Mhopp,Mdiag)) ERROR("system deplacer failed to passe example test");
    cout<<"\nsystem::deplacer is checked on 1x2 system with success\n\n";
  };
  /**********************COLLER TEST*********************************/
  if (test_coller) {
    // coller of two systems
    // first one(2x3=6) at the initial position (10,100)
    // 3 4 5
    // 0 1 2
    // second one(3x3=9) at the initial position (11,101)
    // 6 7 8
    // 3 4 5
    // 0 1 2
    // the result (=13) should be
    //   10 11 12
    //    7  8  9
    // 3  4  5  6
    // 0  1  2
    if (print_on_screen) cout<<"******** coller of the system ***********\n";
    LxLyLz=3,2;
    OxOyOz=10,100;
    s_systemrectangle F(LxLyLz,OxOyOz,V,Hdiag);
    LxLyLz=3,3;
    OxOyOz=11,101;
    scalarM Hdiag1,V1;
    Hdiag1(0,0)=4.;V1(0,0)=8.;
    s_systemrectangle D(LxLyLz,OxOyOz,V1,Hdiag1);
    F.coller(D);
    if (print_on_screen) cout<<F<<endl;
    // we compare with expected value using systeme member function comparer(dim,size,zmax,xyzz,indice_map,hopp,Mhopp,Mdiag)
    int dim=2;
    int size=13;
    int zmax=2*dim;
    //initialize xyz array with manually checked values
    Array<int,2> xyz(size,dim);
    xyz =
      10,    100,
      11,    100,
      12,    100,
      10,    101,
      11,    101,
      12,    101,
      13,    101,
      11,    102,
      12,    102,
      13,    102,
      11,    103,
      12,    103,
      13,    103;
    //initialize indice_map with manually checked values
    map<Array<int,1>,int,cmp_Array> indice_map;
    Array<int,1> vec(2);
    vec=10,100;
    indice_map[vec.copy()]=0;
    vec=10,101;
    indice_map[vec.copy()]=3;
    vec=11,100;
    indice_map[vec.copy()]=1;
    vec=11,101;
    indice_map[vec.copy()]=4;
    vec=11,102;
    indice_map[vec.copy()]=7;
    vec=11,103;
    indice_map[vec.copy()]=10;
    vec=12,100;
    indice_map[vec.copy()]=2;
    vec=12,101;
    indice_map[vec.copy()]=5,
    vec=12,102;
    indice_map[vec.copy()]=8,
    vec=12,103;
    indice_map[vec.copy()]=11,
    vec=13,101;
    indice_map[vec.copy()]=6,
    vec=13,102;
    indice_map[vec.copy()]=9,
    vec=13,103;
    indice_map[vec.copy()]=12;
    //initialize hopping array with manually checked values
    Array<int,2> hopp(size,zmax);
    hopp = 
      -1,        1,       -1,        3,
       0,        2,       -1,        4,
       1,       -1,       -1,        5,
      -1,        4,        0,       -1,
       3,        5,        1,        7,
       4,        6,        2,        8,
       5,       -1,       -1,        9,
      -1,        8,        4,       10,
       7,        9,        5,       11,
       8,       -1,        6,       12,
      -1,       11,        7,       -1,
      10,       12,        8,       -1,
      11,       -1,        9,       -1;
    //initialize Mhopp array with manually checked values
    Array<scalarM,2> Mhopp(size,zmax);
    scalarM nul; nul(0,0)=0.; // scalarM zero definition
    Mhopp =
      nul,   V,   nul,   V, 
      V,     V,   nul,   V, 
      V,   nul,   nul,   V, 
      nul,   V,     V, nul, 
      V,    V1,     V,  V1, 
      V1,   V1,     V,  V1, 
      V1,  nul,   nul,  V1, 
      nul,  V1,    V1,  V1, 
      V1,   V1,    V1,  V1, 
      V1,  nul,    V1,  V1, 
      nul,  V1,    V1, nul, 
      V1,   V1,    V1, nul, 
      V1,  nul,    V1, nul;
    //initialize diagonal matrix with manually checked values
    Array<scalarM,1> Mdiag(size);
    Mdiag(Range(0,3)) = Hdiag;
    Mdiag(Range(4,12))=Hdiag1;
    if (!F.comparer(dim,size,zmax,xyz,indice_map,hopp,Mhopp,Mdiag)) ERROR("system coller member function failed to passe example test");
    cout<<"\nsystem::coller is checked on example system with success\n\n";
  };

  //**********************ADDLEAD TEST*******************//
  if (test_addlead) {
    // construction of the system with 2 leads and comparer it to manually checked system
    //
    // 3 4 5
    // 0 1 2
    //     7
    //     6
    //
    // and (6,7,2) is the lead number 0
    // where (0,3) is the lead number 1
    // 
    // First task, construction of the systemerectangle
    //system is created using costructor from size 2x3, initial position (0,0), hopping 2 and on-site energy 1
    //
    // 3 4 5
    // 0 1 2
    //

    //V(0,0)=-2.;
    //Hdiag(0,0)=1.;
    LxLyLz=3,2;
    OxOyOz=0,0;
    systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V,Hdiag);
    // system was created
    //cout<<"SYSTEM PRINTING"<<endl<<sys<<endl;
    // add first lead to the system
    LxLyLz=1,3;
    OxOyOz=2,-2;
    s_systemrectangle lead_interface(LxLyLz,OxOyOz,2*V,2*Hdiag); // lead's interface
    A_reservoir lead(lead_interface); // create analytic lead from its interface
    N_reservoir<scalarM> lead_N(lead_interface,2*V); // create numeric lead from its interface
    //compare numeric and analytic green functions
    cout<<"Analytic versus Numeric lead GF test=>\n"<<
      ((all(abs(lead.green(0.1)-lead_N.green(0.1))<0.00001))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision test function)!!!")<<endl; 
    //cout<<"LEAD PRINTING"<<endl<<lead<<endl;
    typedef systeme_infini<scalarM> iss;
    iss sys_lead(sys,lead); // created systeme + lead
    if (print_on_screen) cout<<"SYSTEM+LEAD1 PRINTING"<<endl<<sys_lead<<endl;
    // second lead adding
    LxLyLz=1,2;
    OxOyOz=0,0;
    s_systemrectangle lead_interface2(LxLyLz,OxOyOz,3*V,3*Hdiag); // lead's interface
    A_reservoir lead2(lead_interface2); // create analytic lead from its interface
    N_reservoir<scalarM> lead2_N(lead_interface2,3*V); // create numeric lead from its interface
    //compare numeric and analytic green functions
    cout<<"Analytic versus Numeric lead GF test=>\n"<<
      ((all(abs(lead2.green(-0.1)-lead2_N.green(-0.1))<0.00001))?"=>SUCCESS !!!":"=>FAILED (probable problems with precision test function)!!!")<<endl; 
    sys_lead.addlead(lead2);
    if (print_on_screen) cout<<"SYSTEM+LEAD1+LEAD2 PRINTING"<<endl<<sys_lead<<endl;
    //initialize manually checked values
    int Nress=2; //leads number
    Array<int,2> res2syss(2,3);
    res2syss=0, 3,-1, 
             6, 7, 2;
    Array<int,1> sys2ress(8);
    sys2ress=0,-1,1,0,-1,-1,1,1;
    if (!sys_lead.comparer(Nress,res2syss,sys2ress)) ERROR("systeme_infini addlead member function failed to passe example test");
    cout<<"\nsysteme_infini::addlead is checked on two leads system with success\n\n";
  };  
  Array<int,1> voisins(shape(3)),coordinate(shape(2));
  coordinate=4,3;
  voisins=1,2,8;
  scalarM t(COMPLEX(2.)), Hii(COMPLEX(0.));
  sys.add_site(voisins,t,Hii,coordinate);
  //sys.addsite(voisins,Hoppings,Hii,coordinate);
  return 0;
};

#endif




/****************** WHAT TO EXPECT *******************/
/* note! print_on_screan variable should be true in order to get this information on the screen

system created
dim=2
zmax=4
size=6
xyz(size,dim)=6 x 2
[        10       100 
         11       100 
         12       100 
         10       101 
         11       101 
         12       101 ]

hopp(size,zmax)=6 x 4
[        -1         1        -1         3 
          0         2        -1         4 
          1        -1        -1         5 
         -1         4         0        -1 
          3         5         1        -1 
          4        -1         2        -1 ]

Mhopp(size,zmax)=6 x 4
[ (0.000,0.000) (2.000,0.000) (0.000,0.000) (2.000,0.000) 
  (2.000,0.000) (2.000,0.000) (0.000,0.000) (2.000,0.000) 
  (2.000,0.000) (0.000,0.000) (0.000,0.000) (2.000,0.000) 
  (0.000,0.000) (2.000,0.000) (2.000,0.000) (0.000,0.000) 
  (2.000,0.000) (2.000,0.000) (2.000,0.000) (0.000,0.000) 
  (2.000,0.000) (0.000,0.000) (2.000,0.000) (0.000,0.000) ]

Mdiag(size)=6
 [ (1.000,0.000) (1.000,0.000) (1.000,0.000) (1.000,0.000) (1.000,0.000) (1.000,
0.000)  ]
Printing of indice_map
indice=0  for # of coordinates=2
 [        10       100  ]
indice=3  for # of coordinates=2
 [        10       101  ]
indice=1  for # of coordinates=2
 [        11       100  ]
indice=4  for # of coordinates=2
 [        11       101  ]
indice=2  for # of coordinates=2
 [        12       100  ]
indice=5  for # of coordinates=2
 [        12       101  ]

*******************************
 copy check for system 1x2
******** 1x2 system ***********
dim=2
zmax=4
size=2
xyz(size,dim)=2 x 2
[         0         0 
          1         0 ]

hopp(size,zmax)=2 x 4
[        -1         1        -1        -1 
          0        -1        -1        -1 ]

Mhopp(size,zmax)=2 x 4
[ (0.000,0.000) (2.000,0.000) (0.000,0.000) (0.000,0.000) 
  (2.000,0.000) (0.000,0.000) (0.000,0.000) (0.000,0.000) ]

Mdiag(size)=2
 [ (1.000,0.000) (1.000,0.000)  ]
Printing of indice_map
indice=0  for # of coordinates=2
 [         0         0  ]
indice=1  for # of coordinates=2
 [         1         0  ]
******** 1x2 copy of the system ***********
dim=2
zmax=4
size=2
xyz(size,dim)=2 x 2
[         0         0 
          1         0 ]

hopp(size,zmax)=2 x 4
[        -1         1        -1        -1 
          0        -1        -1        -1 ]

Mhopp(size,zmax)=2 x 4
[ (0.000,0.000) (2.000,0.000) (0.000,0.000) (0.000,0.000) 
  (2.000,0.000) (0.000,0.000) (0.000,0.000) (0.000,0.000) ]

Mdiag(size)=2
 [ (1.000,0.000) (1.000,0.000)  ]
Printing of indice_map
indice=0  for # of coordinates=2
 [         0         0  ]
indice=1  for # of coordinates=2
 [         1         0  ]

******** deplacer of the system ***********
system displaced by the vector=2
 [         3         5  ]
dim=2
zmax=4
size=2
xyz(size,dim)=2 x 2
[         3         5 
          4         5 ]

hopp(size,zmax)=2 x 4
[        -1         1        -1        -1 
          0        -1        -1        -1 ]

Mhopp(size,zmax)=2 x 4
[ (0.000,0.000) (2.000,0.000) (0.000,0.000) (0.000,0.000) 
  (2.000,0.000) (0.000,0.000) (0.000,0.000) (0.000,0.000) ]

Mdiag(size)=2
 [ (1.000,0.000) (1.000,0.000)  ]
Printing of indice_map
indice=0  for # of coordinates=2
 [         3         5  ]
indice=1  for # of coordinates=2
 [         4         5  ]


******** coller of the system ***********
dim=2
zmax=4
size=13
xyz(size,dim)=13 x 2
[        10       100 
         11       100 
         12       100 
         10       101 
         11       101 
         12       101 
         13       101 
         11       102 
         12       102 
         13       102 
         11       103 
         12       103 
         13       103 ]

hopp(size,zmax)=13 x 4
[        -1         1        -1         3 
          0         2        -1         4 
          1        -1        -1         5 
         -1         4         0        -1 
          3         5         1         7 
          4         6         2         8 
          5        -1        -1         9 
         -1         8         4        10 
          7         9         5        11 
          8        -1         6        12 
         -1        11         7        -1 
         10        12         8        -1 
         11        -1         9        -1 ]

Mhopp(size,zmax)=13 x 4
[ (0.000,0.000) (2.000,0.000) (0.000,0.000) (2.000,0.000) 
  (2.000,0.000) (2.000,0.000) (0.000,0.000) (2.000,0.000) 
  (2.000,0.000) (0.000,0.000) (0.000,0.000) (2.000,0.000) 
  (0.000,0.000) (2.000,0.000) (2.000,0.000) (0.000,0.000) 
  (2.000,0.000) (8.000,0.000) (2.000,0.000) (8.000,0.000) 
  (8.000,0.000) (8.000,0.000) (2.000,0.000) (8.000,0.000) 
  (8.000,0.000) (0.000,0.000) (0.000,0.000) (8.000,0.000) 
  (0.000,0.000) (8.000,0.000) (8.000,0.000) (8.000,0.000) 
  (8.000,0.000) (8.000,0.000) (8.000,0.000) (8.000,0.000) 
  (8.000,0.000) (0.000,0.000) (8.000,0.000) (8.000,0.000) 
  (0.000,0.000) (8.000,0.000) (8.000,0.000) (0.000,0.000) 
  (8.000,0.000) (8.000,0.000) (8.000,0.000) (0.000,0.000) 
  (8.000,0.000) (0.000,0.000) (8.000,0.000) (0.000,0.000) ]

Mdiag(size)=13
 [ (1.000,0.000) (1.000,0.000) (1.000,0.000) (1.000,0.000) (4.000,0.000) (4.000,0.000) (4.000,0.000)
 
  (4.000,0.000) (4.000,0.000) (4.000,0.000) (4.000,0.000) (4.000,0.000) (4.000,0.000)  ]
Printing of indice_map
indice=0  for # of coordinates=2
 [        10       100  ]
indice=3  for # of coordinates=2
 [        10       101  ]
indice=1  for # of coordinates=2
 [        11       100  ]
indice=4  for # of coordinates=2
 [        11       101  ]
indice=7  for # of coordinates=2
 [        11       102  ]
indice=10  for # of coordinates=2
 [        11       103  ]
indice=2  for # of coordinates=2
 [        12       100  ]
indice=5  for # of coordinates=2
 [        12       101  ]
indice=8  for # of coordinates=2
 [        12       102  ]
indice=11  for # of coordinates=2
 [        12       103  ]
indice=6  for # of coordinates=2
 [        13       101  ]
indice=9  for # of coordinates=2
 [        13       102  ]
indice=12  for # of coordinates=2
 [        13       103  ]


*/


