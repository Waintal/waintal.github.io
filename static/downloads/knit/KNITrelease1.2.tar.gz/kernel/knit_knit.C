// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


//#define _DEBUG_DI_ //DIRECT INVERSION DEBUG


#include "knit_knit.h"
#include "knit_micromatrices.h"

/** This mode permit to test system implementation
// it's used be DATA/FB.py to get forward backward error in calculations
c++ -c -O2  knit_micromatrices.C
c++ -c -O2  knit_acos.C
g++ -c -O2 -I /usr/local/stow/Blitz_g++/include/  knit_system.C	
g++ -c -O2 -I /usr/local/stow/Blitz_g++/include/  knit_geometry.C	
g++ -c -O2 -D_TESTING_ -D_DEBUG_LONG_ -I /usr/local/stow/Blitz_g++/include/  knit_knit.C	
g++ -o test.out -O2 -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz knit_system.o knit_micromatrices.o knit_acos.o knit_geometry.o knit_knit.o
**/


#ifdef _TESTING_

int rank=0;
int size=1;

int main(int argc, char** argv){
  cout<<"******BEGIN of KNIT testing; back and forth test ******\n";
  //  cout<<"Define _SUPPLEM_ variable to add suppelentary testitng\n";
  // forward - backward test for knit variable for given infinite system:
  // we create knit variable then make back and forth knit, then we knit forward to get the whole system and then once again back and forth from both ends, and finally we knit backward to initial position. At each step we compare that back and forth operation does not change the knit ie GFs 
  // all this is made for three different starting points: debut(O), fin(size-1), lead(last last-lead site)

  // testing system is the following
  // construction of the systemerectangle with two leads
  // main system is created using costructor from size 3x4, initial position (0,0), hopping 2 and on-site energy 1
  // first lead is composed of sites 5, 12; lead 0
  // first lead is composed of sites 9, 10; lead 1
  /*
    9 10 11
    6 7  8
    3 4  5  12
    0 1  2
  */
  // common variables for all tests
  //typedef vectorM<2> testM;
  typedef scalarM testM;

  clock_t t_in=clock();
  Array<int,1> LxLyLz(2),OxOyOz(2);
  testM V,Hdiag;
  for (int i=0;i<testM::dim();++i) V(i,i)=-2.;
  for (int i=0;i<testM::dim();++i) Hdiag(i,i)=1.;
  // end of common variables

  // system construction

  cout<<"********* testing small manual system ********\n";
  cout<<9<<"  "<<10<<"  "<<11<<endl
      <<6<<"  "<<7<<"   "<<8 <<endl
      <<3<<"  "<<4<<"   "<<5 <<"  "<<12<<endl
      <<0<<"  "<<1<<"   "<<2 <<endl;

  // main system
  LxLyLz=3,4;
  OxOyOz=0,0;
  systemerectangle<testM> sys(LxLyLz,OxOyOz,V,Hdiag);
  // first lead
  LxLyLz=3,1;
  OxOyOz=1,1;
  systemerectangle<testM> lead_interface(LxLyLz,OxOyOz,1.5*V,2.*Hdiag); // lead's interface
  N_reservoir<testM> lead(lead_interface,1.5*V); // create lead from its interface
  //  cout<<"LEAD PRINTING"<<endl<<lead<<endl;
  systeme_infini<testM> sys_lead(sys,lead); // created systeme + lead
  // second lead
  LxLyLz=2,1;
  OxOyOz=0,3;
  systemerectangle<testM> lead_interface2(LxLyLz,OxOyOz,0.75*V,0.5*Hdiag); // lead's interface
  N_reservoir<testM> lead2(lead_interface2,0.75*V); // create lead from its interface
  // AAA for A_reservoir() gives divergent value to be checked in future!!
  sys_lead.addlead(lead2);

  // some supplementary manual tests just to show how to use knit variables
  const int init_site=4;
  const COMPLEX working_energy=2.5;
  knit<testM> work(init_site,sys_lead,working_energy); 
  knit<testM> copy_work(work);
  copy_work=work;
  work.forward(ToZero); 
  work.forward(ToEnd);
  work.backward(FromEnd);
  work.backward(FromZero); 
  //cout<<"********KNIT PRINTING******"<<endl<<work<<endl;
  bool result = (copy_work == work); // if test is passed result is true
  work.forward(le_debut); work.backward(le_debut); // some more one step back and forth test
  work.forward(la_fin); work.backward(la_fin);  // some more one step back and forth test
  result = result && (work == copy_work);
  if (result) cout<<"supplemetary back-forward TEST for knit is passed with sucess.\n";
  else  cout<<"supplementary back-forward TEST for knit failed !!!\n";

  // third lead
  LxLyLz=1,2;
  OxOyOz=0,-1;
  systemerectangle<testM> lead_interface3(LxLyLz,OxOyOz,1.3*V,2.*Hdiag); // lead's interface
  N_reservoir<testM> lead3(lead_interface3,1.3*V); // create lead from its interface
  sys_lead.addlead(lead3);
  
  // fully automatic back and forth Test for position variable
  position_bfTEST(sys_lead);
  // fully automatic back and forth Test for knit variable
  knit_bfTEST(sys_lead,working_energy);
  // max GF function test
  cout<<"max_GF_size="<<max_GF_size(sys_lead)<<endl;
  cout<<"sytem size = "<<sys_lead.fsize()<<endl;

  //SEW TESTING on 3 lead system

  knit<testM> work4sew(0,sys_lead,3.);
  //cout<<sys_lead.p_lead(0)->selfE(3.)<<endl;
  //cout<<sys_lead.p_lead(1)->selfE(3.)<<endl;
  work4sew.forward(ToEnd);

  cout<<"\n********* testing of SEW on small manual system ********\n";
  cout<<9<<"  "<<10<<"  "<<11<<endl
      <<6<<"  "<<7<<"   "<<8 <<endl
      <<3<<"  "<<4<<"   "<<5 <<"  "<<12<<endl
      <<0<<"  "<<1<<"   "<<2 <<endl
      <<13<<endl;
  cout<<"Construction of SEW\n";
  sew<testM> S(work4sew); // check constructor of sew
  S.sew2end();
  // test getG_LL
  cout<<S.getG_LL(1,0,0,1);
  cout<<S.getG_LL(0,0,0,1);
  // test getSE
  cout<<S.getSE(1,0,0);
  cout<<S.getSE(0,0,1)<<endl;

  clock_t t_out=clock();  
  cout<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<endl;
  return 0;
};

#endif // _TESTING_


