// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


// file to be included to knit_system.h

// ******************************************************************* //
// **************** TEMPLATE FUNCTIONS ******************************* //


// *************
//Class SYSTEME

// copy constructor is needed since we use Array, where copy constructor passe the reference instead of a real copy
//even so we passe coordinate vector by reference to Array<int,1> in indice_map, it does not matter as this coordinate vector remains constant and it's not changed in future
template<class Tmicromatrix>  systeme<Tmicromatrix>::systeme(const systeme<Tmicromatrix>& A): 
  dim(A.dim), size(A.size),zmax(A.zmax), indice_map(A.indice_map), xyz(A.xyz.copy()), hopp(A.hopp.copy()), Mhopp(A.Mhopp.copy()), Mdiag(A.Mdiag.copy())
{};

// coordinates d (<dim) x,y,z of a given site ind
template<class Tmicromatrix> inline int systeme<Tmicromatrix>::coord(int ind,int d) const 
{
#ifdef _DEBUG_LONG_
  if (d>=dim||d<0) ERROR("in systeme::coord d is not inside this set [0..dim-1]"); // check if d=[0..dim-1]
  if (ind>=size||ind<outsample) ERROR("in systeme::coord site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample
  if (ind==outsample) ERROR("in systeme::coord site index is outside the sample (coordinates for outside vector are not defined)"); // check if site index ind is outside of the sample
#endif
  return xyz(ind,d);
}; 

// coordinates of a given site -ind- in 1D Array form
template<class Tmicromatrix> inline Array<int,1> systeme<Tmicromatrix>::vcoord(int ind) const 
{
#ifdef _DEBUG_LONG_
  if (ind>=size||ind<outsample) ERROR("in systeme::vcoord site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample
  if (ind==outsample) ERROR("in systeme::vcoord site index is outside fo the sample (coordinates for outside vector are not defined)"); // check if site index ind is outside of the sample
#endif
  return xyz(ind,Range::all()).copy();
}; 

// index of the given site with coordinates x=coordinate(0),y=coordinate(1),z=coordinate(2) etc
template<class Tmicromatrix> inline int systeme<Tmicromatrix>::indice(const Array<int,1>& coordinate) const 
{
#ifdef _DEBUG_LONG_
  if (coordinate.rows()!=dim) ERROR("in systeme::indice; coordinate's rank is not equal to system dimension");
#endif
  //all the sites out of the sample are given index=outsample (system static constant)
  if (indice_map.find(coordinate)==indice_map.end()) return outsample;
  return indice_map.find(coordinate)->second;
}; 

//neighbour z with index ind
template<class Tmicromatrix> inline int systeme<Tmicromatrix>::voisin(int ind,int z) const 
{
#ifdef _DEBUG_LONG_
  if (z>=zmax||z<0) ERROR("in systeme::voisin coordinance z is not in [0..zmax-1]"); // check if coordinance is out of range
  if (ind>=size||ind<outsample) ERROR("in systeme::voisin site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample
#endif
  if (ind==outsample) return outsample;// outsample neighbors are by definition out of the sample 
  return hopp(ind,z);
};

//neighbours with index ind in the vector form, ie vvoisin(3) is a vector of -dim- components for index -3-
template<class Tmicromatrix> inline Array<int,1> systeme<Tmicromatrix>::vvoisin(int ind) const 
{
#ifdef _DEBUG_LONG_
  if (ind>=size||ind<outsample) ERROR("in systeme::voisin site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample
#endif
  if (ind==outsample) return Array<int,1>(outsample); 
  return hopp(ind,Range::all()).copy();
};

//matrix element between ind and voisin(ind,z)
template<class Tmicromatrix> inline Tmicromatrix systeme<Tmicromatrix>::Mvoisin(int ind,int z) const
{
#ifdef _DEBUG_LONG_
  if (z>=zmax||z<0) ERROR("in systeme::Mvoisin coordinance z is not in [0..zmax-1]"); // check if coordinance is out of range
  if (ind>=size||ind<outsample) ERROR("in systeme::Mvoisin site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample. 
#endif
  if (ind==outsample) return Tmicromatrix();
  return Mhopp(ind,z);
};

//matrix element between ind and voisin(ind,z) for all -z-, ie vMvoisin(10) is a vector of zmax components for index -10-
template<class Tmicromatrix> inline Array<Tmicromatrix,1> systeme<Tmicromatrix>::vMvoisin(int ind) const
{
#ifdef _DEBUG_LONG_
  if (ind>=size||ind<outsample) ERROR("in systeme::Mvoisin site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample. 
#endif
  if (ind==outsample) return Array<Tmicromatrix,1>(zmax);
  return Mhopp(ind,Range::all()).copy();
};

//diagonal matrix element; return zero for sites out of range
template<class Tmicromatrix> inline Tmicromatrix systeme<Tmicromatrix>::Msite(int ind) const
{
#ifdef _DEBUG_LONG_
  if (ind>=size||ind<outsample) ERROR("in systeme::Msite site index is out of range i>=size"); // check if site index ind<size
  //as all the sites out of the sample are given index=outsample, a lower bound check is ind<outsample. 
#endif
  if (ind==outsample) return Tmicromatrix(); 
  return Mdiag(ind);
};

// gives -z- of voisin(ind,z) that points to -ind-
// ind=voisin(voisin(ind,z),z_voisin(ind,z))
template<class Tmicromatrix> inline int systeme<Tmicromatrix>::z_voisin(int ind,int z) const{
  int voisin_ind=voisin(ind,z); // index of the considered neighbour
  if (voisin_ind == outsample) return outsample;
  else
    for (int z=0;z<zmax;++z) if ( voisin(voisin_ind,z) == ind) return z;
  ERROR("in systeme::z_voisin(). Have not found any -z- for the neighbor");
  return outsample;
}

//permute matrix index
template<class Tmicromatrix> systeme<Tmicromatrix>& systeme<Tmicromatrix>::permutme(const permutation& per)
{// creates temporary arrays where we save all private elements of the systeme class
  Array<int,2> xyz_save=xyz.copy(); // copy member is compulsory if not present it creates just array refence 
  Array<int,2> hopp_save=hopp.copy(); 
  Array<Tmicromatrix,2> Mhopp_save=Mhopp.copy();
  Array<Tmicromatrix,1> Mdiag_save=Mdiag.copy();
  //new value for private elements after permutation
  map<Array<int,1>,int,cmp_Array>::const_iterator p=indice_map.begin();
  // update of index in indice_map: !!! iterator of new and old maps are the same AAA (check is needed)
  for (;p!=indice_map.end();++p) indice_map[p->first]=per(p->second);
  for (int ind=xyz.lbound(firstDim);ind<=xyz.ubound(firstDim);++ind)
    {//NOTE for some compilor one needs to replace ind => Range(ind,ind)
      xyz(  ind,Range::all())=xyz_save(per(ind),Range::all());
      hopp( ind,Range::all())=hopp(per(ind),Range::all());
      Mhopp(ind,Range::all())=Mhopp(per(ind),Range::all());
      Mdiag(ind)             =Mdiag(per(ind));
    };
#ifdef _DEBUG_LONG_// test of xyz <-> indice_map correspondance 
  if (!xyz2ind_mapTEST()) ERROR("systeme permutme; xyz <-> indice_map correspondance failed");
#endif
  return *this;
};

// print all inner data of the system (only for small systems, size<50)
template<class Tmicromatrix> void systeme<Tmicromatrix>::sys_print()
{
  if (size<50){
    cout<<"dim="<<             dim  <<endl;
    cout<<"zmax="<<            zmax <<endl;
    cout<<"size="<<            size <<endl;
    cout<<"xyz(size,dim)="<<   xyz  <<endl;
    cout<<"hopp(size,zmax)="<< hopp <<endl;
    cout<<"Mhopp(size,zmax)="<<Mhopp<<endl;
    cout<<"Mdiag(size)="<<     Mdiag<<endl;
    cout<<"Printing of indice_map\n";
    map<Array<int,1>,int,cmp_Array>::const_iterator p;
    for (p=indice_map.begin();p!=indice_map.end();++p) cout<<"indice="<<p->second<<"  for # of coordinates="<<p->first<<endl;
  };
};                                          


//merge with system B. Overlapped part is taken from B system. It means that everywhere where it's possible to choose between A or B matrix elements, we choose B elements. In final system lace indexing of initial system(A) is preserved and for system order of indexing is also preserved

template<class Tmicromatrix> systeme<Tmicromatrix>& systeme<Tmicromatrix>::coller(const systeme<Tmicromatrix>& B)
{
  systeme<Tmicromatrix> A(*this);
  // for a while we implementate only equaldimensional systems
  if (A.dim != B.dim) ERROR("Attempt to glue systems of different size in systeme::coller");
  map<int,int> map_intersecBA;// a map of pairs of index for intersection of systems B and A
  map<int,int> map_intersecAB;// a map of pairs of index for intersection of systems A and B
  set<int> setB_intersecAB;   // a set of intersection index of the system B
  if (A.size<B.size){ // choice of algorithm cost: size_A*log(size_B) or size_B*log(size_A)
    for (int a=0;a<A.size;++a){
      int b=B.indice(A.vcoord(a));// -b- is an index of the system B corresponding to index a of the system A
      // b=outsample means that -b- is not belong to system B 
      // create a pair of index for intersection of A and B   
      if (b!=outsample) {
	map_intersecBA.insert(make_pair(b,a));
	map_intersecAB.insert(make_pair(a,b));
	setB_intersecAB.insert(b);
      };
    };
  } else{
    for (int b=0;b<B.size;++b){
      int a=A.indice(B.vcoord(b));// -a- is an index of the system A corresponding to index b of the system B
      // a=outsample means that -a- is not belong to system A 
      // create a pair of index for intersection of A and B   
      if (a!=outsample) {
	map_intersecBA.insert(make_pair(b,a));
	map_intersecAB.insert(make_pair(a,b));
	setB_intersecAB.insert(b);
      };
    };
  };
  int size_intersecAB=map_intersecBA.size(); // number of sites in the intersection
  // for (map<int,int>::const_iterator p=map_intersecBA.begin();p!=map_intersecBA.end();++p)
  //    cout<<"intersection="<<p->first<<" second="<<p->second<<endl;// AAA
  /******** we acquired all informations needed for AB construction *****/
  dim=dim;// dimension does not change
  size=A.size+B.size-size_intersecAB;
  zmax=max(A.zmax,B.zmax);
  // FIRST STEP: ONSITE UPDATE xyz, indice_map and Mdiag first 
  // A part of onsite update
  xyz.resize(shape(size,dim)); xyz=outsample;
  Mdiag.resize(shape(size));
  for (int a=0,ind=0;a<A.size;++a){
    xyz(ind,Range::all())=A.vcoord(a);
    Mdiag(ind)=A.Msite(a);
    ++ind;
  };
  // B part of onsite update
  for (int b=0,ind=A.size;b<B.size;++b){
    //different action for -b- outside or inside of the intersection
    if (map_intersecBA.find(b)==map_intersecBA.end()){// outside of intersection
      xyz(ind,Range::all())=B.vcoord(b);
      Mdiag(ind)=B.Mdiag(b);
      indice_map[B.vcoord(b)]=ind;
      ++ind;
    } 
    else{                                             //  inside of intersection
      int ab=map_intersecBA.find(b)->second;// index in AB corresponding to b of B
      Mdiag(ab)=B.Msite(b); // overwrite diagonal matrix elements as by convention B is over A
    };
  };
#ifdef _DEBUG_
  if (size!=indice_map.size()) ERROR("systeme systeme::coller(const systeme)| after creating A+B its size is not correct");
#endif
  // SECOND STEP: INTERSITE UPDATE hopp and Mhopp
  Mhopp.resize(shape(size,zmax));
  hopp.resize(shape(size,zmax)); hopp=outsample;
  
  // B part of intersite update
  for (int b=0;b<B.size;++b){
    const Array<int,1> b_coord=B.vcoord(b); //coordinates of -b-
    const int ind=indice_map.find(b_coord)->second;// index is get from previously initialized indice_map of the system AB
    for (int z=0;z<B.zmax;++z){
      if (B.voisin(b,z)!=outsample){ 
	const Array<int,1> coord_voisin=B.vcoord(B.voisin(b,z)); //coordinates of the neighbour of -b-
	const int ind_voisin=indice_map.find(coord_voisin)->second;// index is get from previously initialized indice_map of the system AB
	hopp(ind,z)=ind_voisin;
	Mhopp(ind,z)=B.Mvoisin(b,z);
      }else hopp(ind,z)=outsample;
    }; 
  };

  // A part of intersite update
  for (int a=0;a<A.size;++a){
    const Array<int,1> a_coord=A.vcoord(a); //coordinates of -a-
    const int ind=a; // AB index is the same as in A system
    //only for -a- outside of the intersection
    if (map_intersecAB.find(a)==map_intersecAB.end()){ // outside intersection
      hopp(a,Range::all())=A.vvoisin(a);
      Mhopp(a,Range::all())=A.vMvoisin(a);
    }else                                              // inside intersection
      // analyse neighbors of a
      for (int za=0;za<A.zmax;++za){
	if (A.hopp(a,za) == outsample) continue;
	// if voisin do not belongs to the intersection add this link 
	if ( map_intersecAB.find(A.hopp(a,za))==map_intersecAB.end()) {
	  // if -za- index is not in use
	  if (hopp(a,za) == outsample){
	    hopp(a,za)=A.hopp(a,za);
	    Mhopp(a,za)=A.Mhopp(a,za);}
	  else { // find free link
	    int free_z=outsample; // free link
	    for (int z=0;z<zmax;++z)// search over full zmax
	      if (hopp(a,z)==outsample) {free_z=z;break;};
	    if (free_z == outsample) ERROR("systeme::coller() no free z was found");
	    hopp(a,free_z)=A.hopp(a,za);
	    Mhopp(a,free_z)=A.Mhopp(a,za);
	  };
	};
      };
  };
  //all done
#ifdef _DEBUG_LONG_// test of xyz <-> indice_map correspondance 
  if (!xyz2ind_mapTEST()) ERROR("systemerectangle constructor; xyz <-> indice_map correspondance failed");
#endif
  return *this;
};



// move the system by the vector shift
template<class Tmicromatrix>  systeme<Tmicromatrix>& systeme<Tmicromatrix>::deplacer(const Array<int,1>& shift){
#ifdef _DEBUG_
  if (shift.size()!=dim) ERROR("systeme systeme::deplacer(const Array)| size of the shift vector is not correct");
#endif
  for (int ind=0;ind<size;++ind)  xyz(ind,Range::all())+=shift;
  map<const Array<int,1>,int,cmp_Array> indice_map_save=indice_map;
  //even so indice_map_save is created using references to Array<int,1> as coordinate vector, it's does not matter for our applications as one could not modify this elements in future, they are constant. We used before this operations indice_map_save=indice_map; after indice_map_save declaration, but it was not correct as the size of coordinate vector is not known, so even element by elements assignment operation would in principle give memory problems
  indice_map.clear();
  map<const Array<int,1>,int,cmp_Array>::const_iterator p=indice_map_save.begin();
  // update of index in indice_map
  for (;p!=indice_map_save.end();++p) {indice_map[Array<int,1>(p->first+shift)]=p->second;};
#ifdef _DEBUG_LONG_// test of xyz <-> indice_map correspondance 
  if (!xyz2ind_mapTEST()) ERROR("systeme deplacer; xyz <-> indice_map correspondance failed");
#endif
  return *this;
};

/// allocate memory for the system of ssize
template<class Tmicromatrix>  systeme<Tmicromatrix>& systeme<Tmicromatrix>::reset(int ddim, int ssize, int zzmax){
#ifdef _DEBUG_
  if (ssize<1) ERROR("in systeme::reset() System should have at least one site");
#endif   
  dim=ddim;size=ssize;zmax=zzmax;
  xyz.resize(shape(size,dim));
  hopp.resize(shape(size,zmax));
  hopp(ALL,ALL)=outsample;
  Mhopp.resize(shape(size,zmax));
  Mhopp(ALL,ALL)=Tmicromatrix();
  Mdiag.resize(shape(size));
  Mdiag(ALL)=Tmicromatrix();
  return *this;
}


// add a new site using neighbors list, hoppings from this site, coordinate of this site and onsite energy for this site
template<class Tmicromatrix> 
systeme<Tmicromatrix>& systeme<Tmicromatrix>::addsite(const Array<int,1>& voisins, const Array<Tmicromatrix,1>& hoppings, const Tmicromatrix& Hii,  const Array<int,1>& coordinate){
#ifdef _DEBUG_
  if (voisins.size() != zmax || hoppings.size() != zmax || coordinate.size() != dim) ERROR("in systeme::addsite() one of input arguments has wrong dimension");
#endif 
  size++;
  const Array<int,2> xyz_old(xyz.copy());
  const Array<int,2> hopp_old(hopp.copy());
  const Array<Tmicromatrix,2> Mhopp_old(Mhopp.copy());
  const Array<Tmicromatrix,1> Mdiag_old(Mdiag.copy());
  // coordinate update
  xyz.resize(shape(size,dim));
  xyz(Range(0,size-2),ALL)=xyz_old.copy();
  xyz(size-1,ALL)=coordinate.copy();
  // voisin update
  hopp.resize(shape(size,zmax));
  Mhopp.resize(shape(size,zmax));
  hopp(Range(0,size-2),ALL)=hopp_old.copy();
  Mhopp(Range(0,size-2),ALL)=Mhopp_old.copy();
  hopp(size-1,ALL)=voisins.copy(); // update hopping index from new site
  Mhopp(size-1,ALL)=hoppings.copy(); // update hopping index from new site
  for (int z=0;z<zmax;++z) {// update hopping index to new site
    // find free hopping index for this nearest neighbor(nn)
    const int nn=hopp(size-1,z);
    if (nn != outsample){
      int zv_free=outsample;
      for (int zv=0;zv<zmax;++zv) if (hopp(nn,zv) == outsample) {zv_free=zv;break;};
#ifdef _DEBUG_
      if (zv_free==outsample) ERROR("in systeme::addsite one of the given voisins had no more free connections");
#endif
      hopp( nn, zv_free)=size-1;
      Mhopp(nn, zv_free)=hoppings(z).hconjugate();
    }
  };
  // diagonal matrix update
  Mdiag.resize(shape(size));
  Mdiag(Range(0,size-2))=Mdiag_old.copy();
  Mdiag(size-1)=Hii;
  // update indice map
  indice_map[coordinate]=size-1;
  return *this;
};


/// Add an non existent hopping element between ind and ind2.
template<class Tmicromatrix> systeme<Tmicromatrix>&  systeme<Tmicromatrix>::add_Hopp(int ind1, int ind2, const Tmicromatrix& t){
#ifdef _DEBUG_
  if (ind1<0 || ind1>=fsize()) ERROR("systeme::add_Hopp:  Wrong value for ind1"); 
  if (ind2<0 || ind2>=fsize()) ERROR("systeme::add_Hopp:  Wrong value for ind2");
#endif
  int z1=0;
  while(z1!=zmax){
    if(hopp(ind1,z1)==outsample) break;
    ++z1;
  }
  if(z1==zmax) ERROR("systeme::add_Hopp Trying to have more than zmax neighbours");
  int z2=0;
  while(z2!=zmax){
    if(hopp(ind2,z2)==outsample) break;
    ++z2;
  }
  if(z2==zmax) ERROR("systeme::add_Hopp Trying to have more than zmax neighbours");
  hopp(ind1,z1)=ind2;
  Mhopp(ind1,z1)=t;
  hopp(ind2,z2)=ind1;
  Mhopp(ind2,z2)=t.hconjugate();
  return *this;
};

//deletes site from the system
template<class Tmicromatrix>
systeme<Tmicromatrix>& systeme<Tmicromatrix>:: delete_site(int iii){
// if (iii < 0 || iii >= size ) {
//  ; //do nothing
// }
// else {
//Here we reset all old hopping from iii neighbors to iii
   for (int z=0;z<zmax;++z) {
    const int nn=hopp(iii,z);
    if (nn != outsample){
      for (int zv=0;zv<zmax;++zv) if (hopp(nn,zv) == iii) {
	hopp( nn, zv)=outsample;
	Mhopp(nn, zv)=Tmicromatrix();
      }
    }
   };
    const Array<int,1> coord_old = xyz(iii,ALL).copy(); 
//this function DOES NOT eliminate the sites from the system, but detaches them and puts "aside" -> outsample.
//TEMPORAL solution. 
     for (int zi=0;zi<zmax;++zi) {   
        hopp( iii, zi)=outsample;
        Mhopp( iii, zi)=Tmicromatrix();   
     }
// WE put the site out of the sample:  xyz=outsample;
     xyz(iii,ALL) = outsample;
     indice_map[coord_old]=outsample;
     Mdiag(iii)=Tmicromatrix(); 
     
return *this;
};

// move a site -iii- using neighbors list, hoppings from this site, coordinate of this site and onsite energy for this site
template<class Tmicromatrix> 
systeme<Tmicromatrix>& systeme<Tmicromatrix>::movesite(const Array<int,1>& voisins, 
						       const Array<Tmicromatrix,1>& hoppings, 
						       const Tmicromatrix& Hii,  
						       const Array<int,1>& coordinate, 
						       int iii){
#ifdef _DEBUG_
  if (voisins.size() != zmax || hoppings.size() != zmax || coordinate.size() != dim) ERROR("in systeme::movesite() one of input arguments has wrong dimension");
#endif 
  for (int z=0;z<zmax;++z) {//reset all old hopping of iii neighbors
    const int nn=hopp(iii,z);
    if (nn != outsample){
      for (int zv=0;zv<zmax;++zv) if (hopp(nn,zv) == iii) {
	hopp( nn, zv)=outsample;
	Mhopp(nn, zv)=Tmicromatrix();
      }
    }
  };
  // coordinate update
  //save old coordinate """"""""""""""""""""""""""""""""""""""""""""""""""""""
  const Array<int,1> coord_old = xyz(iii,ALL).copy();
  xyz(iii,ALL)=coordinate.copy();
  // voisin update
  hopp(iii,ALL)=voisins.copy(); // update hopping index from new site
  Mhopp(iii,ALL)=hoppings.copy(); // update hopping index from new site
  for (int z=0;z<zmax;++z) {// update hopping index to new site
    // find free hopping index for this nearest neighbor(nn)
    const int nn=hopp(iii,z);
    if (nn != outsample){
      int zv_free=outsample;
      for (int zv=0;zv<zmax;++zv) if (hopp(nn,zv) == outsample) {zv_free=zv;break;};
#ifdef _DEBUG_
      if (zv_free==outsample) ERROR("in systeme::movesite one of the given voisins had no more free connections");
#endif
      hopp( nn, zv_free)=iii;
      Mhopp(nn, zv_free)=hoppings(z).hconjugate();
    }
  };
  // diagonal matrix update
  Mdiag(iii)=Hii;
  // update indice map
  if (indice_map.count(coord_old) > 0) {
    indice_map.erase(coord_old);
	}
  indice_map[coordinate]=iii;
  return *this;
};

// shifts  a system on the vector delta  : i.e. all sites are shifted on  this coordinate but all the rest system info is preserved
template<class Tmicromatrix> 
systeme<Tmicromatrix>& systeme<Tmicromatrix>::translate_system(const Array<int,1>& delta){
  // delete old index map:
  indice_map.clear();
// coordinate update
  for (int i=0;i<fsize();i++) { 
 //save old coordinate """"""""""""""""""""""""""""""""""""""""""""""""""""""
    //const Array<int,1> coord_old = xyz(i,ALL).copy();
    xyz(i,ALL)+=delta;
    indice_map[xyz(i,ALL)]=i;//update map
  };
    return *this;
};

//testing utility compare the system with all protected variables, returns true if test is OK 
template<class Tmicromatrix> bool systeme<Tmicromatrix>::comparer(int dimm, int sizee,int zmaxx,const Array<int,2>& xyzz, const map<Array<int,1>,int,cmp_Array>& indice_mapp, const Array<int,2>& hoppp, const Array<Tmicromatrix,2>& Mhoppp, const Array<Tmicromatrix,1>& Mdiagg) const{
  bool test_OK=true;
  test_OK=test_OK&&dim==dimm&&size==sizee&&zmax==zmaxx&&all(xyz==xyzz)&&indice_map.size()==indice_mapp.size()&&all(hopp==hoppp)&&all(Mhopp==Mhoppp)&&all(Mdiag==Mdiagg);
  if (!test_OK) return test_OK;
  // check if indice_map are the same, as no bool operator==() is defined for Array, we should rewrite it manually
  map<Array<int,1>,int,cmp_Array>::const_iterator CI1=indice_map.begin(), CI2=indice_mapp.begin();
  for (;CI1!=indice_map.end();) {if ((!all(CI1->first==CI2->first))||(CI1->second!=CI2->second)) {test_OK=false;break;};;++CI1;++CI2;};
  return test_OK;
};




// TESTing utility, check xyz <-> indice_map correspondance, complexity is linear
template<class Tmicromatrix> bool systeme<Tmicromatrix>::xyz2ind_mapTEST() const{
  map<Array<int,1>,int,cmp_Array>::const_iterator CI=indice_map.begin();
  for (;CI!=indice_map.end();++CI) if (all(xyz(CI->second,Range::all())!=CI->first)) return false;
  return true;
};


/*********************/
/*********************/

// Class SYSTEMERECTANGLE, D-dimensional rectangular system

// Constructor from size, hopping V and on-site energy E
template<class Tmicromatrix> 
systemerectangle<Tmicromatrix>::systemerectangle(Array<int,1>& LxLyLz_in, Array<int,1>& OxOyOz_in, const Tmicromatrix& V, 
		 const Tmicromatrix& H_ii):LxLyLz(LxLyLz_in.copy()), OxOyOz(OxOyOz_in.copy()), Hhopp(V), Hdiag(H_ii)
{
#ifdef _DEBUG_
  // check if size_arr is well defined
  for (int i=LxLyLz_in.lbound(firstDim);i<=LxLyLz_in.ubound(firstDim);++i)
  if (LxLyLz_in(i)<=0) ERROR("in systemerectangle::systemerectange LxLyLz has negetive elements"); 
  if (LxLyLz_in.rows()!=OxOyOz_in.rows()) ERROR("in systemerectangle::systemerectangle rows of LxLyLz is not equal to the rows of OxOyOz");
#endif
  //initialisation of superclass protected variables
  Base::dim=LxLyLz.rows();
  Base::size=product(LxLyLz);
  Base::zmax=2*Base::dim;
  Base::xyz.resize(  shape(Base::size,Base::dim) );
  Base::hopp.resize( shape(Base::size,Base::zmax));
  Base::Mhopp.resize(shape(Base::size,Base::zmax));
  Base::Mdiag.resize(shape(Base::size));
  Base::Mdiag=H_ii;
  // initialisation of xyz and indice_map
  {Array<int,1> x_temp=LxLyLz.copy();// x_temp is just needed for recursive call
  recursive_init(x_temp,0);}; // WARNING do not try to use default call with just Array argument
  for (int ind=Base::hopp.lbound(firstDim);ind<=Base::hopp.ubound(firstDim);++ind){
    Array<int,1> x_temp=Base::xyz(ind,Range::all()).copy(); // coordinates of the given index -ind-
    for (int j=Base::hopp.lbound(secondDim);j<=Base::hopp.ubound(secondDim);++j){
      //nearest neighbors are taken as follow: 
      //for an even value of -j- j/2 coordinate is decreased by one
      //for an odd value of -j- (j-1)/2 coordinate is increased by one
      x_temp(j/2)+=(j%2==0)?-1:1; // update coordinates for -j- nearest neighbour
      //check if hopping is out of the sample (hopp=outsample) and assign hopp and Mhopp
      if (Base::indice_map.find(x_temp.copy())==Base::indice_map.end()){
	Base::hopp(ind,j)= Base::outsample;
	Base::Mhopp(ind,j)=Tmicromatrix();
      }
      else{
	Base::hopp(ind,j)=Base::indice_map[x_temp];
	Base::Mhopp(ind,j)=V;
      };
      x_temp(j/2)+=(j%2==0)?1:-1; //return to initial value of x_temp for next operation
    };
  };
#ifdef _DEBUG_ //check if size of indice_map is correct
  if (Base::size!=Base::indice_map.size()) ERROR("systemerectangle constructor indice_map size is not correct");
#endif
#ifdef _DEBUG_LONG_  // systeme member functions test
  // all impair neighbors for the last site as well as all pair neighbors of the first site should be outside of the sample
  bool test_OK=true;      
  if (test_OK!=true) ERROR("systemerectangle constructor; nearest neighbors test for the first and the last element failed");
  for (int z=1;z<Base::fzmax();z+=2) test_OK=test_OK&&(Base::voisin(Base::fsize()-1,z)==Base::outsample);
  for (int z=0;z<Base::fzmax();z+=2) test_OK=test_OK&&(Base::voisin(0,z)==Base::outsample);
  // all impair neighbors hopping matrix elements for the last site as well as all pair neighbors of the first site should be zero
  for (int z=1;z<Base::fzmax();z+=2) test_OK=test_OK&&(Base::Mvoisin(Base::fsize()-1,z)==Tmicromatrix());
  for (int z=0;z<Base::fzmax();z+=2) test_OK=test_OK&&(Base::Mvoisin(0,z)==Tmicromatrix());
  if (test_OK!=true) ERROR("systemerectangle constructor; nearest neighbors matrix element test for the first and the last element failed");
  // all diagonal matrix elements should be the same
  for (int ind=1;ind<Base::fsize();++ind) test_OK=test_OK&&(Base::Msite(ind-1)==Base::Msite(ind));
  if (test_OK!=true) ERROR("systemerectangle constructor; diagonal matrix element test fail");
  if (!Base::xyz2ind_mapTEST()) ERROR("systemerectangle constructor; xyz <-> indice_map correspondance failed");
#endif
};

// dimension of rectagular system ie if LxLyLz=1,3 then real_dim=1, systeme::dim=2, for LxLyLz=4,5,6 real_dim=dim=3
template<class T> int systemerectangle<T>::real_dim() const{ //this function was tested
  int rd=0;
  for (int i=0;i<LxLyLz.rows();++i) if (LxLyLz(i)!=1) rd++;
  if (product(LxLyLz) == 1) rd=1;
  return rd;
};

// Index of an element xx for the sample of size L with the point of origin at (0,0,0 ...) 
// check in test_xyz_for_rectangle_init.C
template<class T> int systemerectangle<T>::indice_Dd(const Array<int,1>&  xx)
{
  int ind_result=xx(0),L_product=1;
  for (int i=1;i<xx.rows();++i) {L_product*=LxLyLz(i-1);ind_result+=xx(i)*L_product;};
  return ind_result;
 };

// Initialize protected variables of the Base class ie xyz and indice_map 
// check in test_xyz_for_rectangle_init.C
template<class T> void systemerectangle<T>::recursive_init(Array<int,1>& x, int n)
{
#ifdef _DEBUG_
  // check if x is of the same size as LxLyLz
  if (LxLyLz.rank()!=x.rank()||LxLyLz.rows()!=x.rows()) 
    ERROR("in systemerectangle::recursive_init LxLyLz is not equivalent to recursive variable x");
#endif
  if (n==LxLyLz.rows()) 
    { 
      // call indice_Dd(x) function just ones with point of origin offset
      int indice_local=indice_Dd(Array<int,1>(x-OxOyOz));
      // initialize systemerectangle::indice_map
      Base::indice_map[x.copy()]=indice_local;
      // initialize systemerectangle::xyz
      Base::xyz(indice_local,Range::all())=x;
     }
  else  for (x(n)=OxOyOz(n);x(n)<LxLyLz(n)+OxOyOz(n);++x(n)) recursive_init(x,n+1);
};

// copy constructor
template<class Tmicromatrix> systemerectangle<Tmicromatrix>::systemerectangle(const systemerectangle<Tmicromatrix>& A)
  :Base(A), LxLyLz(A.LxLyLz.copy()), OxOyOz(A.OxOyOz.copy()), Hhopp(A.Hhopp), Hdiag(A.Hdiag) {};


// ********************* //
// ********************* //

// NUMERIC_LEAD class, system with the leads
/// constructor from interface system and hopping Hamiltonian
template<class Tmicromatrix>
N_reservoir<Tmicromatrix>::N_reservoir(const systeme<Tmicromatrix>& sys,const GF_type& HHhopp): Base(sys), Hhopp(HHhopp.copy()){};

/// constructor from interface system and hopping element (optionnally magnitic field is given flux=phi/phi_0 is also given)
template<class Tmicromatrix>
N_reservoir<Tmicromatrix>::N_reservoir(const systeme<Tmicromatrix>& sys,const Tmicromatrix& hopp, double flux): 
  Base(sys), Hhopp(sys.fsize(), Tmicromatrix::dim(), sys.fsize(), Tmicromatrix::dim()) {
  // initialization of Hhopp
  // all sites from the interface system are supposed to be connected by -hopp- to the same sites of the next slice 
  for (int i=0; i<sys.fsize();++i) Hhopp(i,ALL,i,ALL)=(  hopp*exp( COMPLEX(0.,2.*PI*flux*(sys.coord(0,0)+i)) )  ).micro2arr();
};

/// constructor of Hdiag matrix from interface system
template<class Tmicromatrix>
const GF_type N_reservoir<Tmicromatrix>::getHdiag() const{
  GF_type Hdiag(Hhopp.shape());
  Hdiag=0.;
  // initialization of Hdiag from interface system
  for (int i=0; i<BBase::size;++i){ 
    Hdiag(i,ALL,i,ALL)=BBase::Msite(i).micro2arr();
    for (int z=0; z<BBase::zmax;++z){
      const int j=BBase::voisin(i,z);
      if (j != BBase::outsample ) Hdiag(i,ALL,j,ALL)=BBase::Mvoisin(i,z).micro2arr();
    };
  };
  return Hdiag;
};

/// Green function of leads interface for the energy E
template<class Tmicromatrix>
inline int N_reservoir<Tmicromatrix>::Nchannels(COMPLEX E) const{
  const GF_type Hdiag=getHdiag();
  GF_type GFLead; // Green Function of the lead 
  GFLead.resize(Hhopp.shape());
  return semi_infini(Hhopp, Hdiag, E ,GFLead);
}; 


/// Green function of leads interface for the energy E
template<class Tmicromatrix>
inline GF_type N_reservoir<Tmicromatrix>::green(COMPLEX E) const{
  const GF_type Hdiag=getHdiag();
  GF_type GFLead; // Green Function of the lead 
  GFLead.resize(Hhopp.shape());
  semi_infini(Hhopp, Hdiag, E ,GFLead);
  return GFLead;
}; 

/// self Energy of leads interface supposing it is connected to the system via inter-slice hopping Hhopp
template<class Tmicromatrix>
inline GF_type N_reservoir<Tmicromatrix>::selfE(COMPLEX E) const{
  const GF_type Hdiag=getHdiag();
  GF_type GFLead; // Green Function of the lead 
  GFLead.resize(Hhopp.shape());
  semi_infini(Hhopp, Hdiag, E ,GFLead);
  GF_type SE(GFLead.shape()); SE=0.;// self energy 
  GF_type TMP(GFLead.shape());// temporal for product of GF by V^H
  matmul_blas(GFLead,Hhopp,TMP,COMPLEX(1.),COMPLEX(0.),'n','c');
  matmul_blas(Hhopp,TMP,SE);
  return SE;
}; 

/// GF and self Energy of leads interface
template<class Tmicromatrix>
pair<GF_type,GF_type> N_reservoir<Tmicromatrix>::G_SE(COMPLEX E) const{
  const GF_type Hdiag=getHdiag();
  GF_type GFLead; // Green Function of the lead 
  GFLead.resize(Hhopp.shape());
  semi_infini(Hhopp, Hdiag, E ,GFLead);
  GF_type SE(GFLead.shape()); SE=0.;// self energy 
  GF_type TMP(GFLead.shape());// temporal for product of GF by V^H
  matmul_blas(GFLead,Hhopp,TMP,COMPLEX(1.),COMPLEX(0.),'n','c');
  matmul_blas(Hhopp,TMP,SE);
  return pair<GF_type,GF_type>(GFLead,SE);
}; 


// ********************* //
// ********************* //

// SYSTEME_INFINI class, system with the leads

//copy constructor are needed while Blitz arrays are used
template<class Tmicromatrix>
systeme_infini<Tmicromatrix>::systeme_infini(const systeme_infini<Tmicromatrix>& sys_inf)
  :Base(sys_inf), Nres(sys_inf.Nres), preservoirs(sys_inf.preservoirs.copy()),res2sys_arr(sys_inf.res2sys_arr.copy()), sys2res_arr(sys_inf.sys2res_arr.copy()), sys2res_ind_arr(sys_inf.sys2res_ind_arr.copy())
{
#ifdef _DEBUG_LONG_// test of res2sys_arr <-> sys2res_arr correspondance 
  if (!res2sysTEST()) ERROR("systeme_infini copy constructor; res2sys <-> sys2res correspondance failed");
#endif
};

// constructor of system connected to the single lead, input data are a finit system (sys_fini) and a lead (res)
template<class Tmicromatrix>
systeme_infini<Tmicromatrix>::systeme_infini(const systeme<Tmicromatrix>& sys_fini,const reservoir<Tmicromatrix>& res)
  :Base(sys_fini){
  Base::coller(res); // total system consist of -sys_fini- ovelapped by the lead -res-
  Nres=1; // number of leads
  preservoirs.resize(Nres); //just a single lead
  preservoirs(Nres-1)=&res;
  // res2sys is two dimensional matrix of size (Nres,max_lead_size), which gives for any lead's site the site of the system connected to it; res2sys(lead_number,index_lead)=index_system; We choose also that all the sites of the lead's interface are connected to the system and that the hopping matrix elements from the lead to the system are exactly the same as those inside lead itself
  // sys2res and sys2res_ind together contain the same information as res2sys array in the different form. It's a vector of system_size size. It is made for faster data access; sys2res(index_system)=lead_number sys2res_ind(index_system)=lead_index;  if index_system is not connected to any lead, then its lead_number is set to static variable not_lead.
  res2sys_arr.resize(Nres,res.fsize());
  sys2res_arr.resize(Base::fsize());
  sys2res_ind_arr.resize(Base::fsize());
  sys2res_arr=not_lead; // by default all the sites are not connected to any lead (we take not_lead=-1)
  sys2res_ind_arr=not_lead; // by default all the sites are not connected to any lead (we take not_lead=-1)
  for(int j=0;j<res.fsize();++j) {
    int sys_index=Base::indice(res.vcoord(j)); // system index for lead's sites
    res2sys_arr(Nres-1,j)=sys_index; // leads -> system index correspondance
    sys2res_arr(sys_index)=Nres-1;   // all -res- sites are connected to the lead number=0
    sys2res_ind_arr(sys_index)=j;    // all -res- sites are connected to the lead number=0 with appropriate index j
  };
#ifdef _DEBUG_LONG_// test of res2sys_arr <-> sys2res_arr correspondance 
  if (!res2sysTEST()) ERROR("systeme_infini constructor; res2sys <-> sys2res correspondance failed");
#endif
};

// connect one more lead to already created system with at least one lead
template<class Tmicromatrix>
systeme_infini<Tmicromatrix>& systeme_infini<Tmicromatrix>::addlead(const reservoir<Tmicromatrix>& res){
  const int old_sys_size=Base::size;
  // coller lead to the system
  Base::coller(res);
  Nres++; //update number of leads
  // update the array of pointer to the leads, NB the size of this array is changed
  Array<const reservoir<Tmicromatrix>*,1> temp_preservoirs=preservoirs.copy();
  preservoirs.resize(Nres);
  preservoirs(Range(0,Nres-2))=temp_preservoirs;
  preservoirs(Nres-1)=&res;
  // check if maximum lead's size is not changed
  int Nmax_lead_size=max_lead_size();
  const int Nmax_lead_size_old=Nmax_lead_size;
  if (Nmax_lead_size<res.fsize()) Nmax_lead_size=res.fsize();
  // update the list of system sites connected to the leads
  // first write old sys<=>res correspondance in the arrays of new size
  Array<int,2> res2sys_temp=res2sys_arr.copy();
  res2sys_arr.resize(Nres,Nmax_lead_size);
  res2sys_arr=Base::outsample; //all meaningless elements would be given -outsample- value 
  res2sys_arr(Range(0,Nres-2),Range(0,Nmax_lead_size_old-1))=res2sys_temp; // copy old value
  if (old_sys_size != Base::size){ // if size of the system was changed => resize sys2res
    Array<int,1> sys2res_temp=sys2res_arr.copy();
    Array<int,1> sys2res_ind_temp=sys2res_ind_arr.copy();
    sys2res_arr.resize(Base::size);
    sys2res_ind_arr.resize(Base::size);
    sys2res_arr(Range(0,sys2res_temp.rows()-1))=sys2res_temp; // copy old values
    sys2res_ind_arr(Range(0,sys2res_ind_temp.rows()-1))=sys2res_ind_temp; // copy old values
  };
  // then update new values
  for(int j=0;j<res.fsize();++j) {
    int sys_index=Base::indice(res.vcoord(j)); // // system index for lead's sites
    res2sys_arr(Nres-1,j)=sys_index; // leads -> system index correspondance
    sys2res_arr(sys_index)=Nres-1;   // all -res- sites are connected to the last lead 
    sys2res_ind_arr(sys_index)=j;    // all -res- sites are connected to the last lead with appropriate lead index j 
  };

  //CHANGE LEADS ORDER, so that their ennumeration was the same as order of knitting if started from Zero site
  map<int,int> order_map; // order_map=pair<lowest system index, lead index>
  for (int l=0;l<Nres;++l){//for each lead
    int lsi=Base::size; // lowest system index
    for (int li=0;li<lead_size(l);++li) if ( res2sys(l,li)<lsi ) lsi=res2sys(l,li); // for each element of lead
    order_map[lsi]=l;
  };
  //reorder preservoirs, res2sys
  //save old values
  Array<const reservoir<Tmicromatrix>*,1> preservoirs_reorder=preservoirs.copy();
  Array<int,2> res2sys_reorder=res2sys_arr.copy();
  int new_pos=0;
  for (typename map<int,int>::const_iterator CI=order_map.begin(); CI!=order_map.end(); CI++,new_pos++){
    const int old_pos=CI->second;
    preservoirs(new_pos)  = preservoirs_reorder(old_pos);
    res2sys_arr(new_pos,ALL)= res2sys_reorder(old_pos,ALL);
  };
  // reorder sys2res given newly ordered res2sys
  for (int l=0;l<Nres;++l) for (int li=0;li<lead_size(l);++li) sys2res_arr(res2sys(l,li))=l;
  // sys2res_ind need not to be reordered
#ifdef _DEBUG_LONG_// test of res2sys_arr <-> sys2res_arr correspondance 
  if (!res2sysTEST()) ERROR("systeme_infini addlead member function; res2sys <-> sys2res correspondance failed");
#endif
  return *this;
};

//reservoir to systeme function call: returns list of system sites connected to the leads
template<class Tmicromatrix>
inline int systeme_infini<Tmicromatrix>::res2sys(int lead,int index_lead) const{
#ifdef _DEBUG_
  if (lead<0||lead>=Nres) ERROR("in systeme_infini::res2sys; lead is out of range 0<lead<Nres-1 ");
  if (index_lead<0||index_lead>=lead_size(lead)) ERROR("in systeme_infini::res2sys; index_lead is out of range 0<index_lead<lead_size-1 ");
#endif
  return res2sys_arr(lead,index_lead);
};

// systeme to resvoir function call: returns lead's number for any system sites
// gives -not_lead- if given system site is not connected to any lead
template<class Tmicromatrix>
inline int systeme_infini<Tmicromatrix>::sys2res(int index_system) const{
#ifdef _DEBUG_
  if (index_system<0||index_system>=Base::fsize()) ERROR("in systeme_infini::sys2res; idex_system is out of range");
#endif
  return sys2res_arr(index_system);
};

// systeme to resvoir function call: returns of lead's index for any system sites
// gives -not_lead- if given system site is not connected to any lead
template<class Tmicromatrix>
inline int systeme_infini<Tmicromatrix>::sys2res_ind(int index_system) const{
#ifdef _DEBUG_
  if (index_system<0||index_system>=Base::fsize()) ERROR("in systeme_infini::sys2res_ind; idex_system is out of range");
#endif
  return sys2res_ind_arr(index_system);
};

// returns lead's index for voisin z of leads site (lead,li)
// gives -not_lead- if this voisin do not belongs to the same lead
template<class Tmicromatrix>
inline int systeme_infini<Tmicromatrix>::lead_voisin(int lead, int li, int z) const{
  const int vi=Base::voisin(res2sys_arr(lead,li),z);
  return (vi<0 || sys2res_arr(vi) != lead) ? not_lead : sys2res_ind_arr(vi);
};

//testing utility compare the system_infini with all protected variables, returns true if test is OK 
template<class Tmicromatrix>
bool systeme_infini<Tmicromatrix>::comparer(int Nress, const Array<int,2>& res2syss, const Array<int,1>& sys2ress) const{
  bool test_OK=true;
  test_OK=test_OK&&all(res2syss==res2sys_arr)&&all(sys2ress==sys2res_arr);
  return test_OK;
};

// test of res2sys_arr <-> sys2res_arr correspondance 
template<class Tmicromatrix>
bool systeme_infini<Tmicromatrix>::res2sysTEST() const{
  for (int lead=0;lead<Nres;++lead) // loop over all leads
    for (int index_lead=0;index_lead<lead_size(lead);++index_lead)
      if (sys2res(res2sys(lead,index_lead))!=lead  || sys2res_ind(res2sys(lead,index_lead))!=index_lead ) return false;
  return true;
};




/********************************/

/******************    TO DO *******************/
/*
1) rajouter un teste sur la validite d'une permutation
2) fonction membre exchange(int,int) pour la classe permutation 
3) pour sauver la memoire on pourra utiliser les pointeurs dans systeme::Mhopp et systeme::Mdiag
4) changer la position de inline dans chaque fonction membre
5) creer numerotation de sites longitudinals dans systemerectangle dans le cas ou ysize>xsize;
6) definir systemerectangle::efficacity
7) define assignment operation for system 
8) voir const Tmicromatrix& Mvoisin() const, si le premier const est necessaire
*/
