// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef knit_MICROMATRICES_
#define knit_MICROMATRICES_
#include "blitz_addon.h"
#include "knit_general.h"
#include <blitz/array.h>
using namespace blitz;
#include <complex>
typedef complex<double> COMPLEX;

/** \file knit_micromatrices.h
Module containing the various micromatrices that
describe the microscopic structure of the Hamiltonian.
The microsopic degree of freedom can be spin (magnetic
systems), electron/hole (superconductors), atomic orbitals 
s,p,d... (realistic tight-biding Hamiltonians). In the
most basic example, the micromatrices are just scalars.**/


/*
/// A micromatrix is expected to contain (at least) the following implementation.
class micromatrix { 
 public:
  inline micromatrix();
  inline ~micromatrix();
  inline micromatrix operator-() const; ///< Prefix minus
  inline micromatrix& operator+=(const micromatrix& A); ///< Addition +=
  inline micromatrix& operator-=(const micromatrix& A); ///< Subtraction -=
  inline micromatrix& operator*=(const micromatrix& A); ///< Multiplication *=
  inline micromatrix& operator*=(const COMPLEX& A); ///< Multiplication by COMPLEX *=
  inline COMPLEX operator()(const int i,const int j) const; ///< Matrix element value for rhs expression var=A(i,j)
  inline COMPLEX& operator()(const int i,const int j); ///< Matrix element assignment for lhs expression A(i,j)=value
  inline micromatrix hconjugate() const; ///< Hermitian conjugate
  inline micromatrix inverse() const; ///< Inverse
  inline bool operator==(const micromatrix&); ///< Compair two elements
  Array<COMPLEX,2> micro2arr() const;         ///< Conversion to Array of complex
  static int dim();///< Dimension
};
*/

/*********** functions not declared inside micromatrix ****************/
/*
// cout<<
ostream& operator<<(ostream& output, const micromatrix& a);

// arithmetic operations
inline micromatrix operator+(const micromatrix& A, const micromatrix& B); ///< Addition +
inline micromatrix operator-(const micromatrix& A, const micromatrix& B); ///< Subtraction -
inline micromatrix operator*(const micromatrix& A, const micromatrix& B); ///< Multiplication *
inline micromatrix operator*(const COMPLEX& a,const micromatrix& B); ///< Multiplication by COMPLEX* on the left
inline micromatrix operator*(const micromatrix& B, const COMPLEX& a); ///< Multiplication by COMPLEX* on the right
*/

/***************************************************************************************/
/***************************************************************************************/
/// Scalar micromatrix
class scalarM{
 public:
  inline scalarM(){c=0;};
  inline ~scalarM(){};
  scalarM(COMPLEX A){c=A;}; // Constructor by COMPLEX used to limit operations number for +-* operators
  scalarM operator-() const {return scalarM(-c);};                    ///< Prefix minus
  scalarM& operator+=(const scalarM& A){c+=A.c;return *this;};        ///< Addition +=
  scalarM& operator-=(const scalarM& A){c-=A.c;return *this;};        ///< Subtraction -=
  scalarM& operator*=(const scalarM& A){c*=A.c;return *this;};        ///< Multiplication *=
  scalarM& operator*=(const COMPLEX& com){c*=com;return *this;};      ///< Multiplication by COMPLEX *=
  COMPLEX operator()(const int i,const int j) const;                  ///< Element value
  COMPLEX& operator()(const int i,const int j);                       ///< Element assignment
  scalarM hconjugate() const {return conj(c);};                       ///< Hermitian conjugate
  scalarM inverse() const {return 1./c;};                             ///< Inverse
  Array<COMPLEX,2> micro2arr() const;                                 ///< Conversion to Array of complex
  bool operator==(const scalarM& A){return (c==A.c);};                ///< Compair two elements
  static int dim() {return 1;};///< Dimension
  
 private:
  COMPLEX c;
  operator COMPLEX() const {return c;}; //Conversion from scalarM to COMPLEX for member functions
};



/*********** functions not declared inside scalarM **************/
// cout<<
ostream& operator<<(ostream& output, const scalarM& a);

// arithmetic operations
inline scalarM operator+(const scalarM& A, const scalarM& B) {scalarM C=A;C+=B;return C;}; ///< Addition +
inline scalarM operator-(const scalarM& A, const scalarM& B) {scalarM C=A;C-=B;return C;}; ///< Subtraction -
inline scalarM operator*(const scalarM& A, const scalarM& B) {scalarM C=A;C*=B;return C;}; ///< Multiplication *
/// Multiplication by COMPLEX * on the left
template<class Tnum>
inline scalarM operator*(const Tnum& a, const scalarM& B) {scalarM C=B;C*=COMPLEX(a);return C;};
/// Multiplication by COMPLEX * on the right
template<class Tnum>
inline scalarM operator*(const scalarM& B, const Tnum& a) {scalarM C=B;C*=COMPLEX(a);return C;};

/* //arr2micro */
/* inline scalarM arr2micro(const Array<COMPLEX,2>& A) {scalarM M;M(0,0)=A(0,0);return M;}; */


/************ INLINE funcitons for scalarM **********/

// Element value
inline COMPLEX scalarM::operator()(const int i,const int j) const{
#ifdef _DEBUG_
  if (i>=scalarM::dim()||j>=scalarM::dim()||i<0||j<0) ERROR("scalarM matrix index is out of range");
#endif
  return c;
};

// Element assignment
inline COMPLEX& scalarM::operator()(int i, int j) {
#ifdef _DEBUG_
  if (i>=scalarM::dim()||j>=scalarM::dim()||i<0||j<0) {cout<<"i="<<i<<"  j="<<j<<endl;ERROR("scalarM matrix index is out of range");}
#endif
 return c;
};

// Conversion to Array of complex
inline  Array<COMPLEX,2> scalarM::micro2arr() const {
  Array<COMPLEX,2> r(scalarM::dim(),scalarM::dim());
  r(0,0)=c;
  return r;
};


//////////////////////////////////////



/***************************************************************************************/
/***************************************************************************************/

/// Vector micromatrix
template<int d> class vectorM{
 public:
  // TTT for faster calculations zero assignment should be supressed in the default constructor
/*   vectorM(){for (int i=0;i<d*d;++i) v[i]=0.;}; */
/*   //~vectorM(){};          ///< default destructor  */
/*   vectorM(const vectorM& VV)      ///< copy constructor */
/*     {for (int i=0;i<d*d;++i) v[i]=VV.v[i];};  */
/*   vectorM& operator=(const vectorM& VV) ///< assignement operator */
/*     {for (int i=0;i<d*d;++i) v[i]=VV.v[i];return *this;};  */
  vectorM(const vectorM& AAA){for (int i=0;i<d*d;++i) v[i]=AAA.v[i];}
  vectorM operator-() const                ///< Prefix minu
    { vectorM VV(*this); for (int i=0;i<d*d;++i) VV.v[i]=-v[i]; return VV;}; 
  vectorM& operator+=(const vectorM& VV)   ///< Addition +=
    { for (int i=0;i<d*d;++i) v[i]+=VV.v[i]; return *this;}; 
  vectorM& operator+=(const COMPLEX& com)   ///< Addition += of COMPLEX
    { for (int i=0;i<d;++i) v[i+i*d]+=com; return *this;}; 
  vectorM& operator-=(const vectorM& VV)   ///< Subtraction -=
    { for (int i=0;i<d*d;++i) v[i]-=VV.v[i]; return *this;}; 
  vectorM& operator*=(const vectorM& VV);   ///< Multiplication *=
  vectorM& operator*=(const COMPLEX& com)    ///< Multiplication by COMPLEX *=
    {for (int i=0;i<d*d;++i) v[i]*=com;return *this;};  
  COMPLEX operator()(const int i,const int j) const;                  ///< Element value
  COMPLEX& operator()(const int i,const int j);                       ///< Element assignment
  void set(const int i,const int j,COMPLEX E);
  vectorM();              ///< ZERO matrix
  vectorM(COMPLEX E);     ///< Diagonal matrix
  vectorM hconjugate() const;                       ///< Hermitian conjugate
  vectorM inverse() const;                         ///< Inverse
  Array<COMPLEX,2> micro2arr() const;              ///< Conversion to Array of complex
  bool operator==(const vectorM& VV)                ///< Compare two elements
    {for (int i=0;i<d*d;++i) {if (v[i]!=VV.v[i]) return false;} ;return true;};
  static int dim() {return d;};///< Dimension
 private:
  COMPLEX v[d*d];
};

///************* SPECIFIC FORMS OF vectorM **********************
typedef vectorM<2> spinM;

/*********** functions not declaired inside scalarM **************/
// cout<<
template<int d>
ostream& operator<<(ostream& output, const vectorM<d>& a){
  cout.precision(3);
  cout<<fixed;
  for (int i=0;i<d;++i) {
    for (int j=0;j<d;++j)
      output<<a(i,j);
    if (i!=d-1) output<<endl;
  };
  return output;
};

// arithmetic operations
template<int d>
inline vectorM<d> operator+(const vectorM<d>& A, const vectorM<d>& B) {vectorM<d> C=A;C+=B;return C;}; ///< Addition +
// addition of COMPLEX  on the left
template<class Tnum,int d>
inline vectorM<d> operator+(const Tnum& a, const vectorM<d>& B) {vectorM<d> C=B;C+=COMPLEX(a);return C;};
//addition of COMPLEX  on the right
template<class Tnum, int d>
inline vectorM<d> operator+(const vectorM<d>& B, const Tnum& a) {vectorM<d> C=B;C+=COMPLEX(a);return C;};
template<int d>
inline vectorM<d> operator-(const vectorM<d>& A, const vectorM<d>& B) {vectorM<d> C=A;C-=B;return C;}; ///< Subtraction -
template<int d>
inline vectorM<d> operator*(const vectorM<d>& A, const vectorM<d>& B) {vectorM<d> C=A;C*=B;return C;}; ///< Multiplication *
// Multiplication by COMPLEX * on the left
template<class Tnum,int d>
inline vectorM<d> operator*(const Tnum& a, const vectorM<d>& B) {vectorM<d> C=B;C*=COMPLEX(a);return C;};
// Multiplication by COMPLEX * on the right
template<class Tnum, int d>
inline vectorM<d> operator*(const vectorM<d>& B, const Tnum& a) {vectorM<d> C=B;C*=COMPLEX(a);return C;};

//arr2micro
template<class Tmicromatrix>
inline Tmicromatrix arr2micro(const Array<COMPLEX,2>& A) 
{ Tmicromatrix M; const int d=Tmicromatrix::dim(); for (int i=0;i<d;++i) for (int j=0;j<d;++j) {M(i,j)=A(i,j);} return M;};


/************ INLINE funcitons for vectorM **********/

// Element value
template<int d>
inline COMPLEX vectorM<d>::operator()(const int i,const int j) const{
#ifdef _DEBUG_
  if (i>=vectorM<d>::dim()||j>=vectorM<d>::dim()||i<0||j<0) ERROR("vectorM matrix index is out of range");
#endif
  return v[d*i+j];
};

template<int d> inline void vectorM<d>::set(const int i,const int j,COMPLEX E){
#ifdef _DEBUG_
  if (i>=vectorM<d>::dim()||j>=vectorM<d>::dim()||i<0||j<0) ERROR("vectorM matrix index is out of range");
#endif
  v[d*i+j]=E;
};

template<int d> inline vectorM<d>::vectorM(){
  for(int i=0;i<d*d;++i) v[i]=0.0;
};

template<int d> inline vectorM<d>::vectorM(COMPLEX E){
  for(int i=0;i<d*d;++i) v[i]=0.0;
  for(int i=0;i<d;++i) v[i*(d+1)]=E;
};


// Element assignment
template<int d>
inline COMPLEX& vectorM<d>::operator()(int i, int j) {
#ifdef _DEBUG_
  if (i>=vectorM<d>::dim()||j>=vectorM<d>::dim()||i<0||j<0) ERROR("vectorM matrix index is out of range");
#endif
  return v[d*i+j];
};

// Conversion to Array of complex
template<int d>
inline  Array<COMPLEX,2> vectorM<d>::micro2arr() const {
  Array<COMPLEX,2> r(vectorM::dim(),vectorM::dim());
  for (int i=0;i<d;++i) for (int j=0;j<d;++j) r(i,j)=operator()(i,j);
  return r;
};

// Multiplication *=
template<int d>
inline  vectorM<d>& vectorM<d>::operator*=(const vectorM<d>& VV) {
  vectorM<d> res;
  for (int j=0;j<d*d;++j) res.v[j]=0.;
  for (int i=0;i<d;++i) for (int j=0;j<d;++j) for (int k=0;k<d;++k) 
    res(i,j)+=operator()(i,k)*VV(k,j); 
  *this=res;
  return *this;
}; 

template<int d>
inline  vectorM<d> vectorM<d>::hconjugate() const
{ vectorM<d> res(*this); for (int j=0;j<d;++j) for (int i=0;i<d;++i) res(i,j)=conj(operator()(j,i)); return res;}; 

// Inversion
template<int d>
inline  vectorM<d> vectorM<d>::inverse() const {
  vectorM<d> res(*this);
  int *ipiv = new int[d*d];COMPLEX *work = new COMPLEX[d]; int info;
  F77(zgetrf) (d,d,res.v,d,ipiv,info);
  F77(zgetri) (d,res.v,d,ipiv,work,d,info);
  delete[] work; delete[] ipiv;
  return res;
};



#endif
