// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef _knit_RESEVOIR_
#define _knit_RESERVOIR_
/** \file knit_reservoir.h
    COMPUTE THE SURFACE RETARDED GREEN FUNCTION OF A SEMI INFINITE SYSTEM AT ENERGY E.
    THE HAMILTONIAN ON ONE SLICE IS GIVEN BY Ho AND THE HOPPING FROM SLICE TO SLICE BY V
    THE RESULT IS PUT IN GFsurf.
**/
#include <blitz/array.h>
#include "knit_general.h"

using namespace blitz;
typedef complex<double> COMPLEX;
typedef Array<COMPLEX,4> GF_type;

// Hhopp - hopping Hamiltonian between slices
// Hdiag - intraslice Hamiltonian
// E     - working Energy
// GFsurf (output) - surface GF 

int semi_infini_old(const GF_type& Hhopp, const GF_type& Hdiag, COMPLEX E, GF_type& GFsurf);

int semi_infini_new(const GF_type& Hhopp, const GF_type& Hdiag, COMPLEX E, GF_type& GFsurf);

int semi_infini_newbis(const GF_type& Hhopp, const GF_type& Hdiag, COMPLEX E, GF_type& GFsurf);




int semi_infini(const GF_type& Hhopp, const GF_type& Hdiag, COMPLEX E, GF_type& GFsurf);

// hopp - scalar hopping element
// diag - onsite Energy
// E - Energy
// M - transversal channel number(interface size) 
// GFsurf (output) - scalar surface GF 
void analytic_semi_infini(double hopp,COMPLEX diag,COMPLEX E,int M,GF_type& GFsurf);

#endif // _knit_RESERVOIR_
