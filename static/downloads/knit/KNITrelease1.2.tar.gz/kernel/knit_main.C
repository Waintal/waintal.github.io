// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include "knit_general.h"
#include "knit_Python_Data.h"


int rank=0;
int size=1;

#ifdef _WITHMAIN_

int main(int argc,char** argv){
  
  
#ifdef _MPI_
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&rank); 
  MPI_Comm_size(MPI_COMM_WORLD,&size); 
  MPI_Barrier(MPI_COMM_WORLD);
#endif 
  
#ifdef _DEBUG_LONG_ //in full debug mode simple debug is also activated
#define _DEBUG_
#endif
  
  // READING INPUTS ****************************************************************************
  string fichier="inputfile.knit"; 
  PythonData::Python_Data input(fichier.c_str());
  
  // GENERATING LOGFILE ************************************************************************
  string fichiergeneric=input.S("FICHIER");
  string nom_logfile=fichiergeneric+".log";
  time_t t1,t2;
  string nom_input=fichiergeneric+".input"; 
  ofstream logfile(nom_logfile.c_str(),ios_base::app);
  if(rank==0){string copieinput="cp  "+fichier+"  "+nom_input;system(copieinput.c_str());};
  
  
  
 #ifdef _MPI_
  MPI_Finalize();
#endif
  return 1;
};

#endif // _WITHMAIN_

  

















