// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#ifndef knit_GENERAL_
#define knit_GENERAL_

#include <iostream>
#include "math.h"
#include <vector>
#include <list>
#include <fstream>
#include <string>
#include <sstream>
#include <iterator>
#include <ctime>

#ifdef _MPI_
#include <mpi.h>
#endif

extern int rank;
extern int size;

const double PI=3.14159265358;
#define ALL Range::all()
#define _VERSION_ "v1.0.3"

using namespace std;

#ifdef _DEBUG_LONG_
#ifndef _DEBUG_
#define _DEBUG_
#endif
#endif


void inline ERROR(char* message) {
  if(rank==0) cout<<"*** SORTIE GENEREE PAR ROUTINE ERROR ***"
		  <<endl<<message<<endl;
  for(int i=0;i<size;++i){
    if(i==rank) exit(1);
#ifdef _MPI_
    MPI_Barrier(MPI_COMM_WORLD);
#endif
  };
};

#endif
