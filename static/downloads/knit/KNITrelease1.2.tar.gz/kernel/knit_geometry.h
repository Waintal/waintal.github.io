// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


/** \file knit_geometry.h
Module that contains two classes making connection between current GF interface and geometry of the system:
1) class position with various information about GF index at the given step of knitting. Given intitial and final knit positions, this class contains all index references
2) class position_knit is responsible for dynamical part of knitting, ie how to add or suppress sites while knitting
**/
#ifndef  knit_GEOMETRY_
#define  knit_GEOMETRY_
#include "knit_general.h"
#include "knit_system.h"

#include <blitz/array.h>

using namespace blitz;


/// real copy operator for maps composed of blitz::Arrays elements
template<class T,int n>
void map_copy( map<int,const Array<T,n> > & lM, const map<int,const Array<T,n> >& rM);


// **************POSITION********************** //
//next two declarations are needed just because we want to define friend template operator<< for the template class
template<class Tmicromatrix> class position;
template<class Tmicromatrix> ostream& operator<<(ostream&, const position<Tmicromatrix>&);
/// position (static geometrical postion class) \n Class position permit us to establish bijective correspondance between GF index and system index at each step of knitting provided we have just first and last index of the lace.
 /// s2g(); system index -> Green Function index. It's a vector of the system size, it keeps for any index of the system its index in the GF. s2g is updated at each step of knitting. It's also keep track of the site's last GF index before it was deleted using negative value ie \n s2g(10)=-5 means that site number 10 is already out of knitting procedure and before it was deleted it had GF index = 4 (see N2P(int) function). This information is necessairy in order to perform knitback preserving exactly the same GF <-> system correspondance as for knitforward. All the sites not touched by the knitting are given initial value s2g(site)=outlace
 /// g2s(); Green Function index -> system index. It's a vector of the maximum GF size, which is usually much smaller then the system size. This maximum GF size could be calculated in advance, but at the beginnig one could take system size as well. g2s in principle is inversed function of s2g. Knowing s2g one could scan all its elements and recover g2s, but as this procedure is too costly in processor time both arrays need to be stocked. Only elements  {0,1,2,...,taille-1} are relevant, but it's better not to change g2s size on fly, as it consumes too much time.

template<class Tmicromatrix>
class position{
 public:
  typedef systeme_infini<Tmicromatrix> sys_inf;       ///< infinite system
  position(){taille=0;};                              ///< default constructor
  position(const position&);                          ///< copy constructor
  position& operator=(const position&);               ///< assignment operator
  bool operator==(const position&) const;             ///< bool compare operator
  int s2g(int s_ind) const;                           ///< function call of s2g array  element copy
  int& s2g(int s_ind);                                ///< function call of s2g array element reference
  int g2s(int GF_ind) const;                          ///< function call of g2s array element copy
  int& g2s(int GF_ind);                               ///< function call of g2s array element reference
  const map<int,int> interface(int ind) const;        ///< both voisin index and GF index for in-lace nearest neighbors of the site -ind- <z,GF_ind> 
  void set_interface(int ind, map<int,int>& I) const; ///< both voisin index and GF index for in-lace nearest neighbors of the site -ind- <z,GF_ind> 
  Array<map<int,int>,1> interfaceLead(int lead) const;///< vector of map<z,GF_ind> for each lead's element
  int ftaille() const {return taille;}                ///< function call of taille
  const Range range() const {return Range(0,taille-1);}///< full range for this position
  //const Range range() const {return taille?Range(0,taille-1):Range();}///< full range for this position
  friend ostream& operator<<<>(ostream&, const position<Tmicromatrix>&); ///< cout<< operator
  static int const outlace=INT_MIN+2;                 ///< all the sites not touched by the knitting are given initial value s2g=outlace
  //TESTS
  bool s2gTEST() const;                               ///< test of GF<->System correspondance return true if test succeeds
 protected:
  int taille;                        ///< GF size
  Array<int,1> s2g_array;            ///< system index -> Green Function index.
  Array<int,1> g2s_array;            ///< Green Function index -> system index.
  const sys_inf* p_sys;              ///< pointer to the system (with leads) for which the lace is constructed 
};

// **************** MOVE TYPE ************************//
/// enumerator that simplify calls of avancer (or similar) functions
enum moveType{le_debut,la_fin,ToZero,ToEnd,FromZero,FromEnd};
// avancer(debut_fin); debut_fin==
// la_fin, then lace advanced at the end by one site
// le_debut, then lace advanced at the beginning
// ToEnd, advance to the End of the lace
// ToZero, advance to the Beggining of the lace

//reculer(debut_fin); debut_fin==
// la_fin, then lace is reduced at the end by one site
// le_debut, then lace is reduced at the beginning
// FromZero, completely reduce from zero-site (debut) of the lace
// FromEnd, completely reduce from the end (fin) of the lace


// **************POSITION_KNIT********************** //
//next three declarations are needed just because we want to define friend template operator<< for the template class
template<class Tmicromatrix> class position_knit;
template<class Tmicromatrix> ostream& operator<<(ostream&, const position_knit<Tmicromatrix>&);
template<class Tmicromatrix> bool position_bfTEST(const systeme_infini<Tmicromatrix>&); 
/// position_knit is a dynamical part of the bookkeeping class postion. It contains all the methods needed to resize (advance or stepback) the lace. For example pos_knit.avancer(la_fin) should change corresponded postion superclass adding to the end of the lace one site
/// nv_s (number of the voisins with system indexing ). Vector of the system size that keeps number of the neighbours that connect a given site to the sites out of the "knitting". If nv_s(ind)>0 means that -ind- is belongs to the interface, if nv_s(ind)=0, means that this site is out of knit procedure (its GF elements should not be recalculated anymore).
// AAA nv_s could be replaced in future by smaller size nv_g
/// constructor of position from a single site with system index -indice-. If -indice- is belong to the lead, then all the sites of this lead are added. In other cases, it creates position with debut=fin=indice, taille=1.

template<class Tmicromatrix>
class position_knit: public position<Tmicromatrix>{
 public:
  typedef position<Tmicromatrix> Base;
  typedef systeme_infini<Tmicromatrix> sys_inf;
  position_knit(){Base::taille=0;};                     ///< default constructor
  position_knit(const position_knit&);                  ///< copy constructor
  position_knit& operator=(const position_knit&);       ///< assignment operator
  /// constructor of position_knit from a single site with system index -indice-, one could optionally set where to add leads
  position_knit(int indice,const sys_inf& sys,const Array<int,1>& wwhereAddLead);
  bool operator==(const position_knit& ) const;         ///< bool compare operator
  void avancer(const moveType& debut_fin);              ///< advance by one site using the end or the beginning of the lace
  void reculer(const moveType& debut_fin);              ///< stepback by one site using the end or the beginning of the lace
  int fdebut() const {return debut;};                   ///< function call of debut
  int ffin() const {return fin;};                       ///< function call of fin
  int get_init_pos() const {return init_pos;};          ///< function call of initial position
  int nv_s(int s_ind) const {return nv_s_array(s_ind);};///< function call of nv_s array element copy
  int nv_g(int GFind) const {return nv_s_array(Base::g2s_array(GFind));};///< Number of the Voisins,  GF indexing is used
  int& nv_s(int s_ind) {return nv_s_array(s_ind);};     ///< function call of nv_s array element reference
  const set<int>& changed_GF_ind() const{return changed_GF_ind_set;};///< function call of changed_GF_ind set
  int fwhereAddLead(int lead) const {return whereAddLead(lead);};///< function call of whereAddLead
  const Array<int,1> fwhereAddLead() const {return whereAddLead;};///< function call of whereAddLead
  int flead_offset(int lead) const {return lead_offset(lead);};  ///< function call of lead_offset
  int flead2order(int lead) const {return lead2order(lead);};    ///< function call of lead2order
  Range lead_range(int l) const {return Range(lead_offset(l),lead_offset(l)+Base::p_sys->lead_size(l)-1);}; // range for lead -l-
  int inner_interface_size() const;                     ///< size of inner interface, ie leads do not taken into account
  friend ostream& operator<<<>(ostream&, const position_knit&);  ///< cout<< operator
  friend bool position_bfTEST<>(const sys_inf&);        ///< global back-forth position_knit test
 private:
  int debut;                    ///< index of the lace-beginnig 
  int fin;                      ///< index of the lace-end
  int init_pos;                 ///< initial position for knitting
  Array<int,1> nv_s_array;      ///< nv_s (Number of the Voisins,  System indexing is used).
  set<int> changed_GF_ind_set;  ///< set of GFindexes that were changed during last avancer or reculer
  Array<int,1> whereAddLead;    ///< list of sys_ind where leads are added, whereAddLead(3)=23, lead 3 is added at site=23
  Array<int,1> lead_offset;     ///< lead_offset(l) = first index in GF for lead -l-
  Array<int,1> lead2order;      ///< lead2order(l) = o means that lead -l- was added at o-th order
  map<int,int> order2lead;      ///< order2lead[o] = l means at order -o- lead -l- was added
  void addsite(int index);      ///< advance by one site using site index
  void delsite(int index);      ///< stepback by one site using site index
  static int N2P(int p) {return -p-1;};///< negative to positive bijection i.e. 0 <-> -1; 1 <-> -2; 2 <-> -3; n=-p-1 \equiv p=-n-1
};


/// global function that calculates maximum Green Function size
// Attention this size should be multiplied by Tmicromatrix.dim in order to obtain Array of complex
// position_knit is used to get the GF_size!!!
template<class Tmicromatrix> int max_GF_size(const systeme_infini<Tmicromatrix>& S, int pos_init=0);

/// new_old map is a list of pairs correspondance between old and new indexes. In fact if we add just a single site to the lace, then most of indexes stay unchanges, and only those that have been deleted from the lace may change theirs index. We keep this information in the corresponding map<int,int> in order to perform faster new->old Tensor index conversion.
// construct map of pairs of indexes <new,old>: This map keeps information about indexes difference in pos_new and pos_old 
// we use the set of pos_new.changed_GF_ind. 
// this map do not contains any sites present in pos_new and have no old_ind correspondance
template<class Tmicromatrix>
void get_new_old_map(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, map<int,int>& M_no);

// Global function that reindex tensor M(i,ALL,j,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be derectly derived from pos_old by single move (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& M);

// Global function that reindex just first index of tensor M(i,ALL,lj,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be derectly derived from pos_old by single move (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex_first(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& M);


// Global function that reindex just third index of tensor M(li,ALL,j,ALL) using new position (pos_new) , from previous one (pos_old)
// pos_new should be derectly derived from pos_old by single move (avancer or reculer)
// only indexes presented in both positions are modified
template<class Tmicromatrix>
void reindex_second(const position_knit<Tmicromatrix>& pos_new,const position_knit<Tmicromatrix>& pos_old, GF_type& M);


// include all template and inline functions
#include "knit_geometry.cxx"

#endif  //knit_GEOMETRY_


/*** TO DO *****
1) test sur les elements egaux dans s2g
2) test sur les elements not touches par le knitting nv_s et s2g
*/
