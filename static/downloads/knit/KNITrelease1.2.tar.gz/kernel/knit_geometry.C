// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


#include "knit_general.h"
#include "knit_geometry.h"
#include "knit_micromatrices.h"


/** This mode permit to test system implementation
c++ -c -O2  knit_micromatrices.C
c++ -c -O2  knit_acos.C
g++ -c -O2 -I /usr/local/stow/Blitz_g++/include/  knit_system.C	
g++ -c -O2 -D_TESTING_ -D_DEBUG_LONG_ -I /usr/local/stow/Blitz_g++/include/  knit_geometry.C	
g++ -o test.out -O2 -L /usr/local/stow/Blitz_g++/lib/ -I /usr/local/stow/Blitz_g++/include/ -llapack -lblitz knit_system.o knit_micromatrices.o knit_acos.o knit_geometry.o
**/

#ifdef _TESTING_

int rank=0;
int size=1;

int main(){
  cout<<"******BEGIN of GEOMETRY testing; back and forth test ******\n";
  cout<<"Define _NOSUPPLEM_ variable to suppress suppelemtary testitng\n";
  // forward - backward test for postion_knit variable for given infinite system:
  // we create position_knit variable then make back and forth knit, then we knit forward to get the whole system and then once again back and forth from both ends, and finally we knit backward to initial position. At each step we compare that back and forth operation does not change position_knit 
  // all this is made for three different starting points: debut(O), fin(size-1),midddle(size/2)

  // testing system is the following
  // construction of the systemerectangle with two leads
  // main system is created using costructor from size 3x4, initial position (0,0), hopping 2 and on-site energy 1
  // first lead is composed of sites 4, 5, 12; lead 0
  // first lead is composed of sites 9, 10; lead 1
  /*
    9 10 11
    6 7  8
    3 4  5  12
    0 1  2
  */
  cout<<"********* Creating system with 2 leads  ********\n";
  cout<<9<<"  "<<10<<"  "<<11<<endl
      <<6<<"  "<<7<<"   "<<8 <<endl
      <<3<<"  "<<4<<"   "<<5 <<"  "<<12<<endl
      <<0<<"  "<<1<<"   "<<2 <<endl;

  clock_t t_in=clock();
  Array<int,1> LxLyLz(2),OxOyOz(2);
  scalarM V,Hdiag;
  V(0,0)=2.;
  Hdiag(0,0)=1.;
  // main system
  LxLyLz=3,4;
  OxOyOz=0,0;
  systemerectangle<scalarM> sys(LxLyLz,OxOyOz,V,Hdiag);
  // first lead
  LxLyLz=3,1;
  OxOyOz=1,1;
  s_systemrectangle lead_interface(LxLyLz,OxOyOz,2*V,2*Hdiag); // lead's interface
  A_reservoir lead(lead_interface); // create lead from its interface
  //  cout<<"LEAD PRINTING"<<endl<<lead<<endl;
  systeme_infini<scalarM> sys_lead(sys,lead); // created systeme + lead
  // second lead
  LxLyLz=2,1;
  OxOyOz=0,3;
  s_systemrectangle lead_interface2(LxLyLz,OxOyOz,3*V,3*Hdiag); // lead's interface
  A_reservoir lead2(lead_interface2); // create lead from its interface
  sys_lead.addlead(lead2);
  // cout<<"SYSTEM+LEAD1+LEAD2 PRINTING"<<endl<<sys_lead<<endl;

  // fully automatic back and forth Test for position variable
  position_bfTEST(sys_lead);

#ifndef _NOSUPPLEM_
  // some supplementary manual tests  just  to show how to use position variables
  cout<<"Suplementary testing\n";
  int init_site=3;
  const COMPLEX working_energy=2.5;
  position_knit<scalarM> pos(init_site,sys_lead);
  position_knit<scalarM> start_pos(pos);
  pos.avancer(la_fin);  pos.reculer(la_fin); // forth and back test
  pos.avancer(ToZero);  // change position
  pos.reculer(le_debut);  pos.avancer(le_debut); // back and forth test
  pos.avancer(ToEnd);  // change position
  //cout<<"********POSITION_KNIT PRINTING******"<<endl<<pos<<endl; //print position
  pos.reculer(FromEnd);  // change position
  pos.reculer(FromZero); pos.reculer(FromEnd);  // come back to the initial position
  if ( start_pos == pos )  cout<<"supplemetary back&forth TEST for position_knit is passed with sucess\n";
  else  cout<<"suppelementary Back&forth TEST for position_knit failed !!!\n";

  //cout<<"*********CREATE posR complemetary to posL***********"<<endl;
  init_site=0;
  position_knit<scalarM> posL(init_site,sys_lead);
  posL.avancer(ToEnd); 
  posL.reculer(la_fin);
  init_site=12;
  position_knit<scalarM> posR(init_site,sys_lead,posL.fwhereAddLead());

  for (int i=0;i<-1;++i){ 
    cout<<"xxxxxxxxxxxxxxxxxxxxxxxxxxx\n";
    posL.reculer(la_fin); posR.avancer(le_debut);
    cout<<"LEFT position\n"<<posL<<endl;
    cout<<"RIGHT position\n"<<posR<<endl;
  };
  
#endif //_NOSUPPLEM_



  // max GF function test
  cout<<"max_GF_size="<<max_GF_size(sys_lead)<<endl;
  cout<<"sytem size = "<<sys_lead.fsize()<<endl;
  clock_t t_out=clock();  
  cout<<"execution time = "<<float(t_out-t_in)/CLOCKS_PER_SEC<<endl;
  return 0;
};

#endif // _TESTING_
