#ifndef knit_ACOS_
#define knit_ACOS_

#include <complex>
#include <cmath>

// In this module we define inverse cosine for complex arguments, it's taken so that upper half plain of its argument is projected on the upper strip Real=(0,pi), Im=(0,infty) 

using namespace std;

// inverse of hyperbolic sine, sometimes noted as : arcsh, arcsinh, asinh
inline double arcsh(double x){return log(x+sqrt(x*x+1));};

// inverse of hyperbolic cosine, sometimes noted as : arcch, arccosh, acosh
inline double arcch(double x){
#ifdef _DEBUG_
  if (x<1.) {cout<<"ERROR in function arcch argument < 1\n";exit(1);}
#endif
  return log(x+sqrt(x*x-1));
};

// inverse of trigonometric cosine for complex argument
template<class Tnum> 
inline complex<Tnum> acos(complex<Tnum> z){
  if (z.imag() == 0.) 
    return (abs(z.real())>1.)? complex<Tnum>(0.,arcch(z.real())) : complex<Tnum>(acos(z.real()),0.) ;
  const Tnum z2=z.real()*z.real()+z.imag()*z.imag();
  const Tnum ch_imag=sqrt((z2+1.+sqrt((z2-1)*(z2-1)+4.*z.imag()*z.imag()))/2.);
#ifdef _DEBUG_
  if (z.real()>ch_imag) {cout<<"ERROR in function arcch argument < 1\n"; // in the case of precision lost
    return complex<Tnum>(0.,arcch(ch_imag));
  };
#endif
  return complex<Tnum>(acos(z.real()/ch_imag),arcch(ch_imag));
};

 
#endif
     
