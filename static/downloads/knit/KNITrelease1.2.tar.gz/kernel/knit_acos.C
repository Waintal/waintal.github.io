#if defined(_DEBUG_)||defined(_TESTING_)
#include <iostream>
#include "knit_random.h"
goodrandom Random;
#endif

#include <complex>
#include "knit_acos.h"
// In this module we define inverse cosine for complex arguments, it's taken so that upper half plain of its argument is projected on the upper strip Real=(0,pi), Im=(0,infty) 

// g++ -D_TESTING_ acos.C

// this is the testing part
// general idea is to calculate inverse of inverse and check if it gives intitial value
// for complex arcos it uses random generator in the upper complex plain
#ifdef _TESTING_
int main(){
  typedef complex<double> COMPLEX;
  // for this value acos is not difined due to the lost of precision
  //  cout<<"acosCOMPLE="<<acos(COMPLEX (1.226226552146785664,0.0000000001) )<<endl;//TTT
  cout.precision(1);
  cout<<"arcsh testing for (-10,10) interval\n";
  for (int i=-10;i<10;++i) cout<<i-sinh(arcsh(i))<<'\t'<<i-arcsh(sinh(i))<<endl;
  cout<<"arcch testing for (0,10) interval\n";
  for (int i=0;i<10;++i) cout<<i+1-cosh(arcch(i+1))<<'\t'<<i-arcch(cosh(i))<<endl;
  cout<<"acos testing for upper half plain using random generator\n";
  COMPLEX error=0;
  int Npoints=1000;
  int up_range=100;
  for (int i=0;i<Npoints;++i) {
    COMPLEX xy(2*Random()-1,Random());
    xy*=up_range;
    COMPLEX delta=xy-cos(acos(xy));
    error+=COMPLEX(abs(delta.real()),abs(delta.imag()));
  };
  cout<<"error for "<<Npoints<<" calculation points="<<error<<endl;
  return 0;
};

#endif

