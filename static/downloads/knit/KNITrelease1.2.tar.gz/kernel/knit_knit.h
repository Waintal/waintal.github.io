// #############################################################
//  KNIT SOFTWARE DISTRIBUTED UNDER THE General Public License #
//  DEVELOPPED BY K. KAZYMYRENKO AND X. WAINTAL                #
//  SEE Phys. Rev. B 77, 115119 (2008) FOR MORE INFORMATION    #
// #############################################################


/** \file knit_knit.h
Module containing class knit, which recalculates interface green functions during knitting;
knit forward and knit backward are implemented 

General information:
lace should start on the sites that belong to one of the leads. The knitting would work even if one starts somewhere else, but in this case the corresponded GF would be divergent for finit system
**/
#ifndef  knit_KNIT_
#define  knit_KNIT_
#include "blitz_addon.h"
#include "knit_general.h"
#include "knit_system.h"
#include "knit_geometry.h"

#include <blitz/array.h>

using namespace blitz;

// **************** MOVE TYPE ************************//
// movetype is defined inside knit_geometry
/// enumerator that simplify calls of forward (backward) functions
// enum moveType{le_debut,la_fin,ToZero,ToEnd,FromZero,FromEnd};
// forward(debut_fin); debut_fin==
// la_fin, then lace advanced at the end by one site
// le_debut, then lace advanced at the beginning
// ToEnd, advance to the End of the lace
// ToZero, advance to the Beggining of the lace

// backward(debut_fin); debut_fin==
// la_fin, then lace is reduced at the end by one site
// le_debut, then lace is reduced at the beginning
// FromZero, completely reduce from zero-site (debut) of the lace
// FromEnd, completely reduce from the end (fin) of the lace


// **************KNIT auxiliary classes********************** //
//next two declarations are needed just because we want to define friend template global function for the template class
template<class Tmicromatrix> class knit;
template<class Tmicromatrix> class sew;
template<class Tmicromatrix> ostream& operator<<(ostream&, const knit<Tmicromatrix>&);
template<class Tmicromatrix> bool knit_bfTEST(const systeme_infini<Tmicromatrix>&, COMPLEX En=COMPLEX(0.)); 

///temporal class which store saved part of GF
template<class Tmicromatrix> class temp4knit{
  friend class knit<Tmicromatrix>;
 private:
  typedef systeme_infini<Tmicromatrix> sys_inf;///< infinite system
  temp4knit(){};                               ///< default constructor
  temp4knit(const temp4knit&);                 ///< copy constructor
  temp4knit& operator=(const temp4knit&);      ///< assignment operator
  temp4knit(const sys_inf&,int init_site);     ///< constructor from system and initial site
  // VARIABLES
  int max_taille;                            ///< maximum Green Function size
  Array<COMPLEX,2> G_NN;                     ///< diagonal matrix element for the added site
  Array<COMPLEX,2> VgV;                      ///< equivalent of G_NN for backward knitting
  // CAREFULL what we call for simplicity G_Na and G_aN correspond to their normalised value G_Na = G_Na/G_NN; G_aN = G_aN/G_NN
  GF_type G_Na;                              ///< matrix element between added interface sites(a) and added site(N)
  GF_type G_aN;                              ///< matrix element between added site(N) and interface sites(a)
};

/// class which store saved part of GF, needed for knitback operations
template<class Tmicromatrix> class saved4knit{
  friend class knit<Tmicromatrix>;
  friend class sew<Tmicromatrix>;
 private:
  saved4knit(){};                          ///< hidden default constructor
  saved4knit(const saved4knit&);           ///< copy constructor
  saved4knit& operator=(const saved4knit&);///< assignment operator (makes a real copy)
  /// constructor, given the lead number
  saved4knit(int Nlead,int sys_size):GF(Nlead), SE(Nlead), GFLL(Nlead,Nlead), g_rr(sys_size),G_NN(sys_size), saving_level(-1){};
  // saved parts of GF, in all maps we use first element to indicate sys_index of related site (new or recovered)
  int saving_level; 
  /// level of saving 
  // -1 (exacte version, save G_aN,G_Na,G_NN,G_rN,G_Nr,G_rr at each step) (default value)
  //  0 (no saving, usefull only for transmission calculations or very small systems)
  //  n (save full GF each -n- sites)
  map<int,const Array<COMPLEX,2> > mapG_NN; ///< pair of <N_sys_index,G_NN>
  map<int,const GF_type> mapG_aN;      ///< pair of <N_sys_index,G_aN>, "small" GF index are used for -a- 
  map<int,const GF_type> mapG_Na;      ///< pair of <N_sys_index,G_Na>, "small" GF index are used for -a- 
  map<int,const GF_type> map_g_ra;     ///< pair of <r_sys_index,G_ra>, "small" GF index are used for -a- 
  map<int,const GF_type> map_g_ar;     ///< pair of <r_sys_index,G_ar>, "small" GF index are used for -a- 
  Array<GF_type,1> GF;                 ///< GF(li) = is a GF of the system just before the lead -li- was added
  Array<GF_type,1> SE;                 ///< self energies for each lead: SE(li) - self energy of the lead -li-
  Array<GF_type,2> GFLL;               ///< lead-lead elements of full GF: GFLL(7,2) - GF between lead 7 and 2
  // CORRECTIONS for precision improvement
  Array<GF_type,1> g_rr;               ///<TTTT saved g_rr(sys_ind)
  map<int,const GF_type> mapGF;        ///< pair of <sys_ind,GF> GF of the system just before index -sys_ind- was added
  Array<Array<COMPLEX,2>,1> G_NN;      ///< G_NN(sys_ind) = G_NN element for index -sys_ind-
};

// ************** KNIT ********************** //
/// MAIN class that contains all manupulations during knitting
template<class Tmicromatrix>
class knit{
 public:
  typedef systeme_infini<Tmicromatrix> sys_inf;   ///< infinite system
  knit(){};                                       ///< default constructor
  knit(const knit&);                              ///< copy constructor
  knit& operator=(const knit&);                   ///< assignment operator
  knit(int indice,const sys_inf& sys, COMPLEX E); ///< constructor of knit from a single site with system index -indice-.
  bool operator==(const knit&) const;             ///< bool compare operator
  void forward(int i);                            ///< simple wrapping of forward(const moveType& debut_fin);
  void forward(const moveType& debut_fin);        ///< advance by one site using the end or the beginning of the lace
  void backward(const moveType& debut_fin);       ///< stepback by one site using the end or the beginning of the lace
  Array<COMPLEX,2> G(int sys_i,int sys_j) const;  ///< GF element for system_index arguments
  const GF_type G_LL(int li,int lj) const {return SAV.GFLL(li,lj);};///< contiguously ordered full GF between lead -i- lead -j-
  const GF_type SE(int li) const {return SAV.SE(li);}; ///< contiguously ordered SE for lead -li-
  const GF_type G() const {return GF(pos.range(),ALL,pos.range(),ALL);};///< gives const reference to full GF 
  COMPLEX Energy() const {return E;};             ///< get Energy value
  const sys_inf* p_system() const {return p_sys;};///< get pointer to system_infini
  const position_knit<Tmicromatrix>& fpos() const {return pos;};///< get position
  void set_saving_level(int level);               ///< set level of saving
  int get_saving_level() const {return SAV.saving_level;};///< get level of saving
  Tmicromatrix getG_LL(int i1,int lead1,int i2,int lead2) const {return arr2micro<Tmicromatrix>(SAV.GFLL(lead1,lead2)(i1,ALL,i2,ALL));}
  Tmicromatrix getSE(int i,int j,int li) const {return arr2micro<Tmicromatrix>(SAV.SE(li)(i,ALL,j,ALL));}

 private:
  // order of private variables is very important TMP should be the first one
  temp4knit<Tmicromatrix> TMP;                    ///< temp class
  COMPLEX E;                                      ///< Energy
  const sys_inf* p_sys;                           ///< pointer to the system (with lead) for which knitting is performed 
  position_knit<Tmicromatrix> pos;                ///< bookkeeping position variable
  position_knit<Tmicromatrix> pos_new;            ///< bookkeeping position variable for new position
  GF_type GF;                                     ///< GF array
  saved4knit<Tmicromatrix> SAV;                   ///< saved class
  static const int New=0;                         ///< mark new index
  static int MicroDim;                            ///< Tmicromatrix::dim()
  void collersite(int added_site);                ///< advance by one site using site -added_site- (system indexing)
  void enleversite(int del_site);                 ///< knitback -del_site- site (system indexing)
  void collerlead(int added_lead);                ///< merge current GF with lead -added_lead-
  void enleverlead(int del_lead);                 ///< detouch lead -del_lead- from current GF
  //TEMPORAL variable update functions, N - new(added) site, a(\alpha) - interface sites
  //  forward update
  void forwardG_NN(int added_site,const map<int,int>& interface);
  void forwardG_Na(int added_site,const map<int,int>& interface);
  void forwardG_aN(int added_site,const map<int,int>& interrace);   
  void forward_save(int added_site); 
  //  backward update: we passe from -G- to -g- suppresing a -New- site
  //  g (smallGF) has corresponded position variable pos_new and G (bigGF=smallGF + Newsite) has -pos- indexing
  // -s- index is used to designate nearest neighbors of -New- site
  // -r- indexes the recovered site
  // rec_pair is pair <z,rec_site>, where z - is hopping index from "new" site to recovered site, rec_site = smallGFindex
  void backward_save(int del_site);
  void backward_g_rr(int del_site, const pair<int,int>& rec_pair, const map<int,int>& interface);
  void backward_g_ra(int del_site, const pair<int,int>& rec_pair, const map<int,int>& interface);
  void backward_g_ar(int del_site, const pair<int,int>& rec_pair, const map<int,int>& interface); 
  void backward_all(int del_site); 
  void update_Gnew_map(int added_site);           ///< save G_aN, G_Na, G_NN in forward knitting 
  void update_gRec_map(int added_site);           ///< save g_ar, g_ra forward knitting 
  // FRIENDS
  friend class sew<Tmicromatrix>;                 ///< class which merge site by site during backward knitting
  friend class saved4knit<Tmicromatrix>;          ///< class which store saved part of GF, needed for knitback
  friend class temp4knit<Tmicromatrix>;           ///< temporal class which store saved part of GF, that are not needed for knitback
  friend bool knit_bfTEST<>(const sys_inf&,const COMPLEX En);///< global back-forth position_knit test for the energy En
};

// definition of knit static variable
template<class Tmicromatrix>  int knit<Tmicromatrix>::MicroDim = Tmicromatrix::dim();


// ************** DIRECT ********************** //
/// class that calculate full GF by direct inversion
/// part of the system is concidered between ii and fi indexes
template<class Tmicromatrix>
class direct{
  direct(const direct&);                               ///< hidden copy constructor
  direct& operator=(const direct&);                    ///< hidden assignment operator
 public:
  typedef systeme_infini<Tmicromatrix> sys_inf;        ///< infinite system
  direct(){};                                          ///< default constructor
  direct(const sys_inf& S,int iii=0,int ffi=-1);       ///< constructor from part of the system (ii,fi)
  Array<COMPLEX,2> G(int i, int j) const {return GF(i,ALL,j,ALL).copy();};///< GF element for system indexes i,j
  const GF_type& G() const {return GF;};               ///< full GF for energy E (system indexes are used)
  void calculate4E(COMPLEX EE);                        ///< recalculate GF for this energy
  COMPLEX getE() const {return E;};                    ///< show energy
  const sys_inf* p_system() const {return p_sys;}      ///< pointer to the system (with leads)
 private:
  const sys_inf* p_sys;                                ///< pointer to the system (with leads) 
  const int ii;                                        ///< initial index
  const int fi;                                        ///< final index
  COMPLEX E;                                           ///< energy for which GF is calculated
  GF_type GF;                                          ///< calculated GF for energy E
  GF_type HnoLead;                                     ///< hamiltonian of the system without lead
};


// ************** SEW ********************** //
/// class that sew together two parts of knitted system
template<class Tmicromatrix>
class sew{
  sew(const sew&);                               ///< hidden copy constructor
  sew& operator=(const sew&);                    ///< hidden assignment operator
 public:
  typedef systeme_infini<Tmicromatrix> sys_inf;  ///< infinite system
  typedef subArray<COMPLEX,4> subGF_type;        ///< subArrays of GF, used for hight perfomance BLAS multiplication
  //sew(){};                                       ///< default constructor
  sew(knit<Tmicromatrix>& K);                    ///< constructor from system for given energy, attention -K- is modified during sewing
  void backward();                               ///< sew back by one site
  void sew2end();                                ///< sew completely backward
  // get full GF between -lead1- and -lead2- with lead indexes -i1- and -i2-
  Tmicromatrix getG_LL(int i1,int lead1,int i2,int lead2) const;
  // get self energy SE for lead -li- with lead indexes -i- and -j-
  Tmicromatrix getSE(int i,int j,int li) const;
  //  all nearest neighbors elements are given , onsite is given for z=zmax 
  const GF_type getGnotK() const {return GnotK;}; ///< output of GF (not Keldysh)
  const GF_type getGless(int l) const {return Gless(l);}; ///< output of GF lesser corresponding to lead -l-
  ///< output of GF lesser element corresponding to lead -l-
  Tmicromatrix getG_lesser(int ind,int z,int lead) const {return arr2micro<Tmicromatrix>(Gless(lead)(ind,ALL,z,ALL));};
  ///< output of GF element
  Tmicromatrix getG_retarded(int ind,int z) const {return arr2micro<Tmicromatrix>(GnotK(ind,ALL,z,ALL));};
 private:
  const sys_inf* p_sys;                          ///< pointer to the system (with lead) for which knitting is performed 
  //  COMPLEX E;                                     ///< Energy
  int Os;                                        ///< site for which all GF_lesser are calculeted at given step
  int Or;                                        ///< left GF index of Os (if it not present in left interface we give it recovered value)
  knit<Tmicromatrix>& kn;                        ///< knit
  const position_knit<Tmicromatrix>&  posL;      ///< left position that corresponds to GF with Os site
  position_knit<Tmicromatrix>  posL_new;         ///< left position that corresponds to GF without Os site
  position_knit<Tmicromatrix>  posR;             ///< right position which is complementary for left with Os site
  position_knit<Tmicromatrix>  posR_new;         ///< right position which is complementary for left without Os site
  const Array<GF_type,2>& GFLL;                  ///< lead-lead elements of GF (not Keldysh): GFLL(7,2) - GF between lead 7 and 2
  const Array<GF_type,1>& SE;                    ///< self energies for each lead: SE(li) - self energy of the lead -li-
  GF_type& gf;                                   ///< partial GF of the left subsystem
  GF_type SI;                                    ///< self energy of the interface: SI(i,ALL,j,ALL) - "self energy" for the left interface
  GF_type GF;                                    ///< full GF of full right position
  Array<GF_type,1>  GFIL;                        ///< full GF interface-lead for each lead: GFIL(li) - full GF between right intreface and lead -li-
  Array<GF_type,1>  GFLI;                        ///< full GF lead-interface for each lead: GFLI(li) - full GF between lead -li- and right interface
  Array<GF_type,1>  GFOL;                        ///< full GF Os-lead for each lead: GFOL(li) - full GF between current site Os  and lead -li-
  Array<GF_type,1>  GFLO;                        ///< full GF lead-Os for each lead: GFLO(li) - full GF between lead -li- and current site Os
  GF_type GFOO;                                  ///< full GF Os-Os: diagonal (onsite) GF element for current site Os
  GF_type          GnotK;                        ///< full system GF (not Keldysh): GnotK(si,ALL,z,ALL) -  (si,z) full GF element, (i,zmax)=on_site 
  Array<GF_type,1> Gless;                        ///< lesser GF for each lead: Gless(li)(si,ALL,z,ALL) - lead -li- part of (si,z) lesser GF element, (si,zmax)=on_site 
  void updateOr();                               ///< copy recovered parts of gf if needed and get new value for Or
  void updateGless();                            ///< calculate Gless for Os site
  void updateGnotK(const GF_type& GFO,const GF_type& OGF);///< calculate full GF (not Keldysh) for Os site
  void getOright(GF_type& GFO,GF_type& OGF) const;        ///< calculate full GF between Os and right position
  void getOlead(const GF_type& GFO,const GF_type& OGF);   ///< calculate full GF between Os and all lead position (GFLO,GFOL,GFOO)
  void updateGF(const GF_type& GFO,const GF_type& OGF);   ///< update indexes of full GF right position
  void updateSI();                                        ///< update indexes of "self energy" of right position
  void updateGFLI();                                      ///< update GFLI GFIL using new positions 
  void lead_updateGF(int l);                              ///< update indexes of full GF right position when sewing lead -l-
  void lead_updateSI(int l);                              ///< update indexes of "self energy" of right position when sewing lead -l-
  void lead_updateGFLI(int l);                            ///< update GFLI GFIL using new positions when sewing lead -l-
  static int MicroDim;                                    ///< Tmicromatrix::dim()
  // varios tests
  GF_type dGF;                                            ///< GF calculated by direct inversion
  bool SI_Test() const;                                   ///< test current SI with fully recalculated value (using GF)
  bool GF_Test() const;                                   ///< test current GF with fully recalculated value (using dGF)
  bool GnotK_Test() const;                                ///< test final GFnotK with fully recalculated value (using dGF)
};


// definition of sew static variable
template<class Tmicromatrix>  int sew<Tmicromatrix>::MicroDim = Tmicromatrix::dim();


// include all template and inline functions
#include "knit_knit.cxx"

#endif  //knit_KNIT_
