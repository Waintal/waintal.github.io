from Numeric import *
from LinearAlgebra import * 
