# MODULE THAT CONTAINS FACILITIES TO
# CALL THE KINTTING KERNEL AND COMPUTE
# OBSERVABLES

#from Numeric import array,zeros,Float
from numpy import *
import knit

def conductance_matrix(systeme,Energy):
    tricoter=knit.tricot(0,systeme,Energy)
    tricoter.set_saving_level(0)
    tricoter.forward(2)
    tricoter.forward(3)
    s=systeme.fNres()  
    result=zeros((s,s),float)
    for i in range(s):
        for j in range(s):
            tmp=knit.TransProba(tricoter,i,j)
            result[i,j]=tmp.real
    for i in range(s):
        tmp=0
        for j in range(s):
            if(j != i): tmp=tmp-result[i,j]
        result[i,i]=tmp
    return result

def conductance_matrix_S(systeme,Energy):
    tricoter=knit.tricot_S(0,systeme,Energy)
    tricoter.set_saving_level(0)
    tricoter.forward(2)
    tricoter.forward(3)
    s=systeme.fNres()  
    result=zeros((s,s),float)
    for i in range(s):
        for j in range(s):
            tmp=knit.TransProba_S(tricoter,i,j)
            result[i,j]=tmp.real
    for i in range(s):
        tmp=0
        for j in range(s):
            if(j != i): tmp=tmp-result[i,j]
        result[i,i]=tmp
    return result

def knitonly(systeme,Energy,savinglevel=-1):
    tricoter=knit.tricot(0,systeme,Energy)
    tricoter.set_saving_level(savinglevel)
    tricoter.forward(2)
    tricoter.forward(3)
    return tricoter

def knitonly_S(systeme,Energy,savinglevel=-1):
    tricoter=knit.tricot_S(0,systeme,Energy)
    tricoter.set_saving_level(savinglevel)
    tricoter.forward(2)
    tricoter.forward(3)
    return tricoter

def knitANDsew(systeme,Energy,savinglevel=-1):
    tricoter=knit.tricot(0,systeme,Energy)
    tricoter.set_saving_level(savinglevel)
    tricoter.forward(2)
    tricoter.forward(3)
    S=knit.couture(tricoter)
    S.sew2end()
    return S
#   tricoter is destroyed

def knitANDsew_S(systeme,Energy,savinglevel=-1):
    tricoter=knit.tricot_S(0,systeme,Energy)
    tricoter.set_saving_level(savinglevel)
    tricoter.forward(2)
    tricoter.forward(3)
    S=knit.couture_S(tricoter)
    S.sew2end()
    return S
#   tricoter is destroyed

def Green(contact1,contact2,eh1,eh2,result,mysys):
    size1=mysys.lead_size(contact1)
    size2=mysys.lead_size(contact2)
    G=zeros((size1,size2),complex)
    for i1 in range(size1):
        for i2 in range(size2):
            G[i1,i2]=result.getG_LL(i1,contact1,i2,contact2)(eh1,eh2)    
    return G

def SelfEnergy(contact,eh1,eh2,result,mysys):
    size=mysys.lead_size(contact)
    G=zeros((size,size),complex)
    for i1 in range(size):
        for i2 in range(size):
            G[i1,i2]=result.getSE(i1,i2,contact)(eh1,eh2)
    return G


