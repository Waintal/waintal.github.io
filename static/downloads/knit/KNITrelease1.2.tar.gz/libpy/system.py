from pyx import *
import knit

# takes a system and plot it; 
def visu2D(a,s,ray=0.2,nonumber=0):
    #unit.set(wscale=30)
    taille = a.fsize()
    dessin=canvas.canvas()
    allX=[]
    allY=[]
    systeme_avec_leads=isinstance(a,knit.systemtotal)
    if systeme_avec_leads==0: systeme_avec_leads=isinstance(a,knit.systemtotal_S)
    for i in xrange(taille):
         x=a.coord(i,0)
         y=a.coord(i,1)
       	 allX.append(x)
	 allY.append(y)
	 for j in xrange(a.fzmax()):
	     ibis=a.voisin(i,j)
	     if ibis>=0:
		 dessin.stroke(path.line(x,y,a.coord(ibis,0),a.coord(ibis,1)))
		 
	 dessin.fill(path.circle(x,y,ray),[color.rgb.blue])
	 if systeme_avec_leads and a.sys2res(i)>=0:
	     dessin.fill(path.circle(x,y,ray),[color.cmyk.Orange])
	 if nonumber==0: dessin.text(x+1.2*ray,y+1.5*ray,str(i),[text.halign.boxcenter] )
    if nonumber==0:
        for i in allX: dessin.text(i,-1,"\large"+str(i),[text.halign.boxleft])
        for i in allY: dessin.text(-1,i,"\large"+str(i),[text.halign.boxleft])
    dessin.writeEPSfile(s)
    dessin.writePDFfile(s)

#ATTENTION! THIS function plots only points in the positive quadrant (x>=0; y>=0); Negative quadrant is reserved for deleted elements.
def visu2D_(a,s,ray=0.2,nonumber=0):
    #unit.set(wscale=30)
    taille = a.fsize()
    dessin=canvas.canvas()
    allX=[]
    allY=[]
    systeme_avec_leads=isinstance(a,knit.systemtotal)
    if systeme_avec_leads==0: systeme_avec_leads=isinstance(a,knit.systemtotal_S)
    for i in xrange(taille):
         x=a.coord(i,0)
         y=a.coord(i,1)
         if x>=0 and y>=0:
         	 allX.append(x)
       		 allY.append(y)
		 for j in xrange(a.fzmax()):
		     ibis=a.voisin(i,j)
		     if ibis>=0:
			 dessin.stroke(path.line(x,y,a.coord(ibis,0),a.coord(ibis,1)))
			 
		 dessin.fill(path.circle(x,y,ray),[color.rgb.blue])
		 if systeme_avec_leads and a.sys2res(i)>=0:
		     dessin.fill(path.circle(x,y,ray),[color.cmyk.Orange])
		 if nonumber==0: dessin.text(x+1.2*ray,y+1.5*ray,str(i),[text.halign.boxcenter] )
    if nonumber==0:
        for i in allX: dessin.text(i,-1,"\large"+str(i),[text.halign.boxleft])
        for i in allY: dessin.text(-1,i,"\large"+str(i),[text.halign.boxleft])
    dessin.writeEPSfile(s)
    dessin.writePDFfile(s)


def visu3D(a,s,ray=0.2,nonumber=0):
    """ Basic plot of 3D systems. Primarily for development """
    taille = a.fsize()
    def xyz2xy(x,y,z): return x+0.17*y,1.6*ray*z+0.72*y
    dessin=canvas.canvas()
    grad=color.gradient.Rainbow
    systeme_avec_leads=isinstance(a,knit.systemtotal)
    zmin,zmax=0,0
    for i in xrange(taille):
         z=a.coord(i,2)
         if z<zmin: zmin=z
         if z>zmax: zmax=z
    deltaz= zmax-zmin
    if deltaz==0 : deltaz=1
    if systeme_avec_leads==0: systeme_avec_leads=isinstance(a,knit.systemtotal_S)
    for i in xrange(taille):
         x=a.coord(i,0)
         y=a.coord(i,1)
         z=a.coord(i,2)
         X,Y=xyz2xy(x,y,z)
         colorparameter=float(z-zmin)/deltaz
         for j in xrange(a.fzmax()):
             ibis=a.voisin(i,j)
             if ibis>=0:
                 Xp,Yp=xyz2xy( a.coord(ibis,0) , a.coord(ibis,1) , a.coord(ibis,2) )
                 if(a.coord(ibis,2)==z):
                     dessin.stroke(path.line(X,Y,Xp,Yp),[grad.getcolor(colorparameter)])
                 else:
                     dessin.stroke(path.line(X,Y,Xp,Yp))
         dessin.fill(path.circle(X,Y,ray),[grad.getcolor(colorparameter)])
         if systeme_avec_leads and a.sys2res(i)>=0:
             dessin.fill(path.circle(X,Y,ray*1.4),[color.cmyk.Black])
         if nonumber==0: dessin.text(X+1.2*ray,Y+1.5*ray,str(i),[text.halign.boxcenter] )
    dessin.writeEPSfile(s)
    dessin.writePDFfile(s)

#ATTENTION! THIS function plots only points in the positive quadrant (x>=0; y>=0); Negative quadrant is reserved for deleted elements.
def visu3D_(a,s,ray=0.2,nonumber=0):
    """ Basic plot of 3D systems. Primarily for development """
    taille = a.fsize()
    def xyz2xy(x,y,z): return x+0.17*y,1.6*ray*z+0.72*y
    dessin=canvas.canvas()
    grad=color.gradient.Rainbow
    systeme_avec_leads=isinstance(a,knit.systemtotal)
    zmin,zmax=0,0
    for i in xrange(taille):
         z=a.coord(i,2)
         if z<zmin: zmin=z
         if z>zmax: zmax=z
    deltaz= zmax-zmin
    if deltaz==0 : deltaz=1
    if systeme_avec_leads==0: systeme_avec_leads=isinstance(a,knit.systemtotal_S)
    for i in xrange(taille):
         x=a.coord(i,0)
         y=a.coord(i,1)
         z=a.coord(i,2)
         if x>=0 and y>=0 and z>=0:
		 X,Y=xyz2xy(x,y,z)
		 colorparameter=float(z-zmin)/deltaz
		 for j in xrange(a.fzmax()):
		     ibis=a.voisin(i,j)
		     if ibis>=0:
		         Xp,Yp=xyz2xy( a.coord(ibis,0) , a.coord(ibis,1) , a.coord(ibis,2) )
		         if(a.coord(ibis,2)==z):
		             dessin.stroke(path.line(X,Y,Xp,Yp),[grad.getcolor(colorparameter)])
		         else:
		             dessin.stroke(path.line(X,Y,Xp,Yp))
		 dessin.fill(path.circle(X,Y,ray),[grad.getcolor(colorparameter)])
		 if systeme_avec_leads and a.sys2res(i)>=0:
		     dessin.fill(path.circle(X,Y,ray*1.4),[color.cmyk.Black])
		 if nonumber==0: dessin.text(X+1.2*ray,Y+1.5*ray,str(i),[text.halign.boxcenter] )
    dessin.writeEPSfile(s)
    dessin.writePDFfile(s)


def visuLead2D(a,s,DX,DY,epsilon=1.e-3,ray=0.2):
    taille = a.fsize()
    dessin=canvas.canvas() 
    for i in xrange(taille):
         x=a.coord(i,0)
         y=a.coord(i,1)
         for j in xrange(a.fzmax()):
             ibis=a.voisin(i,j)
             if ibis>=0:
                 dessin.stroke(path.line(x,y,a.coord(ibis,0),a.coord(ibis,1)))
                 dessin.stroke(path.line(x+DX,y+DY,a.coord(ibis,0)+DX,a.coord(ibis,1)+DY))
                 
         dessin.fill(path.circle(x,y,ray),[color.rgb.blue])
         dessin.fill(path.circle(x+DX,y+DY,ray),[color.cmyk.Orange])
         dessin.text(x+1.2*ray,y+1.5*ray,str(i),[text.halign.boxcenter] )
         for j in xrange(taille):
             if abs(a.get_leadHopp(i,j)(0,0)) > epsilon :
                 dessin.stroke(path.line(x,y,a.coord(j,0)+DX,a.coord(j,1)+DY))
    dessin.writeEPSfile(s)
    dessin.writePDFfile(s)



def visualisation_simple(a):
    taille = a.fsize()
    dessin=canvas.canvas()
    for i in xrange(taille):
         dessin.fill(path.circle(a.coord(i,0),a.coord(i,1),0.3))
    dessin.writeEPSfile("image_simple")

# save data in (x,x+dx,y,y+dy,value)
# use
# ./data2plot.py fichier minvalue maxvalue
# for data plotting
def saveplot2D(systeme,fichier,myfonction,minV=-1,maxV=-1,tt=1):
    import pickle
    from pyx import graph,color
    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        data.append([x-tt+1,x+tt,y-tt+1,y+tt,tmp])
        if tmp>maxi :maxi=tmp
        if tmp<mini :mini=tmp
    ## save data for future use
    ff=open(fichier+".data",'w')
    pickle.dump(data,ff)
    ff.close()
    print "data in [x,x+dx,y,y+dy,value] form saved to ", fichier, ".data"


    
def colorplot2D(systeme,fichier,myfonction,minV=-1,maxV=-1,tt=1):
    from pyx import graph,color
    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        data.append([x-tt+1,x+tt,y-tt+1,y+tt,tmp])
        if tmp>maxi :maxi=tmp
        if tmp<mini :mini=tmp
    if minV==-1: minV=mini
    if maxV==-1: maxV=maxi
    aveV=sum(map(lambda x:x[4],data))/len(data)
    for i in data:
        i[4]=(i[4]-minV)/(maxV-minV)
        if i[4]>1: i[4]=1
        if i[4]<0: i[4]=0
    x_size=max(map(lambda x:x[0],data)) - min(map(lambda x:x[0],data))
    y_size=max(map(lambda x:x[2],data)) - min(map(lambda x:x[2],data))
    g = graph.graphxy(width=x_size,height=y_size,
                  x=graph.axis.linear(),
		  y=graph.axis.linear())
    g.plot(graph.data.list(data,xmin=1, xmax=2, ymin=3, ymax=4,color=5),
                  [graph.style.rect(color.gradient.ReverseRainbow)])
#   In new version of PyX color.gradient.ReverseRainbow has
#   replaced color.palette.ReverseRainbow
    g.writeEPSfile(fichier)
    g.writePDFfile(fichier)
    return "min=",minV,"max=",maxV,"average=",aveV

#ATTENTION! THIS function plots only points in the positive quadrant (x>=0; y>=0); Negative quadrant is reserved for deleted elements.
def colorplot2D_(systeme,fichier,myfonction,minV=-1,maxV=-1,tt=1):
    from pyx import graph,color
    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        if x>=0 and y>=0 :  
		data.append([x-tt+1,x+tt,y-tt+1,y+tt,tmp])
		if tmp>maxi :maxi=tmp
		if tmp<mini :mini=tmp
    if minV==-1: minV=mini
    if maxV==-1: maxV=maxi
    aveV=sum(map(lambda x:x[4],data))/len(data)
    for i in data:
        i[4]=(i[4]-minV)/(maxV-minV)
        if i[4]>1: i[4]=1
        if i[4]<0: i[4]=0
    x_size=max(map(lambda x:x[0],data)) - min(map(lambda x:x[0],data))
    y_size=max(map(lambda x:x[2],data)) - min(map(lambda x:x[2],data))
    g = graph.graphxy(width=x_size,height=y_size,
                  x=graph.axis.linear(),
		  y=graph.axis.linear())
    g.plot(graph.data.list(data,xmin=1, xmax=2, ymin=3, ymax=4,color=5),
                  [graph.style.rect(color.gradient.ReverseRainbow)])
#   In new version of PyX color.gradient.ReverseRainbow has
#   replaced color.palette.ReverseRainbow
    g.writeEPSfile(fichier)
    g.writePDFfile(fichier)
    return "min=",minV,"max=",maxV,"average=",aveV


def RGBplot2D(systeme,fichier,myfonction,minV=-1,maxV=-1):
    from pyx import bitmap,canvas,color
    from cStringIO import StringIO
    def flo_to_RGB(h):
        def Hue_2_RGB( vH ):
            while vH<0.0: vH += 1.0
            while vH>1.0: vH -= 1.0
            if 6*vH < 1.0 : return 6.0*vH
            if 2*vH < 1.0 : return 1.
            if 3*vH < 2.0 : return ((2.0/3.0)-vH)*6.0
            return 0.
        r = 255 * Hue_2_RGB( h + 1./3)
        g = 255 * Hue_2_RGB( h )
        b = 255 * Hue_2_RGB( h - 1./3)
        return (int(round(r)),int(round(g)),int(round(b)))
    def rgbcolortostring(c):
        return "".join([chr(int(255*c.color[name])) for name in "rgb"])
    def hsbcolortostring(c):
        rgb=flo_to_RGB(c.color['h'])
        return "".join([chr(name) for name in rgb])

    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        data.append([x,y,tmp])
        if tmp>maxi :maxi=tmp
        if tmp<mini :mini=tmp
    if minV==-1: minV=mini
    if maxV==-1: maxV=maxi
    aveV=sum(map(lambda x:x[2],data))/len(data)
    for i in data:
        i[2]=(i[2]-minV)/(maxV-minV)
        if i[2]>1: i[2]=1.
        if i[2]<0: i[2]=0.
    xmin=min(map(lambda x:x[0],data))
    xmax=max(map(lambda x:x[0],data))
    ymin=min(map(lambda x:x[1],data))
    ymax=max(map(lambda x:x[1],data))
    xiterations = xmax-xmin+1
    yiterations = ymax-ymin+1
    ## rearange data by index
    def xy2ind(x,y):
        return x-xmin+(ymax-y)*xiterations

    dataArr = array([-1. for x in range(xiterations*yiterations)],'f')
    for a in data:
        ind=xy2ind(a[0],a[1])
        dataArr[ind]=a[2]
    
    p = color.gradient.ReverseRainbow

    # string that is used to plot data
    dataBW = StringIO()
    # compute dataBW
    for a in dataArr:
        if a >= 0.:
            # append color(RGB) of the current pixel to the end of data
            dataBW.write(hsbcolortostring(p.getcolor(a)))
        else:
            dataBW.write("\377\377\377")

    # generate image from dataBW
    julia = bitmap.image(xiterations, yiterations, "RGB", dataBW.getvalue())
    juliabitmap = bitmap.bitmap(0, 0, julia, height=10)
    c = canvas.canvas()
    c.insert(juliabitmap)
    
    c.writeEPSfile(fichier)
    c.writePDFfile(fichier)
    return "min=",minV,"max=",maxV,"average=",aveV               
