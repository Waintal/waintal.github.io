#!/usr/bin/python

import sys
import os
import time


from libpy import *
from cmath import *
from Numeric import array
from LinearAlgebra import linear_least_squares


dx,dy=2,2

coordonance=4


# From n,m,AorB to x,y
def XY(n,m,AorB):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   x=3*dx*n/2+dx*AorB
   y=dy*n+2*dy*m
   return [x,y]

# From x,y to n,m, AorB
def nmAorB(x,y):
   tmp=(2*x)/dx
   n=tmp/3
   AorB=(tmp%3)/2
   m=(y-dy*n)/(2*dy)
   return n,m,AorB


def Neighbours(n,m,AorB,voisin):
   s= -2*AorB+1
   z=voisin-1
   return n-z*z*s,m+s*z*(1+z)/2,1-AorB

def add_one_site(n,m,AorB,t,Hd,monsys,x=0,y=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   if monsys.indice([X+x,Y+y]) != -1: return
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv])
      if where != -1 : v.append(where)
   monsys.add_site(v,t,Hd,[X+x,Y+y])


def move_one_site(n,m,AorB,t,Hd,monsys,ind,x=0,y=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv])
      if where != -1 : v.append(where)
   monsys.move_site(v,t,Hd,[X+x,Y+y],ind)

# Zigzag rectangle; lace from left to right
def ZigzagLR(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y=Init_xy
   monsys=knit.unsysteme()
   monsys.reset(2,fullsize,coordonance)
   vv=[]
   ind=0
   monsys.move_site(vv,t,Hd,[x,y],ind)
   # monsys=knit.rectangle([1,1],[x,y],t,Hd)
   for m in range(m_max):
      ind+=1
      move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(0,m+1,'A',t,Hd,monsys,ind,x,y)
   for n in range(n_max):
      for m in range(m_max+1):
         ind+=1
         move_one_site(n,m,'B',t,Hd,monsys,ind,x,y)
      for m in range(m_max):
         ind+=1
         move_one_site(n+1,m,'A',t,Hd,monsys,ind,x,y)
      if n+1 != n_max:
         ind+=1
         move_one_site(n+1,m_max,'A',t,Hd,monsys,ind,x,y)
   return monsys


def Zigzag_havard(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   m_max=m_max+1
   fullsize=2*n_max*m_max+(m_max-1)*2
   x,y=Init_xy
   monsys=knit.unsysteme()
   monsys.reset(2,fullsize,coordonance)
   ind=0
   for m in range(m_max-1):
         move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y)
         ind+=1
   for n in range(n_max):
      for m in range(m_max):
         move_one_site(n,m-n,'A',t,Hd,monsys,ind,x,y)
         ind+=1
      for m in range(m_max):
         move_one_site(n,m-n,'B',t,Hd,monsys,ind,x,y)
         ind+=1
   for m in range(m_max-1):
         move_one_site(n_max,m+1-n_max,'A',t,Hd,monsys,ind,x,y)
         ind+=1
   return monsys


# Zigzag rectangle lace from down to up
def ZigzagDU(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y=Init_xy
   monsys=knit.unsysteme()
   monsys.reset(2,fullsize,coordonance)
   vv=[]
   ind=0
   First_Site=XY(-1,1,'B')
   First_Site[0]+=x
   First_Site[1]+=y
   monsys.move_site(vv,t,Hd,First_Site,ind)
   # monsys=knit.rectangle([1,1],First_Site,t,Hd)
   for m in range(m_max):
      for n in range(n_max):
         ind+=1
         move_one_site(n,m,'A',t,Hd,monsys,ind,x,y)
         ind+=1
         move_one_site(n,m,'B',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(n_max,m,'A',t,Hd,monsys,ind,x,y)
      if m != 0 :
         ind+=1
         move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y)
   for n in range(n_max):
      ind+=1
      move_one_site(n,m_max,'A',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(n,m_max,'B',t,Hd,monsys,ind,x,y)
   return monsys

# Zigzag rectangle lace from up to down
def ZigzagUD(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y=Init_xy
   monsys=knit.unsysteme()
   monsys.reset(2,fullsize,coordonance)
   vv=[]
   ind=0
   First_Site=XY(0,m_max,'A')
   First_Site+=Init_xy
   monsys.move_site(vv,t,Hd,First_Site,ind)
   #monsys=knit.rectangle([1,1],First_Site,t,Hd)
   for n in range(n_max):
      ind+=1
      move_one_site(n,m_max,'B',t,Hd,monsys,ind,x,y)
      if n != n_max-1:
         ind+=1
         move_one_site(n+1,m_max,'A',t,Hd,monsys,ind,x,y)
   for m in range(m_max,0,-1):
      ind+=1
      move_one_site(-1,m,'B',t,Hd,monsys,ind,x,y)
      for n in range(n_max):
         ind+=1
         move_one_site(n,m-1,'A',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(n_max,m-1,'A',t,Hd,monsys,ind,x,y)
      for n in range(n_max):
         ind+=1
         move_one_site(n,m-1,'B',t,Hd,monsys,ind,x,y)
   return monsys


# Zigzag for left or right lead 
def ZigzagLeadLR(n,m_min,m_max,Init_xy,t,Hd,LR):
   #LR = O : Left lead , LR=1 : Right lead
   if LR=="RIGHT": LR=1
   if LR=="LEFT": LR=0
   x,y=Init_xy
   X,Y=XY(n,m_min,LR)
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for m in range(m_min+1,m_max+1):add_one_site(n,m,LR,t,Hd,monsys,x,y)
   for m in range(m_min,m_max+1):add_one_site(n,m,1-LR,t,Hd,monsys,x,y)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=m_max-m_min+1
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+LR,i+L+1-LR,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.scalarM(1.e-5))
   return a


def ZigzagLead_havard(n,m_min,m_max,Init_xy,t,Hd):
   x,y=Init_xy
   X,Y=XY(n,m_min,"A")
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for m in range(m_min+1,m_max+1):add_one_site(n,m,"A",t,Hd,monsys,x,y)
   for m in range(m_min,m_max+1):add_one_site(n,m,"B",t,Hd,monsys,x,y)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=m_max-m_min+1
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+1,i+L,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.scalarM(1.e-5))
   return a

# Zigzag for down or up lead 
def ZigzagLeadDU(n_min,n_max,m,Init_xy,t,Hd,DU):
   #DU = O : Up lead , DU=1 : Down lead
   if DU=="DOWN": DU=1
   if DU=="UP": DU=0
   x,y=Init_xy
   X,Y=XY(n_min,m,DU)
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for n in range(n_min+1,n_max+1):add_one_site(n,m,DU,t,Hd,monsys,x,y)
   for n in range(n_min,n_max+1):add_one_site(n+2*DU-1,m+1-2*DU,1-DU,t,Hd,monsys,x,y)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=n_max-n_min+1
   for i in range(L):
      a.put_leadHopp(i+L,i,t)
   for i in range(L-1):
      a.put_leadHopp(i+L+1-DU,i+DU,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i,i+L,knit.scalarM(1.e-5))
   return a


def put_magnetic_field(monsys,phi):
   for i in range(monsys.fsize()):
        x=monsys.coord(i,0)
        y=monsys.coord(i,1)
        n,m,AorB=nmAorB(x,y)
        if AorB == 0 :
           xxx=0
           x,y=XY(n,m,1)
           for z in range(monsys.fzmax()):
              mon_voisin=monsys.voisin(i,z)
              if mon_voisin != -1:
                 xp=monsys.coord(mon_voisin,0)
                 yp=monsys.coord(mon_voisin,1)
                 if x == xp and y == yp :
                    monsys.put_Hopp(i,z,knit.scalarM(exp(1j*phi*m))) 
                    xxx=xxx+1
           if xxx>1 : print "Y'a comme un probleme"

def put_magnetic_field_lead(monlead,what,phi):
   L=monlead.fsize()/2
   xx=monlead.coord(0,0)
   yy=monlead.coord(0,1)
   nn,mm,AorB=nmAorB(xx,yy)
   def APPLY(phi):
      for i in range(monlead.fsize()/2):
          xxx=0
          for z in range(monlead.fzmax()):
              mon_voisin=monlead.voisin(i,z)
              if mon_voisin != -1:
                   monlead.put_Hopp(i,z,knit.scalarM(exp(+1j*phi*i)) )
                   xxx=xxx+1
          if xxx!=1 : print "there should be just one neighbor in lead interface"   
   if what == "UP":
      APPLY(-phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.scalarM(exp(+1j*phi*mm)) )
   elif what == "DOWN":
      APPLY(phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.scalarM(exp(-1j*phi*mm)) )
   elif what == "LEFT":APPLY(phi)
   elif what == "RIGHT":APPLY(-phi)
   else: raise ValueError,"neither of UP DOWN LEFT RIGHT index were used for leads"
      
def put_magnetic_field_fullsystem(monsys,mycontacts,phi):
   put_magnetic_field(monsys,phi)
   for ci in mycontacts:
      put_magnetic_field_lead(ci[0],ci[1],phi)

        
# Set white desorder given as ration of hopping elements
# the same dedorder is put on A and B neighbors
def set_AB_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        x,y=that_system.coord(i,0), that_system.coord(i,1)
        n,m,AorB=nmAorB(x,y)
        if AorB == 0 :
           xxx=0
           x,y=XY(n,m,'B')
           for z in range(that_system.fzmax()):
              mon_voisin=that_system.voisin(i,z)
              if mon_voisin != -1:
                 xp,yp=that_system.coord(mon_voisin,0), that_system.coord(mon_voisin,1)
                 if x == xp and y == yp :
                    t=abs(that_system.get_Hopp(i,z)(0,0))
                    V=knit.scalarM( t*W*(random.random()-0.5) )
                    that_system.put_Hdiag( i, V )
                    that_system.put_Hdiag( mon_voisin, V )
                    xxx=xxx+1
           if xxx>1 : print "Y'a comme un probleme"
        
# Set white desorder given in absolute value
def set_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
       V=knit.scalarM( W*(random.random()-0.5) )
       that_system.put_Hdiag( i, V )
       
def local_data2file(systeme,fichier,myfonction):
    import pickle
    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        data.append([x,y,tmp])
        if tmp>maxi :maxi=tmp
        if tmp<mini :mini=tmp
    ff=open(fichier+".data",'w')
    pickle.dump(data,ff)
    ff.close()
    aveV=sum(map(lambda x:x[2],data))/len(data)
   
    return "min=",mini,"max=",maxi,"average=",aveV

