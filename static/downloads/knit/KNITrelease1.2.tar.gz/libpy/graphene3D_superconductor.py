#!/usr/bin/python

import sys
import os
import time

sys.path.append('../')
sys.path.append('pyx/')
sys.path.append('libpy/')
sys.path.append('libpy/Numeric')
from libpy import *
from cmath import *
from Numeric import array
from LinearAlgebra import linear_least_squares

dx,dy=2,2

coordonance=6



# From n,m,AorB to x,y
def XY(n,m,AorB):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   x=3*dx*n/2+dx*AorB
   y=dy*n+2*dy*m
   return [x,y]

# From x,y to n,m, AorB
def nmAorB(x,y):
   tmp=(2*x)/dx
   n=tmp/3
   AorB=(tmp%3)/2
   m=(y-dy*n)/(2*dy)
   return n,m,AorB


def Neighbours(n,m,AorB,voisin):
   s= -2*AorB+1
   z=voisin-1
   return n-z*z*s,m+s*z*(1+z)/2,1-AorB

def add_one_site(n,m,AorB,t,Hd,monsys,x=0,y=0,z=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   if monsys.indice([X+x,Y+y,z]) != -1: return
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv,z])
      if where != -1 : v.append(where)
   monsys.add_site(v,t,Hd,[X+x,Y+y,z])


def move_one_site(n,m,AorB,t,Hd,monsys,ind,x=0,y=0,z=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv,z])
      if where != -1 : v.append(where)
   monsys.move_site(v,t,Hd,[X+x,Y+y,z],ind)

# Zigzag rectangle; lace from left to right
def ZigzagLR(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y,z=Init_xy
   monsys=knit.unsysteme_S()
   monsys.reset(3,fullsize,coordonance)
   vv=[]
   ind=0
   monsys.move_site(vv,t,Hd,[x,y,z],ind)
   # monsys=knit.rectangle([1,1],[x,y],t,Hd)
   for m in range(m_max):
      ind+=1
      move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y,z)
      ind+=1
      move_one_site(0,m+1,'A',t,Hd,monsys,ind,x,y,z)
   for n in range(n_max):
      for m in range(m_max+1):
         ind+=1
         move_one_site(n,m,'B',t,Hd,monsys,ind,x,y,z)
      for m in range(m_max):
         ind+=1
         move_one_site(n+1,m,'A',t,Hd,monsys,ind,x,y,z)
      if n+1 != n_max:
         ind+=1
         move_one_site(n+1,m_max,'A',t,Hd,monsys,ind,x,y,z)
   return monsys


def Zigzag_havard(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   m_max=m_max+1
   fullsize=2*n_max*m_max+(m_max-1)*2
   x,y,z=Init_xy
   monsys=knit.unsysteme_S()
   monsys.reset(3,fullsize,coordonance)
   ind=0
   for m in range(m_max-1):
         move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y,z)
         ind+=1
   for n in range(n_max):
      for m in range(m_max):
         move_one_site(n,m-n,'A',t,Hd,monsys,ind,x,y,z)
         ind+=1
      for m in range(m_max):
         move_one_site(n,m-n,'B',t,Hd,monsys,ind,x,y,z)
         ind+=1
   for m in range(m_max-1):
         move_one_site(n_max,m+1-n_max,'A',t,Hd,monsys,ind,x,y,z)
         ind+=1
   return monsys


# Zigzag rectangle lace from down to up
def ZigzagDU(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y,z=Init_xy
   monsys=knit.unsysteme_S()
   monsys.reset(3,fullsize,coordonance)
   vv=[]
   ind=0
   First_Site=XY(-1,1,'B')
   First_Site[0]+=x
   First_Site[1]+=y
   monsys.move_site(vv,t,Hd,First_Site,ind)
   # monsys=knit.rectangle([1,1],First_Site,t,Hd)
   for m in range(m_max):
      for n in range(n_max):
         ind+=1
         move_one_site(n,m,'A',t,Hd,monsys,ind,x,y,z)
         ind+=1
         move_one_site(n,m,'B',t,Hd,monsys,ind,x,y,z)
      ind+=1
      move_one_site(n_max,m,'A',t,Hd,monsys,ind,x,y,z)
      if m != 0 :
         ind+=1
         move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y,z)
   for n in range(n_max):
      ind+=1
      move_one_site(n,m_max,'A',t,Hd,monsys,ind,x,y,z)
      ind+=1
      move_one_site(n,m_max,'B',t,Hd,monsys,ind,x,y,z)
   return monsys

# Zigzag rectangle lace from up to down
def ZigzagUD(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y,z=Init_xy
   monsys=knit.unsysteme_S()
   monsys.reset(3,fullsize,coordonance)
   vv=[]
   ind=0
   First_Site=XY(0,m_max,'A')
   First_Site+=Init_xy
   monsys.move_site(vv,t,Hd,First_Site,ind)
   #monsys=knit.rectangle([1,1],First_Site,t,Hd)
   for n in range(n_max):
      ind+=1
      move_one_site(n,m_max,'B',t,Hd,monsys,ind,x,y)
      if n != n_max-1:
         ind+=1
         move_one_site(n+1,m_max,'A',t,Hd,monsys,ind,x,y)
   for m in range(m_max,0,-1):
      ind+=1
      move_one_site(-1,m,'B',t,Hd,monsys,ind,x,y)
      for n in range(n_max):
         ind+=1
         move_one_site(n,m-1,'A',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(n_max,m-1,'A',t,Hd,monsys,ind,x,y)
      for n in range(n_max):
         ind+=1
         move_one_site(n,m-1,'B',t,Hd,monsys,ind,x,y)
   return monsys


# Zigzag for left or right lead 
def ZigzagLeadLR(n,m_min,m_max,Init_xy,t,Hd,LR):
   #LR = O : Left lead , LR=1 : Right lead
   if LR=="RIGHT": LR=1
   if LR=="LEFT": LR=0
   x,y,z=Init_xy
   X,Y=XY(n,m_min,LR)
   monsys=knit.rectangle_S([1,1,1],[x+X,y+Y,z],t,Hd)
   for m in range(m_min+1,m_max+1):add_one_site(n,m,LR,t,Hd,monsys,x,y,z)
   for m in range(m_min,m_max+1):add_one_site(n,m,1-LR,t,Hd,monsys,x,y,z)
   a=knit.unreservoirN_S(monsys,knit.spinM(0.),0.)
   L=m_max-m_min+1
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+LR,i+L+1-LR,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.spinM(1.e-5))
   return a


def ZigzagLead_havard(n,m_min,m_max,Init_xy,t,Hd):
   x,y,z=Init_xy
   X,Y=XY(n,m_min,"A")
   monsys=knit.rectangle_S([1,1,1],[x+X,y+Y,z],t,Hd)
   for m in range(m_min+1,m_max+1):add_one_site(n,m,"A",t,Hd,monsys,x,y,z)
   for m in range(m_min,m_max+1):add_one_site(n,m,"B",t,Hd,monsys,x,y,z)
   a=knit.unreservoirN_S(monsys,knit.spinM(0.),0.)
   L=m_max-m_min+1
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+1,i+L,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.spinM(1.e-5))
   return a

# Zigzag for down or up lead 
def ZigzagLeadDU(n_min,n_max,m,Init_xy,t,Hd,DU):
   #DU = O : Up lead , DU=1 : Down lead
   if DU=="DOWN": DU=1
   if DU=="UP": DU=0
   x,y,z=Init_xy
   X,Y=XY(n_min,m,DU)
   monsys=knit.rectangle_S([1,1,1],[x+X,y+Y,z],t,Hd)
   for n in range(n_min+1,n_max+1):add_one_site(n,m,DU,t,Hd,monsys,x,y,z)
   for n in range(n_min,n_max+1):add_one_site(n+2*DU-1,m+1-2*DU,1-DU,t,Hd,monsys,x,y,z)
   a=knit.unreservoirN_S(monsys,knit.spinM(0.),0.)
   L=n_max-n_min+1
   for i in range(L):
      a.put_leadHopp(i+L,i,t)
   for i in range(L-1):
      a.put_leadHopp(i+L+1-DU,i+DU,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i,i+L,knit.spinM(1.e-5))
   return a


def put_magnetic_field(monsys,phi):
   for i in range(monsys.fsize()):
        x=monsys.coord(i,0)
        y=monsys.coord(i,1)
        n,m,AorB=nmAorB(x,y)
        if AorB == 0 :
           xxx=0
           x,y=XY(n,m,1)
           for z in range(monsys.fzmax()):
              mon_voisin=monsys.voisin(i,z)
              if mon_voisin != -1:
                 xp=monsys.coord(mon_voisin,0)
                 yp=monsys.coord(mon_voisin,1)
                 if x == xp and y == yp :
                    monsys.put_Hopp(i,z,knit.spinM(exp(1j*phi*m))) 
                    xxx=xxx+1
           if xxx>1 : print "Y'a comme un probleme"

def put_magnetic_field_lead(monlead,what,phi):
   L=monlead.fsize()/2
   xx=monlead.coord(0,0)
   yy=monlead.coord(0,1)
   nn,mm,AorB=nmAorB(xx,yy)
   def APPLY(phi):
      for i in range(monlead.fsize()/2):
          xxx=0
          for z in range(monlead.fzmax()):
              mon_voisin=monlead.voisin(i,z)
              if mon_voisin != -1:
                   monlead.put_Hopp(i,z,knit.spinM(exp(+1j*phi*i)) )
                   xxx=xxx+1
          if xxx!=1 : print "there should be just one neighbor in lead interface"   
   if what == "UP":
      APPLY(-phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.spinM(exp(+1j*phi*mm)) )
   elif what == "DOWN":
      APPLY(phi)
      for i in range(L):
         hh=monlead.get_leadHopp(i+L,i)(0,0)
         monlead.put_leadHopp(i+L,i,knit.spinM(exp(-1j*phi*mm)) )
   elif what == "LEFT":APPLY(phi)
   elif what == "RIGHT":APPLY(-phi)
   else: raise ValueError,"neither of UP DOWN LEFT RIGHT index were used for leads"
      
def put_magnetic_field_fullsystem(monsys,mycontacts,phi):
   put_magnetic_field(monsys,phi)
   for ci in mycontacts:
      put_magnetic_field_lead(ci[0],ci[1],phi)

        
# Set white desorder given as ration of hopping elements
# the same dedorder is put on A and B neighbors
def set_AB_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        x,y=that_system.coord(i,0), that_system.coord(i,1)
        n,m,AorB=nmAorB(x,y)
        if AorB == 0 :
           xxx=0
           x,y=XY(n,m,'B')
           for z in range(that_system.fzmax()):
              mon_voisin=that_system.voisin(i,z)
              if mon_voisin != -1:
                 xp,yp=that_system.coord(mon_voisin,0), that_system.coord(mon_voisin,1)
                 if x == xp and y == yp :
                    t=abs(that_system.get_Hopp(i,z)(0,0))
                    V=knit.spinM( t*W*(random.random()-0.5) )
                    that_system.put_Hdiag( i, V )
                    that_system.put_Hdiag( mon_voisin, V )
                    xxx=xxx+1
           if xxx>1 : print "Y'a comme un probleme"
        
# Set white desorder given in absolute value
def set_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
       V=knit.spinM( W*(random.random()-0.5) )
       that_system.put_Hdiag( i, V )
       
def grapheneplot(systeme,fichier,myfonction,minV=-1,maxV=-1):
    from pyx import bitmap,canvas,color
    import pickle
    from cStringIO import StringIO
    def flo_to_RGB(h):
        def Hue_2_RGB( vH ):
            while vH<0.0: vH += 1.0
            while vH>1.0: vH -= 1.0
            if 6*vH < 1.0 : return 6.0*vH
            if 2*vH < 1.0 : return 1.
            if 3*vH < 2.0 : return ((2.0/3.0)-vH)*6.0
            return 0.
        r = 255 * Hue_2_RGB( h + 1./3)
        g = 255 * Hue_2_RGB( h )
        b = 255 * Hue_2_RGB( h - 1./3)
        return (int(round(r)),int(round(g)),int(round(b)))
    def rgbcolortostring(c):
        return "".join([chr(int(255*c.color[name])) for name in "rgb"])
    def hsbcolortostring(c):
        rgb=flo_to_RGB(c.color['h'])
        return "".join([chr(name) for name in rgb])

    taille = systeme.fsize()
    mini=myfonction(0)
    maxi=myfonction(0)
    data=[]
    for i in xrange(taille):
        tmp=myfonction(i)
        x=systeme.coord(i,0)
        y=systeme.coord(i,1)
        data.append([x,y,tmp])
        if tmp>maxi :maxi=tmp
        if tmp<mini :mini=tmp
    ff=open("courant"+str(M)+".data",'w')
    pickle.dump(data,ff)
    ff.close()
    if minV==-1: minV=mini
    if maxV==-1: maxV=maxi
    aveV=sum(map(lambda x:x[2],data))/len(data)
    for i in data:
        i[2]=(i[2]-minV)/(maxV-minV)
        if i[2]>1: i[2]=1.
        if i[2]<0: i[2]=0.
    xmin=min(map(lambda x:x[0],data))
    xmax=max(map(lambda x:x[0],data))
    ymin=min(map(lambda x:x[1],data))
    ymax=max(map(lambda x:x[1],data))
    xiterations = xmax-xmin+1
    yiterations = ymax-ymin+1
    ## rearange data by index
    def xy2ind(x,y):
        return x-xmin+(ymax-y)*xiterations

    dataArr = array([-1. for x in range(xiterations*yiterations)],'f')
    for a in data:
        ind=xy2ind(a[0],a[1])
        dataArr[ind]=a[2]
        if a[0]<xmax and a[1]<ymax:
           ind1=xy2ind(a[0],a[1]+1)
           ind2=xy2ind(a[0]+1,a[1])
           ind3=xy2ind(a[0]+1,a[1]+1)
           dataArr[ind1]=a[2]
           dataArr[ind2]=a[2]
           dataArr[ind3]=a[2]
    
    p = color.palette.ReverseRainbow

    # string that is used to plot data
    dataBW = StringIO()
    # compute dataBW
    for a in dataArr:
        if a >= 0.:
            # append color(RGB) of the current pixel to the end of data
            dataBW.write(hsbcolortostring(p.getcolor(a)))
        else:
            dataBW.write("\377\377\377")

    # generate image from dataBW
    julia = bitmap.image(xiterations, yiterations, "RGB", dataBW.getvalue())
    juliabitmap = bitmap.bitmap(0, 0, julia, height=10)
    c = canvas.canvas()
    c.insert(juliabitmap)
    
    c.writeEPSfile(fichier)
    c.writePDFfile(fichier)
    return "min=",minV,"max=",maxV,"average=",aveV

def toprint(L):
   outstring=''
   for l in L: outstring+=str(l)+'\t'
   outstring+='\n'
   return outstring

def f_range(xmin,xmax,steps):
   return [(xmin+float(xmax-xmin)*x/steps) for x in range(steps+1)]

###############################################

#Left-Right check 
#M=int(sys.argv[1]) 
#N=10
#a=ZigzagLR([N,M],[0,0],t,Hd)
#add_one_site(N,M,'A',t,Hd,a)
#add_one_site(-1,0,'B',t,Hd,a)
#lead0=ZigzagLeadLR(-1,0,M,[0,0],t,Hd,"LEFT")
#monsys=knit.systemtotal(a,lead0)
#lead1=ZigzagLeadLR(N,0,M,[0,0],t,Hd,"RIGHT")
#monsys.addlead(lead1)
# add B_field
#mycontacts=[]
#mycontacts.append([lead0,"LEFT"])
#mycontacts.append([lead1,"RIGHT"])

## phi=1.2*E**2
## put_magnetic_field_fullsystem(monsys,mycontacts,phi) 


## N=20
## M=35
## #Up_Down check 
## a=ZigzagDU([N,M],[0,0],t,Hd)
## add_one_site(N,M,'A',t,Hd,a)
## add_one_site(-1,0,'B',t,Hd,a)
## lead0=ZigzagLeadDU(-1,N-1,0,[0,0],t,Hd,"DOWN")
## monsys=knit.systemtotal(a,lead0)
## lead1=ZigzagLeadDU(0,N,M,[0,0],t,Hd,"UP")
## monsys.addlead(lead1)
## #add B_field
## mycontacts=[]
## mycontacts.append([lead0,"DOWN"])
## mycontacts.append([lead1,"UP"])
## phi=0.1
## put_magnetic_field_fullsystem(monsys,mycontacts,phi) 


## def an(tt): return atan(tt.imag/(tt.real+1e-6)).real/pi
## def aa(ind,z):
##    tt=monsys.get_Hopp(ind,z)(0,0)
##    print ind,"->",monsys.voisin(ind,z),"=",an(tt)
## for i in range(5): aa(50+2*i,2)

## # QUANTUM HALL SAMPLE
## M=int(sys.argv[1]) 
## # Main block
## a=ZigzagLR([5*M,M],[0,0],t,Hd)
## add_one_site(5*M,M,'A',t,Hd,a)
## add_one_site(-1,0,'B',t,Hd,a)
## # upper parts
## b=ZigzagDU([M,M],XY(M,M,'A'),t,Hd)
## add_one_site(2*M,2*M,'A',t,Hd,b)
## a.coller(b)
## c=ZigzagDU([M,M],XY(3*M,M,'A'),t,Hd)
## add_one_site(4*M,2*M,'A',t,Hd,c)
## a.coller(c)
## # lower parts
## d=ZigzagUD([M,M],XY(M,-M,'A'),t,Hd)
## add_one_site(M-1,-M,'B',t,Hd,d)
## a.coller(d)
## e=ZigzagUD([M,M],XY(3*M,-M,'A'),t,Hd)
## add_one_site(3*M-1,-M,'B',t,Hd,e)
## a.coller(e)

## # leads
## lead0=ZigzagLeadLR(-1,0,M,[0,0],t,Hd,"LEFT")
## hallbar=knit.systemtotal(a,lead0)
## lead1=ZigzagLeadLR(5*M,0,M,[0,0],t,Hd,"RIGHT")
## hallbar.addlead(lead1)
## lead2=ZigzagLeadDU(0,M,M,XY(M,M,'A'),t,Hd,"UP")
## hallbar.addlead(lead2)
## lead3=ZigzagLeadDU(0,M,M,XY(3*M,M,'A'),t,Hd,"UP")
## hallbar.addlead(lead3)
## lead4=ZigzagLeadDU(-1,M-1,0,XY(M,-M,'A'),t,Hd,"DOWN")
## hallbar.addlead(lead4)
## lead5=ZigzagLeadDU(-1,M-1,0,XY(3*M,-M,'A'),t,Hd,"DOWN")
## hallbar.addlead(lead5)

## # for B_field
## mycontacts=[]
## mycontacts.append([lead0,"LEFT"])
## mycontacts.append([lead1,"RIGHT"])
## mycontacts.append([lead2,"UP"])
## mycontacts.append([lead3,"UP"])
## mycontacts.append([lead4,"DOWN"])
## mycontacts.append([lead5,"DOWN"])

## system.visu2D(monsys,".systeme")
## os.system("xpdf .systeme.pdf & ")
## sys.exit()


# set initial point for calculation time
#in_time=time.time()


## s=sys.argv[0]
## system.visu2D(monsys,s+".systeme")
## #system.visu2D(lead1,s+".systeme")
## #system.visuLead2D(lead0,s+".systeme",-20,-7,ray=.2)
## #system.visuLead2D(lead1,s+".systeme",20,7,ray=.2)
## os.system("xpdf "+s+".systeme.pdf & ")
## sys.exit()

## # transmission on Energy
## N=101
## data=[]
## for boucle_i in range(N):
##    E=-3.+6.*(float(boucle_i)/N)
##    s=obs.conductance_matrix(hallbar,E)
##    print E,s[1,0]
## sys.exit()


## #######################
## ## sigma_xy (E) curve
## #######################
## Nit=100
## phi=0.09
## # disorder
## W=0.1
## print "phi=", phi, "sys size M=",M, "W=",W
## set_white_disorder(hallbar,W,666)
## put_magnetic_field_fullsystem(hallbar,mycontacts,phi)

## f=open("Hall_Eg_xyM"+str(M)+"phi"+str(phi)+"W"+str(W)+"z.dat",'a')
## f.write("#E \t g_xy \t R_xx \t R_24 \t R_35 \t R_32 \t R_54 \n")
## E_range=f_range(-0.555,-0.53,Nit)+f_range(-0.4,-0.38,Nit)+f_range(-0.01,0.01,Nit)+f_range(0.38,0.4,Nit)+f_range(0.53,0.555,Nit)+f_range(0.645,0.665,Nit)
## for E in E_range:
##    if E == 0. : continue   
##    s=obs.conductance_matrix(hallbar,E)
##    rr=linear_least_squares(s,array((1.,-1.,0.,0.,0.,0.)))[0]
##    # print phi,rr[2]-rr[4],rr[3]-rr[5],rr[3]-rr[2],rr[5]-rr[4]
##    R_24 = rr[2]-rr[4]
##    R_35 = rr[3]-rr[5]
##    R_32 = rr[3]-rr[2]
##    R_54 = rr[5]-rr[4]
##    R_xy = (rr[2]-rr[4]+rr[3]-rr[5])/2.
##    R_xx = (rr[3]-rr[2]+rr[5]-rr[4])/2.
##    g_xy=R_xy/(R_xy**2+R_xx**2)
##    output=toprint([E, g_xy, R_xx, R_24, R_35, R_32, R_54])
##    f.write(output)
##    f.flush()
## sys.exit()


## #######################
## ## sigma_xy (1/B) curve
## #######################
## Nit=200
## nmax=4.5 #index of last Hall plateau, Hall plateau number = nmax/2
## def En(MM,nnmax): return sqrt(nnmax**3*16/1.2)/MM
## E=round(abs(En(M,nmax)),2)
## # disorder
## W=0.1
## print "Energy=", E, "plateau index =", nmax, "sys size M=",M, "W=",W
## set_white_disorder(hallbar,W,666)

## if E>1. : raise ValueError, " Energy is bigger then 1, finite size effects are expected"
## f=open("Hall_Bg_xyM"+str(M)+"E"+str(E)+"W"+str(W)+".dat",'a')
## f.write("#1/phi \t g_xy \t R_xx \t R_24 \t R_35 \t R_32 \t R_54 \n")
## # inversed flux range construction
## iflux_min,iflux_max=1/pi,(0.25*M/nmax)**2
## range1=f_range(iflux_min,iflux_max,Nit)
## range2=f_range(2.8,3.4,Nit)
## range3=f_range(6.1,6.8,Nit)
## range4=f_range(9.4,10.,Nit)
## range_inf=f_range(iflux_max,10*iflux_max,Nit)
## iflux_range=range1+range2+range3+range4+range_inf
## for iflux in iflux_range:
##    for phi in [-1./iflux,1/iflux]:
##       put_magnetic_field_fullsystem(hallbar,mycontacts,phi)
##       s=obs.conductance_matrix(hallbar,E)
##       rr=linear_least_squares(s,array((1.,-1.,0.,0.,0.,0.)))[0]
##       # print phi,rr[2]-rr[4],rr[3]-rr[5],rr[3]-rr[2],rr[5]-rr[4]
##       R_24 = rr[2]-rr[4]
##       R_35 = rr[3]-rr[5]
##       R_32 = rr[3]-rr[2]
##       R_54 = rr[5]-rr[4]
##       R_xy = (rr[2]-rr[4]+rr[3]-rr[5])/2.
##       R_xx = (rr[3]-rr[2]+rr[5]-rr[4])/2.
##       g_xy=R_xy/(R_xy**2+R_xx**2)
##       output=toprint([1./phi,g_xy,R_xx,R_24,R_35,R_32,R_54])
##       f.write(output)
##       f.flush()
## sys.exit()

#######################################################
## phi=0.25
## put_magnetic_field_fullsystem(hallbar,mycontacts,phi) 
## monsys=hallbar

## E=float(sys.argv[1])
## for M in [40,60,80]: 
##    N=M
##    f=open("W_R_ErrR_E"+str(E)+"M"+str(M)+"WD.dat",'w')
##    for just_lead in [1,0]:
##       if just_lead : N=1
##       #sys construction
##       a=ZigzagLR([N,M],[0,0],t,Hd)
##       add_one_site(N,M,'A',t,Hd,a)
##       add_one_site(-1,0,'B',t,Hd,a)
##       lead0=ZigzagLeadLR(-1,0,M,[0,0],t,Hd,"LEFT")
##       monsys=knit.systemtotal(a,lead0)
##       lead1=ZigzagLeadLR(N,0,M,[0,0],t,Hd,"RIGHT")
##       monsys.addlead(lead1)
##       if just_lead:
##          s=obs.conductance_matrix(monsys,E)
##          R_lead=1./s[0,1]
##          f.write("#R_lead="+str(R_lead)+" E="+str(E)+"\n")
##          f.write("#W\tR_bulk\tdeltaR\n")
##          f.flush()
##          continue
##       Wmax=2.
##       for W in [Wmax*x/20. for x in range(1,20)]:  
##          # average over desorder
##          Number=int((100./M/E)**3)
##          T,T2=0.,0.
##          for i in range(Number):
##             set_white_disorder(monsys,W,666*i*N)
##             s=obs.conductance_matrix(monsys,E)
##             T+=s[0,1]
##             T2+=s[0,1]**2
##          T=T/Number
##          T2=T2/Number
##          dT=sqrt( abs(T2-T**2)/Number )
##          R_bulk=1./T-R_lead
##          f.write(str(W)+"\t"+str(R_bulk)+"\t"+str(dT/T**2)+"\n")
##          f.flush()

########

## E=float(sys.argv[1])
## #W=float(sys.argv[2])
## W=0. ###
## #f=open("GM_E"+str(E)+"W"+str(W)+"AB.dat",'a')
## f=open("Rlead"+str(E)+"N1.dat",'a') ###
## f.write("#E="+str(E)+"W="+str(W)+'\n')
## f.write("#M\t 1/(R5-Rlead) \t deltaR \t  Rlead\n")
## for M in range(1,100):
##    N=5
##    for just_lead in [1,0]:
##       if just_lead : N=1
##       else: continue ###
##       #sys construction
##       a=ZigzagLR([N,M],[0,0],t,Hd)
##       add_one_site(N,M,'A',t,Hd,a)
##       add_one_site(-1,0,'B',t,Hd,a)
##       lead0=ZigzagLeadLR(-1,0,M,[0,0],t,Hd,"LEFT")
##       monsys=knit.systemtotal(a,lead0)
##       lead1=ZigzagLeadLR(N,0,M,[0,0],t,Hd,"RIGHT")
##       monsys.addlead(lead1)
##       if just_lead:
##          s=obs.conductance_matrix(monsys,E)
##          R_lead=1./s[0,1]
##          f.write(str(M)+"\t"+str(R_lead)+"\n") ###
##          f.flush()
##          continue
##       continue ###
##       # average over desorder
##       Number=int((200./M/E)**3)
##       Number=min(Number,10000)
##       T,T2=0.,0.
##       for i in range(Number):
##          set_AB_disorder(monsys,W,i*i*M+M+1)
##          s=obs.conductance_matrix(monsys,E)
##          T+=s[0,1]
##          T2+=s[0,1]**2
##       T=T/Number
##       T2=T2/Number
##       dT=sqrt( abs(T2-T**2)/Number )
##       T_bulk=1./(1./T-R_lead)
##       f.write(str(M)+"\t"+str(T_bulk)+"\t"+str(dT)+'\t'+str(R_lead)+"\n")
##       f.flush()


## # POTENTIAL FORM
## def V_potent(i):
##     return monsys.get_Hdiag(i)(0,0).real
## print obs.RGBplot2D(monsys,"sysPlot",V_potent)
## os.system("xpdf sysPlot.pdf & ")
## sys.exit()

## f=open("LDOS_Edesor.dat",'a')
## Nit=31*5
## for E in [3.*x/Nit for x in range(1,Nit)]:
##    resultats=obs.knitANDsew(monsys,E)
##    def densite(i): return -resultats.getG_retarded(i,4)(0,0).imag/pi
##    den=sum([densite(2*M+2+x) for x in range(2*M+2)])/(2.*M+2)
##    f.write(str(E)+' '+str(den)+'\n')
#n_chan=int(sys.argv[2]) 
#rc=M/n_chan
#phi=4./rc**2
# phi=4.*5**2/M**2
# E=sqrt(sqrt(3)/2.*n_chan*phi)
# #W=0.04*abs(E)/0.7
# W=0.4
# print "E=", E, "phi=", phi, "sys size M=",M, "W=",W
# #monsys=hallbar ###
# set_white_disorder(monsys,W,666)
# put_magnetic_field_fullsystem(monsys,mycontacts,phi) 
# resultats=obs.knitANDsew(monsys,E) ### 8*M

# def densite(i): return -resultats.getG_retarded(i,4)(0,0).imag/pi

# # Current plot
# def courant(i):
#     tmp=0.
#     for z in range(monsys.fzmax()):
#        vi= monsys.voisin(i,z)
#        if vi != -1  and monsys.sys2res(i)<0 and monsys.sys2res(vi)<0:
#           Gij=0.
#           # for lead in [1,4] :
#           for lead in [0] :
#              Gij+=resultats.getG_lesser(i,z,lead)(0,0)
#           Vji=monsys.get_Hopp(i,z)(0,0).conjugate()
#           tmp=tmp+((Vji*Gij).real)**2
#     return  abs(sqrt(tmp))


# def test(i):
#    tmp=0.
#    for z in range(3):
#       vi= monsys.voisin(i,z)
#       if vi == -1 or monsys.sys2res(i)>=0 or  monsys.sys2res(vi)>=0 : return 0.
#       Gij=0.
#       for lead in range(2): Gij+=resultats.getG_lesser(i,z,lead)(0,0)
#       Vji=monsys.get_Hopp(i,z)(0,0).conjugate()
#       tmp=tmp+(Vji*Gij).real
#    if abs(tmp)>1e-10:print "######## ",i,tmp
#    return  tmp

# f=open("edgeDenRec_M"+str(M)+"E"+str(round(abs(E),3))+"chan"+str(n_chan)+".dat",'w')
# #M_init=M+(M+1)*(4*M+M/2*2)
# M_init=M+(M+1)*5
# for i in range(M_init,M_init+M+1):
#    # lead=4 ###
#    lead=0 ###
#    x,y=monsys.coord(i,0),monsys.coord(i,1)
#    # print "i,x = ",i,x
#    for z in range(monsys.fzmax()):
#       vi= monsys.voisin(i,z)
#       output=toprint([i,densite(i)])
#       f.write(output)
#       break
#       if monsys.coord(vi,0) == x+dx and monsys.coord(vi,1) == y :
#          Vji=monsys.get_Hopp(i,z)(0,0).conjugate()
#          Gij=resultats.getG_lesser(i,z,lead)(0,0)
#          curr=(Vji*Gij).real
#          output=toprint([i,curr])
#          f.write(output)
#          f.flush()
#          # print "vi,x,z = ",vi,monsys.coord(vi,0),z
#          break


# s=".courant"+str(M)+str(n_chan)
# #obs.colorplot2D(monsys,s,densite,tt=4)
# #grapheneplot(monsys,s,densite)
# print grapheneplot(monsys,s,courant)
# os.system("xpdf "+s+".pdf & ")


# out_time=time.time()
# print "# pure execution time=",int(out_time-in_time)," sec \n#sample M=",M
# f=open("exec_time.dat",'w')
# f.write("execution time="+str(int(out_time-in_time))+" sec \n sample M="+str(M))



