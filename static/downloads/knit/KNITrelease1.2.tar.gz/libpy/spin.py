from math import *
from libpy import *


class spin(knit.spinM):
    def __init__(self,E=0.):
        if isinstance(E,knit.spinM):
            knit.spinM.__init__(self,E)
        else:
            knit.spinM.__init__(self,complex(E))
    def affiche(self):
        print " [ ",self(0,0),"    \t\t",self(0,1)," ] "
        print " [ ",self(1,0),"    \t\t",self(1,1)," ] "
    def __add__(self,other):
        tmp=spin()
        for i in range(2):
            for j in range(2): tmp.set(i,j,self(i,j)+other(i,j))
        return tmp
    def __radd__(self,other):return spin.__add__(self,other)
    def __mul__(self,other):
        tmp=spin()
        for i in range(2):
            for j in range(2): tmp.set(i,j,self(i,0)*other(0,j)+self(i,1)*other(1,j))
        return tmp
    def __rmul__(self,other):
        return other.__mul__(self)
    def __sub__(self,other):
        tmp=spin()
        for i in range(2):
            for j in range(2): tmp.set(i,j,self(i,j)-other(i,j))
        return tmp
    def __rsub__(self,other):return  spin.__sub__(other,self)
    def __coerce__(self,other):
        return self,spin(complex(other))
   
    
id=spin(1.)
sx=spin()
sx.set(0,1,1.)
sx.set(1,0,1.)
sy=spin()
sy.set(0,1,-1.J)
sy.set(1,0,1.J)
sz=spin(1.)
sz.set(1,1,-1.)

def rotate(toto,axe,angle):
        norme=axe[0]*axe[0]+axe[1]*axe[1]+axe[2]*axe[2]
        axe=[i/sqrt(norme) for i in axe]
        rot=complex(cos(angle/2.))*id - sin(angle/2.)*1J*(complex(axe[0])*sx+complex(axe[1])*sy+complex(axe[2])*sz)
        roth=complex(cos(angle/2.))*id + sin(angle/2.)*1J*(complex(axe[0])*sx+complex(axe[1])*sy+complex(axe[2])*sz)
        return rot*toto*roth
    


class scalar(knit.scalarM):
    def __init__(self,E=0.):
        if isinstance(E,knit.scalarM):
            knit.scalarM.__init__(self,E)
        else:
            knit.scalarM.__init__(self,complex(E))
    def affiche(self):
        print self(0,0)
    def __add__(self,other):
        tmp=scalar(self(0,0)+other(0,0))
        return tmp
    def __radd__(self,other):return self.__add__(other)
    def __mul__(self,other):
        if isinstance(other,complex):
            tmp=scalar(self(0,0)*other)
        else:
            tmp=scalar(self(0,0)*other(0,0))
        return tmp
    def __rmul__(self,other):
        return self.__mul__(other)
    def __sub__(self,other):
        tmp=scalar(self(0,0)-other(0,0))
        return tmp
    def __rsub__(self,other):
        tmp=scalar(other(0,0)-self(0,0))
        return tmp
