# A FEW USEFUL FUNCTIONS FOR THE TWO D GAS.
# MOST OF THEM WON'T WORK FOR ANYTHING ELSE THAN
# A SQUARE LATTICE WITH SCALAR MICROMATRIX.

import knit
from cmath import *

def haut(i,monsys):
    y=monsys.coord(i,1)
    for z in range(monsys.fzmax()):
        mon_voisin=monsys.voisin(i,z)
        if mon_voisin != -1:
           if monsys.coord(mon_voisin,1) > y: return z
    return -1

def phase_lead(monlead,phi,j):
    for i in range(monlead.fsize()):
         x=monlead.coord(i,j)
         monlead.put_leadHopp(i,i,knit.scalarM(exp(1j*phi*x)) )

# TAKE THE INFINITE SYSTEM, THE LIST OF THE CONTACTS AND THE FLUX
# THE LIST OF CONTACTS SHOULD BE AS FOLLOWS:
# mescontacts=[ [a,"UP"],[b,"DOWN"],[c,"LEFT"],[d,"RIGHT"]]
# WHERE THE DIRECTION INDICATE WHICH WAY IS THE CONTACT GOING.
def add_magnetic_flux(that_system,mescontacts,phi):
    for i in range(that_system.fsize()):
        z=haut(i,that_system)
        x=that_system.coord(i,0)
        if z != -1:
           that_system.put_Hopp(i,z,knit.scalarM(exp(1j*phi*x)) )
    for ci in mescontacts:
        for i in range(ci[0].fsize()):
           z=haut(i,ci[0])
           x=ci[0].coord(i,0)
           if z != -1:
              ci[0].put_Hopp(i,z,knit.scalarM(exp(1j*phi*x)) )
        if ci[1] == "DOWN": phase_lead(ci[0],-phi,0)
        if ci[1] == "RIGHT": phase_lead(ci[0],-phi,1)
        if ci[1] == "UP": phase_lead(ci[0],phi,0)
        if ci[1] == "LEFT": phase_lead(ci[0],phi,1)
        
# Set white desorder given in ratio of given value Hdiag_initial
# attention if given value is zero NO desorder would be added
# Hdiag_initial should belong to scalarM
def set_white_disorder(that_system,W,Hdiag_initial,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        that_system.put_Hdiag(i,knit.scalarM(Hdiag_initial(0,0)*(1.+W*(random.random()-0.5))))


#Add white desorder given in ratio of initial value
# attention for zero value of Hdiag NO desorder is added
def add_white_disorder(that_system,W,SEED):
    import random
    random.seed(SEED)
    for i in range(that_system.fsize()):
        Hdiag_initial=that_system.get_Hdiag(i)
        that_system.put_Hdiag(i,knit.scalarM(Hdiag_initial(0,0)*(1.+W*(random.random()-0.5))))
