
print "A SIMPLE CALCULATION: conductance of a T shape system."

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E and number of sites MYSIZE)"

"""
it would be good to have somewhere description of all main classes and variables:
scalarM
rectangle
coller
etc.

"""

t=knit.scalarM(1.)
V=knit.scalarM(0.)
""" Here we specify intercite coupling and oncite energies. Here they are scalar but could be matrices
for super conductors and  for spin systems TO BE IMLEMENTED BY KYRYLO KAZYMYRENKO!!!!!"""
E=-0.5
MYSIZE=4 #system size

print "3. We built the system."
MyT=knit.rectangle([MYSIZE,2*MYSIZE],[MYSIZE,0],t,V)
MyT1=knit.rectangle([3*MYSIZE,MYSIZE],[0,MYSIZE],t,V)
""" knit.rectangle([X_size,Y_size][X_coordinate_of_left_bottom_corner,Y_toto],hopping,oncite_potential) """

"""Here we stik system by adding new pieces to the main part"""

MyT.coller(MyT1)

print "4. We built the reservoirs."
interface_contact1=knit.rectangle([MYSIZE,1],[MYSIZE,0],t,V)
contact1=knit.unreservoirN(interface_contact1,t)

interface_contact2=knit.rectangle([1,MYSIZE],[0,MYSIZE],t,V)
contact2=knit.unreservoirN(interface_contact2,t)

print "5. We create the full system with the electrodes"
MyTwithLeads=knit.systemtotal(MyT,contact1)
"""contact1 is added to FINITE system"""
MyTwithLeads.addlead(contact2)
"""contact2 is added to INFINITE system since contact 1 is already added"""

print "6. We plot the system to make sure it looks as it should."
import os
s=sys.argv[0]
"""
argv = array of arguments of python input for example  for command python xy.py 10 argv={xy.py,10} and
argv[0]=xy.py
"""
system.visu2D(MyTwithLeads,s+".systeme")
#writing .eps and .pdf files with names "argv[0]".systeme
os.system("gv "+s+".systeme.eps & ")
#running of applications which show pictures.

print "7. We calculate the conductance as a function of energy E."
for i in range(10):
     E=(float(i)/10)*2.-1.99
     G_MATRIX=obs.conductance_matrix(MyTwithLeads,E) #here is hard core calculation!!!!!
     
     print E,G_MATRIX[1,0]
"""
everything what TAB-ed is inside the cycle
"""
