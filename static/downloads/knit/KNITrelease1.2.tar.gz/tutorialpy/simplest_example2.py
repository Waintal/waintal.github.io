# This is a variation on simplest_example1.py
# here we add a third reservoir, define a function
# to mimic an impurity in the system and use PyX to plot 
# the results directly.
 
print "A SIMPLE CALCULATION 2:" 
print "role of disorder in the conductance of a T shape system."

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E and number of sites MYSIZE)"
t=knit.scalarM(1.)
V=knit.scalarM(0.)
E=0.0001
MYSIZE=5

print "3. We built the system."
MyT=knit.rectangle([MYSIZE,2*MYSIZE],[MYSIZE,0],t,V)
MyT.coller(knit.rectangle([3*MYSIZE,MYSIZE],[0,MYSIZE],t,V))

print "4. We built the 3 reservoirs."
contact1=knit.unreservoirN(knit.rectangle([MYSIZE,1],[MYSIZE,0],t,V),t,0)
contact2=knit.unreservoirN(knit.rectangle([1,MYSIZE],[0,MYSIZE],t,V),t,0)
contact3=knit.unreservoirN(knit.rectangle([1,MYSIZE],[3*MYSIZE-1,MYSIZE],t,V),t,0)

print "5. We create the full system with 3 electrodes"
MyTwithLeads=knit.systemtotal(MyT,contact3)
MyTwithLeads.addlead(contact1)
MyTwithLeads.addlead(contact2)


print "6. We plot the system to make sure it looks as it should."
import os,sys
s=sys.argv[0]
system.visu2D(MyTwithLeads,s+".systeme")
os.system("gv "+s+".systeme.eps & ")

print "7. We define a function to introduce an impurity in the system"
def Tdisorder(W):
   import random
   random.seed(666)
   for ix in range(MYSIZE):
       for iy in range(MYSIZE):
           i=MyTwithLeads.indice([ix+2*MYSIZE,iy+MYSIZE])
	   MyTwithLeads.put_Hdiag(i,knit.scalarM(W*(random.random()-0.5)))

print "8. We calculate the conductance as a function of impurity strength W."
MYDATA=[]
for i in range(10):
     W=(float(i)/10)*2.
     Tdisorder(W)
     G_MATRIX=obs.conductance_matrix(MyTwithLeads,E)
     MYDATA.append([W,G_MATRIX[2,1],G_MATRIX[0,1]])
     print W,G_MATRIX[2,1],G_MATRIX[0,1],G_MATRIX[0,2]


print "9. We plot the datas using PyX"
from pyx import *

g =graph.graphxy(width=10,x=graph.axis.linear(title="$W$"),y=graph.axis.linear(title="$G$"))
g.plot(graph.data.list(MYDATA,x=1,y=2),[graph.style.line([style.linewidth.Thick])])
g.plot(graph.data.list(MYDATA,x=1,y=3),[graph.style.line([style.linewidth.Thick,style.linestyle.dashed])])

g.writeEPSfile(s+".conductance")
g.writePDFfile(s+".conductance")
os.system("gv "+s+".conductance.eps & ")

