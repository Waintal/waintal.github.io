# This is a variation on simplest_example2.py
# here we plot the 2D potential to see how it looks
# and then plot the local current density 
 
print "A SIMPLE CALCULATION 3:" 
print "Observables inside a T shape system."

print "1. We import the knit algorithm just as any python module."
import sys
sys.path.append('../')
from libpy import *

print "2. We define the parameters."
print "(hopping element t, potential V, energy E and number of sites MYSIZE)"
t=knit.scalarM(1.)
V=knit.scalarM(0.)
E=0.
MYSIZE=5

print "3. We built the system."
MyT=knit.rectangle([MYSIZE,2*MYSIZE],[MYSIZE,0],t,V)
MyT.coller(knit.rectangle([3*MYSIZE,MYSIZE],[0,MYSIZE],t,V))

print "4. We built the 3 reservoirs."
contact1=knit.unreservoirN(knit.rectangle([MYSIZE,1],[MYSIZE,0],t,V),t,0)
contact2=knit.unreservoirN(knit.rectangle([1,MYSIZE],[0,MYSIZE],t,V),t,0)
contact3=knit.unreservoirN(knit.rectangle([1,MYSIZE],[3*MYSIZE-1,MYSIZE],t,V),t,0)

print "5. We create the full system with 3 electrodes"
MyTwithLeads=knit.systemtotal(MyT,contact1)
MyTwithLeads.addlead(contact2)
MyTwithLeads.addlead(contact3)


print "6. We define a function to introduce an impurity in the system"
def Tdisorder(W):
   import random
   random.seed(666)
   for ix in range(MYSIZE):
       for iy in range(MYSIZE):
           i=MyTwithLeads.indice([ix+2*MYSIZE,iy+MYSIZE])
	   MyTwithLeads.put_Hdiag(i,knit.scalarM(W*(random.random()-0.5)))

print "7. We plot the 2D potential to make sure it looks correct."
def potential(i):
     return MyTwithLeads.get_Hdiag(i)(0,0).real
Tdisorder(6.)
import sys,os
s=sys.argv[0]
print system.colorplot2D(MyTwithLeads,s+".pot",potential)
os.system("gv "+s+".pot.eps & ")

print "9. We calculate all the local quantities"
resultats=obs.knitANDsew(MyTwithLeads,E)
print obs.conductance_matrix(MyTwithLeads,E)

print "10. We plot the local current coming from lead 1."
from math import *
def currentdensity(i,lead=1):
    tmp=0.
    for z in range(MyTwithLeads.fzmax()):
       vi= MyTwithLeads.voisin(i,z)
       if MyTwithLeads.voisin(i,z) != -1 and MyTwithLeads.sys2res(i)<0 and MyTwithLeads.sys2res(vi)<0:
           Gij=resultats.getG_lesser(i,z,lead)(0,0)
           Vji=MyTwithLeads.get_Hopp(i,z)(0,0).conjugate()
           tmp=tmp+((Vji*Gij).real)**2
    return sqrt(tmp)

print system.colorplot2D(MyTwithLeads,s+".cur",currentdensity)
#system.colorplot2D(MyTwithLeads,s+".cur",currentdensity,0.1,0.)
os.system("gv "+s+".cur.eps & ")




