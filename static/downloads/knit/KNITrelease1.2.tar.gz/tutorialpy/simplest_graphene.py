#!/usr/bin/python
import sys
sys.path.append('../')
from libpy import *

##################################################
# ROUTINES TO BUILD GRAPHENE LAYERS              #
#                                                #
# NOTE: THIS KIND OF DEVELOPMENT IS DONE ONCE    #
# THEN PACKAGED INTO A SMALL MODULE AND USED     #
# AFTERWARD BY OTHER "GRAPHENE" USERS            #
##################################################

dx,dy=2,2
coordonance=4


# INTRODUCING THE COORDINATE IN "GRAPHENE SPACE":
# n,m label the hexagons along the two directions
# AorB either we are talking about a A site or a B site

# From n,m,AorB to x,y
def XY(n,m,AorB):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   x=3*dx*n/2+dx*AorB
   y=dy*n+2*dy*m
   return [x,y]

# From x,y to n,m, AorB
def nmAorB(x,y):
   tmp=(2*x)/dx
   n=tmp/3
   AorB=(tmp%3)/2
   m=(y-dy*n)/(2*dy)
   return n,m,AorB


def Neighbours(n,m,AorB,voisin):
   s= -2*AorB+1
   z=voisin-1
   return n-z*z*s,m+s*z*(1+z)/2,1-AorB

def add_one_site(n,m,AorB,t,Hd,monsys,x=0,y=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   if monsys.indice([X+x,Y+y]) != -1: return
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv])
      if where != -1 : v.append(where)
   monsys.add_site(v,t,Hd,[X+x,Y+y])


def move_one_site(n,m,AorB,t,Hd,monsys,ind,x=0,y=0):
   if AorB=='A': AorB=0
   if AorB=='B': AorB=1
   X,Y=XY(n,m,AorB)
   v=[]
   for i in range(3):
      nv,mv,AorBv=Neighbours(n,m,AorB,i)
      xv,yv=XY(nv,mv,AorBv)
      xv=xv+x
      yv=yv+y
      where=monsys.indice([xv,yv])
      if where != -1 : v.append(where)
   monsys.move_site(v,t,Hd,[X+x,Y+y],ind)

# Zigzag rectangle; lace from left to right
def ZigzagLR(nmSize,Init_xy,t,Hd):
   n_max,m_max=nmSize
   fullsize=2*n_max*m_max+2*n_max+2*m_max
   x,y=Init_xy
   #monsys=knit.unsysteme()
   #monsys.reset(2,fullsize,coordonance)
   monsys=knit.rectangle([fullsize,1],[x,y],t,Hd)
   vv=[]
   ind=0
   monsys.move_site(vv,t,Hd,[x,y],ind)
   #monsys=knit.rectangle([1,1],[x,y],t,Hd)
   for m in range(m_max):
      ind+=1
      move_one_site(-1,m+1,'B',t,Hd,monsys,ind,x,y)
      ind+=1
      move_one_site(0,m+1,'A',t,Hd,monsys,ind,x,y)
   for n in range(n_max):
      for m in range(m_max+1):
         ind+=1
         move_one_site(n,m,'B',t,Hd,monsys,ind,x,y)
      for m in range(m_max):
         ind+=1
         move_one_site(n+1,m,'A',t,Hd,monsys,ind,x,y)
      if n+1 != n_max:
         ind+=1
         move_one_site(n+1,m_max,'A',t,Hd,monsys,ind,x,y)
   return monsys


# Zigzag for left or right lead 
def ZigzagLeadLR(n,m_min,m_max,Init_xy,t,Hd,LR):
   #LR = O : Left lead , LR=1 : Right lead
   if LR=="RIGHT": LR=1
   if LR=="LEFT": LR=0
   x,y=Init_xy
   X,Y=XY(n,m_min,LR)
   monsys=knit.rectangle([1,1],[x+X,y+Y],t,Hd)
   for m in range(m_min+1,m_max+1):add_one_site(n,m,LR,t,Hd,monsys,x,y)
   for m in range(m_min,m_max+1):add_one_site(n,m,1-LR,t,Hd,monsys,x,y)
   a=knit.unreservoirN(monsys,knit.scalarM(0.),0.)
   L=m_max-m_min+1
   for i in range(L):
      a.put_leadHopp(i,i+L,t)
   for i in range(L-1):
      a.put_leadHopp(i+LR,i+L+1-LR,t)
   # The following is not really cool......   
   for i in range(L):a.put_leadHopp(i+L,i,knit.scalarM(1.e-5))
   return a

#####################################################################
#                                                                   #
# NOW WE ARE GOING TO DO A SIMPLE CALCULATION FOR A RIBBON          #
#                                                                   #
#####################################################################

t=knit.scalarM(1.)
Hd=knit.scalarM(0.)

print "USAGE: python simple_graphene.py 5 10"
print "to calculate a ribbon with 5x10 hexagons (width X length) "
M=7
if len(sys.argv)>1 : M=int(sys.argv[1]) 
N=5
if len(sys.argv)>2 : N=int(sys.argv[2])


a=ZigzagLR([N,M],[0,0],t,Hd)
add_one_site(N,M,'A',t,Hd,a)
add_one_site(-1,0,'B',t,Hd,a)
lead0=ZigzagLeadLR(-1,0,M,[0,0],t,Hd,"LEFT")
monsys=knit.systemtotal(a,lead0)
lead1=ZigzagLeadLR(N,0,M,[0,0],t,Hd,"RIGHT")
monsys.addlead(lead1)

import os
forvisu=sys.argv[0]+".systeme"
system.visu2D(monsys,forvisu)
os.system("gv  "+forvisu+".eps & ")

MYDATA=[]
Ndata=101
for i in range(Ndata):
     E= 3.5*((float(i)/Ndata)*2.-1.001)
     G_MATRIX=obs.conductance_matrix(monsys,E)
     MYDATA.append([E,G_MATRIX[0,1]  ])
     print E,G_MATRIX[0,1]


from pyx import *

g =graph.graphxy(width=20,x=graph.axis.linear(title="$E$"),y=graph.axis.linear(title="$G$"))
g.plot(graph.data.list(MYDATA,x=1,y=2))

forplot=sys.argv[0]+".res_new"+str(M)+"X"+str(N)
g.writeEPSfile(forplot)
g.writePDFfile(forplot)
os.system("gv "+forplot+".eps & ")
